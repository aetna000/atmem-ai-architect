# WCS web server

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Shared WCS deployment serves decanting, picking, clearing, packing, returns, stock counts and supervisor screens over HTTPS. Enforces server-side permissions and passes authorised actions to Core, which runs in the same deployment. Presents workflow state, equipment status and RFID discrepancies, and collects physical-check confirmations or authorised overrides. Hosting remains open.

Authorize against workstation and user before invoking Core; derive current workflow context server-side

## Decomposition

Parent: System

- [Decanting workstation](../block-646563616e742d776f726b73746174696f6e/spec.md)
- [Picking workstation](../block-7069636b696e672d776f726b73746174696f6e/spec.md)
- [WCS execution records](../block-7763732d7374617465/spec.md)
- [Clearing workstation](../block-636c656172696e672d776f726b73746174696f6e/spec.md)
- [Host integration gateway](../block-686f73742d67617465776179/spec.md)
- [Packing workstation](../block-7061636b696e672d776f726b73746174696f6e/spec.md)
- [Supervisor console](../block-73757065727669736f722d636f6e736f6c65/spec.md)
- [Core](../block-7763732d636f7265/spec.md)

## Inputs and preconditions

Authorised workstation request with configured workstation identity and workflow stage

## Outputs and postconditions

Workflow state, validation response and accepted action reference

## Boundaries

- decant-wcs · Decanting workstation → WCS web server · HTTPS decanting screen and load confirmations
- pick-wcs · Picking workstation → WCS web server · HTTPS picking screen and pick confirmations
- clearing-wcs · Clearing workstation → WCS web server · Clearing tasks, reject parcel identification and operator confirmations
- packing-wcs · Packing workstation → WCS web server · HTTPS packing screen, package confirmations and label requests
- manual-consolidation-wcs · Manual consolidation and re-induction → WCS web server · Partial-pick handoff and WMS-authorised tote re-induction
- returns-counting-wcs · Returns and stock counts → WCS web server · Returns induction, stock counts and workstation mode changes
- supervisor-wcs · Supervisor console → WCS web server · Operational status and authorised supervisory actions
- wcs-core-actions · WCS web server → Core · Authorised workstation actions in, tasks and outcomes back

## Failure and recovery

Disconnect after submission must reload the persisted step before retry

## Implementation

Implement or integrate this responsibility against its linked requirements. Authorize against workstation and user before invoking Core; derive current workflow context server-side Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-workstation-flows · Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.
- ai-wcs-airrob-control · Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.
- ai-wcs-host-json · Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.
- ai-wcs-kiosk-web · Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.
- ai-wcs-conveyor-coordination · Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.
- ai-wcs-rfid-validation · Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.
- ai-wcs-supervisor-operations · Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

Tasks: TASK-CONTRACT-646563616e742d776373, TASK-CONTRACT-7069636b2d776373, TASK-CONTRACT-636c656172696e672d776373, TASK-CONTRACT-7061636b696e672d776373, TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-CONTRACT-72657475726e732d636f756e74696e672d776373, TASK-CONTRACT-73757065727669736f722d776373, TASK-CONTRACT-7763732d636f72652d616374696f6e73, TASK-RESOURCE-776373, TASK-INTEGRATION-646563616e742d776373, TASK-INTEGRATION-7069636b2d776373, TASK-INTEGRATION-636c656172696e672d776373, TASK-INTEGRATION-7061636b696e672d776373, TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-73757065727669736f722d776373, TASK-INTEGRATION-7763732d636f72652d616374696f6e73, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73, TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773, TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c, TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e, TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562, TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e, TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e, TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73

- wcs-discovery-8 · Where must WCS run, and what availability, recovery and site-network constraints apply?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
