# WCS web server scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to WCS web server #8212; Authorised workstation request with configured workstation identity and workflow stage"]
  step1["WCS web server to WCS web server #8212; Authorize against workstation and user before invoking Core#59; derive current workflow context server-side"]
  step2["WCS web server to Calling workflow #8212; Workflow state, validation response and accepted action reference"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as WCS web server
  actor0->>actor1: Authorised workstation request with configured workstation identity and workflow stage
  actor1->>actor1: Authorize against workstation and user before invoking Core#59; derive current workflow context server-side
  actor1->>actor0: Workflow state, validation response and accepted action reference
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["WCS web server to WCS web server #8212; Disconnect after submission must reload the persisted step before retry"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as WCS web server
  actor0->>actor0: Disconnect after submission must reload the persisted step before retry
```
