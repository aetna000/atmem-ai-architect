# WCS web server infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Single HTTPS server for Core and kiosk routes

## CI, release and operations

Build one immutable release. Verify route permissions and stage each kiosk mode before cutover.
