# Conveyor controller acceptance tests

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Inject fault before arrival; no completion occurs until correlated evidence resolves the hold.

Record the test environment, command, input, expected result and observed evidence. Execution status: pending.
