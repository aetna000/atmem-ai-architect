# Conveyor controller infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Site control equipment boundary. Confirm ownership, fixtures and supported interface.

## CI, release and operations

Qualify routing simulator before controlled site testing with the controller owner.
