# Conveyor controller scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Conveyor controller #8212; Routing request with tote and correlation reference"]
  step1["Conveyor controller to Conveyor controller #8212; Define the site protocol. Site PLC#47;controller owns motion, interlocks and emergency stops."]
  step2["Conveyor controller to Calling workflow #8212; Observed arrival, equipment status or fault"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Conveyor controller
  actor0->>actor1: Routing request with tote and correlation reference
  actor1->>actor1: Define the site protocol. Site PLC#47;controller owns motion, interlocks and emergency stops.
  actor1->>actor0: Observed arrival, equipment status or fault
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Conveyor controller to Conveyor controller #8212; Hold work on ambiguous route outcome until reconciled"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Conveyor controller
  actor0->>actor0: Hold work on ambiguous route outcome until reconciled
```
