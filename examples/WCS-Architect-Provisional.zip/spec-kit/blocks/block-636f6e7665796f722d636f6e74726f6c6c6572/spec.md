# Conveyor controller

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Proposed site equipment integration boundary. The WCS requests routing and consumes arrival, availability and fault events through a supported interface. The controller owns motion, interlocks and emergency stops. Controller product, ownership, interface and recovery behaviour remain open.

Define the site protocol. Site PLC/controller owns motion, interlocks and emergency stops.

## Decomposition

Parent: System

None recorded.

## Inputs and preconditions

Routing request with tote and correlation reference

## Outputs and postconditions

Observed arrival, equipment status or fault

## Boundaries

- wcs-conveyor · Core → Conveyor controller · Tote routes to manual packing or auto-bagging, arrivals and faults

### Proposed interface wcs-conveyor

#### Transport and version

Controller-specific site protocol and equipment map open.

#### Request or event

Tote route request with destination and task correlation.

#### Response or result

Supported arrival and correlated controller fault states.

#### Identity and authority

Use a site-approved interop identity. Motion, interlocks and emergency stops remain with the controller.

#### Failure and retry

Hold work on a fault or uncertain path pending reconciliation.

#### Contract tests

Simulate arrival out of order and a fault before an arrival. Ensure only the correct task can advance.

## Failure and recovery

Hold work on ambiguous route outcome until reconciled

## Implementation

Implement or integrate this responsibility against its linked requirements. Define the site protocol. Site PLC/controller owns motion, interlocks and emergency stops. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-conveyor-coordination · Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.
- ai-wcs-manual-handoff · Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.
- ai-wcs-outbound-sortation · Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.
- ai-wcs-durable-recovery · Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Tasks: TASK-CONTRACT-7763732d636f6e7665796f72, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-INTEGRATION-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e, TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666, TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e, TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
