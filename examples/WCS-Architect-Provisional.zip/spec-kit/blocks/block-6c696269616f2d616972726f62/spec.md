# Libiao AirRob controller

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

External vendor control boundary for AirRob. Proposed exchange sends tote transport jobs and receives job status and faults. Site-specific interface, job identifiers and recovery behavior need vendor evidence.

WCS requests tote jobs; AirRob controller retains execution ownership.

## Decomposition

Parent: System

None recorded.

## Inputs and preconditions

Correlated transport job via agreed site adapter

## Outputs and postconditions

Supported job reference, status and fault reports

## Boundaries

- wcs-airrob · Core → Libiao AirRob controller · Tote move jobs out, status and faults in

### Proposed interface wcs-airrob

#### Transport and version

Site-supported AirRob interface. Await vendor protocol, version and simulator.

#### Request or event

Proposed canonical request includes a tote, destination and correlation. Map only supported fields to the vendor protocol.

#### Response or result

Job identifier, correlated state and faults where supported.

#### Identity and authority

Limit adapter access to the approved controller and operations. The site controller retains motion and safety authority.

#### Failure and retry

Hold unknown submission outcomes and use supported lookup or authorised reconciliation before retry.

#### Contract tests

Simulate accepted moves with lost acknowledgements, late status and faults. Confirm site behavior with approved equipment tests.

## Failure and recovery

On missing response mark outcome unknown; use approved status lookup or site operator reconciliation before another job

## Implementation

Implement or integrate this responsibility against its linked requirements. WCS requests tote jobs; AirRob controller retains execution ownership. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-airrob-control · Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.
- ai-wcs-conveyor-coordination · Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.
- ai-wcs-durable-recovery · Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Tasks: TASK-CONTRACT-7763732d616972726f62, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-INTEGRATION-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c, TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e, TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

- wcs-discovery-3 · Which AirRob interface and job status lookup does the site support, and who can supply its official contract and simulator?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
