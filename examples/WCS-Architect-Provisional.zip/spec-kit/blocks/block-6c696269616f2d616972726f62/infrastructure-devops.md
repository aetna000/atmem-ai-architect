# Libiao AirRob controller infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Existing controller and site network boundary. Obtain interface and simulator evidence.

## CI, release and operations

Agree controlled commissioning with site owner. Exercise disconnect and restart with simulator first.
