# Libiao AirRob controller scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Libiao AirRob controller #8212; Correlated transport job via agreed site adapter"]
  step1["Libiao AirRob controller to Libiao AirRob controller #8212; WCS requests tote jobs#59; AirRob controller retains execution ownership."]
  step2["Libiao AirRob controller to Calling workflow #8212; Supported job reference, status and fault reports"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Libiao AirRob controller
  actor0->>actor1: Correlated transport job via agreed site adapter
  actor1->>actor1: WCS requests tote jobs#59; AirRob controller retains execution ownership.
  actor1->>actor0: Supported job reference, status and fault reports
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Libiao AirRob controller to Libiao AirRob controller #8212; On missing response mark outcome unknown#59; use approved status lookup or site operator reconciliation before another job"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Libiao AirRob controller
  actor0->>actor0: On missing response mark outcome unknown#59; use approved status lookup or site operator reconciliation before another job
```
