# Picking workstation infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Kiosk route within the shared WCS server.

## CI, release and operations

CI covers partial picks and adjusted compartment contents; verify station interactions in site acceptance.
