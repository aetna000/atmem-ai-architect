# Picking workstation

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Kiosk screen within the shared WCS deployment. Show the pick task when the expected tote is available, including the relevant compartment. Record quantity picked and shortages. Where RFID is enabled, show read discrepancies and require physical checking and operator confirmation or an authorised override before committing the outcome.

Show pick only for ready tote; persist compartment-specific outcomes through Core.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Ready tote, pick task, compartment and expected items

## Outputs and postconditions

Confirmed quantity, shortage or recorded discrepancy

## Boundaries

- pick-wcs · Picking workstation → WCS web server · HTTPS picking screen and pick confirmations

## Failure and recovery

Unexpected tote, expired task or RFID mismatch cannot silently complete pick

## Implementation

Implement or integrate this responsibility against its linked requirements. Show pick only for ready tote; persist compartment-specific outcomes through Core. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-workstation-flows · Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.
- ai-wcs-kiosk-web · Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.
- ai-wcs-order-planning · Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.
- ai-wcs-rfid-validation · Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.
- ai-wcs-returns-count-modes · Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.

Tasks: TASK-CONTRACT-7069636b2d776373, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-INTEGRATION-7069636b2d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773, TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562, TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67, TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e, TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
