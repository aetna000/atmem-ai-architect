# Picking workstation scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Picking workstation #8212; Ready tote, pick task, compartment and expected items"]
  step1["Picking workstation to Picking workstation #8212; Show pick only for ready tote#59; persist compartment-specific outcomes through Core."]
  step2["Picking workstation to Calling workflow #8212; Confirmed quantity, shortage or recorded discrepancy"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Picking workstation
  actor0->>actor1: Ready tote, pick task, compartment and expected items
  actor1->>actor1: Show pick only for ready tote#59; persist compartment-specific outcomes through Core.
  actor1->>actor0: Confirmed quantity, shortage or recorded discrepancy
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Picking workstation to Picking workstation #8212; Unexpected tote, expired task or RFID mismatch cannot silently complete pick"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Picking workstation
  actor0->>actor0: Unexpected tote, expired task or RFID mismatch cannot silently complete pick
```
