> Provisional WCS design derived from the exported project. The original customer document was unavailable. Requirements and proposed contracts require source review before implementation; no WCS code or commissioning evidence is included.

# Component Spec Kits

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

- [WCS web server](block-776373/spec.md)
  - [Decanting workstation](block-646563616e742d776f726b73746174696f6e/spec.md)
  - [Picking workstation](block-7069636b696e672d776f726b73746174696f6e/spec.md)
  - [WCS execution records](block-7763732d7374617465/spec.md)
  - [Clearing workstation](block-636c656172696e672d776f726b73746174696f6e/spec.md)
  - [Host integration gateway](block-686f73742d67617465776179/spec.md)
  - [Packing workstation](block-7061636b696e672d776f726b73746174696f6e/spec.md)
  - [Supervisor console](block-73757065727669736f722d636f6e736f6c65/spec.md)
  - [Core](block-7763732d636f7265/spec.md)
    - [Order planning](block-6f726465722d706c616e6e696e67/spec.md)
    - [Local stock tracking](block-7763732d6c6f63616c2d73746f636b/spec.md)
    - [Manual consolidation and re-induction](block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md)
    - [Returns and stock counts](block-72657475726e732d636f756e74696e67/spec.md)
- [Warehouse host system](block-77617265686f7573652d686f7374/spec.md)
- [Libiao AirRob controller](block-6c696269616f2d616972726f62/spec.md)
- [Conveyor controller](block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md)
- [Packing label printers](block-7061636b696e672d7072696e74657273/spec.md)
- [RFID readers](block-726669642d72656164657273/spec.md)
- [Auto-bagging equipment](block-6175746f2d62616767696e67/spec.md)
- [Outbound sortation](block-6f7574626f756e642d736f72746174696f6e/spec.md)
