# WCS execution records

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

WCS-owned durable store for order plans, task progress, local stock by SKU and tote, host and equipment identifiers, package and label jobs, operator confirmations, RFID mismatch evidence and supervisor audit records. Reconcile uncertain host, motion or print outcomes before retrying. Retain decisions by authorised operators. Storage technology remains open.

Store quantities, package associations, equipment references and append-only resolution history. Use conditional writes for transitions.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Task transition, correlation keys and audit identity

## Outputs and postconditions

Committed task state, effect references and recoverable history

## Boundaries

- wcs-records · Core → WCS execution records · Save and recover orders, tasks, packages and equipment jobs
- local-stock-records · Local stock tracking → WCS execution records · Save stock by SKU and tote and record reason-coded changes

## Failure and recovery

Preserve unknown outcomes across restart and restore

## Implementation

Implement or integrate this responsibility against its linked requirements. Store quantities, package associations, equipment references and append-only resolution history. Use conditional writes for transitions. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-airrob-control · Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.
- ai-wcs-host-json · Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.
- ai-wcs-order-planning · Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.
- ai-wcs-conveyor-coordination · Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.
- ai-wcs-local-stock · Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.
- ai-wcs-rfid-validation · Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.
- ai-wcs-outbound-sortation · Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.
- ai-wcs-supervisor-operations · Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.
- ai-wcs-durable-recovery · Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Tasks: TASK-CONTRACT-7763732d7265636f726473, TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473, TASK-RESOURCE-7763732d7374617465, TASK-INTEGRATION-7763732d7265636f726473, TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c, TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e, TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67, TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e, TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b, TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e, TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e, TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73, TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
