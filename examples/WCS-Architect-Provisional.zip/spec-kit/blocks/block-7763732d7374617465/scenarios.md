# WCS execution records scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to WCS execution records #8212; Task transition, correlation keys and audit identity"]
  step1["WCS execution records to WCS execution records #8212; Store quantities, package associations, equipment references and append-only resolution history. Use conditional writes for transitions."]
  step2["WCS execution records to Calling workflow #8212; Committed task state, effect references and recoverable history"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as WCS execution records
  actor0->>actor1: Task transition, correlation keys and audit identity
  actor1->>actor1: Store quantities, package associations, equipment references and append-only resolution history. Use conditional writes for transitions.
  actor1->>actor0: Committed task state, effect references and recoverable history
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["WCS execution records to WCS execution records #8212; Preserve unknown outcomes across restart and restore"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as WCS execution records
  actor0->>actor0: Preserve unknown outcomes across restart and restore
```
