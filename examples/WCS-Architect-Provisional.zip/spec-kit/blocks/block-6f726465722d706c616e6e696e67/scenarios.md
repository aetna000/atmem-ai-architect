# Order planning scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Order planning #8212; WMS start#47;cancel, ready stock, priorities, finishing time and escalation rules"]
  step1["Order planning to Order planning #8212; Define an atomic planning boundary. Preserve each order#47;item in batches and audit authorised overrides."]
  step2["Order planning to Calling workflow #8212; Tote#47;compartment assignments, milestone records or cancellation decision"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Order planning
  actor0->>actor1: WMS start#47;cancel, ready stock, priorities, finishing time and escalation rules
  actor1->>actor1: Define an atomic planning boundary. Preserve each order#47;item in batches and audit authorised overrides.
  actor1->>actor0: Tote#47;compartment assignments, milestone records or cancellation decision
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Order planning to Order planning #8212; Reject calls outside their valid state#59; persist delays and shortages"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Order planning
  actor0->>actor0: Reject calls outside their valid state#59; persist delays and shortages
```
