# Order planning

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Module within the WCS application. Plans internal work from WMS start instructions using agreed priorities, finishing times and readiness rules. Accepts cancellation only before planning begins. Batches eligible single-SKU single-item orders under configurable rules and preserves order and item identity against each tote compartment. Audits operator overrides and emits planning-started, picked and execution-completed outcomes through the gateway. Stock allocation rules and batching thresholds remain open.

Define an atomic planning boundary. Preserve each order/item in batches and audit authorised overrides.

## Decomposition

Parent: Core

None recorded.

## Inputs and preconditions

WMS start/cancel, ready stock, priorities, finishing time and escalation rules

## Outputs and postconditions

Tote/compartment assignments, milestone records or cancellation decision

## Boundaries

- wcs-order-planning · Core → Order planning · Accepted orders and progress in, planned tasks out

## Failure and recovery

Reject calls outside their valid state; persist delays and shortages

## Implementation

Implement or integrate this responsibility against its linked requirements. Define an atomic planning boundary. Preserve each order/item in batches and audit authorised overrides. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-order-planning · Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.
- ai-wcs-packing-labels · Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.
- ai-wcs-supervisor-operations · Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

Tasks: TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67, TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73, TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73

- wcs-discovery-5 · Which priority, readiness, batching and finishing-time rules are required at launch?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
