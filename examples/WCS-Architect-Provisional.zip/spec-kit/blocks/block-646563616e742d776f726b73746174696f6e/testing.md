# Decanting workstation acceptance tests

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

RFID read is short by one; verify stock is unchanged before authorised resolution.

Record the test environment, command, input, expected result and observed evidence. Execution status: pending.
