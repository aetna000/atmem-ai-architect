# Decanting workstation

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Kiosk screen within the shared WCS deployment. Operators identify the inbound item and destination tote, confirm the loaded quantity and flag discrepancies. Where RFID is enabled, display expected and read quantities and require physical checking and an operator confirmation or authorised override before committing a mismatch.

Validate on-screen quantities and require physical check or authorised override if RFID disagrees.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Inbound SKU, quantity, destination tote and assigned workstation

## Outputs and postconditions

Confirmed tote load or discrepancy with audit record

## Boundaries

- decant-wcs · Decanting workstation → WCS web server · HTTPS decanting screen and load confirmations

## Failure and recovery

Retain discrepancy before changing stock; stale screen forces reread

## Implementation

Implement or integrate this responsibility against its linked requirements. Validate on-screen quantities and require physical check or authorised override if RFID disagrees. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-workstation-flows · Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.
- ai-wcs-kiosk-web · Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.
- ai-wcs-rfid-validation · Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.

Tasks: TASK-CONTRACT-646563616e742d776373, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-INTEGRATION-646563616e742d776373, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773, TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562, TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
