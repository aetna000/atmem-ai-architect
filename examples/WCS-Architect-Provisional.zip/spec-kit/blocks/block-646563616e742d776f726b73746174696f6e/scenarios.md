# Decanting workstation scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Decanting workstation #8212; Inbound SKU, quantity, destination tote and assigned workstation"]
  step1["Decanting workstation to Decanting workstation #8212; Validate on-screen quantities and require physical check or authorised override if RFID disagrees."]
  step2["Decanting workstation to Calling workflow #8212; Confirmed tote load or discrepancy with audit record"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Decanting workstation
  actor0->>actor1: Inbound SKU, quantity, destination tote and assigned workstation
  actor1->>actor1: Validate on-screen quantities and require physical check or authorised override if RFID disagrees.
  actor1->>actor0: Confirmed tote load or discrepancy with audit record
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Decanting workstation to Decanting workstation #8212; Retain discrepancy before changing stock#59; stale screen forces reread"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Decanting workstation
  actor0->>actor0: Retain discrepancy before changing stock#59; stale screen forces reread
```
