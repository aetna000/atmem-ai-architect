# Local stock tracking scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Local stock tracking #8212; Confirmed quantity deltas, SKU retirement request and snapshot request"]
  step1["Local stock tracking to Local stock tracking #8212; Apply confirmed movements once. Retire only after stock and references clear. Keep location out of snapshot."]
  step2["Local stock tracking to Calling workflow #8212; Local tote#47;SKU state, coded deltas and standstill aggregate"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Local stock tracking
  actor0->>actor1: Confirmed quantity deltas, SKU retirement request and snapshot request
  actor1->>actor1: Apply confirmed movements once. Retire only after stock and references clear. Keep location out of snapshot.
  actor1->>actor0: Local tote#47;SKU state, coded deltas and standstill aggregate
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Local stock tracking to Local stock tracking #8212; Reject inconsistent changes#59; put discrepancies into reconciliation"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Local stock tracking
  actor0->>actor0: Reject inconsistent changes#59; put discrepancies into reconciliation
```
