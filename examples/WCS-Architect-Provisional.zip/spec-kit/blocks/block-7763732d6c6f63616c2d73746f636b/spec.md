# Local stock tracking

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Module within the shared WCS application. Tracks stock by SKU, stock properties and tote using WCS execution records. Reports exceptional quantity deltas with reason codes and returns WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Acknowledges SKU retirement once stock and order references clear. Temporary unavailability stays local. Its treatment in snapshots remains open. WMS owns warehouse-wide inventory and SKU master data.

Apply confirmed movements once. Retire only after stock and references clear. Keep location out of snapshot.

## Decomposition

Parent: Core

None recorded.

## Inputs and preconditions

Confirmed quantity deltas, SKU retirement request and snapshot request

## Outputs and postconditions

Local tote/SKU state, coded deltas and standstill aggregate

## Boundaries

- wcs-local-stock-flow · Core → Local stock tracking · Confirmed stock changes, availability and snapshot requests
- local-stock-records · Local stock tracking → WCS execution records · Save stock by SKU and tote and record reason-coded changes

## Failure and recovery

Reject inconsistent changes; put discrepancies into reconciliation

## Implementation

Implement or integrate this responsibility against its linked requirements. Apply confirmed movements once. Retire only after stock and references clear. Keep location out of snapshot. Add executable acceptance cases before enabling downstream integration.

## Traceability

None recorded.

Tasks: TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473, TASK-RESOURCE-7763732d6c6f63616c2d73746f636b, TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473

- wcs-discovery-6 · How should temporary stock unavailability appear in a standstill snapshot?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
