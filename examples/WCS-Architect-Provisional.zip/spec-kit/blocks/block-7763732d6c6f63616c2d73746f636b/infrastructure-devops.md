# Local stock tracking infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Logical module in WCS with durable stock records. WMS retains master inventory.

## CI, release and operations

Test replay, concurrent allocation, retirement and representative standstill snapshots.
