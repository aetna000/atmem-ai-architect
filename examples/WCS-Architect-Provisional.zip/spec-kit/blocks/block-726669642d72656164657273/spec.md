# RFID readers

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Proposed on-site reader equipment at RFID-enabled workstations. Supply tagged-item observations and reader health to WCS with enough context to associate each read with the correct workstation and task. Qualify tag-to-SKU identification, reader placement, read stability and filtering of nearby tags with real totes. Reader model, exact locations, interface and ownership remain open. WCS owns validation and the manual fallback.

Qualify near-tag filtering, reader spacing, stability and tag-to-SKU attribution. Core owns discrepancy policy.

## Decomposition

Parent: System

None recorded.

## Inputs and preconditions

Read session, reader, workstation and task context

## Outputs and postconditions

Timestamped tag observations and reader health where supported

## Boundaries

- rfid-wcs · RFID readers → Core · Tag reads and reader faults for workstation checks

## Failure and recovery

Unhealthy or unreliable reader goes to physical validation

## Implementation

Implement or integrate this responsibility against its linked requirements. Qualify near-tag filtering, reader spacing, stability and tag-to-SKU attribution. Core owns discrepancy policy. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-rfid-validation · Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.

Tasks: TASK-CONTRACT-726669642d776373, TASK-RESOURCE-726669642d72656164657273, TASK-INTEGRATION-726669642d776373, TASK-INTEGRATION-LIVE-726669642d776373, TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
