# RFID readers scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to RFID readers #8212; Read session, reader, workstation and task context"]
  step1["RFID readers to RFID readers #8212; Qualify near-tag filtering, reader spacing, stability and tag-to-SKU attribution. Core owns discrepancy policy."]
  step2["RFID readers to Calling workflow #8212; Timestamped tag observations and reader health where supported"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as RFID readers
  actor0->>actor1: Read session, reader, workstation and task context
  actor1->>actor1: Qualify near-tag filtering, reader spacing, stability and tag-to-SKU attribution. Core owns discrepancy policy.
  actor1->>actor0: Timestamped tag observations and reader health where supported
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["RFID readers to RFID readers #8212; Unhealthy or unreliable reader goes to physical validation"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as RFID readers
  actor0->>actor0: Unhealthy or unreliable reader goes to physical validation
```
