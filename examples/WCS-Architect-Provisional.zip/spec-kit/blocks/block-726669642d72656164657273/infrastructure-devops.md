# RFID readers infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Site reader equipment. Models, placements, identities and driver contracts open.

## CI, release and operations

Use simulated results in CI. Measure nearby-tag contamination and repeatability at each approved station.
