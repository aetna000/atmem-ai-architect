# Warehouse host system

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Existing warehouse management system (WMS). Owns warehouse-wide inventory and SKU master data. Exchanges JSON work requests, direct transport orders, execution outcomes and exceptions through the host gateway. Receives exceptional stock deltas, manual-consolidation handoffs and requested standstill snapshots, and provides shipping label data for packing. Product, schemas and transport remain open.

WMS owns inventory totals and SKU master. Preserve its external ownership.

## Decomposition

Parent: System

None recorded.

## Inputs and preconditions

Gateway outcomes, snapshots and exceptions

## Outputs and postconditions

WMS work instructions, label data and SKU master changes

## Boundaries

- wcs-host · Host integration gateway → Warehouse host system · Host JSON requests in, results and exceptions out

### Proposed interface wcs-host

#### Transport and version

Host-facing JSON. Site transport, schema and version open pending WMS documentation.

#### Request or event

Inbound work, cancellation, SKU changes, direct transport, snapshot requests and label data. Derive exact payloads from the host specification.

#### Response or result

Correlated milestones, results, exceptions, deltas, handoff and snapshot outcomes. Acknowledgement semantics open.

#### Identity and authority

Approve a warehouse-host identity and gateway permissions with the WMS owner.

#### Failure and retry

Persist stable request/result identities. Reconcile unknown acknowledgement before replay.

#### Contract tests

Replay duplicate start/cancel messages. Verify one recorded transition and recover an uncertain outbound response.

## Failure and recovery

Define authoritative acknowledgement and lookup with WMS owner

## Implementation

Implement or integrate this responsibility against its linked requirements. WMS owns inventory totals and SKU master. Preserve its external ownership. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-host-json · Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.
- ai-wcs-local-stock · Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.
- ai-wcs-manual-handoff · Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.

Tasks: TASK-CONTRACT-7763732d686f7374, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-INTEGRATION-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e, TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b, TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
