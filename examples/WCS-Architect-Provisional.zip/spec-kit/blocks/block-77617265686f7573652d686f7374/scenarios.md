# Warehouse host system scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Warehouse host system #8212; Gateway outcomes, snapshots and exceptions"]
  step1["Warehouse host system to Warehouse host system #8212; WMS owns inventory totals and SKU master. Preserve its external ownership."]
  step2["Warehouse host system to Calling workflow #8212; WMS work instructions, label data and SKU master changes"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Warehouse host system
  actor0->>actor1: Gateway outcomes, snapshots and exceptions
  actor1->>actor1: WMS owns inventory totals and SKU master. Preserve its external ownership.
  actor1->>actor0: WMS work instructions, label data and SKU master changes
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Warehouse host system to Warehouse host system #8212; Define authoritative acknowledgement and lookup with WMS owner"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Warehouse host system
  actor0->>actor0: Define authoritative acknowledgement and lookup with WMS owner
```
