# Packing label printers scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Packing label printers #8212; Label bytes#47;reference and package-linked print intent"]
  step1["Packing label printers to Packing label printers #8212; Send only authorised label jobs. Treat actual print feedback as available only after protocol qualification."]
  step2["Packing label printers to Calling workflow #8212; Supported acknowledgement, confirmed output or uncertainty"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Packing label printers
  actor0->>actor1: Label bytes#47;reference and package-linked print intent
  actor1->>actor1: Send only authorised label jobs. Treat actual print feedback as available only after protocol qualification.
  actor1->>actor0: Supported acknowledgement, confirmed output or uncertainty
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Packing label printers to Packing label printers #8212; Keep uncertain status and original reference pending physical check"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Packing label printers
  actor0->>actor0: Keep uncertain status and original reference pending physical check
```
