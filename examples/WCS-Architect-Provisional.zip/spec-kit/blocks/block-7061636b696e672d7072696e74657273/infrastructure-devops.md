# Packing label printers infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Site printer boundary; label formats, models and network access open.

## CI, release and operations

Check supported format and test approved label stock and scanner readability at site.
