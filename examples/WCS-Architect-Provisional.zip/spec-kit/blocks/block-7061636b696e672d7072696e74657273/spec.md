# Packing label printers

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Proposed site print integration boundary for packing stations. The WCS sends package-linked label jobs and records job acknowledgements or faults where supported. The packing screen shows uncertain outcomes and supports controlled reprints. Printer ownership, interface, label formats and status capabilities remain open.

Send only authorised label jobs. Treat actual print feedback as available only after protocol qualification.

## Decomposition

Parent: System

None recorded.

## Inputs and preconditions

Label bytes/reference and package-linked print intent

## Outputs and postconditions

Supported acknowledgement, confirmed output or uncertainty

## Boundaries

- wcs-packing-printers · Core → Packing label printers · Package label jobs out, available status and faults in

### Proposed interface wcs-packing-printers

#### Transport and version

Printer model, job protocol and WMS label format open.

#### Request or event

Package-linked label job using the WMS-supplied label.

#### Response or result

Supported acknowledgement or explicit unknown outcome.

#### Identity and authority

Limit job submission to packing. Authorised reprints capture the actor and reason.

#### Failure and retry

Query supported job state or reconcile physically before authorised reprint.

#### Contract tests

Simulate printer acceptance followed by timeout, then force authorised reprint with a reason. Verify both events remain auditable.

## Failure and recovery

Keep uncertain status and original reference pending physical check

## Implementation

Implement or integrate this responsibility against its linked requirements. Send only authorised label jobs. Treat actual print feedback as available only after protocol qualification. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-packing-labels · Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.
- ai-wcs-durable-recovery · Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Tasks: TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273, TASK-RESOURCE-7061636b696e672d7072696e74657273, TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273, TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73, TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
