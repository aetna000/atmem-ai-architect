# Core

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Business logic module within the shared WCS web server deployment. Owns order planning, task and workflow state, local stock tracking, RFID validation and manual discrepancy resolution, returns, counting, manual consolidation and re-induction, packing and label rules, outbound sortation and supervisor actions. Coordinates AirRob tote moves, conveyor routing, auto-bagging, printing and sorter operations through site interfaces. Equipment controllers retain motion and safety control. Persists execution and audit records, reconciles uncertain outcomes before retrying, and exchanges work, results and exceptions with the WMS through the host gateway.

Coordinate task lifecycle and persist transition with its side-effect intent; advance only on accepted outcome

## Decomposition

Parent: WCS web server

- [Order planning](../block-6f726465722d706c616e6e696e67/spec.md)
- [Local stock tracking](../block-7763732d6c6f63616c2d73746f636b/spec.md)
- [Manual consolidation and re-induction](../block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md)
- [Returns and stock counts](../block-72657475726e732d636f756e74696e67/spec.md)

## Inputs and preconditions

Authorised operator action or versioned gateway message with correlation ID

## Outputs and postconditions

Durable task transition and pending side effects

## Boundaries

- wcs-airrob · Core → Libiao AirRob controller · Tote move jobs out, status and faults in
- wcs-records · Core → WCS execution records · Save and recover orders, tasks, packages and equipment jobs
- wcs-host-gateway · Core → Host integration gateway · Validated work requests in, results and exceptions out
- wcs-order-planning · Core → Order planning · Accepted orders and progress in, planned tasks out
- wcs-conveyor · Core → Conveyor controller · Tote routes to manual packing or auto-bagging, arrivals and faults
- wcs-packing-printers · Core → Packing label printers · Package label jobs out, available status and faults in
- rfid-wcs · RFID readers → Core · Tag reads and reader faults for workstation checks
- wcs-local-stock-flow · Core → Local stock tracking · Confirmed stock changes, availability and snapshot requests
- wcs-auto-bagging · Core → Auto-bagging equipment · Eligible packing work, package outcomes and equipment faults
- wcs-outbound-sortation · Core → Outbound sortation · Shipping label and chute mapping, route and reject feedback
- wcs-core-actions · WCS web server → Core · Authorised workstation actions in, tasks and outcomes back

### Proposed interface wcs-airrob

#### Transport and version

Site-supported AirRob interface. Await vendor protocol, version and simulator.

#### Request or event

Proposed canonical request includes a tote, destination and correlation. Map only supported fields to the vendor protocol.

#### Response or result

Job identifier, correlated state and faults where supported.

#### Identity and authority

Limit adapter access to the approved controller and operations. The site controller retains motion and safety authority.

#### Failure and retry

Hold unknown submission outcomes and use supported lookup or authorised reconciliation before retry.

#### Contract tests

Simulate accepted moves with lost acknowledgements, late status and faults. Confirm site behavior with approved equipment tests.

### Proposed interface wcs-conveyor

#### Transport and version

Controller-specific site protocol and equipment map open.

#### Request or event

Tote route request with destination and task correlation.

#### Response or result

Supported arrival and correlated controller fault states.

#### Identity and authority

Use a site-approved interop identity. Motion, interlocks and emergency stops remain with the controller.

#### Failure and retry

Hold work on a fault or uncertain path pending reconciliation.

#### Contract tests

Simulate arrival out of order and a fault before an arrival. Ensure only the correct task can advance.

### Proposed interface wcs-packing-printers

#### Transport and version

Printer model, job protocol and WMS label format open.

#### Request or event

Package-linked label job using the WMS-supplied label.

#### Response or result

Supported acknowledgement or explicit unknown outcome.

#### Identity and authority

Limit job submission to packing. Authorised reprints capture the actor and reason.

#### Failure and retry

Query supported job state or reconcile physically before authorised reprint.

#### Contract tests

Simulate printer acceptance followed by timeout, then force authorised reprint with a reason. Verify both events remain auditable.

## Failure and recovery

After missing acknowledgement hold the task for reconciliation, then resume or escalate

## Implementation

Implement or integrate this responsibility against its linked requirements. Coordinate task lifecycle and persist transition with its side-effect intent; advance only on accepted outcome Add executable acceptance cases before enabling downstream integration.

## Traceability

None recorded.

Tasks: TASK-CONTRACT-7763732d616972726f62, TASK-CONTRACT-7763732d7265636f726473, TASK-CONTRACT-7763732d686f73742d67617465776179, TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67, TASK-CONTRACT-7763732d636f6e7665796f72, TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273, TASK-CONTRACT-726669642d776373, TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-CONTRACT-7763732d6175746f2d62616767696e67, TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e, TASK-CONTRACT-7763732d636f72652d616374696f6e73, TASK-RESOURCE-7763732d636f7265, TASK-INTEGRATION-7763732d616972726f62, TASK-INTEGRATION-7763732d7265636f726473, TASK-INTEGRATION-7763732d686f73742d67617465776179, TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-7763732d636f6e7665796f72, TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-726669642d776373, TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-7763732d6175746f2d62616767696e67, TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-7763732d636f72652d616374696f6e73, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-726669642d776373, TASK-INTEGRATION-LIVE-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-LIVE-7763732d6175746f2d62616767696e67, TASK-INTEGRATION-LIVE-7763732d6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73

- wcs-discovery-1 · Which system or role is authorised to release a held tote after WMS and equipment outcomes disagree?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
