# Core scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Release and fulfill warehouse work

### Functional flow

```mermaid
flowchart TD
  step0["WMS to Host gateway #8212; Submit start request with stable WMS reference"]
  step1["Host gateway to WCS Core #8212; Resolve prior message outcome or persist accepted start"]
  step2["WCS Core to Order planning #8212; Allocate eligible work to tote compartments under approved rules"]
  step3["WCS Core to AirRob controller #8212; Request correlated tote move through site contract"]
  step4["AirRob controller to WCS Core #8212; Report job result using supported status interface"]
  step5["Picking workstation to WCS Core #8212; Confirm quantities and resolve any RFID discrepancy"]
  step6["WCS Core to Packing workflow #8212; Route by approved bagging eligibility or manual packing rules"]
  step7["WCS Core to Host gateway #8212; Publish the observed milestone when its completion condition is satisfied"]
  step8["Host gateway to WMS #8212; Send correlated result and retain confirmed acknowledgement"]
  step0 --> step1
  step1 --> step2
  step2 --> step3
  step3 --> step4
  step4 --> step5
  step5 --> step6
  step6 --> step7
  step7 --> step8
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as WMS
  participant actor1 as Host gateway
  participant actor2 as WCS Core
  participant actor3 as Order planning
  participant actor4 as AirRob controller
  participant actor5 as Picking workstation
  participant actor6 as Packing workflow
  actor0->>actor1: Submit start request with stable WMS reference
  actor1->>actor2: Resolve prior message outcome or persist accepted start
  actor2->>actor3: Allocate eligible work to tote compartments under approved rules
  actor2->>actor4: Request correlated tote move through site contract
  actor4->>actor2: Report job result using supported status interface
  actor5->>actor2: Confirm quantities and resolve any RFID discrepancy
  actor2->>actor6: Route by approved bagging eligibility or manual packing rules
  actor2->>actor1: Publish the observed milestone when its completion condition is satisfied
  actor1->>actor0: Send correlated result and retain confirmed acknowledgement
```

## Reconcile a lost move acknowledgement

### Functional flow

```mermaid
flowchart TD
  step0["WCS Core to Execution records #8212; Commit pending operation and correlation reference"]
  step1["WCS Core to AirRob controller #8212; Submit tote move through site adapter"]
  step2["WCS Core to Execution records #8212; Mark unknown on timeout and withhold a replacement job"]
  step3["WCS Core to AirRob controller #8212; Ask for outcome if supported by the approved interface"]
  step4["WCS Core to Authorised operator #8212; Escalate when the result cannot be established"]
  step5["Authorised operator to WCS Core #8212; Record verified resolution before releasing work"]
  step0 --> step1
  step1 --> step2
  step2 --> step3
  step3 --> step4
  step4 --> step5
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as WCS Core
  participant actor1 as Execution records
  participant actor2 as AirRob controller
  participant actor3 as Authorised operator
  actor0->>actor1: Commit pending operation and correlation reference
  actor0->>actor2: Submit tote move through site adapter
  actor0->>actor1: Mark unknown on timeout and withhold a replacement job
  actor0->>actor2: Ask for outcome if supported by the approved interface
  actor0->>actor3: Escalate when the result cannot be established
  actor3->>actor0: Record verified resolution before releasing work
```
