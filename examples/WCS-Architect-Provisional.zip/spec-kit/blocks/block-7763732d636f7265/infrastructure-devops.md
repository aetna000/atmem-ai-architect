# Core infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Co-locate with WCS server. Keep controller integrations behind protocols and retain site safety custody.

## CI, release and operations

Exercise full order with simulated WMS and equipment on CI. For site acceptance, validate each controller and rollback with its owner.
