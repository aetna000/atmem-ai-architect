# Auto-bagging equipment acceptance tests

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Oversize ineligible work is diverted and never booked into auto-bagging.

Record the test environment, command, input, expected result and observed evidence. Execution status: pending.
