# Auto-bagging equipment infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Site equipment boundary. Confirm message and label custody with equipment owner.

## CI, release and operations

Exercise limits and signal mapping with owner before site rollout.
