# Auto-bagging equipment scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Auto-bagging equipment #8212; Eligible package routing and correlation to order#47;package"]
  step1["Auto-bagging equipment to Auto-bagging equipment #8212; Accept only qualified eligible work and retain package association across routing."]
  step2["Auto-bagging equipment to Calling workflow #8212; Supported packing result, reject or fault"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Auto-bagging equipment
  actor0->>actor1: Eligible package routing and correlation to order#47;package
  actor1->>actor1: Accept only qualified eligible work and retain package association across routing.
  actor1->>actor0: Supported packing result, reject or fault
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Auto-bagging equipment to Auto-bagging equipment #8212; Recovery holds ambiguous results#59; ineligible work goes to manual packing"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Auto-bagging equipment
  actor0->>actor0: Recovery holds ambiguous results#59; ineligible work goes to manual packing
```
