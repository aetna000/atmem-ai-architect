# Host integration gateway infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

WCS-owned adapter. Confirm host transport, authentication and whether a separate process is required.

## CI, release and operations

Test version compatibility and replay with a WMS double. Qualify external credentials and rollback with WMS owner.
