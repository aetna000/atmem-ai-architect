# Host integration gateway scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Host integration gateway #8212; Versioned WMS JSON messages with stable identity"]
  step1["Host integration gateway to Host integration gateway #8212; Validate message#47;schema and record acceptance before dispatch#59; map canonical WCS events to the agreed WMS contract."]
  step2["Host integration gateway to Calling workflow #8212; Durable acknowledgement, mapped results, exceptions and milestones"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Host integration gateway
  actor0->>actor1: Versioned WMS JSON messages with stable identity
  actor1->>actor1: Validate message#47;schema and record acceptance before dispatch#59; map canonical WCS events to the agreed WMS contract.
  actor1->>actor0: Durable acknowledgement, mapped results, exceptions and milestones
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Host integration gateway to Host integration gateway #8212; Duplicates yield previous result#59; uncertain delivery requires status reconciliation"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Host integration gateway
  actor0->>actor0: Duplicates yield previous result#59; uncertain delivery requires status reconciliation
```
