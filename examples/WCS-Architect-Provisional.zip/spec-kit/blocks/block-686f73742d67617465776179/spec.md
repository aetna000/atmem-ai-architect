# Host integration gateway

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

WCS-owned integration component. Validates and maps host JSON for order start and cancellation, SKU changes, direct transport orders, label data and snapshot requests. Returns planning and execution milestones, exceptions, manual-consolidation handoffs, quantity deltas and snapshots. Use stable identifiers and durable tracking of accepted requests and pending results to prevent duplicate or lost work through retries and restarts. Exact host contract, acknowledgements, authentication and deployment boundary remain open.

Validate message/schema and record acceptance before dispatch; map canonical WCS events to the agreed WMS contract.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Versioned WMS JSON messages with stable identity

## Outputs and postconditions

Durable acknowledgement, mapped results, exceptions and milestones

## Boundaries

- wcs-host · Host integration gateway → Warehouse host system · Host JSON requests in, results and exceptions out
- wcs-host-gateway · Core → Host integration gateway · Validated work requests in, results and exceptions out

### Proposed interface wcs-host

#### Transport and version

Host-facing JSON. Site transport, schema and version open pending WMS documentation.

#### Request or event

Inbound work, cancellation, SKU changes, direct transport, snapshot requests and label data. Derive exact payloads from the host specification.

#### Response or result

Correlated milestones, results, exceptions, deltas, handoff and snapshot outcomes. Acknowledgement semantics open.

#### Identity and authority

Approve a warehouse-host identity and gateway permissions with the WMS owner.

#### Failure and retry

Persist stable request/result identities. Reconcile unknown acknowledgement before replay.

#### Contract tests

Replay duplicate start/cancel messages. Verify one recorded transition and recover an uncertain outbound response.

## Failure and recovery

Duplicates yield previous result; uncertain delivery requires status reconciliation

## Implementation

Implement or integrate this responsibility against its linked requirements. Validate message/schema and record acceptance before dispatch; map canonical WCS events to the agreed WMS contract. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-order-planning · Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.
- ai-wcs-packing-labels · Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.
- ai-wcs-local-stock · Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.
- ai-wcs-manual-handoff · Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.
- ai-wcs-durable-recovery · Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Tasks: TASK-CONTRACT-7763732d686f7374, TASK-CONTRACT-7763732d686f73742d67617465776179, TASK-RESOURCE-686f73742d67617465776179, TASK-INTEGRATION-7763732d686f7374, TASK-INTEGRATION-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67, TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73, TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b, TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666, TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

- wcs-discovery-2 · Who can provide the current WMS JSON schemas, sample exchanges and the authoritative acknowledgement and replay rules?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
