# Returns and stock counts

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Workstation workflows within the shared WCS deployment. Record inspected mixed returns and operator-confirmed off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote, with manual checking when RFID readings are unreliable. Before switching between picking, counting and clearing, stop new allocations and let assigned work finish.

Drain assigned work before changing mode and offer physical counts when reads are unreliable.

## Decomposition

Parent: Core

None recorded.

## Inputs and preconditions

Inspected returns, authorised count request and workstation mode command

## Outputs and postconditions

Confirmed transfer/count and audited mode transition

## Boundaries

- returns-counting-wcs · Returns and stock counts → WCS web server · Returns induction, stock counts and workstation mode changes

## Failure and recovery

Retain assigned work while draining; report blocked mode transition

## Implementation

Implement or integrate this responsibility against its linked requirements. Drain assigned work before changing mode and offer physical counts when reads are unreliable. Add executable acceptance cases before enabling downstream integration.

## Traceability

None recorded.

Tasks: TASK-CONTRACT-72657475726e732d636f756e74696e672d776373, TASK-RESOURCE-72657475726e732d636f756e74696e67, TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
