# Returns and stock counts scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Returns and stock counts #8212; Inspected returns, authorised count request and workstation mode command"]
  step1["Returns and stock counts to Returns and stock counts #8212; Drain assigned work before changing mode and offer physical counts when reads are unreliable."]
  step2["Returns and stock counts to Calling workflow #8212; Confirmed transfer#47;count and audited mode transition"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Returns and stock counts
  actor0->>actor1: Inspected returns, authorised count request and workstation mode command
  actor1->>actor1: Drain assigned work before changing mode and offer physical counts when reads are unreliable.
  actor1->>actor0: Confirmed transfer#47;count and audited mode transition
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Returns and stock counts to Returns and stock counts #8212; Retain assigned work while draining#59; report blocked mode transition"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Returns and stock counts
  actor0->>actor0: Retain assigned work while draining#59; report blocked mode transition
```
