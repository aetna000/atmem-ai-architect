# Returns and stock counts infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Shared workflow and kiosk routes within WCS.

## CI, release and operations

Test concurrent allocation during draining, then qualify workstation operations in staging.
