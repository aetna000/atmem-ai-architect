# Returns and stock counts acceptance tests

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Issue new work during mode drain; refuse allocation and finish original assignment before switching.

Record the test environment, command, input, expected result and observed evidence. Execution status: pending.
