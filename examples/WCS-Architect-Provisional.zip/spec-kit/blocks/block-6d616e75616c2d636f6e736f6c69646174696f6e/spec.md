# Manual consolidation and re-induction

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Workflow within the shared WCS deployment. When a partially picked tote goes to manual consolidation, report its contents to WMS. Accept a manually completed or fully manually picked tote back into WCS only against a WMS direct transport order linking tote, order, destination, revised quantities and additions or shortages. Pass the revised expected contents to packing.

Record handoff, accept re-induction against the identified order, and supply revised packing expectation.

## Decomposition

Parent: Core

None recorded.

## Inputs and preconditions

Partial tote contents and WMS direct transport order with revised contents

## Outputs and postconditions

Outbound handoff and updated expected contents or denial

## Boundaries

- manual-consolidation-wcs · Manual consolidation and re-induction → WCS web server · Partial-pick handoff and WMS-authorised tote re-induction

## Failure and recovery

Mismatched order or quantities stay held

## Implementation

Implement or integrate this responsibility against its linked requirements. Record handoff, accept re-induction against the identified order, and supply revised packing expectation. Add executable acceptance cases before enabling downstream integration.

## Traceability

None recorded.

Tasks: TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e, TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
