# Manual consolidation and re-induction scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Manual consolidation and re-induction #8212; Partial tote contents and WMS direct transport order with revised contents"]
  step1["Manual consolidation and re-induction to Manual consolidation and re-induction #8212; Record handoff, accept re-induction against the identified order, and supply revised packing expectation."]
  step2["Manual consolidation and re-induction to Calling workflow #8212; Outbound handoff and updated expected contents or denial"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Manual consolidation and re-induction
  actor0->>actor1: Partial tote contents and WMS direct transport order with revised contents
  actor1->>actor1: Record handoff, accept re-induction against the identified order, and supply revised packing expectation.
  actor1->>actor0: Outbound handoff and updated expected contents or denial
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Manual consolidation and re-induction to Manual consolidation and re-induction #8212; Mismatched order or quantities stay held"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Manual consolidation and re-induction
  actor0->>actor0: Mismatched order or quantities stay held
```
