# Clearing workstation infrastructure and operations

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Infrastructure

Shared kiosk route and authorised station permission.

## CI, release and operations

Exercise assigned reject stations before release.
