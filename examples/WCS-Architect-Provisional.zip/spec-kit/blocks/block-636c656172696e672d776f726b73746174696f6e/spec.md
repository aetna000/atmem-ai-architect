# Clearing workstation

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Kiosk screen within the shared WCS deployment. Supports clearing tasks and records operator confirmations or exceptions. For sorter rejects, allow parcel identification, destination confirmation and manual clearing. Other clearing scenarios and the effects of their confirmations remain open.

Confirm parcel and destination for sorter rejects. Obtain approved rules for other clearing workflows.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Assigned clearing work or reject parcel and logical destination

## Outputs and postconditions

Audited clearing confirmation or unresolved exception

## Boundaries

- clearing-wcs · Clearing workstation → WCS web server · Clearing tasks, reject parcel identification and operator confirmations

## Failure and recovery

Hold unidentified parcels for supervisor resolution

## Implementation

Implement or integrate this responsibility against its linked requirements. Confirm parcel and destination for sorter rejects. Obtain approved rules for other clearing workflows. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-kiosk-web · Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.
- ai-wcs-returns-count-modes · Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.

Tasks: TASK-CONTRACT-636c656172696e672d776373, TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e, TASK-INTEGRATION-636c656172696e672d776373, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562, TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573

- wcs-discovery-4 · Which clearing workflows beyond sorter rejects belong in first release, and what should each confirmation trigger?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
