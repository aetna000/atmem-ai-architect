# Clearing workstation scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Clearing workstation #8212; Assigned clearing work or reject parcel and logical destination"]
  step1["Clearing workstation to Clearing workstation #8212; Confirm parcel and destination for sorter rejects. Obtain approved rules for other clearing workflows."]
  step2["Clearing workstation to Calling workflow #8212; Audited clearing confirmation or unresolved exception"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Clearing workstation
  actor0->>actor1: Assigned clearing work or reject parcel and logical destination
  actor1->>actor1: Confirm parcel and destination for sorter rejects. Obtain approved rules for other clearing workflows.
  actor1->>actor0: Audited clearing confirmation or unresolved exception
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Clearing workstation to Clearing workstation #8212; Hold unidentified parcels for supervisor resolution"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Clearing workstation
  actor0->>actor0: Hold unidentified parcels for supervisor resolution
```
