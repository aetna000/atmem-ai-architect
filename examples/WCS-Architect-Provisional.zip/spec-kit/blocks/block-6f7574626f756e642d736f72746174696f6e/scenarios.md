# Outbound sortation scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Outbound sortation #8212; Shipping-label identifier, logical destination and chute availability"]
  step1["Outbound sortation to Outbound sortation #8212; Map logical destination to chute and send full-chute overflow to reject once. Preserve manual clearing evidence."]
  step2["Outbound sortation to Calling workflow #8212; Booked#47;actual route where available or reject disposition"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Outbound sortation
  actor0->>actor1: Shipping-label identifier, logical destination and chute availability
  actor1->>actor1: Map logical destination to chute and send full-chute overflow to reject once. Preserve manual clearing evidence.
  actor1->>actor0: Booked#47;actual route where available or reject disposition
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Outbound sortation to Outbound sortation #8212; Hold unknown labels and never recirculate full-chute rejects"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Outbound sortation
  actor0->>actor0: Hold unknown labels and never recirculate full-chute rejects
```
