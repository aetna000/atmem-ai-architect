# Outbound sortation

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Site sorter and WCS integration boundary. WCS maps shipping-label identifiers to logical destinations and physical chutes, and records the booked route and available actual-route feedback. Send full-chute overflow to reject without recirculation. At the clearing screen, allow operators to identify rejected parcels, confirm destinations and record manual clearing. Confirm equipment event and routing contracts on site.

Map logical destination to chute and send full-chute overflow to reject once. Preserve manual clearing evidence.

## Decomposition

Parent: System

None recorded.

## Inputs and preconditions

Shipping-label identifier, logical destination and chute availability

## Outputs and postconditions

Booked/actual route where available or reject disposition

## Boundaries

- wcs-outbound-sortation · Core → Outbound sortation · Shipping label and chute mapping, route and reject feedback

## Failure and recovery

Hold unknown labels and never recirculate full-chute rejects

## Implementation

Implement or integrate this responsibility against its linked requirements. Map logical destination to chute and send full-chute overflow to reject once. Preserve manual clearing evidence. Add executable acceptance cases before enabling downstream integration.

## Traceability

None recorded.

Tasks: TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e, TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-LIVE-7763732d6f7574626f756e642d736f72746174696f6e

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
