# Packing workstation scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Packing workstation #8212; Tote and compartment, revised expected contents, WMS label and package identity"]
  step1["Packing workstation to Packing workstation #8212; Verify the current expected content and create one print intent per authorised package action."]
  step2["Packing workstation to Calling workflow #8212; Verified package or discrepancy plus correlated print intent"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Packing workstation
  actor0->>actor1: Tote and compartment, revised expected contents, WMS label and package identity
  actor1->>actor1: Verify the current expected content and create one print intent per authorised package action.
  actor1->>actor0: Verified package or discrepancy plus correlated print intent
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Packing workstation to Packing workstation #8212; Uncertain print cannot silently reissue#59; require authorised reason for reprint"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Packing workstation
  actor0->>actor0: Uncertain print cannot silently reissue#59; require authorised reason for reprint
```
