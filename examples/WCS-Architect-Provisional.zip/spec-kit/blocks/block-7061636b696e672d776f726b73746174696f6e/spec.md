# Packing workstation

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Manual packing kiosk within the shared WCS deployment, including for ineligible or oversized work and fully manually picked orders. Verify the tote and compartment against current expected contents, including revisions from manual consolidation. Confirm package contents and request the WMS-supplied shipping label linked to the order and package. Record uncertain print outcomes and require an authorised reason for reprints. The exact completion trigger remains open.

Verify the current expected content and create one print intent per authorised package action.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Tote and compartment, revised expected contents, WMS label and package identity

## Outputs and postconditions

Verified package or discrepancy plus correlated print intent

## Boundaries

- packing-wcs · Packing workstation → WCS web server · HTTPS packing screen, package confirmations and label requests

## Failure and recovery

Uncertain print cannot silently reissue; require authorised reason for reprint

## Implementation

Implement or integrate this responsibility against its linked requirements. Verify the current expected content and create one print intent per authorised package action. Add executable acceptance cases before enabling downstream integration.

## Traceability

- ai-wcs-packing-labels · Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.
- ai-wcs-manual-handoff · Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.

Tasks: TASK-CONTRACT-7061636b696e672d776373, TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e, TASK-INTEGRATION-7061636b696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73, TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666

- wcs-discovery-7 · What event marks manual packing complete, and which role can authorise a reprint?

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
