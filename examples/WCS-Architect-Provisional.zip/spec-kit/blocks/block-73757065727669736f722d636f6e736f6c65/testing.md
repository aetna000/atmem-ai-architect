# Supervisor console acceptance tests

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

A packing kiosk credential cannot shorten an order or change a location lock.

Record the test environment, command, input, expected result and observed evidence. Execution status: pending.
