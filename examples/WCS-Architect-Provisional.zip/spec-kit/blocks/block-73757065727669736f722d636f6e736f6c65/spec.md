# Supervisor console

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

Status: proposed design. Check open sections and source requirements before implementing.

## Responsibility

Screen within the shared WCS deployment. Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. WCS authorises and audits changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

Expose workload, progress and exceptions. Authorize each mutation server-side.

## Decomposition

Parent: WCS web server

None recorded.

## Inputs and preconditions

Authorised supervisor action and visible workflow data

## Outputs and postconditions

Operational views, audited override result or denial

## Boundaries

- supervisor-wcs · Supervisor console → WCS web server · Operational status and authorised supervisory actions

## Failure and recovery

On stale order or station state reject action and refresh

## Implementation

Implement or integrate this responsibility against its linked requirements. Expose workload, progress and exceptions. Authorize each mutation server-side. Add executable acceptance cases before enabling downstream integration.

## Traceability

None recorded.

Tasks: TASK-CONTRACT-73757065727669736f722d776373, TASK-RESOURCE-73757065727669736f722d636f6e736f6c65, TASK-INTEGRATION-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373

None recorded.

[Infrastructure and operations](infrastructure-devops.md) · [Testing](testing.md) · [Scenarios](scenarios.md)
