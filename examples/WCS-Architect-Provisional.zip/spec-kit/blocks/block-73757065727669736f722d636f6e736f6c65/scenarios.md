# Supervisor console scenarios

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

## Process an accepted input

### Functional flow

```mermaid
flowchart TD
  step0["Calling workflow to Supervisor console #8212; Authorised supervisor action and visible workflow data"]
  step1["Supervisor console to Supervisor console #8212; Expose workload, progress and exceptions. Authorize each mutation server-side."]
  step2["Supervisor console to Calling workflow #8212; Operational views, audited override result or denial"]
  step0 --> step1
  step1 --> step2
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Calling workflow
  participant actor1 as Supervisor console
  actor0->>actor1: Authorised supervisor action and visible workflow data
  actor1->>actor1: Expose workload, progress and exceptions. Authorize each mutation server-side.
  actor1->>actor0: Operational views, audited override result or denial
```

## Handle a failure

### Functional flow

```mermaid
flowchart TD
  step0["Supervisor console to Supervisor console #8212; On stale order or station state reject action and refresh"]
```

### Sequence

```mermaid
sequenceDiagram
  participant actor0 as Supervisor console
  actor0->>actor0: On stale order or station state reject action and refresh
```
