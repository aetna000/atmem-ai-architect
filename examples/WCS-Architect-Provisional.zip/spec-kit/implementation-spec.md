# Implementation Spec Kit

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

21 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

I want to build a wcs system controlling libiao airrob has ui has workstation decanting and picking connects to host using json
we need a gateway connecting wcs to host system
we need to have business logic about order planning managing conveyor systems and printers packing
use this and check the diagrams add more needex
I CANNOT SEE ANY CHANGES TO THE. OARD VERSHER IS RFID
we want the biz logics to be in one blcok call it core can we have nested blocks

## Confirmed design decisions

- design.first-sketch-of-the-airrob-warehouse-control-system: Drawn while talking as design revision 2.
- design.serve-all-three-workstation-workflows-in-kiosk-mode: Drawn while talking as design revision 92.
- design.add-the-warehouse-host-gateway: Drawn while talking as design revision 93.
- design.add-order-planning-conveyor-coordination-and-packing: Drawn while talking as design revision 94.
- design.show-rfid-and-complete-the-recorded-warehouse-workflows: Drawn while talking as design revision 98.
- design.group-wcs-business-logic-under-core: Drawn while talking as design revision 100.

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Decanting workstation (decant-workstation): Implementation needed; tools, To be selected.
- Picking workstation (picking-workstation): Implementation needed; tools, To be selected.
- WCS web server (wcs): Implementation needed; tools, To be selected.
- WCS execution records (wcs-state): Implementation needed; tools, To be selected.
- Warehouse host system (warehouse-host): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, To be selected.
- Libiao AirRob controller (libiao-airrob): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, To be selected.
- Clearing workstation (clearing-workstation): Implementation needed; tools, To be selected.
- Host integration gateway (host-gateway): Implementation needed; tools, To be selected.
- Order planning (order-planning): Implementation needed; tools, To be selected.
- Packing workstation (packing-workstation): Implementation needed; tools, To be selected.
- Conveyor controller (conveyor-controller): Implementation needed; tools, To be selected.
- Packing label printers (packing-printers): Implementation needed; tools, To be selected.
- RFID readers (rfid-readers): Implementation needed; tools, To be selected.
- Local stock tracking (wcs-local-stock): Implementation needed; tools, To be selected.
- Manual consolidation and re-induction (manual-consolidation): Implementation needed; tools, To be selected.
- Returns and stock counts (returns-counting): Implementation needed; tools, To be selected.
- Supervisor console (supervisor-console): Implementation needed; tools, To be selected.
- Auto-bagging equipment (auto-bagging): Implementation needed; tools, To be selected.
- Outbound sortation (outbound-sortation): Implementation needed; tools, To be selected.
- Core (wcs-core): Implementation needed; tools, To be selected.

## How to use this kit

Read contracts.md, tasks.md and [Component Spec Kits](blocks/README.md). Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d31 — priority 1

Which system or role is authorised to release a held tote after WMS and equipment outcomes disagree?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d32 — priority 1

Who can provide the current WMS JSON schemas, sample exchanges and the authoritative acknowledgement and replay rules?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d33 — priority 1

Which AirRob interface and job status lookup does the site support, and who can supply its official contract and simulator?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d34 — priority 1

Which clearing workflows beyond sorter rejects belong in first release, and what should each confirmation trigger?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d35 — priority 1

Which priority, readiness, batching and finishing-time rules are required at launch?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d36 — priority 1

How should temporary stock unavailability appear in a standstill snapshot?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d37 — priority 1

What event marks manual packing complete, and which role can authorise a reprint?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d38 — priority 1

Where must WCS run, and what availability, recovery and site-network constraints apply?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### requirement-proposed-61692d7763732d616972726f622d636f6e74726f6c — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c

### requirement-proposed-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e

### requirement-proposed-61692d7763732d64757261626c652d7265636f76657279 — priority 1

REQ-016 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

### requirement-proposed-61692d7763732d6b696f736b2d776562 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562

### requirement-proposed-61692d7763732d6c6f63616c2d73746f636b — priority 1

REQ-010 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b

### requirement-proposed-61692d7763732d6d616e75616c2d68616e646f6666 — priority 1

REQ-012 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666

### requirement-proposed-61692d7763732d6f726465722d706c616e6e696e67 — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67

### requirement-proposed-61692d7763732d6f7574626f756e642d736f72746174696f6e — priority 1

REQ-013 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e

### requirement-proposed-61692d7763732d7061636b696e672d6c6162656c73 — priority 1

REQ-009 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73

### requirement-proposed-61692d7763732d72657475726e732d636f756e742d6d6f646573 — priority 1

REQ-014 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573

### requirement-proposed-61692d7763732d726669642d76616c69646174696f6e — priority 1

REQ-011 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e

### requirement-proposed-61692d7763732d73757065727669736f722d6f7065726174696f6e73 — priority 1

REQ-015 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73

### placement-6175746f2d62616767696e67 — priority 2

Auto-bagging equipment: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6175746f2d62616767696e67

### placement-636c656172696e672d776f726b73746174696f6e — priority 2

Clearing workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e

### placement-636f6e7665796f722d636f6e74726f6c6c6572 — priority 2

Conveyor controller: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572

### placement-646563616e742d776f726b73746174696f6e — priority 2

Decanting workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-646563616e742d776f726b73746174696f6e

### placement-686f73742d67617465776179 — priority 2

Host integration gateway: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-686f73742d67617465776179

### placement-6d616e75616c2d636f6e736f6c69646174696f6e — priority 2

Manual consolidation and re-induction: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e

### placement-6f726465722d706c616e6e696e67 — priority 2

Order planning: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6f726465722d706c616e6e696e67

### placement-6f7574626f756e642d736f72746174696f6e — priority 2

Outbound sortation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e

### placement-7061636b696e672d7072696e74657273 — priority 2

Packing label printers: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7061636b696e672d7072696e74657273

### placement-7061636b696e672d776f726b73746174696f6e — priority 2

Packing workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e

### placement-7069636b696e672d776f726b73746174696f6e — priority 2

Picking workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e

### placement-72657475726e732d636f756e74696e67 — priority 2

Returns and stock counts: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-72657475726e732d636f756e74696e67

### placement-726669642d72656164657273 — priority 2

RFID readers: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-726669642d72656164657273

### placement-73757065727669736f722d636f6e736f6c65 — priority 2

Supervisor console: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-73757065727669736f722d636f6e736f6c65

### placement-776373 — priority 2

WCS web server: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-776373

### placement-7763732d636f7265 — priority 2

Core: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7763732d636f7265

### placement-7763732d6c6f63616c2d73746f636b — priority 2

Local stock tracking: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7763732d6c6f63616c2d73746f636b

### placement-7763732d7374617465 — priority 2

WCS execution records: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7763732d7374617465

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

20 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d7763732d616972726f622d636f6e74726f6c — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c

### acceptance-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e

### acceptance-61692d7763732d64757261626c652d7265636f76657279 — priority 2

REQ-016: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

### acceptance-61692d7763732d686f73742d6a736f6e — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e

### acceptance-61692d7763732d6b696f736b2d776562 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562

### acceptance-61692d7763732d6c6f63616c2d73746f636b — priority 2

REQ-010: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b

### acceptance-61692d7763732d6d616e75616c2d68616e646f6666 — priority 2

REQ-012: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666

### acceptance-61692d7763732d6f726465722d706c616e6e696e67 — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67

### acceptance-61692d7763732d6f7574626f756e642d736f72746174696f6e — priority 2

REQ-013: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e

### acceptance-61692d7763732d7061636b696e672d6c6162656c73 — priority 2

REQ-009: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73

### acceptance-61692d7763732d72657475726e732d636f756e742d6d6f646573 — priority 2

REQ-014: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573

### acceptance-61692d7763732d726669642d76616c69646174696f6e — priority 2

REQ-011: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e

### acceptance-61692d7763732d73757065727669736f722d6f7065726174696f6e73 — priority 2

REQ-015: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73

### acceptance-61692d7763732d776f726b73746174696f6e2d666c6f7773 — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773

### implementation-6175746f2d62616767696e67 — priority 2

Auto-bagging equipment: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6175746f2d62616767696e67

### implementation-636c656172696e672d776f726b73746174696f6e — priority 2

Clearing workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e

### implementation-636f6e7665796f722d636f6e74726f6c6c6572 — priority 2

Conveyor controller: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572

### implementation-646563616e742d776f726b73746174696f6e — priority 2

Decanting workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-646563616e742d776f726b73746174696f6e

### implementation-686f73742d67617465776179 — priority 2

Host integration gateway: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-686f73742d67617465776179

### implementation-6d616e75616c2d636f6e736f6c69646174696f6e — priority 2

Manual consolidation and re-induction: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e

### implementation-6f726465722d706c616e6e696e67 — priority 2

Order planning: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6f726465722d706c616e6e696e67

### implementation-6f7574626f756e642d736f72746174696f6e — priority 2

Outbound sortation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e

### implementation-7061636b696e672d7072696e74657273 — priority 2

Packing label printers: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7061636b696e672d7072696e74657273

### implementation-7061636b696e672d776f726b73746174696f6e — priority 2

Packing workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e

### implementation-7069636b696e672d776f726b73746174696f6e — priority 2

Picking workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e

### implementation-72657475726e732d636f756e74696e67 — priority 2

Returns and stock counts: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-72657475726e732d636f756e74696e67

### implementation-726669642d72656164657273 — priority 2

RFID readers: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-726669642d72656164657273

### implementation-73757065727669736f722d636f6e736f6c65 — priority 2

Supervisor console: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-73757065727669736f722d636f6e736f6c65

### implementation-776373 — priority 2

WCS web server: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-776373

### implementation-7763732d636f7265 — priority 2

Core: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7763732d636f7265

### implementation-7763732d6c6f63616c2d73746f636b — priority 2

Local stock tracking: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7763732d6c6f63616c2d73746f636b

### implementation-7763732d7374617465 — priority 2

WCS execution records: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7763732d7374617465

### existing-6c696269616f2d616972726f62 — priority 2

Libiao AirRob controller: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-6c696269616f2d616972726f62

### existing-77617265686f7573652d686f7374 — priority 2

Warehouse host system: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-77617265686f7573652d686f7374


# Component and interface contracts

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component decant-workstation: Decanting workstation

- Responsibility: Kiosk screen within the shared WCS deployment. Operators identify the inbound item and destination tote, confirm the loaded quantity and flag discrepancies. Where RFID is enabled, display expected and read quantities and require physical checking and an operator confirmation or authorised override before committing a mismatch.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-646563616e742d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component picking-workstation: Picking workstation

- Responsibility: Kiosk screen within the shared WCS deployment. Show the pick task when the expected tote is available, including the relevant compartment. Record quantity picked and shortages. Where RFID is enabled, show read discrepancies and require physical checking and operator confirmation or an authorised override before committing the outcome.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs: WCS web server

- Responsibility: Shared WCS deployment serves decanting, picking, clearing, packing, returns, stock counts and supervisor screens over HTTPS. Enforces server-side permissions and passes authorised actions to Core, which runs in the same deployment. Presents workflow state, equipment status and RFID discrepancies, and collects physical-check confirmations or authorised overrides. Hosting remains open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-776373
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs-state: WCS execution records

- Responsibility: WCS-owned durable store for order plans, task progress, local stock by SKU and tote, host and equipment identifiers, package and label jobs, operator confirmations, RFID mismatch evidence and supervisor audit records. Reconcile uncertain host, motion or print outcomes before retrying. Retain decisions by authorised operators. Storage technology remains open.
- Service: Storage or existing data connector
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7763732d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component warehouse-host: Warehouse host system

- Responsibility: Existing warehouse management system (WMS). Owns warehouse-wide inventory and SKU master data. Exchanges JSON work requests, direct transport orders, execution outcomes and exceptions through the host gateway. Receives exceptional stock deltas, manual-consolidation handoffs and requested standstill snapshots, and provides shipping label data for packing. Product, schemas and transport remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-77617265686f7573652d686f7374
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component libiao-airrob: Libiao AirRob controller

- Responsibility: External vendor control boundary for AirRob. Proposed exchange sends tote transport jobs and receives job status and faults. Site-specific interface, job identifiers and recovery behavior need vendor evidence.
- Service: Libiao AirRob
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6c696269616f2d616972726f62
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component clearing-workstation: Clearing workstation

- Responsibility: Kiosk screen within the shared WCS deployment. Supports clearing tasks and records operator confirmations or exceptions. For sorter rejects, allow parcel identification, destination confirmation and manual clearing. Other clearing scenarios and the effects of their confirmations remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component host-gateway: Host integration gateway

- Responsibility: WCS-owned integration component. Validates and maps host JSON for order start and cancellation, SKU changes, direct transport orders, label data and snapshot requests. Returns planning and execution milestones, exceptions, manual-consolidation handoffs, quantity deltas and snapshots. Use stable identifiers and durable tracking of accepted requests and pending results to prevent duplicate or lost work through retries and restarts. Exact host contract, acknowledgements, authentication and deployment boundary remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-686f73742d67617465776179
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component order-planning: Order planning

- Responsibility: Module within the WCS application. Plans internal work from WMS start instructions using agreed priorities, finishing times and readiness rules. Accepts cancellation only before planning begins. Batches eligible single-SKU single-item orders under configurable rules and preserves order and item identity against each tote compartment. Audits operator overrides and emits planning-started, picked and execution-completed outcomes through the gateway. Stock allocation rules and batching thresholds remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f726465722d706c616e6e696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component packing-workstation: Packing workstation

- Responsibility: Manual packing kiosk within the shared WCS deployment, including for ineligible or oversized work and fully manually picked orders. Verify the tote and compartment against current expected contents, including revisions from manual consolidation. Confirm package contents and request the WMS-supplied shipping label linked to the order and package. Record uncertain print outcomes and require an authorised reason for reprints. The exact completion trigger remains open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component conveyor-controller: Conveyor controller

- Responsibility: Proposed site equipment integration boundary. The WCS requests routing and consumes arrival, availability and fault events through a supported interface. The controller owns motion, interlocks and emergency stops. Controller product, ownership, interface and recovery behaviour remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component packing-printers: Packing label printers

- Responsibility: Proposed site print integration boundary for packing stations. The WCS sends package-linked label jobs and records job acknowledgements or faults where supported. The packing screen shows uncertain outcomes and supports controlled reprints. Printer ownership, interface, label formats and status capabilities remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7061636b696e672d7072696e74657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component rfid-readers: RFID readers

- Responsibility: Proposed on-site reader equipment at RFID-enabled workstations. Supply tagged-item observations and reader health to WCS with enough context to associate each read with the correct workstation and task. Qualify tag-to-SKU identification, reader placement, read stability and filtering of nearby tags with real totes. Reader model, exact locations, interface and ownership remain open. WCS owns validation and the manual fallback.
- Service: Ingestion / processing service
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-726669642d72656164657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs-local-stock: Local stock tracking

- Responsibility: Module within the shared WCS application. Tracks stock by SKU, stock properties and tote using WCS execution records. Reports exceptional quantity deltas with reason codes and returns WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Acknowledges SKU retirement once stock and order references clear. Temporary unavailability stays local. Its treatment in snapshots remains open. WMS owns warehouse-wide inventory and SKU master data.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7763732d6c6f63616c2d73746f636b
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component manual-consolidation: Manual consolidation and re-induction

- Responsibility: Workflow within the shared WCS deployment. When a partially picked tote goes to manual consolidation, report its contents to WMS. Accept a manually completed or fully manually picked tote back into WCS only against a WMS direct transport order linking tote, order, destination, revised quantities and additions or shortages. Pass the revised expected contents to packing.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component returns-counting: Returns and stock counts

- Responsibility: Workstation workflows within the shared WCS deployment. Record inspected mixed returns and operator-confirmed off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote, with manual checking when RFID readings are unreliable. Before switching between picking, counting and clearing, stop new allocations and let assigned work finish.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-72657475726e732d636f756e74696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component supervisor-console: Supervisor console

- Responsibility: Screen within the shared WCS deployment. Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. WCS authorises and audits changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73757065727669736f722d636f6e736f6c65
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component auto-bagging: Auto-bagging equipment

- Responsibility: Site equipment boundary for automatic packing. WCS proposes routing eligible single-item batches and multi-item orders here through the conveyor controller and diverting ineligible or oversized work to manual packing. Correlate supported packing results and faults with the correct package and order. Bagging interface, arrival and completion signals, eligibility rules and label handoff require site evidence.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6175746f2d62616767696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component outbound-sortation: Outbound sortation

- Responsibility: Site sorter and WCS integration boundary. WCS maps shipping-label identifiers to logical destinations and physical chutes, and records the booked route and available actual-route feedback. Send full-chute overflow to reject without recirculation. At the clearing screen, allow operators to identify rejected parcels, confirm destinations and record manual clearing. Confirm equipment event and routing contracts on site.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs-core: Core

- Responsibility: Business logic module within the shared WCS web server deployment. Owns order planning, task and workflow state, local stock tracking, RFID validation and manual discrepancy resolution, returns, counting, manual consolidation and re-induction, packing and label rules, outbound sortation and supervisor actions. Coordinates AirRob tote moves, conveyor routing, auto-bagging, printing and sorter operations through site interfaces. Equipment controllers retain motion and safety control. Persists execution and audit records, reconciles uncertain outcomes before retrying, and exchanges work, results and exceptions with the WMS through the host gateway.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7763732d636f7265
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### decant-wcs: decant-workstation → wcs

- Drawn payload/purpose: HTTPS decanting screen and load confirmations
- Contract task: TASK-CONTRACT-646563616e742d776373
- Integration task: TASK-INTEGRATION-646563616e742d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### pick-wcs: picking-workstation → wcs

- Drawn payload/purpose: HTTPS picking screen and pick confirmations
- Contract task: TASK-CONTRACT-7069636b2d776373
- Integration task: TASK-INTEGRATION-7069636b2d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-host: host-gateway → warehouse-host

- Drawn payload/purpose: Host JSON requests in, results and exceptions out
- Contract task: TASK-CONTRACT-7763732d686f7374
- Integration task: TASK-INTEGRATION-7763732d686f7374
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-airrob: wcs-core → libiao-airrob

- Drawn payload/purpose: Tote move jobs out, status and faults in
- Contract task: TASK-CONTRACT-7763732d616972726f62
- Integration task: TASK-INTEGRATION-7763732d616972726f62
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-records: wcs-core → wcs-state

- Drawn payload/purpose: Save and recover orders, tasks, packages and equipment jobs
- Contract task: TASK-CONTRACT-7763732d7265636f726473
- Integration task: TASK-INTEGRATION-7763732d7265636f726473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### clearing-wcs: clearing-workstation → wcs

- Drawn payload/purpose: Clearing tasks, reject parcel identification and operator confirmations
- Contract task: TASK-CONTRACT-636c656172696e672d776373
- Integration task: TASK-INTEGRATION-636c656172696e672d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-host-gateway: wcs-core → host-gateway

- Drawn payload/purpose: Validated work requests in, results and exceptions out
- Contract task: TASK-CONTRACT-7763732d686f73742d67617465776179
- Integration task: TASK-INTEGRATION-7763732d686f73742d67617465776179
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-order-planning: wcs-core → order-planning

- Drawn payload/purpose: Accepted orders and progress in, planned tasks out
- Contract task: TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67
- Integration task: TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### packing-wcs: packing-workstation → wcs

- Drawn payload/purpose: HTTPS packing screen, package confirmations and label requests
- Contract task: TASK-CONTRACT-7061636b696e672d776373
- Integration task: TASK-INTEGRATION-7061636b696e672d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-conveyor: wcs-core → conveyor-controller

- Drawn payload/purpose: Tote routes to manual packing or auto-bagging, arrivals and faults
- Contract task: TASK-CONTRACT-7763732d636f6e7665796f72
- Integration task: TASK-INTEGRATION-7763732d636f6e7665796f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-packing-printers: wcs-core → packing-printers

- Drawn payload/purpose: Package label jobs out, available status and faults in
- Contract task: TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273
- Integration task: TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### rfid-wcs: rfid-readers → wcs-core

- Drawn payload/purpose: Tag reads and reader faults for workstation checks
- Contract task: TASK-CONTRACT-726669642d776373
- Integration task: TASK-INTEGRATION-726669642d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-local-stock-flow: wcs-core → wcs-local-stock

- Drawn payload/purpose: Confirmed stock changes, availability and snapshot requests
- Contract task: TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77
- Integration task: TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### local-stock-records: wcs-local-stock → wcs-state

- Drawn payload/purpose: Save stock by SKU and tote and record reason-coded changes
- Contract task: TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473
- Integration task: TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### manual-consolidation-wcs: manual-consolidation → wcs

- Drawn payload/purpose: Partial-pick handoff and WMS-authorised tote re-induction
- Contract task: TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373
- Integration task: TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### returns-counting-wcs: returns-counting → wcs

- Drawn payload/purpose: Returns induction, stock counts and workstation mode changes
- Contract task: TASK-CONTRACT-72657475726e732d636f756e74696e672d776373
- Integration task: TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### supervisor-wcs: supervisor-console → wcs

- Drawn payload/purpose: Operational status and authorised supervisory actions
- Contract task: TASK-CONTRACT-73757065727669736f722d776373
- Integration task: TASK-INTEGRATION-73757065727669736f722d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-auto-bagging: wcs-core → auto-bagging

- Drawn payload/purpose: Eligible packing work, package outcomes and equipment faults
- Contract task: TASK-CONTRACT-7763732d6175746f2d62616767696e67
- Integration task: TASK-INTEGRATION-7763732d6175746f2d62616767696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-outbound-sortation: wcs-core → outbound-sortation

- Drawn payload/purpose: Shipping label and chute mapping, route and reject feedback
- Contract task: TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e
- Integration task: TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-core-actions: wcs → wcs-core

- Drawn payload/purpose: Authorised workstation actions in, tasks and outcomes back
- Contract task: TASK-CONTRACT-7763732d636f72652d616374696f6e73
- Integration task: TASK-INTEGRATION-7763732d636f72652d616374696f6e73
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Block specifications: Project-wide
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. For a greenfield repository, recommend a language and runtime when team skills, site constraints or integration support make the choice consequential. Keep contracts portable and record the decision before generating language-specific code.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Block specifications: Project-wide
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-646563616e742d776373 — Define Decanting workstation → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: decant-workstation, wcs
- Block specifications: spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection decant-wcs: HTTPS decanting screen and load confirmations. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge decant-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7069636b2d776373 — Define Picking workstation → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: picking-workstation, wcs
- Block specifications: spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection pick-wcs: HTTPS picking screen and pick confirmations. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge pick-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d686f7374 — Define Host integration gateway → Warehouse host system

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: host-gateway, warehouse-host
- Block specifications: spec-kit/blocks/block-686f73742d67617465776179/spec.md, spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-host: Host JSON requests in, results and exceptions out. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-host
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d616972726f62 — Define Core → Libiao AirRob controller

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, libiao-airrob
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-airrob: Tote move jobs out, status and faults in. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-airrob
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d7265636f726473 — Define Core → WCS execution records

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, wcs-state
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-records: Save and recover orders, tasks, packages and equipment jobs. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-records
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-636c656172696e672d776373 — Define Clearing workstation → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: clearing-workstation, wcs
- Block specifications: spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection clearing-wcs: Clearing tasks, reject parcel identification and operator confirmations. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge clearing-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d686f73742d67617465776179 — Define Core → Host integration gateway

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, host-gateway
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-host-gateway: Validated work requests in, results and exceptions out. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-host-gateway
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67 — Define Core → Order planning

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, order-planning
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-order-planning: Accepted orders and progress in, planned tasks out. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-order-planning
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7061636b696e672d776373 — Define Packing workstation → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: packing-workstation, wcs
- Block specifications: spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection packing-wcs: HTTPS packing screen, package confirmations and label requests. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge packing-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d636f6e7665796f72 — Define Core → Conveyor controller

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, conveyor-controller
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-conveyor: Tote routes to manual packing or auto-bagging, arrivals and faults. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-conveyor
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273 — Define Core → Packing label printers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, packing-printers
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-packing-printers: Package label jobs out, available status and faults in. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-packing-printers
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-726669642d776373 — Define RFID readers → Core

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: rfid-readers, wcs-core
- Block specifications: spec-kit/blocks/block-726669642d72656164657273/spec.md, spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection rfid-wcs: Tag reads and reader faults for workstation checks. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge rfid-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77 — Define Core → Local stock tracking

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, wcs-local-stock
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-local-stock-flow: Confirmed stock changes, availability and snapshot requests. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-local-stock-flow
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473 — Define Local stock tracking → WCS execution records

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-local-stock, wcs-state
- Block specifications: spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection local-stock-records: Save stock by SKU and tote and record reason-coded changes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge local-stock-records
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373 — Define Manual consolidation and re-induction → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: manual-consolidation, wcs
- Block specifications: spec-kit/blocks/block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection manual-consolidation-wcs: Partial-pick handoff and WMS-authorised tote re-induction. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge manual-consolidation-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72657475726e732d636f756e74696e672d776373 — Define Returns and stock counts → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: returns-counting, wcs
- Block specifications: spec-kit/blocks/block-72657475726e732d636f756e74696e67/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection returns-counting-wcs: Returns induction, stock counts and workstation mode changes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge returns-counting-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73757065727669736f722d776373 — Define Supervisor console → WCS web server

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: supervisor-console, wcs
- Block specifications: spec-kit/blocks/block-73757065727669736f722d636f6e736f6c65/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection supervisor-wcs: Operational status and authorised supervisory actions. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge supervisor-wcs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d6175746f2d62616767696e67 — Define Core → Auto-bagging equipment

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, auto-bagging
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6175746f2d62616767696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-auto-bagging: Eligible packing work, package outcomes and equipment faults. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-auto-bagging
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e — Define Core → Outbound sortation

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs-core, outbound-sortation
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6f7574626f756e642d736f72746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-outbound-sortation: Shipping label and chute mapping, route and reject feedback. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-outbound-sortation
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7763732d636f72652d616374696f6e73 — Define WCS web server → Core

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: wcs, wcs-core
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection wcs-core-actions: Authorised workstation actions in, tasks and outcomes back. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge wcs-core-actions
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-646563616e742d776f726b73746174696f6e — Implement Decanting workstation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-646563616e742d776373
- Components: decant-workstation
- Block specifications: spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-workstation-flows, ai-wcs-kiosk-web, ai-wcs-rfid-validation

### Implementation steps

1. Read spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Kiosk screen within the shared WCS deployment. Operators identify the inbound item and destination tote, confirm the loaded quantity and flag discrepancies. Where RFID is enabled, display expected and read quantities and require physical checking and an operator confirmation or authorised override before committing a mismatch.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.; REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component decant-workstation
- Application/configuration and tests for Decanting workstation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/testing.md and capture results.

## TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e — Implement Picking workstation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7069636b2d776373
- Components: picking-workstation
- Block specifications: spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-workstation-flows, ai-wcs-kiosk-web, ai-wcs-order-planning, ai-wcs-rfid-validation, ai-wcs-returns-count-modes

### Implementation steps

1. Read spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Kiosk screen within the shared WCS deployment. Show the pick task when the expected tote is available, including the relevant compartment. Record quantity picked and shortages. Where RFID is enabled, show read discrepancies and require physical checking and operator confirmation or an authorised override before committing the outcome.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.; REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.; REQ-014: Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component picking-workstation
- Application/configuration and tests for Picking workstation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/testing.md and capture results.

## TASK-RESOURCE-776373 — Implement WCS web server

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-646563616e742d776373, TASK-CONTRACT-7069636b2d776373, TASK-CONTRACT-636c656172696e672d776373, TASK-CONTRACT-7061636b696e672d776373, TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-CONTRACT-72657475726e732d636f756e74696e672d776373, TASK-CONTRACT-73757065727669736f722d776373, TASK-CONTRACT-7763732d636f72652d616374696f6e73
- Components: wcs
- Block specifications: spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-workstation-flows, ai-wcs-airrob-control, ai-wcs-host-json, ai-wcs-kiosk-web, ai-wcs-conveyor-coordination, ai-wcs-rfid-validation, ai-wcs-supervisor-operations

### Implementation steps

1. Read spec-kit/blocks/block-776373/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Shared WCS deployment serves decanting, picking, clearing, packing, returns, stock counts and supervisor screens over HTTPS. Enforces server-side permissions and passes authorised actions to Core, which runs in the same deployment. Presents workflow state, equipment status and RFID discrepancies, and collects physical-check confirmations or authorised overrides. Hosting remains open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.; REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.; REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.; REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.; REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component wcs
- Application/configuration and tests for WCS web server

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-776373/testing.md and capture results.

## TASK-RESOURCE-7763732d7374617465 — Implement WCS execution records

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d7265636f726473, TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473
- Components: wcs-state
- Block specifications: spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-airrob-control, ai-wcs-host-json, ai-wcs-order-planning, ai-wcs-conveyor-coordination, ai-wcs-local-stock, ai-wcs-rfid-validation, ai-wcs-outbound-sortation, ai-wcs-supervisor-operations, ai-wcs-durable-recovery

### Implementation steps

1. Read spec-kit/blocks/block-7763732d7374617465/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: WCS-owned durable store for order plans, task progress, local stock by SKU and tote, host and equipment identifiers, package and label jobs, operator confirmations, RFID mismatch evidence and supervisor audit records. Reconcile uncertain host, motion or print outcomes before retrying. Retain decisions by authorised operators. Storage technology remains open.
4. Verify Storage or existing data connector on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Storage or existing data connector; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.; REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.; REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.; REQ-013: Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.; REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component wcs-state
- Application/configuration and tests for WCS execution records

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-7763732d7374617465/testing.md and capture results.

## TASK-RESOURCE-77617265686f7573652d686f7374 — Integrate existing Warehouse host system

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d686f7374
- Components: warehouse-host
- Block specifications: spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md
- Generated files: terraform/deployment-ownership.json
- Requirements: ai-wcs-host-json, ai-wcs-local-stock, ai-wcs-manual-handoff

### Implementation steps

1. Read spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Existing warehouse management system (WMS). Owns warehouse-wide inventory and SKU master data. Exchanges JSON work requests, direct transport orders, execution outcomes and exceptions through the host gateway. Receives exceptional stock deltas, manual-consolidation handoffs and requested standstill snapshots, and provides shipping label data for packing. Product, schemas and transport remain open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
6. Preserve this externally managed service without creating or importing it.
7. Document its owner, endpoint, identity and integration contract; test actual connections separately.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.; REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component warehouse-host
- Application/configuration and tests for Warehouse host system

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-77617265686f7573652d686f7374/testing.md and capture results.

## TASK-RESOURCE-6c696269616f2d616972726f62 — Integrate existing Libiao AirRob controller

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d616972726f62
- Components: libiao-airrob
- Block specifications: spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md
- Generated files: terraform/deployment-ownership.json
- Requirements: ai-wcs-airrob-control, ai-wcs-conveyor-coordination, ai-wcs-durable-recovery

### Implementation steps

1. Read spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: External vendor control boundary for AirRob. Proposed exchange sends tote transport jobs and receives job status and faults. Site-specific interface, job identifiers and recovery behavior need vendor evidence.
4. Verify Libiao AirRob on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
6. Preserve this externally managed service without creating or importing it.
7. Document its owner, endpoint, identity and integration contract; test actual connections separately.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.; REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component libiao-airrob
- Application/configuration and tests for Libiao AirRob controller

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-6c696269616f2d616972726f62/testing.md and capture results.

## TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e — Implement Clearing workstation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-636c656172696e672d776373
- Components: clearing-workstation
- Block specifications: spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-kiosk-web, ai-wcs-returns-count-modes

### Implementation steps

1. Read spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Kiosk screen within the shared WCS deployment. Supports clearing tasks and records operator confirmations or exceptions. For sorter rejects, allow parcel identification, destination confirmation and manual clearing. Other clearing scenarios and the effects of their confirmations remain open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-014: Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component clearing-workstation
- Application/configuration and tests for Clearing workstation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/testing.md and capture results.

## TASK-RESOURCE-686f73742d67617465776179 — Implement Host integration gateway

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d686f7374, TASK-CONTRACT-7763732d686f73742d67617465776179
- Components: host-gateway
- Block specifications: spec-kit/blocks/block-686f73742d67617465776179/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-order-planning, ai-wcs-packing-labels, ai-wcs-local-stock, ai-wcs-manual-handoff, ai-wcs-durable-recovery

### Implementation steps

1. Read spec-kit/blocks/block-686f73742d67617465776179/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: WCS-owned integration component. Validates and maps host JSON for order start and cancellation, SKU changes, direct transport orders, label data and snapshot requests. Returns planning and execution milestones, exceptions, manual-consolidation handoffs, quantity deltas and snapshots. Use stable identifiers and durable tracking of accepted requests and pending results to prevent duplicate or lost work through retries and restarts. Exact host contract, acknowledgements, authentication and deployment boundary remain open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component host-gateway
- Application/configuration and tests for Host integration gateway

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-686f73742d67617465776179/testing.md and capture results.

## TASK-RESOURCE-6f726465722d706c616e6e696e67 — Implement Order planning

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67
- Components: order-planning
- Block specifications: spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-order-planning, ai-wcs-packing-labels, ai-wcs-supervisor-operations

### Implementation steps

1. Read spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Module within the WCS application. Plans internal work from WMS start instructions using agreed priorities, finishing times and readiness rules. Accepts cancellation only before planning begins. Batches eligible single-SKU single-item orders under configurable rules and preserves order and item identity against each tote compartment. Audits operator overrides and emits planning-started, picked and execution-completed outcomes through the gateway. Stock allocation rules and batching thresholds remain open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component order-planning
- Application/configuration and tests for Order planning

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-6f726465722d706c616e6e696e67/testing.md and capture results.

## TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e — Implement Packing workstation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7061636b696e672d776373
- Components: packing-workstation
- Block specifications: spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-packing-labels, ai-wcs-manual-handoff

### Implementation steps

1. Read spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Manual packing kiosk within the shared WCS deployment, including for ineligible or oversized work and fully manually picked orders. Verify the tote and compartment against current expected contents, including revisions from manual consolidation. Confirm package contents and request the WMS-supplied shipping label linked to the order and package. Record uncertain print outcomes and require an authorised reason for reprints. The exact completion trigger remains open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component packing-workstation
- Application/configuration and tests for Packing workstation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/testing.md and capture results.

## TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572 — Implement Conveyor controller

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d636f6e7665796f72
- Components: conveyor-controller
- Block specifications: spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-conveyor-coordination, ai-wcs-manual-handoff, ai-wcs-outbound-sortation, ai-wcs-durable-recovery

### Implementation steps

1. Read spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Proposed site equipment integration boundary. The WCS requests routing and consumes arrival, availability and fault events through a supported interface. The controller owns motion, interlocks and emergency stops. Controller product, ownership, interface and recovery behaviour remain open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.; REQ-013: Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component conveyor-controller
- Application/configuration and tests for Conveyor controller

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/testing.md and capture results.

## TASK-RESOURCE-7061636b696e672d7072696e74657273 — Implement Packing label printers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273
- Components: packing-printers
- Block specifications: spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-packing-labels, ai-wcs-durable-recovery

### Implementation steps

1. Read spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Proposed site print integration boundary for packing stations. The WCS sends package-linked label jobs and records job acknowledgements or faults where supported. The packing screen shows uncertain outcomes and supports controlled reprints. Printer ownership, interface, label formats and status capabilities remain open.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component packing-printers
- Application/configuration and tests for Packing label printers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-7061636b696e672d7072696e74657273/testing.md and capture results.

## TASK-RESOURCE-726669642d72656164657273 — Implement RFID readers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-726669642d776373
- Components: rfid-readers
- Block specifications: spec-kit/blocks/block-726669642d72656164657273/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: ai-wcs-rfid-validation

### Implementation steps

1. Read spec-kit/blocks/block-726669642d72656164657273/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Proposed on-site reader equipment at RFID-enabled workstations. Supply tagged-item observations and reader health to WCS with enough context to associate each read with the correct workstation and task. Qualify tag-to-SKU identification, reader placement, read stability and filtering of nearby tags with real totes. Reader model, exact locations, interface and ownership remain open. WCS owns validation and the manual fallback.
4. Verify Ingestion / processing service on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Ingestion / processing service; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component rfid-readers
- Application/configuration and tests for RFID readers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-726669642d72656164657273/testing.md and capture results.

## TASK-RESOURCE-7763732d6c6f63616c2d73746f636b — Implement Local stock tracking

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473
- Components: wcs-local-stock
- Block specifications: spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Module within the shared WCS application. Tracks stock by SKU, stock properties and tote using WCS execution records. Reports exceptional quantity deltas with reason codes and returns WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Acknowledges SKU retirement once stock and order references clear. Temporary unavailability stays local. Its treatment in snapshots remains open. WMS owns warehouse-wide inventory and SKU master data.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component wcs-local-stock
- Application/configuration and tests for Local stock tracking

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/testing.md and capture results.

## TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e — Implement Manual consolidation and re-induction

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373
- Components: manual-consolidation
- Block specifications: spec-kit/blocks/block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Workflow within the shared WCS deployment. When a partially picked tote goes to manual consolidation, report its contents to WMS. Accept a manually completed or fully manually picked tote back into WCS only against a WMS direct transport order linking tote, order, destination, revised quantities and additions or shortages. Pass the revised expected contents to packing.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component manual-consolidation
- Application/configuration and tests for Manual consolidation and re-induction

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-6d616e75616c2d636f6e736f6c69646174696f6e/testing.md and capture results.

## TASK-RESOURCE-72657475726e732d636f756e74696e67 — Implement Returns and stock counts

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72657475726e732d636f756e74696e672d776373
- Components: returns-counting
- Block specifications: spec-kit/blocks/block-72657475726e732d636f756e74696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-72657475726e732d636f756e74696e67/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Workstation workflows within the shared WCS deployment. Record inspected mixed returns and operator-confirmed off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote, with manual checking when RFID readings are unreliable. Before switching between picking, counting and clearing, stop new allocations and let assigned work finish.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component returns-counting
- Application/configuration and tests for Returns and stock counts

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-72657475726e732d636f756e74696e67/testing.md and capture results.

## TASK-RESOURCE-73757065727669736f722d636f6e736f6c65 — Implement Supervisor console

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73757065727669736f722d776373
- Components: supervisor-console
- Block specifications: spec-kit/blocks/block-73757065727669736f722d636f6e736f6c65/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-73757065727669736f722d636f6e736f6c65/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Screen within the shared WCS deployment. Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. WCS authorises and audits changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component supervisor-console
- Application/configuration and tests for Supervisor console

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-73757065727669736f722d636f6e736f6c65/testing.md and capture results.

## TASK-RESOURCE-6175746f2d62616767696e67 — Implement Auto-bagging equipment

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d6175746f2d62616767696e67
- Components: auto-bagging
- Block specifications: spec-kit/blocks/block-6175746f2d62616767696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-6175746f2d62616767696e67/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Site equipment boundary for automatic packing. WCS proposes routing eligible single-item batches and multi-item orders here through the conveyor controller and diverting ineligible or oversized work to manual packing. Correlate supported packing results and faults with the correct package and order. Bagging interface, arrival and completion signals, eligibility rules and label handoff require site evidence.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component auto-bagging
- Application/configuration and tests for Auto-bagging equipment

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-6175746f2d62616767696e67/testing.md and capture results.

## TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e — Implement Outbound sortation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e
- Components: outbound-sortation
- Block specifications: spec-kit/blocks/block-6f7574626f756e642d736f72746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-6f7574626f756e642d736f72746174696f6e/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Site sorter and WCS integration boundary. WCS maps shipping-label identifiers to logical destinations and physical chutes, and records the booked route and available actual-route feedback. Send full-chute overflow to reject without recirculation. At the clearing screen, allow operators to identify rejected parcels, confirm destinations and record manual clearing. Confirm equipment event and routing contracts on site.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component outbound-sortation
- Application/configuration and tests for Outbound sortation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-6f7574626f756e642d736f72746174696f6e/testing.md and capture results.

## TASK-RESOURCE-7763732d636f7265 — Implement Core

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7763732d616972726f62, TASK-CONTRACT-7763732d7265636f726473, TASK-CONTRACT-7763732d686f73742d67617465776179, TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67, TASK-CONTRACT-7763732d636f6e7665796f72, TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273, TASK-CONTRACT-726669642d776373, TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-CONTRACT-7763732d6175746f2d62616767696e67, TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e, TASK-CONTRACT-7763732d636f72652d616374696f6e73
- Components: wcs-core
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read spec-kit/blocks/block-7763732d636f7265/spec.md and follow its implementation, boundary and recovery contract.
2. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
3. Responsibility from the board: Business logic module within the shared WCS web server deployment. Owns order planning, task and workflow state, local stock tracking, RFID validation and manual discrepancy resolution, returns, counting, manual consolidation and re-induction, packing and label rules, outbound sortation and supervisor actions. Coordinates AirRob tote moves, conveyor routing, auto-bagging, printing and sorter operations through site interfaces. Equipment controllers retain motion and safety control. Persists execution and audit records, reconciles uncertain outcomes before retrying, and exchanges work, results and exceptions with the WMS through the host gateway.
4. Verify Application runtime and API on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
5. Implement the provider-native infrastructure for Application runtime and API; determine exact resource types and required application code. The export has not generated this implementation.
6. Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
7. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
8. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
9. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
10. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
11. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component wcs-core
- Application/configuration and tests for Core

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.
- Run the proposed acceptance cases in spec-kit/blocks/block-7763732d636f7265/testing.md and capture results.

## TASK-INTEGRATION-646563616e742d776373 — Wire Decanting workstation to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-646563616e742d776373, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-RESOURCE-776373
- Components: decant-workstation, wcs
- Block specifications: spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge decant-wcs carrying HTTPS decanting screen and load confirmations, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation decant-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7069636b2d776373 — Wire Picking workstation to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7069636b2d776373, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-776373
- Components: picking-workstation, wcs
- Block specifications: spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge pick-wcs carrying HTTPS picking screen and pick confirmations, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation pick-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d686f7374 — Wire Host integration gateway to Warehouse host system

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d686f7374, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-RESOURCE-686f73742d67617465776179
- Components: host-gateway, warehouse-host
- Block specifications: spec-kit/blocks/block-686f73742d67617465776179/spec.md, spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-host carrying Host JSON requests in, results and exceptions out, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-host
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d616972726f62 — Wire Core to Libiao AirRob controller

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d616972726f62, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, libiao-airrob
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-airrob carrying Tote move jobs out, status and faults in, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-airrob
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d7265636f726473 — Wire Core to WCS execution records

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d7265636f726473, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, wcs-state
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-records carrying Save and recover orders, tasks, packages and equipment jobs, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-records
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-636c656172696e672d776373 — Wire Clearing workstation to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-636c656172696e672d776373, TASK-RESOURCE-776373, TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e
- Components: clearing-workstation, wcs
- Block specifications: spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge clearing-wcs carrying Clearing tasks, reject parcel identification and operator confirmations, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation clearing-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d686f73742d67617465776179 — Wire Core to Host integration gateway

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d686f73742d67617465776179, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, host-gateway
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-host-gateway carrying Validated work requests in, results and exceptions out, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-host-gateway
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67 — Wire Core to Order planning

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, order-planning
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-order-planning carrying Accepted orders and progress in, planned tasks out, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-order-planning
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7061636b696e672d776373 — Wire Packing workstation to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7061636b696e672d776373, TASK-RESOURCE-776373, TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e
- Components: packing-workstation, wcs
- Block specifications: spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge packing-wcs carrying HTTPS packing screen, package confirmations and label requests, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation packing-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d636f6e7665796f72 — Wire Core to Conveyor controller

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d636f6e7665796f72, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, conveyor-controller
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-conveyor carrying Tote routes to manual packing or auto-bagging, arrivals and faults, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-conveyor
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273 — Wire Core to Packing label printers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273, TASK-RESOURCE-7061636b696e672d7072696e74657273, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, packing-printers
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-packing-printers carrying Package label jobs out, available status and faults in, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-packing-printers
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-726669642d776373 — Wire RFID readers to Core

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-726669642d776373, TASK-RESOURCE-726669642d72656164657273, TASK-RESOURCE-7763732d636f7265
- Components: rfid-readers, wcs-core
- Block specifications: spec-kit/blocks/block-726669642d72656164657273/spec.md, spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge rfid-wcs carrying Tag reads and reader faults for workstation checks, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation rfid-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77 — Wire Core to Local stock tracking

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-RESOURCE-7763732d6c6f63616c2d73746f636b, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, wcs-local-stock
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-local-stock-flow carrying Confirmed stock changes, availability and snapshot requests, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-local-stock-flow
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473 — Wire Local stock tracking to WCS execution records

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-7763732d6c6f63616c2d73746f636b
- Components: wcs-local-stock, wcs-state
- Block specifications: spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge local-stock-records carrying Save stock by SKU and tote and record reason-coded changes, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation local-stock-records
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373 — Wire Manual consolidation and re-induction to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-RESOURCE-776373, TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e
- Components: manual-consolidation, wcs
- Block specifications: spec-kit/blocks/block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge manual-consolidation-wcs carrying Partial-pick handoff and WMS-authorised tote re-induction, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation manual-consolidation-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373 — Wire Returns and stock counts to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72657475726e732d636f756e74696e672d776373, TASK-RESOURCE-776373, TASK-RESOURCE-72657475726e732d636f756e74696e67
- Components: returns-counting, wcs
- Block specifications: spec-kit/blocks/block-72657475726e732d636f756e74696e67/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge returns-counting-wcs carrying Returns induction, stock counts and workstation mode changes, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation returns-counting-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73757065727669736f722d776373 — Wire Supervisor console to WCS web server

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73757065727669736f722d776373, TASK-RESOURCE-776373, TASK-RESOURCE-73757065727669736f722d636f6e736f6c65
- Components: supervisor-console, wcs
- Block specifications: spec-kit/blocks/block-73757065727669736f722d636f6e736f6c65/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge supervisor-wcs carrying Operational status and authorised supervisory actions, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation supervisor-wcs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d6175746f2d62616767696e67 — Wire Core to Auto-bagging equipment

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d6175746f2d62616767696e67, TASK-RESOURCE-6175746f2d62616767696e67, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, auto-bagging
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6175746f2d62616767696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-auto-bagging carrying Eligible packing work, package outcomes and equipment faults, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-auto-bagging
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e — Wire Core to Outbound sortation

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e, TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e, TASK-RESOURCE-7763732d636f7265
- Components: wcs-core, outbound-sortation
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6f7574626f756e642d736f72746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-outbound-sortation carrying Shipping label and chute mapping, route and reject feedback, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-outbound-sortation
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7763732d636f72652d616374696f6e73 — Wire WCS web server to Core

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7763732d636f72652d616374696f6e73, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d636f7265
- Components: wcs, wcs-core
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge wcs-core-actions carrying Authorised workstation actions in, tasks and outcomes back, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation wcs-core-actions
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-646563616e742d776373 — Verify live Decanting workstation → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-646563616e742d776373
- Components: decant-workstation, wcs
- Block specifications: spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge decant-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence decant-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7069636b2d776373 — Verify live Picking workstation → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7069636b2d776373
- Components: picking-workstation, wcs
- Block specifications: spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge pick-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence pick-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d686f7374 — Verify live Host integration gateway → Warehouse host system

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d686f7374
- Components: host-gateway, warehouse-host
- Block specifications: spec-kit/blocks/block-686f73742d67617465776179/spec.md, spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-host with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-host

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d616972726f62 — Verify live Core → Libiao AirRob controller

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d616972726f62
- Components: wcs-core, libiao-airrob
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-airrob with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-airrob

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d7265636f726473 — Verify live Core → WCS execution records

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d7265636f726473
- Components: wcs-core, wcs-state
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-records with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-records

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-636c656172696e672d776373 — Verify live Clearing workstation → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-636c656172696e672d776373
- Components: clearing-workstation, wcs
- Block specifications: spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge clearing-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence clearing-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179 — Verify live Core → Host integration gateway

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d686f73742d67617465776179
- Components: wcs-core, host-gateway
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-host-gateway with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-host-gateway

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67 — Verify live Core → Order planning

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67
- Components: wcs-core, order-planning
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-order-planning with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-order-planning

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7061636b696e672d776373 — Verify live Packing workstation → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7061636b696e672d776373
- Components: packing-workstation, wcs
- Block specifications: spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge packing-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence packing-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72 — Verify live Core → Conveyor controller

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d636f6e7665796f72
- Components: wcs-core, conveyor-controller
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-conveyor with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-conveyor

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273 — Verify live Core → Packing label printers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273
- Components: wcs-core, packing-printers
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-packing-printers with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-packing-printers

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-726669642d776373 — Verify live RFID readers → Core

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-726669642d776373
- Components: rfid-readers, wcs-core
- Block specifications: spec-kit/blocks/block-726669642d72656164657273/spec.md, spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge rfid-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence rfid-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d6c6f63616c2d73746f636b2d666c6f77 — Verify live Core → Local stock tracking

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77
- Components: wcs-core, wcs-local-stock
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-local-stock-flow with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-local-stock-flow

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473 — Verify live Local stock tracking → WCS execution records

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473
- Components: wcs-local-stock, wcs-state
- Block specifications: spec-kit/blocks/block-7763732d6c6f63616c2d73746f636b/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge local-stock-records with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence local-stock-records

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373 — Verify live Manual consolidation and re-induction → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373
- Components: manual-consolidation, wcs
- Block specifications: spec-kit/blocks/block-6d616e75616c2d636f6e736f6c69646174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge manual-consolidation-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence manual-consolidation-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373 — Verify live Returns and stock counts → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373
- Components: returns-counting, wcs
- Block specifications: spec-kit/blocks/block-72657475726e732d636f756e74696e67/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge returns-counting-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence returns-counting-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73757065727669736f722d776373 — Verify live Supervisor console → WCS web server

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73757065727669736f722d776373
- Components: supervisor-console, wcs
- Block specifications: spec-kit/blocks/block-73757065727669736f722d636f6e736f6c65/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge supervisor-wcs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence supervisor-wcs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d6175746f2d62616767696e67 — Verify live Core → Auto-bagging equipment

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d6175746f2d62616767696e67
- Components: wcs-core, auto-bagging
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6175746f2d62616767696e67/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-auto-bagging with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-auto-bagging

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d6f7574626f756e642d736f72746174696f6e — Verify live Core → Outbound sortation

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e
- Components: wcs-core, outbound-sortation
- Block specifications: spec-kit/blocks/block-7763732d636f7265/spec.md, spec-kit/blocks/block-6f7574626f756e642d736f72746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-outbound-sortation with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-outbound-sortation

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73 — Verify live WCS web server → Core

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7763732d636f72652d616374696f6e73
- Components: wcs, wcs-core
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-7763732d636f7265/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge wcs-core-actions with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence wcs-core-actions

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773 — Verify REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-776373, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: decant-workstation, picking-workstation, wcs
- Block specifications: spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-776373/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-workstation-flows

### Implementation steps

1. Basis: User statement: I need a webserver to run decanting and picking and clearing in kiosk mode; rationale: Clearing is now explicit workstation scope. Its business rules need to be defined before implementation.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c — Verify REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: wcs, libiao-airrob, wcs-state
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-airrob-control

### Implementation steps

1. Basis: The user asked for a WCS controlling Libiao AirRob. Tote jobs and status tracking are proposed responsibilities.; rationale: The WCS needs to match each move to warehouse work and account for failures before advancing the task.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e — Verify REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: warehouse-host, wcs, wcs-state
- Block specifications: spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md, spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-host-json

### Implementation steps

1. Basis: User statement: we need a gateway connecting wcs to host system; rationale: The gateway provides a single host integration boundary. Stable identifiers let the WCS recognize repeated requests and avoid creating duplicate warehouse work.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562 — Verify REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-776373, TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: wcs, decant-workstation, picking-workstation, clearing-workstation
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-kiosk-web

### Implementation steps

1. Basis: The user requested a webserver for decanting, picking and clearing in kiosk mode. Per-workstation assignment and server-side permission checks are proposed controls.; rationale: A workstation should open directly to its assigned workflow. Server-side checks prevent a kiosk session from using actions beyond its permissions.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67 — Verify REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473
- Components: order-planning, picking-workstation, wcs-state, host-gateway
- Block specifications: spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md, spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-order-planning

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, Compartment selection, Order planning and Order fulfilment.; rationale: Keeps individual orders identifiable through shared-tote picking, packing and label printing.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e — Verify REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: wcs, conveyor-controller, wcs-state, libiao-airrob
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md, spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-conveyor-coordination

### Implementation steps

1. Basis: The user requested conveyor management. Routing and fault handling through the site controller are proposed boundaries.; rationale: Arrival and fault feedback let the WCS hold affected work when a tote is delayed, a conveyor is blocked or a move outcome is uncertain.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73 — Verify REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e, TASK-RESOURCE-7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273
- Components: order-planning, packing-workstation, packing-printers, host-gateway
- Block specifications: spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md, spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-packing-labels

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, Conveying to packing and Packing. The preceding board has an open controlled-reprint requirement.; rationale: Preserves package identity when work changes packing route or a print outcome is uncertain.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-009

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b — Verify REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-RESOURCE-686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473
- Components: wcs-state, host-gateway, warehouse-host
- Block specifications: spec-kit/blocks/block-7763732d7374617465/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md, spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-local-stock

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, SKU master data management, Stock management and Stock reconciliation.; rationale: Keeps the WMS inventory record aligned with execution while allowing the WCS to manage individual totes.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-010

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e — Verify REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-726669642d72656164657273, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-726669642d776373, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: rfid-readers, wcs, wcs-state, decant-workstation, picking-workstation
- Block specifications: spec-kit/blocks/block-726669642d72656164657273/spec.md, spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md, spec-kit/blocks/block-646563616e742d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-rfid-validation

### Implementation steps

1. Basis: Existing REQ-011 and the user’s request to show RFID on the board.; rationale: Prevents stray reads, missed tags and unstable counts from silently changing confirmed inventory or order quantities.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-011

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666 — Verify REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72
- Components: conveyor-controller, host-gateway, warehouse-host, packing-workstation
- Block specifications: spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md, spec-kit/blocks/block-77617265686f7573652d686f7374/spec.md, spec-kit/blocks/block-7061636b696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-manual-handoff

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, Partial orders and manual completion and Transport orders.; rationale: Prevents stale quantities from being used when manually picked items reach packing.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-012

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e — Verify REQ-013: Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473
- Components: conveyor-controller, wcs-state
- Block specifications: spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-outbound-sortation

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, Sortation and conveying, Chute overflow and clearing, and End-of-chute bin handling.; rationale: Prevents overflow from recirculating and lets operators complete routing of affected parcels.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-013

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573 — Verify REQ-014: Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-636c656172696e672d776373
- Components: picking-workstation, clearing-workstation
- Block specifications: spec-kit/blocks/block-7069636b696e672d776f726b73746174696f6e/spec.md, spec-kit/blocks/block-636c656172696e672d776f726b73746174696f6e/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-returns-count-modes

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, Inventory – Cycle counting, Inventory – Returns housekeeping and GTP modes.; rationale: Maintains accurate counts and prevents a mode switch from stranding assigned work.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-014

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73 — Verify REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: wcs, order-planning, wcs-state
- Block specifications: spec-kit/blocks/block-776373/spec.md, spec-kit/blocks/block-6f726465722d706c616e6e696e67/spec.md, spec-kit/blocks/block-7763732d7374617465/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-supervisor-operations

### Implementation steps

1. Basis: LSKD TAL WCS OCD Customer_v1.docx, WCS supervisor application and Reporting. Server-side role checks and audit are proposed engineering controls consistent with the kiosk permission boundary.; rationale: Gives supervisors operational control with accountability for changes that affect work or stock.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-015

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279 — Verify REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-RESOURCE-7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473
- Components: wcs-state, host-gateway, libiao-airrob, conveyor-controller, packing-printers
- Block specifications: spec-kit/blocks/block-7763732d7374617465/spec.md, spec-kit/blocks/block-686f73742d67617465776179/spec.md, spec-kit/blocks/block-6c696269616f2d616972726f62/spec.md, spec-kit/blocks/block-636f6e7665796f722d636f6e74726f6c6c6572/spec.md, spec-kit/blocks/block-7061636b696e672d7072696e74657273/spec.md
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-wcs-durable-recovery

### Implementation steps

1. Basis: Proposed recovery requirement derived from the board's WCS execution records and the OCD's host and equipment handoffs.; rationale: Prevents duplicate moves, stock adjustments or labels after a timeout or restart.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-016

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-RESOURCE-7061636b696e672d7072696e74657273, TASK-RESOURCE-726669642d72656164657273, TASK-RESOURCE-7763732d6c6f63616c2d73746f636b, TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e, TASK-RESOURCE-72657475726e732d636f756e74696e67, TASK-RESOURCE-73757065727669736f722d636f6e736f6c65, TASK-RESOURCE-6175746f2d62616767696e67, TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e, TASK-RESOURCE-7763732d636f7265, TASK-INTEGRATION-646563616e742d776373, TASK-INTEGRATION-7069636b2d776373, TASK-INTEGRATION-7763732d686f7374, TASK-INTEGRATION-7763732d616972726f62, TASK-INTEGRATION-7763732d7265636f726473, TASK-INTEGRATION-636c656172696e672d776373, TASK-INTEGRATION-7763732d686f73742d67617465776179, TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-7061636b696e672d776373, TASK-INTEGRATION-7763732d636f6e7665796f72, TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-726669642d776373, TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-73757065727669736f722d776373, TASK-INTEGRATION-7763732d6175746f2d62616767696e67, TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-7763732d636f72652d616374696f6e73
- Components: project-wide
- Block specifications: Project-wide
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-646563616e742d776f726b73746174696f6e, TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e, TASK-RESOURCE-776373, TASK-RESOURCE-7763732d7374617465, TASK-RESOURCE-77617265686f7573652d686f7374, TASK-RESOURCE-6c696269616f2d616972726f62, TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e, TASK-RESOURCE-686f73742d67617465776179, TASK-RESOURCE-6f726465722d706c616e6e696e67, TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e, TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572, TASK-RESOURCE-7061636b696e672d7072696e74657273, TASK-RESOURCE-726669642d72656164657273, TASK-RESOURCE-7763732d6c6f63616c2d73746f636b, TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e, TASK-RESOURCE-72657475726e732d636f756e74696e67, TASK-RESOURCE-73757065727669736f722d636f6e736f6c65, TASK-RESOURCE-6175746f2d62616767696e67, TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e, TASK-RESOURCE-7763732d636f7265, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-726669642d776373, TASK-INTEGRATION-LIVE-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d6175746f2d62616767696e67, TASK-INTEGRATION-LIVE-7763732d6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773, TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c, TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e, TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562, TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67, TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e, TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73, TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b, TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e, TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666, TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e, TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573, TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73, TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279, TASK-INTEGRATION-LIVE-646563616e742d776373, TASK-INTEGRATION-LIVE-7069636b2d776373, TASK-INTEGRATION-LIVE-7763732d686f7374, TASK-INTEGRATION-LIVE-7763732d616972726f62, TASK-INTEGRATION-LIVE-7763732d7265636f726473, TASK-INTEGRATION-LIVE-636c656172696e672d776373, TASK-INTEGRATION-LIVE-7763732d686f73742d67617465776179, TASK-INTEGRATION-LIVE-7763732d6f726465722d706c616e6e696e67, TASK-INTEGRATION-LIVE-7061636b696e672d776373, TASK-INTEGRATION-LIVE-7763732d636f6e7665796f72, TASK-INTEGRATION-LIVE-7763732d7061636b696e672d7072696e74657273, TASK-INTEGRATION-LIVE-726669642d776373, TASK-INTEGRATION-LIVE-7763732d6c6f63616c2d73746f636b2d666c6f77, TASK-INTEGRATION-LIVE-6c6f63616c2d73746f636b2d7265636f726473, TASK-INTEGRATION-LIVE-6d616e75616c2d636f6e736f6c69646174696f6e2d776373, TASK-INTEGRATION-LIVE-72657475726e732d636f756e74696e672d776373, TASK-INTEGRATION-LIVE-73757065727669736f722d776373, TASK-INTEGRATION-LIVE-7763732d6175746f2d62616767696e67, TASK-INTEGRATION-LIVE-7763732d6f7574626f756e642d736f72746174696f6e, TASK-INTEGRATION-LIVE-7763732d636f72652d616374696f6e73
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: I want to build a wcs system controlling libiao airrob has ui has workstation decanting and picking connects to host using json
we need a gateway connecting wcs to host system
we need to have business logic about order planning managing conveyor systems and printers packing
use this and check the diagrams add more needex
I CANNOT SEE ANY CHANGES TO THE. OARD VERSHER IS RFID
we want the biz logics to be in one blcok call it core can we have nested blocks
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Block specifications: Project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-003 (ai-wcs-workstation-flows) → TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773; Recorded from user discussion
- REQ-004 (ai-wcs-airrob-control) → TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c; Proposed; needs confirmation
- REQ-005 (ai-wcs-host-json) → TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e; Recorded from user discussion
- REQ-006 (ai-wcs-kiosk-web) → TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562; Proposed; needs confirmation
- REQ-007 (ai-wcs-order-planning) → TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67; Proposed; needs confirmation
- REQ-008 (ai-wcs-conveyor-coordination) → TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e; Proposed; needs confirmation
- REQ-009 (ai-wcs-packing-labels) → TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73; Proposed; needs confirmation
- REQ-010 (ai-wcs-local-stock) → TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b; Proposed; needs confirmation
- REQ-011 (ai-wcs-rfid-validation) → TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e; Proposed; needs confirmation
- REQ-012 (ai-wcs-manual-handoff) → TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666; Proposed; needs confirmation
- REQ-013 (ai-wcs-outbound-sortation) → TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e; Proposed; needs confirmation
- REQ-014 (ai-wcs-returns-count-modes) → TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573; Proposed; needs confirmation
- REQ-015 (ai-wcs-supervisor-operations) → TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73; Proposed; needs confirmation
- REQ-016 (ai-wcs-durable-recovery) → TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279; Proposed; needs confirmation
