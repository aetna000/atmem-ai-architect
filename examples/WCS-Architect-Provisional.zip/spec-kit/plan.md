# Implementation Spec Kit

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

21 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

I want to build a wcs system controlling libiao airrob has ui has workstation decanting and picking connects to host using json
we need a gateway connecting wcs to host system
we need to have business logic about order planning managing conveyor systems and printers packing
use this and check the diagrams add more needex
I CANNOT SEE ANY CHANGES TO THE. OARD VERSHER IS RFID
we want the biz logics to be in one blcok call it core can we have nested blocks

## Confirmed design decisions

- design.first-sketch-of-the-airrob-warehouse-control-system: Drawn while talking as design revision 2.
- design.serve-all-three-workstation-workflows-in-kiosk-mode: Drawn while talking as design revision 92.
- design.add-the-warehouse-host-gateway: Drawn while talking as design revision 93.
- design.add-order-planning-conveyor-coordination-and-packing: Drawn while talking as design revision 94.
- design.show-rfid-and-complete-the-recorded-warehouse-workflows: Drawn while talking as design revision 98.
- design.group-wcs-business-logic-under-core: Drawn while talking as design revision 100.

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Decanting workstation (decant-workstation): Implementation needed; tools, To be selected.
- Picking workstation (picking-workstation): Implementation needed; tools, To be selected.
- WCS web server (wcs): Implementation needed; tools, To be selected.
- WCS execution records (wcs-state): Implementation needed; tools, To be selected.
- Warehouse host system (warehouse-host): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, To be selected.
- Libiao AirRob controller (libiao-airrob): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, To be selected.
- Clearing workstation (clearing-workstation): Implementation needed; tools, To be selected.
- Host integration gateway (host-gateway): Implementation needed; tools, To be selected.
- Order planning (order-planning): Implementation needed; tools, To be selected.
- Packing workstation (packing-workstation): Implementation needed; tools, To be selected.
- Conveyor controller (conveyor-controller): Implementation needed; tools, To be selected.
- Packing label printers (packing-printers): Implementation needed; tools, To be selected.
- RFID readers (rfid-readers): Implementation needed; tools, To be selected.
- Local stock tracking (wcs-local-stock): Implementation needed; tools, To be selected.
- Manual consolidation and re-induction (manual-consolidation): Implementation needed; tools, To be selected.
- Returns and stock counts (returns-counting): Implementation needed; tools, To be selected.
- Supervisor console (supervisor-console): Implementation needed; tools, To be selected.
- Auto-bagging equipment (auto-bagging): Implementation needed; tools, To be selected.
- Outbound sortation (outbound-sortation): Implementation needed; tools, To be selected.
- Core (wcs-core): Implementation needed; tools, To be selected.

## How to use this kit

Read contracts.md, tasks.md and [Component Spec Kits](blocks/README.md). Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
