Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d31 — priority 1

Which system or role is authorised to release a held tote after WMS and equipment outcomes disagree?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d32 — priority 1

Who can provide the current WMS JSON schemas, sample exchanges and the authoritative acknowledgement and replay rules?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d33 — priority 1

Which AirRob interface and job status lookup does the site support, and who can supply its official contract and simulator?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d34 — priority 1

Which clearing workflows beyond sorter rejects belong in first release, and what should each confirmation trigger?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d35 — priority 1

Which priority, readiness, batching and finishing-time rules are required at launch?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d36 — priority 1

How should temporary stock unavailability appear in a standstill snapshot?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d37 — priority 1

What event marks manual packing complete, and which role can authorise a reprint?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### question-7763732d646973636f766572792d38 — priority 1

Where must WCS run, and what availability, recovery and site-network constraints apply?

Action: Resolve or explicitly defer this question with an owner and affected tasks.

Tasks: TASK-SCOPE

### requirement-proposed-61692d7763732d616972726f622d636f6e74726f6c — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c

### requirement-proposed-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e

### requirement-proposed-61692d7763732d64757261626c652d7265636f76657279 — priority 1

REQ-016 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

### requirement-proposed-61692d7763732d6b696f736b2d776562 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562

### requirement-proposed-61692d7763732d6c6f63616c2d73746f636b — priority 1

REQ-010 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b

### requirement-proposed-61692d7763732d6d616e75616c2d68616e646f6666 — priority 1

REQ-012 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666

### requirement-proposed-61692d7763732d6f726465722d706c616e6e696e67 — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67

### requirement-proposed-61692d7763732d6f7574626f756e642d736f72746174696f6e — priority 1

REQ-013 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e

### requirement-proposed-61692d7763732d7061636b696e672d6c6162656c73 — priority 1

REQ-009 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73

### requirement-proposed-61692d7763732d72657475726e732d636f756e742d6d6f646573 — priority 1

REQ-014 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573

### requirement-proposed-61692d7763732d726669642d76616c69646174696f6e — priority 1

REQ-011 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e

### requirement-proposed-61692d7763732d73757065727669736f722d6f7065726174696f6e73 — priority 1

REQ-015 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73

### placement-6175746f2d62616767696e67 — priority 2

Auto-bagging equipment: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6175746f2d62616767696e67

### placement-636c656172696e672d776f726b73746174696f6e — priority 2

Clearing workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e

### placement-636f6e7665796f722d636f6e74726f6c6c6572 — priority 2

Conveyor controller: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572

### placement-646563616e742d776f726b73746174696f6e — priority 2

Decanting workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-646563616e742d776f726b73746174696f6e

### placement-686f73742d67617465776179 — priority 2

Host integration gateway: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-686f73742d67617465776179

### placement-6d616e75616c2d636f6e736f6c69646174696f6e — priority 2

Manual consolidation and re-induction: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e

### placement-6f726465722d706c616e6e696e67 — priority 2

Order planning: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6f726465722d706c616e6e696e67

### placement-6f7574626f756e642d736f72746174696f6e — priority 2

Outbound sortation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e

### placement-7061636b696e672d7072696e74657273 — priority 2

Packing label printers: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7061636b696e672d7072696e74657273

### placement-7061636b696e672d776f726b73746174696f6e — priority 2

Packing workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e

### placement-7069636b696e672d776f726b73746174696f6e — priority 2

Picking workstation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e

### placement-72657475726e732d636f756e74696e67 — priority 2

Returns and stock counts: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-72657475726e732d636f756e74696e67

### placement-726669642d72656164657273 — priority 2

RFID readers: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-726669642d72656164657273

### placement-73757065727669736f722d636f6e736f6c65 — priority 2

Supervisor console: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-73757065727669736f722d636f6e736f6c65

### placement-776373 — priority 2

WCS web server: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-776373

### placement-7763732d636f7265 — priority 2

Core: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7763732d636f7265

### placement-7763732d6c6f63616c2d73746f636b — priority 2

Local stock tracking: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7763732d6c6f63616c2d73746f636b

### placement-7763732d7374617465 — priority 2

WCS execution records: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-7763732d7374617465

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

20 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d7763732d616972726f622d636f6e74726f6c — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d616972726f622d636f6e74726f6c

### acceptance-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d636f6e7665796f722d636f6f7264696e6174696f6e

### acceptance-61692d7763732d64757261626c652d7265636f76657279 — priority 2

REQ-016: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d64757261626c652d7265636f76657279

### acceptance-61692d7763732d686f73742d6a736f6e — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d686f73742d6a736f6e

### acceptance-61692d7763732d6b696f736b2d776562 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6b696f736b2d776562

### acceptance-61692d7763732d6c6f63616c2d73746f636b — priority 2

REQ-010: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6c6f63616c2d73746f636b

### acceptance-61692d7763732d6d616e75616c2d68616e646f6666 — priority 2

REQ-012: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6d616e75616c2d68616e646f6666

### acceptance-61692d7763732d6f726465722d706c616e6e696e67 — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f726465722d706c616e6e696e67

### acceptance-61692d7763732d6f7574626f756e642d736f72746174696f6e — priority 2

REQ-013: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d6f7574626f756e642d736f72746174696f6e

### acceptance-61692d7763732d7061636b696e672d6c6162656c73 — priority 2

REQ-009: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d7061636b696e672d6c6162656c73

### acceptance-61692d7763732d72657475726e732d636f756e742d6d6f646573 — priority 2

REQ-014: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d72657475726e732d636f756e742d6d6f646573

### acceptance-61692d7763732d726669642d76616c69646174696f6e — priority 2

REQ-011: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d726669642d76616c69646174696f6e

### acceptance-61692d7763732d73757065727669736f722d6f7065726174696f6e73 — priority 2

REQ-015: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d73757065727669736f722d6f7065726174696f6e73

### acceptance-61692d7763732d776f726b73746174696f6e2d666c6f7773 — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7763732d776f726b73746174696f6e2d666c6f7773

### implementation-6175746f2d62616767696e67 — priority 2

Auto-bagging equipment: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6175746f2d62616767696e67

### implementation-636c656172696e672d776f726b73746174696f6e — priority 2

Clearing workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e

### implementation-636f6e7665796f722d636f6e74726f6c6c6572 — priority 2

Conveyor controller: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572

### implementation-646563616e742d776f726b73746174696f6e — priority 2

Decanting workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-646563616e742d776f726b73746174696f6e

### implementation-686f73742d67617465776179 — priority 2

Host integration gateway: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-686f73742d67617465776179

### implementation-6d616e75616c2d636f6e736f6c69646174696f6e — priority 2

Manual consolidation and re-induction: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e

### implementation-6f726465722d706c616e6e696e67 — priority 2

Order planning: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6f726465722d706c616e6e696e67

### implementation-6f7574626f756e642d736f72746174696f6e — priority 2

Outbound sortation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e

### implementation-7061636b696e672d7072696e74657273 — priority 2

Packing label printers: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7061636b696e672d7072696e74657273

### implementation-7061636b696e672d776f726b73746174696f6e — priority 2

Packing workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e

### implementation-7069636b696e672d776f726b73746174696f6e — priority 2

Picking workstation: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e

### implementation-72657475726e732d636f756e74696e67 — priority 2

Returns and stock counts: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-72657475726e732d636f756e74696e67

### implementation-726669642d72656164657273 — priority 2

RFID readers: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-726669642d72656164657273

### implementation-73757065727669736f722d636f6e736f6c65 — priority 2

Supervisor console: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-73757065727669736f722d636f6e736f6c65

### implementation-776373 — priority 2

WCS web server: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-776373

### implementation-7763732d636f7265 — priority 2

Core: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7763732d636f7265

### implementation-7763732d6c6f63616c2d73746f636b — priority 2

Local stock tracking: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7763732d6c6f63616c2d73746f636b

### implementation-7763732d7374617465 — priority 2

WCS execution records: native infrastructure/application implementation is absent.

Action: Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-7763732d7374617465

### existing-6c696269616f2d616972726f62 — priority 2

Libiao AirRob controller: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-6c696269616f2d616972726f62

### existing-77617265686f7573652d686f7374 — priority 2

Warehouse host system: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-77617265686f7573652d686f7374
