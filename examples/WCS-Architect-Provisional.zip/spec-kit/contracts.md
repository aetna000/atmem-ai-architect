# Component and interface contracts

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component decant-workstation: Decanting workstation

- Responsibility: Kiosk screen within the shared WCS deployment. Operators identify the inbound item and destination tote, confirm the loaded quantity and flag discrepancies. Where RFID is enabled, display expected and read quantities and require physical checking and an operator confirmation or authorised override before committing a mismatch.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-646563616e742d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component picking-workstation: Picking workstation

- Responsibility: Kiosk screen within the shared WCS deployment. Show the pick task when the expected tote is available, including the relevant compartment. Record quantity picked and shortages. Where RFID is enabled, show read discrepancies and require physical checking and operator confirmation or an authorised override before committing the outcome.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7069636b696e672d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs: WCS web server

- Responsibility: Shared WCS deployment serves decanting, picking, clearing, packing, returns, stock counts and supervisor screens over HTTPS. Enforces server-side permissions and passes authorised actions to Core, which runs in the same deployment. Presents workflow state, equipment status and RFID discrepancies, and collects physical-check confirmations or authorised overrides. Hosting remains open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-776373
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs-state: WCS execution records

- Responsibility: WCS-owned durable store for order plans, task progress, local stock by SKU and tote, host and equipment identifiers, package and label jobs, operator confirmations, RFID mismatch evidence and supervisor audit records. Reconcile uncertain host, motion or print outcomes before retrying. Retain decisions by authorised operators. Storage technology remains open.
- Service: Storage or existing data connector
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7763732d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component warehouse-host: Warehouse host system

- Responsibility: Existing warehouse management system (WMS). Owns warehouse-wide inventory and SKU master data. Exchanges JSON work requests, direct transport orders, execution outcomes and exceptions through the host gateway. Receives exceptional stock deltas, manual-consolidation handoffs and requested standstill snapshots, and provides shipping label data for packing. Product, schemas and transport remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-77617265686f7573652d686f7374
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component libiao-airrob: Libiao AirRob controller

- Responsibility: External vendor control boundary for AirRob. Proposed exchange sends tote transport jobs and receives job status and faults. Site-specific interface, job identifiers and recovery behavior need vendor evidence.
- Service: Libiao AirRob
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6c696269616f2d616972726f62
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component clearing-workstation: Clearing workstation

- Responsibility: Kiosk screen within the shared WCS deployment. Supports clearing tasks and records operator confirmations or exceptions. For sorter rejects, allow parcel identification, destination confirmation and manual clearing. Other clearing scenarios and the effects of their confirmations remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636c656172696e672d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component host-gateway: Host integration gateway

- Responsibility: WCS-owned integration component. Validates and maps host JSON for order start and cancellation, SKU changes, direct transport orders, label data and snapshot requests. Returns planning and execution milestones, exceptions, manual-consolidation handoffs, quantity deltas and snapshots. Use stable identifiers and durable tracking of accepted requests and pending results to prevent duplicate or lost work through retries and restarts. Exact host contract, acknowledgements, authentication and deployment boundary remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-686f73742d67617465776179
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component order-planning: Order planning

- Responsibility: Module within the WCS application. Plans internal work from WMS start instructions using agreed priorities, finishing times and readiness rules. Accepts cancellation only before planning begins. Batches eligible single-SKU single-item orders under configurable rules and preserves order and item identity against each tote compartment. Audits operator overrides and emits planning-started, picked and execution-completed outcomes through the gateway. Stock allocation rules and batching thresholds remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f726465722d706c616e6e696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component packing-workstation: Packing workstation

- Responsibility: Manual packing kiosk within the shared WCS deployment, including for ineligible or oversized work and fully manually picked orders. Verify the tote and compartment against current expected contents, including revisions from manual consolidation. Confirm package contents and request the WMS-supplied shipping label linked to the order and package. Record uncertain print outcomes and require an authorised reason for reprints. The exact completion trigger remains open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7061636b696e672d776f726b73746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component conveyor-controller: Conveyor controller

- Responsibility: Proposed site equipment integration boundary. The WCS requests routing and consumes arrival, availability and fault events through a supported interface. The controller owns motion, interlocks and emergency stops. Controller product, ownership, interface and recovery behaviour remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f6e7665796f722d636f6e74726f6c6c6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component packing-printers: Packing label printers

- Responsibility: Proposed site print integration boundary for packing stations. The WCS sends package-linked label jobs and records job acknowledgements or faults where supported. The packing screen shows uncertain outcomes and supports controlled reprints. Printer ownership, interface, label formats and status capabilities remain open.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7061636b696e672d7072696e74657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component rfid-readers: RFID readers

- Responsibility: Proposed on-site reader equipment at RFID-enabled workstations. Supply tagged-item observations and reader health to WCS with enough context to associate each read with the correct workstation and task. Qualify tag-to-SKU identification, reader placement, read stability and filtering of nearby tags with real totes. Reader model, exact locations, interface and ownership remain open. WCS owns validation and the manual fallback.
- Service: Ingestion / processing service
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-726669642d72656164657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs-local-stock: Local stock tracking

- Responsibility: Module within the shared WCS application. Tracks stock by SKU, stock properties and tote using WCS execution records. Reports exceptional quantity deltas with reason codes and returns WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Acknowledges SKU retirement once stock and order references clear. Temporary unavailability stays local. Its treatment in snapshots remains open. WMS owns warehouse-wide inventory and SKU master data.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7763732d6c6f63616c2d73746f636b
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component manual-consolidation: Manual consolidation and re-induction

- Responsibility: Workflow within the shared WCS deployment. When a partially picked tote goes to manual consolidation, report its contents to WMS. Accept a manually completed or fully manually picked tote back into WCS only against a WMS direct transport order linking tote, order, destination, revised quantities and additions or shortages. Pass the revised expected contents to packing.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6d616e75616c2d636f6e736f6c69646174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component returns-counting: Returns and stock counts

- Responsibility: Workstation workflows within the shared WCS deployment. Record inspected mixed returns and operator-confirmed off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote, with manual checking when RFID readings are unreliable. Before switching between picking, counting and clearing, stop new allocations and let assigned work finish.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-72657475726e732d636f756e74696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component supervisor-console: Supervisor console

- Responsibility: Screen within the shared WCS deployment. Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. WCS authorises and audits changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73757065727669736f722d636f6e736f6c65
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component auto-bagging: Auto-bagging equipment

- Responsibility: Site equipment boundary for automatic packing. WCS proposes routing eligible single-item batches and multi-item orders here through the conveyor controller and diverting ineligible or oversized work to manual packing. Correlate supported packing results and faults with the correct package and order. Bagging interface, arrival and completion signals, eligibility rules and label handoff require site evidence.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6175746f2d62616767696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component outbound-sortation: Outbound sortation

- Responsibility: Site sorter and WCS integration boundary. WCS maps shipping-label identifiers to logical destinations and physical chutes, and records the booked route and available actual-route feedback. Send full-chute overflow to reject without recirculation. At the clearing screen, allow operators to identify rejected parcels, confirm destinations and record manual clearing. Confirm equipment event and routing contracts on site.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7574626f756e642d736f72746174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component wcs-core: Core

- Responsibility: Business logic module within the shared WCS web server deployment. Owns order planning, task and workflow state, local stock tracking, RFID validation and manual discrepancy resolution, returns, counting, manual consolidation and re-induction, packing and label rules, outbound sortation and supervisor actions. Coordinates AirRob tote moves, conveyor routing, auto-bagging, printing and sorter operations through site interfaces. Equipment controllers retain motion and safety control. Persists execution and audit records, reconciles uncertain outcomes before retrying, and exchanges work, results and exceptions with the WMS through the host gateway.
- Service: Application runtime and API
- Provider / placement: tools / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7763732d636f7265
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### decant-wcs: decant-workstation → wcs

- Drawn payload/purpose: HTTPS decanting screen and load confirmations
- Contract task: TASK-CONTRACT-646563616e742d776373
- Integration task: TASK-INTEGRATION-646563616e742d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### pick-wcs: picking-workstation → wcs

- Drawn payload/purpose: HTTPS picking screen and pick confirmations
- Contract task: TASK-CONTRACT-7069636b2d776373
- Integration task: TASK-INTEGRATION-7069636b2d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-host: host-gateway → warehouse-host

- Drawn payload/purpose: Host JSON requests in, results and exceptions out
- Contract task: TASK-CONTRACT-7763732d686f7374
- Integration task: TASK-INTEGRATION-7763732d686f7374
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-airrob: wcs-core → libiao-airrob

- Drawn payload/purpose: Tote move jobs out, status and faults in
- Contract task: TASK-CONTRACT-7763732d616972726f62
- Integration task: TASK-INTEGRATION-7763732d616972726f62
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-records: wcs-core → wcs-state

- Drawn payload/purpose: Save and recover orders, tasks, packages and equipment jobs
- Contract task: TASK-CONTRACT-7763732d7265636f726473
- Integration task: TASK-INTEGRATION-7763732d7265636f726473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### clearing-wcs: clearing-workstation → wcs

- Drawn payload/purpose: Clearing tasks, reject parcel identification and operator confirmations
- Contract task: TASK-CONTRACT-636c656172696e672d776373
- Integration task: TASK-INTEGRATION-636c656172696e672d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-host-gateway: wcs-core → host-gateway

- Drawn payload/purpose: Validated work requests in, results and exceptions out
- Contract task: TASK-CONTRACT-7763732d686f73742d67617465776179
- Integration task: TASK-INTEGRATION-7763732d686f73742d67617465776179
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-order-planning: wcs-core → order-planning

- Drawn payload/purpose: Accepted orders and progress in, planned tasks out
- Contract task: TASK-CONTRACT-7763732d6f726465722d706c616e6e696e67
- Integration task: TASK-INTEGRATION-7763732d6f726465722d706c616e6e696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### packing-wcs: packing-workstation → wcs

- Drawn payload/purpose: HTTPS packing screen, package confirmations and label requests
- Contract task: TASK-CONTRACT-7061636b696e672d776373
- Integration task: TASK-INTEGRATION-7061636b696e672d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-conveyor: wcs-core → conveyor-controller

- Drawn payload/purpose: Tote routes to manual packing or auto-bagging, arrivals and faults
- Contract task: TASK-CONTRACT-7763732d636f6e7665796f72
- Integration task: TASK-INTEGRATION-7763732d636f6e7665796f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-packing-printers: wcs-core → packing-printers

- Drawn payload/purpose: Package label jobs out, available status and faults in
- Contract task: TASK-CONTRACT-7763732d7061636b696e672d7072696e74657273
- Integration task: TASK-INTEGRATION-7763732d7061636b696e672d7072696e74657273
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### rfid-wcs: rfid-readers → wcs-core

- Drawn payload/purpose: Tag reads and reader faults for workstation checks
- Contract task: TASK-CONTRACT-726669642d776373
- Integration task: TASK-INTEGRATION-726669642d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-local-stock-flow: wcs-core → wcs-local-stock

- Drawn payload/purpose: Confirmed stock changes, availability and snapshot requests
- Contract task: TASK-CONTRACT-7763732d6c6f63616c2d73746f636b2d666c6f77
- Integration task: TASK-INTEGRATION-7763732d6c6f63616c2d73746f636b2d666c6f77
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### local-stock-records: wcs-local-stock → wcs-state

- Drawn payload/purpose: Save stock by SKU and tote and record reason-coded changes
- Contract task: TASK-CONTRACT-6c6f63616c2d73746f636b2d7265636f726473
- Integration task: TASK-INTEGRATION-6c6f63616c2d73746f636b2d7265636f726473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### manual-consolidation-wcs: manual-consolidation → wcs

- Drawn payload/purpose: Partial-pick handoff and WMS-authorised tote re-induction
- Contract task: TASK-CONTRACT-6d616e75616c2d636f6e736f6c69646174696f6e2d776373
- Integration task: TASK-INTEGRATION-6d616e75616c2d636f6e736f6c69646174696f6e2d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### returns-counting-wcs: returns-counting → wcs

- Drawn payload/purpose: Returns induction, stock counts and workstation mode changes
- Contract task: TASK-CONTRACT-72657475726e732d636f756e74696e672d776373
- Integration task: TASK-INTEGRATION-72657475726e732d636f756e74696e672d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### supervisor-wcs: supervisor-console → wcs

- Drawn payload/purpose: Operational status and authorised supervisory actions
- Contract task: TASK-CONTRACT-73757065727669736f722d776373
- Integration task: TASK-INTEGRATION-73757065727669736f722d776373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-auto-bagging: wcs-core → auto-bagging

- Drawn payload/purpose: Eligible packing work, package outcomes and equipment faults
- Contract task: TASK-CONTRACT-7763732d6175746f2d62616767696e67
- Integration task: TASK-INTEGRATION-7763732d6175746f2d62616767696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-outbound-sortation: wcs-core → outbound-sortation

- Drawn payload/purpose: Shipping label and chute mapping, route and reject feedback
- Contract task: TASK-CONTRACT-7763732d6f7574626f756e642d736f72746174696f6e
- Integration task: TASK-INTEGRATION-7763732d6f7574626f756e642d736f72746174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### wcs-core-actions: wcs → wcs-core

- Drawn payload/purpose: Authorised workstation actions in, tasks and outcomes back
- Contract task: TASK-CONTRACT-7763732d636f72652d616374696f6e73
- Integration task: TASK-INTEGRATION-7763732d636f72652d616374696f6e73
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
