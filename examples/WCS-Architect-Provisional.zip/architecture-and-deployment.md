Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

# A wcs system controlling libiao airrob… — deployment document

Generated 2026-11-18 12:40 UTC from design revision r101 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

I want to build a wcs system controlling libiao airrob has ui has workstation decanting and picking connects to host using json
we need a gateway connecting wcs to host system
we need to have business logic about order planning managing conveyor systems and printers packing
use this and check the diagrams add more needex
I CANNOT SEE ANY CHANGES TO THE. OARD VERSHER IS RFID
we want the biz logics to be in one blcok call it core can we have nested blocks

- **Cloud:** not chosen
- **Usage:** 10,000 requests/month (Small planning assumption)
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 6

## 2. Scope and context

- **What you want to build:** I want to build a wcs system controlling libiao airrob has ui has workstation decanting and picking connects to host using json we need a gateway connecting wcs to host system we need to have business logic about order planning managing conveyor systems and printers packing use this and check the diagrams add more needex I CANNOT SEE ANY CHANGES TO THE. OARD VERSHER IS RFID we want the biz logics to be in one blcok call it core can we have nested blocks
- **Information it uses:** extend wcs and the board to catter for this document we need to implmenet it
- **Who uses it, and how much:** —
- **Systems it connects to:** I need a webserver to run decanting and picking and clearing in kiosk mode
- **How good, fast and safe:** —
- **Cloud preference:** —
- **Budget and timeline:** —

## 3. Architecture

**Workstation UI**

- Decanting workstation (Tools & data, sketch) — Kiosk screen within the shared WCS deployment. Operators identify the inbound item and destination tote, confirm the loaded quantity and flag discrepancies. Where RFID is enabled, display expected and read quantities and require physical checking and an operator confirmation or authorised override before committing a mismatch.
- Picking workstation (Tools & data, sketch) — Kiosk screen within the shared WCS deployment. Show the pick task when the expected tote is available, including the relevant compartment. Record quantity picked and shortages. Where RFID is enabled, show read discrepancies and require physical checking and operator confirmation or an authorised override before committing the outcome.
- Clearing workstation (Tools & data, sketch) — Kiosk screen within the shared WCS deployment. Supports clearing tasks and records operator confirmations or exceptions. For sorter rejects, allow parcel identification, destination confirmation and manual clearing. Other clearing scenarios and the effects of their confirmations remain open.
- Packing workstation (Tools & data, sketch) — Manual packing kiosk within the shared WCS deployment, including for ineligible or oversized work and fully manually picked orders. Verify the tote and compartment against current expected contents, including revisions from manual consolidation. Confirm package contents and request the WMS-supplied shipping label linked to the order and package. Record uncertain print outcomes and require an authorised reason for reprints. The exact completion trigger remains open.
- Manual consolidation and re-induction (Tools & data, sketch) — Workflow within the shared WCS deployment. When a partially picked tote goes to manual consolidation, report its contents to WMS. Accept a manually completed or fully manually picked tote back into WCS only against a WMS direct transport order linking tote, order, destination, revised quantities and additions or shortages. Pass the revised expected contents to packing.
- Returns and stock counts (Tools & data, sketch) — Workstation workflows within the shared WCS deployment. Record inspected mixed returns and operator-confirmed off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote, with manual checking when RFID readings are unreliable. Before switching between picking, counting and clearing, stop new allocations and let assigned work finish.
- Supervisor console (Tools & data, sketch) — Screen within the shared WCS deployment. Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. WCS authorises and audits changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

**Warehouse control**

- WCS web server (Tools & data, sketch) — Shared WCS deployment serves decanting, picking, clearing, packing, returns, stock counts and supervisor screens over HTTPS. Enforces server-side permissions and passes authorised actions to Core, which runs in the same deployment. Presents workflow state, equipment status and RFID discrepancies, and collects physical-check confirmations or authorised overrides. Hosting remains open.
- WCS execution records (Tools & data, sketch) — WCS-owned durable store for order plans, task progress, local stock by SKU and tote, host and equipment identifiers, package and label jobs, operator confirmations, RFID mismatch evidence and supervisor audit records. Reconcile uncertain host, motion or print outcomes before retrying. Retain decisions by authorised operators. Storage technology remains open.

**Warehouse host system**

- Warehouse host system (Tools & data, existing, sketch) — Existing warehouse management system (WMS). Owns warehouse-wide inventory and SKU master data. Exchanges JSON work requests, direct transport orders, execution outcomes and exceptions through the host gateway. Receives exceptional stock deltas, manual-consolidation handoffs and requested standstill snapshots, and provides shipping label data for packing. Product, schemas and transport remain open.

**Libiao AirRob controller**

- Libiao AirRob controller (Tools & data, existing, sketch) — External vendor control boundary for AirRob. Proposed exchange sends tote transport jobs and receives job status and faults. Site-specific interface, job identifiers and recovery behavior need vendor evidence.

**Host integration**

- Host integration gateway (Tools & data, sketch) — WCS-owned integration component. Validates and maps host JSON for order start and cancellation, SKU changes, direct transport orders, label data and snapshot requests. Returns planning and execution milestones, exceptions, manual-consolidation handoffs, quantity deltas and snapshots. Use stable identifiers and durable tracking of accepted requests and pending results to prevent duplicate or lost work through retries and restarts. Exact host contract, acknowledgements, authentication and deployment boundary remain open.

**Core**

- Order planning (Tools & data, sketch) — Module within the WCS application. Plans internal work from WMS start instructions using agreed priorities, finishing times and readiness rules. Accepts cancellation only before planning begins. Batches eligible single-SKU single-item orders under configurable rules and preserves order and item identity against each tote compartment. Audits operator overrides and emits planning-started, picked and execution-completed outcomes through the gateway. Stock allocation rules and batching thresholds remain open.
- Local stock tracking (Tools & data, sketch) — Module within the shared WCS application. Tracks stock by SKU, stock properties and tote using WCS execution records. Reports exceptional quantity deltas with reason codes and returns WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Acknowledges SKU retirement once stock and order references clear. Temporary unavailability stays local. Its treatment in snapshots remains open. WMS owns warehouse-wide inventory and SKU master data.
- Core (Tools & data, sketch) — Business logic module within the shared WCS web server deployment. Owns order planning, task and workflow state, local stock tracking, RFID validation and manual discrepancy resolution, returns, counting, manual consolidation and re-induction, packing and label rules, outbound sortation and supervisor actions. Coordinates AirRob tote moves, conveyor routing, auto-bagging, printing and sorter operations through site interfaces. Equipment controllers retain motion and safety control. Persists execution and audit records, reconciles uncertain outcomes before retrying, and exchanges work, results and exceptions with the WMS through the host gateway.

**Site equipment**

- Conveyor controller (Tools & data, sketch) — Proposed site equipment integration boundary. The WCS requests routing and consumes arrival, availability and fault events through a supported interface. The controller owns motion, interlocks and emergency stops. Controller product, ownership, interface and recovery behaviour remain open.
- Packing label printers (Tools & data, sketch) — Proposed site print integration boundary for packing stations. The WCS sends package-linked label jobs and records job acknowledgements or faults where supported. The packing screen shows uncertain outcomes and supports controlled reprints. Printer ownership, interface, label formats and status capabilities remain open.
- RFID readers (Tools & data, sketch) — Proposed on-site reader equipment at RFID-enabled workstations. Supply tagged-item observations and reader health to WCS with enough context to associate each read with the correct workstation and task. Qualify tag-to-SKU identification, reader placement, read stability and filtering of nearby tags with real totes. Reader model, exact locations, interface and ownership remain open. WCS owns validation and the manual fallback.
- Auto-bagging equipment (Tools & data, sketch) — Site equipment boundary for automatic packing. WCS proposes routing eligible single-item batches and multi-item orders here through the conveyor controller and diverting ineligible or oversized work to manual packing. Correlate supported packing results and faults with the correct package and order. Bagging interface, arrival and completion signals, eligibility rules and label handoff require site evidence.
- Outbound sortation (Tools & data, sketch) — Site sorter and WCS integration boundary. WCS maps shipping-label identifiers to logical destinations and physical chutes, and records the booked route and available actual-route feedback. Send full-chute overflow to reject without recirculation. At the clearing screen, allow operators to identify rejected parcels, confirm destinations and record manual clearing. Confirm equipment event and routing contracts on site.

```mermaid
flowchart LR
  n0["Decanting workstation<br/>Tools & data"]
  n1["Picking workstation<br/>Tools & data"]
  n2["WCS web server<br/>Tools & data"]
  n3["WCS execution records<br/>Tools & data"]
  n4["Warehouse host system<br/>Tools & data"]
  n5["Libiao AirRob controller<br/>Tools & data"]
  n6["Clearing workstation<br/>Tools & data"]
  n7["Host integration gateway<br/>Tools & data"]
  n8["Order planning<br/>Tools & data"]
  n9["Packing workstation<br/>Tools & data"]
  n10["Conveyor controller<br/>Tools & data"]
  n11["Packing label printers<br/>Tools & data"]
  n12["RFID readers<br/>Tools & data"]
  n13["Local stock tracking<br/>Tools & data"]
  n14["Manual consolidation and re-induction<br/>Tools & data"]
  n15["Returns and stock counts<br/>Tools & data"]
  n16["Supervisor console<br/>Tools & data"]
  n17["Auto-bagging equipment<br/>Tools & data"]
  n18["Outbound sortation<br/>Tools & data"]
  n19["Core<br/>Tools & data"]
  n0 -->|HTTPS decanting screen and load confirmations| n2
  n1 -->|HTTPS picking screen and pick confirmations| n2
  n7 -->|Host JSON requests in, results and exceptions out| n4
  n19 -->|Tote move jobs out, status and faults in| n5
  n19 -->|Save and recover orders, tasks, packages and equipment jobs| n3
  n6 -->|Clearing tasks, reject parcel identification and operator confirmations| n2
  n19 -->|Validated work requests in, results and exceptions out| n7
  n19 -->|Accepted orders and progress in, planned tasks out| n8
  n9 -->|HTTPS packing screen, package confirmations and label requests| n2
  n19 -->|Tote routes to manual packing or auto-bagging, arrivals and faults| n10
  n19 -->|Package label jobs out, available status and faults in| n11
  n12 -->|Tag reads and reader faults for workstation checks| n19
  n19 -->|Confirmed stock changes, availability and snapshot requests| n13
  n13 -->|Save stock by SKU and tote and record reason-coded changes| n3
  n14 -->|Partial-pick handoff and WMS-authorised tote re-induction| n2
  n15 -->|Returns induction, stock counts and workstation mode changes| n2
  n16 -->|Operational status and authorised supervisory actions| n2
  n19 -->|Eligible packing work, package outcomes and equipment faults| n17
  n19 -->|Shipping label and chute mapping, route and reject feedback| n18
  n2 -->|Authorised workstation actions in, tasks and outcomes back| n19
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| decant-workstation | Decanting workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| picking-workstation | Picking workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| wcs | WCS web server | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| wcs-state | WCS execution records | tools | Storage or existing data connector | To be selected | Proposed | Implementation needed |
| warehouse-host | Warehouse host system | tools | Application runtime and API | To be selected | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| libiao-airrob | Libiao AirRob controller | tools | Libiao AirRob | To be selected | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| clearing-workstation | Clearing workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| host-gateway | Host integration gateway | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| order-planning | Order planning | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| packing-workstation | Packing workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| conveyor-controller | Conveyor controller | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| packing-printers | Packing label printers | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| rfid-readers | RFID readers | tools | Ingestion / processing service | To be selected | Proposed | Implementation needed |
| wcs-local-stock | Local stock tracking | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| manual-consolidation | Manual consolidation and re-induction | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| returns-counting | Returns and stock counts | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| supervisor-console | Supervisor console | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| auto-bagging | Auto-bagging equipment | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| outbound-sortation | Outbound sortation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| wcs-core | Core | tools | Application runtime and API | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Decanting workstation** (decant-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Picking workstation** (picking-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **WCS web server** (wcs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: decant-workstation, picking-workstation, clearing-workstation, packing-workstation, manual-consolidation, returns-counting, supervisor-console.
- **WCS execution records** (wcs-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core, wcs-local-stock.
- **Warehouse host system** (warehouse-host): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: host-gateway.
- **Libiao AirRob controller** (libiao-airrob): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Clearing workstation** (clearing-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Host integration gateway** (host-gateway): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Order planning** (order-planning): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Packing workstation** (packing-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Conveyor controller** (conveyor-controller): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Packing label printers** (packing-printers): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **RFID readers** (rfid-readers): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Local stock tracking** (wcs-local-stock): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Manual consolidation and re-induction** (manual-consolidation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Returns and stock counts** (returns-counting): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Supervisor console** (supervisor-console): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Auto-bagging equipment** (auto-bagging): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Outbound sortation** (outbound-sortation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Core** (wcs-core): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: rfid-readers, wcs.

### Engineering work remaining

- Decanting workstation: Implementation needed.
- Picking workstation: Implementation needed.
- WCS web server: Implementation needed.
- WCS execution records: Implementation needed.
- Clearing workstation: Implementation needed.
- Host integration gateway: Implementation needed.
- Order planning: Implementation needed.
- Packing workstation: Implementation needed.
- Conveyor controller: Implementation needed.
- Packing label printers: Implementation needed.
- RFID readers: Implementation needed.
- Local stock tracking: Implementation needed.
- Manual consolidation and re-induction: Implementation needed.
- Returns and stock counts: Implementation needed.
- Supervisor console: Implementation needed.
- Auto-bagging equipment: Implementation needed.
- Outbound sortation: Implementation needed.
- Core: Implementation needed.
- Wire decant-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire picking-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire host-gateway → warehouse-host: implement data flow, access policy and acceptance test.
- Wire wcs-core → libiao-airrob: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-state: implement data flow, access policy and acceptance test.
- Wire clearing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → host-gateway: implement data flow, access policy and acceptance test.
- Wire wcs-core → order-planning: implement data flow, access policy and acceptance test.
- Wire packing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → conveyor-controller: implement data flow, access policy and acceptance test.
- Wire wcs-core → packing-printers: implement data flow, access policy and acceptance test.
- Wire rfid-readers → wcs-core: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-local-stock: implement data flow, access policy and acceptance test.
- Wire wcs-local-stock → wcs-state: implement data flow, access policy and acceptance test.
- Wire manual-consolidation → wcs: implement data flow, access policy and acceptance test.
- Wire returns-counting → wcs: implement data flow, access policy and acceptance test.
- Wire supervisor-console → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → auto-bagging: implement data flow, access policy and acceptance test.
- Wire wcs-core → outbound-sortation: implement data flow, access policy and acceptance test.
- Wire wcs → wcs-core: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Decanting workstation | WCS web server | HTTPS decanting screen and load confirmations | Internal |
| Picking workstation | WCS web server | HTTPS picking screen and pick confirmations | Internal |
| Host integration gateway | Warehouse host system | Host JSON requests in, results and exceptions out | Internal |
| Core | Libiao AirRob controller | Tote move jobs out, status and faults in | Internal |
| Core | WCS execution records | Save and recover orders, tasks, packages and equipment jobs | Internal |
| Clearing workstation | WCS web server | Clearing tasks, reject parcel identification and operator confirmations | Internal |
| Core | Host integration gateway | Validated work requests in, results and exceptions out | Internal |
| Core | Order planning | Accepted orders and progress in, planned tasks out | Internal |
| Packing workstation | WCS web server | HTTPS packing screen, package confirmations and label requests | Internal |
| Core | Conveyor controller | Tote routes to manual packing or auto-bagging, arrivals and faults | Internal |
| Core | Packing label printers | Package label jobs out, available status and faults in | Internal |
| RFID readers | Core | Tag reads and reader faults for workstation checks | Internal |
| Core | Local stock tracking | Confirmed stock changes, availability and snapshot requests | Internal |
| Local stock tracking | WCS execution records | Save stock by SKU and tote and record reason-coded changes | Internal |
| Manual consolidation and re-induction | WCS web server | Partial-pick handoff and WMS-authorised tote re-induction | Internal |
| Returns and stock counts | WCS web server | Returns induction, stock counts and workstation mode changes | Internal |
| Supervisor console | WCS web server | Operational status and authorised supervisory actions | Internal |
| Core | Auto-bagging equipment | Eligible packing work, package outcomes and equipment faults | Internal |
| Core | Outbound sortation | Shipping label and chute mapping, route and reject feedback | Internal |
| WCS web server | Core | Authorised workstation actions in, tasks and outcomes back | Internal |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action. (must)
- Requirement: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history. | reliability | not measurable yet | Open |

**Functional**

- Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers. (must, open)
- Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move. (must, open)
- Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized. (must, open)
- Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action. (must, open)
- Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes. (must, open)
- Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller. (must, open)
- Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design. (must, open)
- Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it. (must, open)
- Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site. (must, open)
- Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing. (must, open)
- Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope. (must, open)
- Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing. (must, open)
- Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 6 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 20 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| WCS execution records | Storage | 10 GB-month | price needed | — | — |
| RFID readers | Data processed | 10 GB | price needed | — | — |

**Usage inputs:** Data stored: 10 (Small planning assumption).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Decanting workstation, Picking workstation, WCS web server, Warehouse host system, Libiao AirRob controller, Clearing workstation, Host integration gateway, Order planning, Packing workstation, Conveyor controller, Packing label printers, Local stock tracking, Manual consolidation and re-induction, Returns and stock counts, Supervisor console, Auto-bagging equipment, Outbound sortation, Core.

**Estimate gaps:**

- WCS execution records / Storage: price needed.
- RFID readers / Data processed: price needed.
- Decanting workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Picking workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- WCS web server: no cost lines; add charges or an explicit zero-cost line with a reason.
- Warehouse host system: no cost lines; add charges or an explicit zero-cost line with a reason.
- Libiao AirRob controller: no cost lines; add charges or an explicit zero-cost line with a reason.
- Clearing workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Host integration gateway: no cost lines; add charges or an explicit zero-cost line with a reason.
- Order planning: no cost lines; add charges or an explicit zero-cost line with a reason.
- Packing workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Conveyor controller: no cost lines; add charges or an explicit zero-cost line with a reason.
- Packing label printers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Local stock tracking: no cost lines; add charges or an explicit zero-cost line with a reason.
- Manual consolidation and re-induction: no cost lines; add charges or an explicit zero-cost line with a reason.
- Returns and stock counts: no cost lines; add charges or an explicit zero-cost line with a reason.
- Supervisor console: no cost lines; add charges or an explicit zero-cost line with a reason.
- Auto-bagging equipment: no cost lines; add charges or an explicit zero-cost line with a reason.
- Outbound sortation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Core: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision workstation ui: Decanting workstation, Picking workstation, Clearing workstation, Packing workstation, Manual consolidation and re-induction, Returns and stock counts, Supervisor console.
4. Provision site equipment: RFID readers, Conveyor controller, Packing label printers, Auto-bagging equipment, Outbound sortation.
5. Provision warehouse control: WCS web server, WCS execution records.
6. Provision core: Core, Order planning, Local stock tracking.
7. Provision host integration: Host integration gateway.
8. Connect existing systems: Warehouse host system, Libiao AirRob controller; test failure behaviour.
9. Run the acceptance checks (success measures and requirements) in staging; record results.
10. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · First sketch of the AirRob warehouse control system

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r1 · **Subject:** `design.first-sketch-of-the-airrob-warehouse-control-system`

**Context**

The decanting and picking screens share one proposed warehouse control application. The application coordinates workstation work with the Libiao AirRob controller, exchanges JSON messages with the host, and records execution progress in a durable store. We treat the host and AirRob controller as external systems. The host remains connected through JSON, with message definitions, transport and stock allocation ownership open. The AirRob integration depends on the supported interface for the site's controller. Hosting is open. The diagram is a design sketch, and the WCS application and its integration adapters require custom implementation.

**Options considered**

—

**Decision**

Drawn while talking as design revision 2.

**Consequences**

—

### ADR-002 · Serve all three workstation workflows in kiosk mode

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r91 · **Subject:** `design.serve-all-three-workstation-workflows-in-kiosk-mode`

**Context**

Make the existing WCS component the shared web server. Keep decanting and picking as screens owned by the WCS, and add clearing as a third screen. Each workstation browser opens its assigned screen in kiosk mode over HTTPS. Hosting location and the clearing workflow rules are open. The JSON host connection, Libiao AirRob controller and durable execution records stay connected to the WCS. The browser flows and kiosk setup require implementation and testing.

**Options considered**

—

**Decision**

Drawn while talking as design revision 92.

**Consequences**

—

### ADR-003 · Add the warehouse host gateway

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r92 · **Subject:** `design.add-the-warehouse-host-gateway`

**Context**

Route the host exchange through a WCS-owned gateway. The gateway handles message validation and translation, while the WCS owns warehouse workflow decisions. Hosting, transport and service authentication remain open. The gateway and both interfaces require custom implementation and testing against the host contract.

**Options considered**

—

**Decision**

Drawn while talking as design revision 93.

**Consequences**

—

### ADR-004 · Add order planning, conveyor coordination and packing

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r93 · **Subject:** `design.add-order-planning-conveyor-coordination-and-packing`

**Context**

The WCS proposes a rules-based order planner within the shared application and a packing screen served by the same web server. Accepted host orders feed planning through the existing JSON gateway. The WCS coordinates conveyor routing through the site controller, which retains motion control, interlocks and emergency stops. Packing confirms package contents and requests the associated label through a print interface. Proposed execution records correlate orders, totes, packages and device jobs so operators can recover from jams, lost acknowledgements and printer faults. Stock allocation ownership, release rules, packing and label rules, equipment ownership and device interfaces remain open. The WCS workflows and equipment connections require custom implementation and site acceptance tests.

**Options considered**

—

**Decision**

Drawn while talking as design revision 94.

**Consequences**

—

### ADR-005 · Show RFID and complete the recorded warehouse workflows

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r97 · **Subject:** `design.show-rfid-and-complete-the-recorded-warehouse-workflows`

**Context**

Place RFID readers directly above the WCS web server and connect tag reads, reader faults and workstation checks. Draw local stock tracking, returns and counting, manual consolidation, auto-bagging, outbound sortation and supervisor controls from the recorded project requirements. Reuse the shared WCS application and execution store for its software modules. The WMS remains authoritative for warehouse-wide inventory and SKU master data, and site equipment retains motion and safety control. Reader locations, device contracts and installation ownership need site qualification. Individual dispatch-container contents and mandatory scanning at every chute are outside the initial sortation scope. This patch describes the design. WCS software and site integrations require implementation and acceptance testing.

**Options considered**

—

**Decision**

Drawn while talking as design revision 98.

**Consequences**

—

### ADR-006 · Group WCS business logic under Core

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r99 · **Subject:** `design.group-wcs-business-logic-under-core`

**Context**

Add Core as the business logic boundary within the shared WCS deployment. Group order planning and local stock tracking with Core, keeping their existing blocks for traceability. Workstation screens send actions to the web server, which checks permissions and calls Core. Core owns the workflow rules and coordinates the execution store, host gateway and equipment interfaces. The canvas uses a shared group to represent this relationship. Native parent-child nesting is unavailable in the current diagram format.

**Options considered**

—

**Decision**

Drawn while talking as design revision 100.

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which system or role is authorised to release a held tote after WMS and equipment outcomes disagree?
- Who can provide the current WMS JSON schemas, sample exchanges and the authoritative acknowledgement and replay rules?
- Which AirRob interface and job status lookup does the site support, and who can supply its official contract and simulator?
- Which clearing workflows beyond sorter rejects belong in first release, and what should each confirmation trigger?
- Which priority, readiness, batching and finishing-time rules are required at launch?
- How should temporary stock unavailability appear in a standstill snapshot?
- What event marks manual packing complete, and which role can authorise a reprint?
- Where must WCS run, and what availability, recovery and site-network constraints apply?
- Who will use this system? _(discovery)_
- WCS execution records: needs a unit price with a source _(estimate)_
- RFID readers: needs a unit price with a source _(estimate)_
