# Infrastructure implementation required

Requested providers: not selected. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Decanting workstation: Implementation needed.
- Picking workstation: Implementation needed.
- WCS web server: Implementation needed.
- WCS execution records: Implementation needed.
- Clearing workstation: Implementation needed.
- Host integration gateway: Implementation needed.
- Order planning: Implementation needed.
- Packing workstation: Implementation needed.
- Conveyor controller: Implementation needed.
- Packing label printers: Implementation needed.
- RFID readers: Implementation needed.
- Local stock tracking: Implementation needed.
- Manual consolidation and re-induction: Implementation needed.
- Returns and stock counts: Implementation needed.
- Supervisor console: Implementation needed.
- Auto-bagging equipment: Implementation needed.
- Outbound sortation: Implementation needed.
- Core: Implementation needed.
- Wire decant-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire picking-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire host-gateway → warehouse-host: implement data flow, access policy and acceptance test.
- Wire wcs-core → libiao-airrob: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-state: implement data flow, access policy and acceptance test.
- Wire clearing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → host-gateway: implement data flow, access policy and acceptance test.
- Wire wcs-core → order-planning: implement data flow, access policy and acceptance test.
- Wire packing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → conveyor-controller: implement data flow, access policy and acceptance test.
- Wire wcs-core → packing-printers: implement data flow, access policy and acceptance test.
- Wire rfid-readers → wcs-core: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-local-stock: implement data flow, access policy and acceptance test.
- Wire wcs-local-stock → wcs-state: implement data flow, access policy and acceptance test.
- Wire manual-consolidation → wcs: implement data flow, access policy and acceptance test.
- Wire returns-counting → wcs: implement data flow, access policy and acceptance test.
- Wire supervisor-console → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → auto-bagging: implement data flow, access policy and acceptance test.
- Wire wcs-core → outbound-sortation: implement data flow, access policy and acceptance test.
- Wire wcs → wcs-core: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
