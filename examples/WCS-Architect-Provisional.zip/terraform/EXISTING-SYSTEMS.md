# Existing systems

These components remain externally managed. This export does not create, import, replace or modify them. Their presence in the diagram is not proof of availability, authentication, permissions or integration behavior. Connection implementations and runtime tests remain separate requirements.

- "Warehouse host system" ("warehouse-host"): reference only, preserve existing system.
- "Libiao AirRob controller" ("libiao-airrob"): reference only, preserve existing system.
