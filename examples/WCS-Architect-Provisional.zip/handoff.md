# Delivery handoff

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- WCS execution records / Storage: price needed.
- RFID readers / Data processed: price needed.
- Decanting workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Picking workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- WCS web server: no cost lines; add charges or an explicit zero-cost line with a reason.
- Warehouse host system: no cost lines; add charges or an explicit zero-cost line with a reason.
- Libiao AirRob controller: no cost lines; add charges or an explicit zero-cost line with a reason.
- Clearing workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Host integration gateway: no cost lines; add charges or an explicit zero-cost line with a reason.
- Order planning: no cost lines; add charges or an explicit zero-cost line with a reason.
- Packing workstation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Conveyor controller: no cost lines; add charges or an explicit zero-cost line with a reason.
- Packing label printers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Local stock tracking: no cost lines; add charges or an explicit zero-cost line with a reason.
- Manual consolidation and re-induction: no cost lines; add charges or an explicit zero-cost line with a reason.
- Returns and stock counts: no cost lines; add charges or an explicit zero-cost line with a reason.
- Supervisor console: no cost lines; add charges or an explicit zero-cost line with a reason.
- Auto-bagging equipment: no cost lines; add charges or an explicit zero-cost line with a reason.
- Outbound sortation: no cost lines; add charges or an explicit zero-cost line with a reason.
- Core: no cost lines; add charges or an explicit zero-cost line with a reason.
- Decanting workstation: Implementation needed.
- Picking workstation: Implementation needed.
- WCS web server: Implementation needed.
- WCS execution records: Implementation needed.
- Clearing workstation: Implementation needed.
- Host integration gateway: Implementation needed.
- Order planning: Implementation needed.
- Packing workstation: Implementation needed.
- Conveyor controller: Implementation needed.
- Packing label printers: Implementation needed.
- RFID readers: Implementation needed.
- Local stock tracking: Implementation needed.
- Manual consolidation and re-induction: Implementation needed.
- Returns and stock counts: Implementation needed.
- Supervisor console: Implementation needed.
- Auto-bagging equipment: Implementation needed.
- Outbound sortation: Implementation needed.
- Core: Implementation needed.
- Wire decant-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire picking-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire host-gateway → warehouse-host: implement data flow, access policy and acceptance test.
- Wire wcs-core → libiao-airrob: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-state: implement data flow, access policy and acceptance test.
- Wire clearing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → host-gateway: implement data flow, access policy and acceptance test.
- Wire wcs-core → order-planning: implement data flow, access policy and acceptance test.
- Wire packing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → conveyor-controller: implement data flow, access policy and acceptance test.
- Wire wcs-core → packing-printers: implement data flow, access policy and acceptance test.
- Wire rfid-readers → wcs-core: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-local-stock: implement data flow, access policy and acceptance test.
- Wire wcs-local-stock → wcs-state: implement data flow, access policy and acceptance test.
- Wire manual-consolidation → wcs: implement data flow, access policy and acceptance test.
- Wire returns-counting → wcs: implement data flow, access policy and acceptance test.
- Wire supervisor-console → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → auto-bagging: implement data flow, access policy and acceptance test.
- Wire wcs-core → outbound-sortation: implement data flow, access policy and acceptance test.
- Wire wcs → wcs-core: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.
- Which system or role is authorised to release a held tote after WMS and equipment outcomes disagree?
- Who can provide the current WMS JSON schemas, sample exchanges and the authoritative acknowledgement and replay rules?
- Which AirRob interface and job status lookup does the site support, and who can supply its official contract and simulator?
- Which clearing workflows beyond sorter rejects belong in first release, and what should each confirmation trigger?
- Which priority, readiness, batching and finishing-time rules are required at launch?
- How should temporary stock unavailability appear in a standstill snapshot?
- What event marks manual packing complete, and which role can authorise a reprint?
- Where must WCS run, and what availability, recovery and site-network constraints apply?

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
