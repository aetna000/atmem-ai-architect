> Provisional WCS design derived from the exported project. The original customer document was unavailable. Requirements and proposed contracts require source review before implementation; no WCS code or commissioning evidence is included.

# A wcs system controlling libiao airrob… — delivery pack

Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

For a coding-agent handoff, start with START_HERE.md and AGENTS.md, then spec-kit/implementation-spec.md or PDF. The kit includes detailed task dependencies, acceptance criteria, contracts and a progress journal.

Open specification.md for scope, requirements, options and decisions; architecture-and-deployment.md for the diagram, review, costs and steps. estimate.json separates monthly cloud cost and one-off consulting/build cost. resource-schedule.json links resources to diagram IDs. terraform/ contains provider-specific generated artifacts where supported; generation-quality.json records component coverage, missing implementations, selected skill digests and validation boundaries.

Reopen project.atmem-ai-architect.json in AtMem AI Architect to change requirements, assumptions, decisions, prices or the diagram, then regenerate this pack. All files come from the same snapshot; do not maintain edited copies as the source of truth. Design revision tracks board changes; snapshot ID and generation time identify exports including changes to costs and requirements.

Cloud prices and professional-service rates are only those entered in the project. A ROM or detailed worksheet is not a fixed-price quote. No cloud access, deployment or successful infrastructure validation is implied.
