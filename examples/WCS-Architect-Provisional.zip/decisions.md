Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

### ADR-001 · First sketch of the AirRob warehouse control system

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r1 · **Subject:** `design.first-sketch-of-the-airrob-warehouse-control-system`

**Context**

The decanting and picking screens share one proposed warehouse control application. The application coordinates workstation work with the Libiao AirRob controller, exchanges JSON messages with the host, and records execution progress in a durable store. We treat the host and AirRob controller as external systems. The host remains connected through JSON, with message definitions, transport and stock allocation ownership open. The AirRob integration depends on the supported interface for the site's controller. Hosting is open. The diagram is a design sketch, and the WCS application and its integration adapters require custom implementation.

**Options considered**

—

**Decision**

Drawn while talking as design revision 2.

**Consequences**

—

### ADR-002 · Serve all three workstation workflows in kiosk mode

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r91 · **Subject:** `design.serve-all-three-workstation-workflows-in-kiosk-mode`

**Context**

Make the existing WCS component the shared web server. Keep decanting and picking as screens owned by the WCS, and add clearing as a third screen. Each workstation browser opens its assigned screen in kiosk mode over HTTPS. Hosting location and the clearing workflow rules are open. The JSON host connection, Libiao AirRob controller and durable execution records stay connected to the WCS. The browser flows and kiosk setup require implementation and testing.

**Options considered**

—

**Decision**

Drawn while talking as design revision 92.

**Consequences**

—

### ADR-003 · Add the warehouse host gateway

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r92 · **Subject:** `design.add-the-warehouse-host-gateway`

**Context**

Route the host exchange through a WCS-owned gateway. The gateway handles message validation and translation, while the WCS owns warehouse workflow decisions. Hosting, transport and service authentication remain open. The gateway and both interfaces require custom implementation and testing against the host contract.

**Options considered**

—

**Decision**

Drawn while talking as design revision 93.

**Consequences**

—

### ADR-004 · Add order planning, conveyor coordination and packing

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r93 · **Subject:** `design.add-order-planning-conveyor-coordination-and-packing`

**Context**

The WCS proposes a rules-based order planner within the shared application and a packing screen served by the same web server. Accepted host orders feed planning through the existing JSON gateway. The WCS coordinates conveyor routing through the site controller, which retains motion control, interlocks and emergency stops. Packing confirms package contents and requests the associated label through a print interface. Proposed execution records correlate orders, totes, packages and device jobs so operators can recover from jams, lost acknowledgements and printer faults. Stock allocation ownership, release rules, packing and label rules, equipment ownership and device interfaces remain open. The WCS workflows and equipment connections require custom implementation and site acceptance tests.

**Options considered**

—

**Decision**

Drawn while talking as design revision 94.

**Consequences**

—

### ADR-005 · Show RFID and complete the recorded warehouse workflows

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r97 · **Subject:** `design.show-rfid-and-complete-the-recorded-warehouse-workflows`

**Context**

Place RFID readers directly above the WCS web server and connect tag reads, reader faults and workstation checks. Draw local stock tracking, returns and counting, manual consolidation, auto-bagging, outbound sortation and supervisor controls from the recorded project requirements. Reuse the shared WCS application and execution store for its software modules. The WMS remains authoritative for warehouse-wide inventory and SKU master data, and site equipment retains motion and safety control. Reader locations, device contracts and installation ownership need site qualification. Individual dispatch-container contents and mandatory scanning at every chute are outside the initial sortation scope. This patch describes the design. WCS software and site integrations require implementation and acceptance testing.

**Options considered**

—

**Decision**

Drawn while talking as design revision 98.

**Consequences**

—

### ADR-006 · Group WCS business logic under Core

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r99 · **Subject:** `design.group-wcs-business-logic-under-core`

**Context**

Add Core as the business logic boundary within the shared WCS deployment. Group order planning and local stock tracking with Core, keeping their existing blocks for traceability. Workstation screens send actions to the web server, which checks permissions and calls Core. Core owns the workflow rules and coordinates the execution store, host gateway and equipment interfaces. The canvas uses a shared group to represent this relationship. Native parent-child nesting is unavailable in the current diagram format.

**Options considered**

—

**Decision**

Drawn while talking as design revision 100.

**Consequences**

—
