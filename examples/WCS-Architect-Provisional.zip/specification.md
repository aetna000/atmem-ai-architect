Snapshot 6abffcb6-9bcc-4b5c-b976-5af04737300c · design r101 · generated 2026-11-18T12:40:05.140Z

# A wcs system controlling libiao airrob… — solution specification

## Problem and intended outcome

I want to build a wcs system controlling libiao airrob has ui has workstation decanting and picking connects to host using json
we need a gateway connecting wcs to host system
we need to have business logic about order planning managing conveyor systems and printers packing
use this and check the diagrams add more needex
I CANNOT SEE ANY CHANGES TO THE. OARD VERSHER IS RFID
we want the biz logics to be in one blcok call it core can we have nested blocks

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers. (must, open); target: acceptance target needed; linked blocks: decant-workstation, picking-workstation, wcs

Design explanation: Clearing is now explicit workstation scope. Its business rules need to be defined before implementation.

Basis: User statement: I need a webserver to run decanting and picking and clearing in kiosk mode
- [REQ-004] Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move. (must, open); target: acceptance target needed; linked blocks: wcs, libiao-airrob, wcs-state

Design explanation: The WCS needs to match each move to warehouse work and account for failures before advancing the task.

Basis: The user asked for a WCS controlling Libiao AirRob. Tote jobs and status tracking are proposed responsibilities.
- [REQ-005] Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized. (must, open); target: acceptance target needed; linked blocks: warehouse-host, wcs, wcs-state

Design explanation: The gateway provides a single host integration boundary. Stable identifiers let the WCS recognize repeated requests and avoid creating duplicate warehouse work.

Basis: User statement: we need a gateway connecting wcs to host system
- [REQ-006] Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action. (must, open); target: acceptance target needed; linked blocks: wcs, decant-workstation, picking-workstation, clearing-workstation

Design explanation: A workstation should open directly to its assigned workflow. Server-side checks prevent a kiosk session from using actions beyond its permissions.

Basis: The user requested a webserver for decanting, picking and clearing in kiosk mode. Per-workstation assignment and server-side permission checks are proposed controls.
- [REQ-007] Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes. (must, open); target: acceptance target needed; linked blocks: order-planning, picking-workstation, wcs-state, host-gateway

Design explanation: Keeps individual orders identifiable through shared-tote picking, packing and label printing.

Basis: LSKD TAL WCS OCD Customer_v1.docx, Compartment selection, Order planning and Order fulfilment.
- [REQ-008] Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller. (must, open); target: acceptance target needed; linked blocks: wcs, conveyor-controller, wcs-state, libiao-airrob

Design explanation: Arrival and fault feedback let the WCS hold affected work when a tote is delayed, a conveyor is blocked or a move outcome is uncertain.

Basis: The user requested conveyor management. Routing and fault handling through the site controller are proposed boundaries.
- [REQ-009] Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design. (must, open); target: acceptance target needed; linked blocks: order-planning, packing-workstation, packing-printers, host-gateway

Design explanation: Preserves package identity when work changes packing route or a print outcome is uncertain.

Basis: LSKD TAL WCS OCD Customer_v1.docx, Conveying to packing and Packing. The preceding board has an open controlled-reprint requirement.
- [REQ-010] Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it. (must, open); target: acceptance target needed; linked blocks: wcs-state, host-gateway, warehouse-host

Design explanation: Keeps the WMS inventory record aligned with execution while allowing the WCS to manage individual totes.

Basis: LSKD TAL WCS OCD Customer_v1.docx, SKU master data management, Stock management and Stock reconciliation.
- [REQ-011] Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site. (must, open); target: acceptance target needed; linked blocks: rfid-readers, wcs, wcs-state, decant-workstation, picking-workstation

Design explanation: Prevents stray reads, missed tags and unstable counts from silently changing confirmed inventory or order quantities.

Basis: Existing REQ-011 and the user’s request to show RFID on the board.
- [REQ-012] Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing. (must, open); target: acceptance target needed; linked blocks: conveyor-controller, host-gateway, warehouse-host, packing-workstation

Design explanation: Prevents stale quantities from being used when manually picked items reach packing.

Basis: LSKD TAL WCS OCD Customer_v1.docx, Partial orders and manual completion and Transport orders.
- [REQ-013] Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope. (must, open); target: acceptance target needed; linked blocks: conveyor-controller, wcs-state

Design explanation: Prevents overflow from recirculating and lets operators complete routing of affected parcels.

Basis: LSKD TAL WCS OCD Customer_v1.docx, Sortation and conveying, Chute overflow and clearing, and End-of-chute bin handling.
- [REQ-014] Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing. (must, open); target: acceptance target needed; linked blocks: picking-workstation, clearing-workstation

Design explanation: Maintains accurate counts and prevents a mode switch from stranding assigned work.

Basis: LSKD TAL WCS OCD Customer_v1.docx, Inventory – Cycle counting, Inventory – Returns housekeeping and GTP modes.
- [REQ-015] Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks. (must, open); target: acceptance target needed; linked blocks: wcs, order-planning, wcs-state

Design explanation: Gives supervisors operational control with accountability for changes that affect work or stock.

Basis: LSKD TAL WCS OCD Customer_v1.docx, WCS supervisor application and Reporting. Server-side role checks and audit are proposed engineering controls consistent with the kiosk permission boundary.
- [REQ-016] Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history. (must, open); target: acceptance target needed; linked blocks: wcs-state, host-gateway, libiao-airrob, conveyor-controller, packing-printers

Design explanation: Prevents duplicate moves, stock adjustments or labels after a timeout or restart.

Basis: Proposed recovery requirement derived from the board's WCS execution records and the OCD's host and equipment handoffs.

## How the system works

The current design contains 20 components and 20 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Decanting workstation → WCS web server

HTTPS decanting screen and load confirmations

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Picking workstation → WCS web server

HTTPS picking screen and pick confirmations

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Host integration gateway → Warehouse host system

Host JSON requests in, results and exceptions out

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Core → Libiao AirRob controller

Tote move jobs out, status and faults in

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Core → WCS execution records

Save and recover orders, tasks, packages and equipment jobs

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Clearing workstation → WCS web server

Clearing tasks, reject parcel identification and operator confirmations

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Core → Host integration gateway

Validated work requests in, results and exceptions out

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Core → Order planning

Accepted orders and progress in, planned tasks out

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Packing workstation → WCS web server

HTTPS packing screen, package confirmations and label requests

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Core → Conveyor controller

Tote routes to manual packing or auto-bagging, arrivals and faults

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Core → Packing label printers

Package label jobs out, available status and faults in

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: RFID readers → Core

Tag reads and reader faults for workstation checks

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Core → Local stock tracking

Confirmed stock changes, availability and snapshot requests

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Local stock tracking → WCS execution records

Save stock by SKU and tote and record reason-coded changes

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 15: Manual consolidation and re-induction → WCS web server

Partial-pick handoff and WMS-authorised tote re-induction

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 16: Returns and stock counts → WCS web server

Returns induction, stock counts and workstation mode changes

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 17: Supervisor console → WCS web server

Operational status and authorised supervisory actions

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 18: Core → Auto-bagging equipment

Eligible packing work, package outcomes and equipment faults

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 19: Core → Outbound sortation

Shipping label and chute mapping, route and reject feedback

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 20: WCS web server → Core

Authorised workstation actions in, tasks and outcomes back

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Decanting workstation

Application runtime and API · tools · region: To be selected · classification: Internal

Kiosk screen within the shared WCS deployment. Operators identify the inbound item and destination tote, confirm the loaded quantity and flag discrepancies. Where RFID is enabled, display expected and read quantities and require physical checking and an operator confirmation or authorised override before committing a mismatch.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Decanting workstation → WCS web server: HTTPS decanting screen and load confirmations

Requirement traceability: REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.; REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Picking workstation

Application runtime and API · tools · region: To be selected · classification: Internal

Kiosk screen within the shared WCS deployment. Show the pick task when the expected tote is available, including the relevant compartment. Record quantity picked and shortages. Where RFID is enabled, show read discrepancies and require physical checking and operator confirmation or an authorised override before committing the outcome.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Picking workstation → WCS web server: HTTPS picking screen and pick confirmations

Requirement traceability: REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.; REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.; REQ-014: Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### WCS web server

Application runtime and API · tools · region: To be selected · classification: Internal

Shared WCS deployment serves decanting, picking, clearing, packing, returns, stock counts and supervisor screens over HTTPS. Enforces server-side permissions and passes authorised actions to Core, which runs in the same deployment. Presents workflow state, equipment status and RFID discrepancies, and collects physical-check confirmations or authorised overrides. Hosting remains open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Decanting workstation → WCS web server: HTTPS decanting screen and load confirmations; Picking workstation → WCS web server: HTTPS picking screen and pick confirmations; Clearing workstation → WCS web server: Clearing tasks, reject parcel identification and operator confirmations; Packing workstation → WCS web server: HTTPS packing screen, package confirmations and label requests; Manual consolidation and re-induction → WCS web server: Partial-pick handoff and WMS-authorised tote re-induction; Returns and stock counts → WCS web server: Returns induction, stock counts and workstation mode changes; Supervisor console → WCS web server: Operational status and authorised supervisory actions

Outputs: WCS web server → Core: Authorised workstation actions in, tasks and outcomes back

Requirement traceability: REQ-003: Provide kiosk-mode workstation screens for decanting, picking and clearing. Let operators confirm items and quantities during decanting and picking and flag exceptions for follow-up. Define what clearing acts on and what confirming it triggers.; REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.; REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.; REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.; REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### WCS execution records

Storage or existing data connector · tools · region: To be selected · classification: Internal

WCS-owned durable store for order plans, task progress, local stock by SKU and tote, host and equipment identifiers, package and label jobs, operator confirmations, RFID mismatch evidence and supervisor audit records. Reconcile uncertain host, motion or print outcomes before retrying. Retain decisions by authorised operators. Storage technology remains open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → WCS execution records: Save and recover orders, tasks, packages and equipment jobs; Local stock tracking → WCS execution records: Save stock by SKU and tote and record reason-coded changes

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.; REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.; REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.; REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.; REQ-013: Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.; REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Warehouse host system

Application runtime and API · tools · region: To be selected · classification: Internal

Existing warehouse management system (WMS). Owns warehouse-wide inventory and SKU master data. Exchanges JSON work requests, direct transport orders, execution outcomes and exceptions through the host gateway. Receives exceptional stock deltas, manual-consolidation handoffs and requested standstill snapshots, and provides shipping label data for packing. Product, schemas and transport remain open.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Host integration gateway → Warehouse host system: Host JSON requests in, results and exceptions out

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Exchange work requests, results and exceptions between the WCS and warehouse host through a gateway using an agreed host-facing JSON contract with stable identifiers so repeated messages can be recognized.; REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Libiao AirRob controller

Libiao AirRob · tools · region: To be selected · classification: Internal

External vendor control boundary for AirRob. Proposed exchange sends tote transport jobs and receives job status and faults. Site-specific interface, job identifiers and recovery behavior need vendor evidence.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Core → Libiao AirRob controller: Tote move jobs out, status and faults in

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Submit tote transport jobs through the site's supported Libiao AirRob interface, correlate status and faults to warehouse tasks, and reconcile uncertain outcomes before retrying a move.; REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Clearing workstation

Application runtime and API · tools · region: To be selected · classification: Internal

Kiosk screen within the shared WCS deployment. Supports clearing tasks and records operator confirmations or exceptions. For sorter rejects, allow parcel identification, destination confirmation and manual clearing. Other clearing scenarios and the effects of their confirmations remain open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Clearing workstation → WCS web server: Clearing tasks, reject parcel identification and operator confirmations

Requirement traceability: REQ-006: Serve all three workstation workflows from one WCS web server. Each configured workstation opens its assigned screen in kiosk mode over HTTPS, and the server enforces permissions for each workstation action.; REQ-014: Allow operators to induct inspected mixed returns and confirm off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote with manual assistance when RFID is unreliable. When changing a goods-to-picker mode, stop new allocations and let assigned work finish before switching to picking, counting or clearing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Host integration gateway

Application runtime and API · tools · region: To be selected · classification: Internal

WCS-owned integration component. Validates and maps host JSON for order start and cancellation, SKU changes, direct transport orders, label data and snapshot requests. Returns planning and execution milestones, exceptions, manual-consolidation handoffs, quantity deltas and snapshots. Use stable identifiers and durable tracking of accepted requests and pending results to prevent duplicate or lost work through retries and restarts. Exact host contract, acknowledgements, authentication and deployment boundary remain open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Host integration gateway: Validated work requests in, results and exceptions out

Outputs: Host integration gateway → Warehouse host system: Host JSON requests in, results and exceptions out

Requirement traceability: REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-010: Keep WMS authoritative for warehouse-wide inventory and SKU master data. Track stock by SKU, stock properties and tote within WCS. Acknowledge SKU retirement only after stock and order references clear. Report exceptional quantity deltas with reason codes and provide WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Keep temporary unavailability local and confirm how snapshots represent it.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Order planning

Application runtime and API · tools · region: To be selected · classification: Internal

Module within the WCS application. Plans internal work from WMS start instructions using agreed priorities, finishing times and readiness rules. Accepts cancellation only before planning begins. Batches eligible single-SKU single-item orders under configurable rules and preserves order and item identity against each tote compartment. Audits operator overrides and emits planning-started, picked and execution-completed outcomes through the gateway. Stock allocation rules and batching thresholds remain open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Order planning: Accepted orders and progress in, planned tasks out

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-007: Plan internal work from WMS start instructions and agreed priority, finishing time and readiness rules. Accept cancellation only before planning starts. Batch eligible single-SKU single-item orders using agreed thresholds, preserve each order and item against its tote compartment, audit operator overrides and publish planning-started, picked and execution-completed outcomes.; REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-015: Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. Authorise and audit supervisory changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Packing workstation

Application runtime and API · tools · region: To be selected · classification: Internal

Manual packing kiosk within the shared WCS deployment, including for ineligible or oversized work and fully manually picked orders. Verify the tote and compartment against current expected contents, including revisions from manual consolidation. Confirm package contents and request the WMS-supplied shipping label linked to the order and package. Record uncertain print outcomes and require an authorised reason for reprints. The exact completion trigger remains open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Packing workstation → WCS web server: HTTPS packing screen, package confirmations and label requests

Requirement traceability: REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Conveyor controller

Application runtime and API · tools · region: To be selected · classification: Internal

Proposed site equipment integration boundary. The WCS requests routing and consumes arrival, availability and fault events through a supported interface. The controller owns motion, interlocks and emergency stops. Controller product, ownership, interface and recovery behaviour remain open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Conveyor controller: Tote routes to manual packing or auto-bagging, arrivals and faults

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-008: Coordinate tote routing through the site conveyor controller and correlate supported arrival and fault events with WCS tasks. Hold affected work on a fault or uncertain route outcome until it is reconciled. Keep motion and safety controls in the site controller.; REQ-012: Report partially picked totes and their contents to WMS when routed to manual consolidation. Re-induct manually completed or fully manually picked totes only against an identified WMS direct transport order that links tote, order, destination, revised quantities and additions or shortages. Use the updated expected contents at packing.; REQ-013: Map shipping-label identifiers to logical destinations and physical chutes. Record booked and actual routing where the equipment provides it. Send full-chute overflow to reject without recirculation and let an operator identify the parcel, confirm its destination and record manual clearing. Exclude individual dispatch container contents and mandatory scanning at every chute from initial scope.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Packing label printers

Application runtime and API · tools · region: To be selected · classification: Internal

Proposed site print integration boundary for packing stations. The WCS sends package-linked label jobs and records job acknowledgements or faults where supported. The packing screen shows uncertain outcomes and supports controlled reprints. Printer ownership, interface, label formats and status capabilities remain open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Packing label printers: Package label jobs out, available status and faults in

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-009: Route eligible single-item batches and multi-item orders to auto-bagging and divert ineligible or oversized work to manual packing. At manual packing check the tote and compartment, confirm contents and print the WMS-supplied label for the linked order and package, including fully manual orders. Record print failures and uncertain outcomes. Define authorised reprints with a recorded reason during detailed design.; REQ-016: Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### RFID readers

Ingestion / processing service · tools · region: To be selected · classification: Internal

Proposed on-site reader equipment at RFID-enabled workstations. Supply tagged-item observations and reader health to WCS with enough context to associate each read with the correct workstation and task. Qualify tag-to-SKU identification, reader placement, read stability and filtering of nearby tags with real totes. Reader model, exact locations, interface and ownership remain open. WCS owns validation and the manual fallback.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: RFID readers → Core: Tag reads and reader faults for workstation checks

Requirement traceability: REQ-011: Compare workstation RFID reads with expected SKU quantities. On a discrepancy require physical checking and operator confirmation or an authorised override before changing an order or inventory record. Record mismatch evidence and resolution. Qualify tag identification, spacing, nearby-tag filtering and read stability at the site.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Local stock tracking

Application runtime and API · tools · region: To be selected · classification: Internal

Module within the shared WCS application. Tracks stock by SKU, stock properties and tote using WCS execution records. Reports exceptional quantity deltas with reason codes and returns WMS-requested standstill snapshots as aggregate SKU quantities without rack locations. Acknowledges SKU retirement once stock and order references clear. Temporary unavailability stays local. Its treatment in snapshots remains open. WMS owns warehouse-wide inventory and SKU master data.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Local stock tracking: Confirmed stock changes, availability and snapshot requests

Outputs: Local stock tracking → WCS execution records: Save stock by SKU and tote and record reason-coded changes

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Manual consolidation and re-induction

Application runtime and API · tools · region: To be selected · classification: Internal

Workflow within the shared WCS deployment. When a partially picked tote goes to manual consolidation, report its contents to WMS. Accept a manually completed or fully manually picked tote back into WCS only against a WMS direct transport order linking tote, order, destination, revised quantities and additions or shortages. Pass the revised expected contents to packing.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Manual consolidation and re-induction → WCS web server: Partial-pick handoff and WMS-authorised tote re-induction

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Returns and stock counts

Application runtime and API · tools · region: To be selected · classification: Internal

Workstation workflows within the shared WCS deployment. Record inspected mixed returns and operator-confirmed off-peak transfers to product totes. Support supervisor-requested counts by SKU or tote, with manual checking when RFID readings are unreliable. Before switching between picking, counting and clearing, stop new allocations and let assigned work finish.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Returns and stock counts → WCS web server: Returns induction, stock counts and workstation mode changes

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Supervisor console

Application runtime and API · tools · region: To be selected · classification: Internal

Screen within the shared WCS deployment. Show inbound and outbound workload, progress, pipeline and carrier levels, stock, pending counts and transport orders, prioritised alerts and productivity. WCS authorises and audits changes to finishing times, shortening of orders awaiting allocation, count requests, workstation activation and modes, and location locks.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Supervisor console → WCS web server: Operational status and authorised supervisory actions

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Auto-bagging equipment

Application runtime and API · tools · region: To be selected · classification: Internal

Site equipment boundary for automatic packing. WCS proposes routing eligible single-item batches and multi-item orders here through the conveyor controller and diverting ineligible or oversized work to manual packing. Correlate supported packing results and faults with the correct package and order. Bagging interface, arrival and completion signals, eligibility rules and label handoff require site evidence.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Auto-bagging equipment: Eligible packing work, package outcomes and equipment faults

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Outbound sortation

Application runtime and API · tools · region: To be selected · classification: Internal

Site sorter and WCS integration boundary. WCS maps shipping-label identifiers to logical destinations and physical chutes, and records the booked route and available actual-route feedback. Send full-chute overflow to reject without recirculation. At the clearing screen, allow operators to identify rejected parcels, confirm destinations and record manual clearing. Confirm equipment event and routing contracts on site.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Core → Outbound sortation: Shipping label and chute mapping, route and reject feedback

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Core

Application runtime and API · tools · region: To be selected · classification: Internal

Business logic module within the shared WCS web server deployment. Owns order planning, task and workflow state, local stock tracking, RFID validation and manual discrepancy resolution, returns, counting, manual consolidation and re-induction, packing and label rules, outbound sortation and supervisor actions. Coordinates AirRob tote moves, conveyor routing, auto-bagging, printing and sorter operations through site interfaces. Equipment controllers retain motion and safety control. Persists execution and audit records, reconciles uncertain outcomes before retrying, and exchanges work, results and exceptions with the WMS through the host gateway.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: RFID readers → Core: Tag reads and reader faults for workstation checks; WCS web server → Core: Authorised workstation actions in, tasks and outcomes back

Outputs: Core → Libiao AirRob controller: Tote move jobs out, status and faults in; Core → WCS execution records: Save and recover orders, tasks, packages and equipment jobs; Core → Host integration gateway: Validated work requests in, results and exceptions out; Core → Order planning: Accepted orders and progress in, planned tasks out; Core → Conveyor controller: Tote routes to manual packing or auto-bagging, arrivals and faults; Core → Packing label printers: Package label jobs out, available status and faults in; Core → Local stock tracking: Confirmed stock changes, availability and snapshot requests; Core → Auto-bagging equipment: Eligible packing work, package outcomes and equipment faults; Core → Outbound sortation: Shipping label and chute mapping, route and reject feedback

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact tools service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Decanting workstation<br/>Tools & data"]
  n1["Picking workstation<br/>Tools & data"]
  n2["WCS web server<br/>Tools & data"]
  n3["WCS execution records<br/>Tools & data"]
  n4["Warehouse host system<br/>Tools & data"]
  n5["Libiao AirRob controller<br/>Tools & data"]
  n6["Clearing workstation<br/>Tools & data"]
  n7["Host integration gateway<br/>Tools & data"]
  n8["Order planning<br/>Tools & data"]
  n9["Packing workstation<br/>Tools & data"]
  n10["Conveyor controller<br/>Tools & data"]
  n11["Packing label printers<br/>Tools & data"]
  n12["RFID readers<br/>Tools & data"]
  n13["Local stock tracking<br/>Tools & data"]
  n14["Manual consolidation and re-induction<br/>Tools & data"]
  n15["Returns and stock counts<br/>Tools & data"]
  n16["Supervisor console<br/>Tools & data"]
  n17["Auto-bagging equipment<br/>Tools & data"]
  n18["Outbound sortation<br/>Tools & data"]
  n19["Core<br/>Tools & data"]
  n0 -->|HTTPS decanting screen and load confirmations| n2
  n1 -->|HTTPS picking screen and pick confirmations| n2
  n7 -->|Host JSON requests in, results and exceptions out| n4
  n19 -->|Tote move jobs out, status and faults in| n5
  n19 -->|Save and recover orders, tasks, packages and equipment jobs| n3
  n6 -->|Clearing tasks, reject parcel identification and operator confirmations| n2
  n19 -->|Validated work requests in, results and exceptions out| n7
  n19 -->|Accepted orders and progress in, planned tasks out| n8
  n9 -->|HTTPS packing screen, package confirmations and label requests| n2
  n19 -->|Tote routes to manual packing or auto-bagging, arrivals and faults| n10
  n19 -->|Package label jobs out, available status and faults in| n11
  n12 -->|Tag reads and reader faults for workstation checks| n19
  n19 -->|Confirmed stock changes, availability and snapshot requests| n13
  n13 -->|Save stock by SKU and tote and record reason-coded changes| n3
  n14 -->|Partial-pick handoff and WMS-authorised tote re-induction| n2
  n15 -->|Returns induction, stock counts and workstation mode changes| n2
  n16 -->|Operational status and authorised supervisory actions| n2
  n19 -->|Eligible packing work, package outcomes and equipment faults| n17
  n19 -->|Shipping label and chute mapping, route and reject feedback| n18
  n2 -->|Authorised workstation actions in, tasks and outcomes back| n19
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| decant-workstation | Decanting workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| picking-workstation | Picking workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| wcs | WCS web server | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| wcs-state | WCS execution records | tools | Storage or existing data connector | To be selected | Proposed | Implementation needed |
| warehouse-host | Warehouse host system | tools | Application runtime and API | To be selected | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| libiao-airrob | Libiao AirRob controller | tools | Libiao AirRob | To be selected | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| clearing-workstation | Clearing workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| host-gateway | Host integration gateway | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| order-planning | Order planning | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| packing-workstation | Packing workstation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| conveyor-controller | Conveyor controller | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| packing-printers | Packing label printers | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| rfid-readers | RFID readers | tools | Ingestion / processing service | To be selected | Proposed | Implementation needed |
| wcs-local-stock | Local stock tracking | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| manual-consolidation | Manual consolidation and re-induction | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| returns-counting | Returns and stock counts | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| supervisor-console | Supervisor console | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| auto-bagging | Auto-bagging equipment | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| outbound-sortation | Outbound sortation | tools | Application runtime and API | To be selected | Proposed | Implementation needed |
| wcs-core | Core | tools | Application runtime and API | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Decanting workstation** (decant-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Picking workstation** (picking-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **WCS web server** (wcs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: decant-workstation, picking-workstation, clearing-workstation, packing-workstation, manual-consolidation, returns-counting, supervisor-console.
- **WCS execution records** (wcs-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core, wcs-local-stock.
- **Warehouse host system** (warehouse-host): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: host-gateway.
- **Libiao AirRob controller** (libiao-airrob): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Clearing workstation** (clearing-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Host integration gateway** (host-gateway): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Order planning** (order-planning): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Packing workstation** (packing-workstation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Conveyor controller** (conveyor-controller): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Packing label printers** (packing-printers): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **RFID readers** (rfid-readers): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Local stock tracking** (wcs-local-stock): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Manual consolidation and re-induction** (manual-consolidation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Returns and stock counts** (returns-counting): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Supervisor console** (supervisor-console): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Auto-bagging equipment** (auto-bagging): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Outbound sortation** (outbound-sortation): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: wcs-core.
- **Core** (wcs-core): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: rfid-readers, wcs.

### Engineering work remaining

- Decanting workstation: Implementation needed.
- Picking workstation: Implementation needed.
- WCS web server: Implementation needed.
- WCS execution records: Implementation needed.
- Clearing workstation: Implementation needed.
- Host integration gateway: Implementation needed.
- Order planning: Implementation needed.
- Packing workstation: Implementation needed.
- Conveyor controller: Implementation needed.
- Packing label printers: Implementation needed.
- RFID readers: Implementation needed.
- Local stock tracking: Implementation needed.
- Manual consolidation and re-induction: Implementation needed.
- Returns and stock counts: Implementation needed.
- Supervisor console: Implementation needed.
- Auto-bagging equipment: Implementation needed.
- Outbound sortation: Implementation needed.
- Core: Implementation needed.
- Wire decant-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire picking-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire host-gateway → warehouse-host: implement data flow, access policy and acceptance test.
- Wire wcs-core → libiao-airrob: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-state: implement data flow, access policy and acceptance test.
- Wire clearing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → host-gateway: implement data flow, access policy and acceptance test.
- Wire wcs-core → order-planning: implement data flow, access policy and acceptance test.
- Wire packing-workstation → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → conveyor-controller: implement data flow, access policy and acceptance test.
- Wire wcs-core → packing-printers: implement data flow, access policy and acceptance test.
- Wire rfid-readers → wcs-core: implement data flow, access policy and acceptance test.
- Wire wcs-core → wcs-local-stock: implement data flow, access policy and acceptance test.
- Wire wcs-local-stock → wcs-state: implement data flow, access policy and acceptance test.
- Wire manual-consolidation → wcs: implement data flow, access policy and acceptance test.
- Wire returns-counting → wcs: implement data flow, access policy and acceptance test.
- Wire supervisor-console → wcs: implement data flow, access policy and acceptance test.
- Wire wcs-core → auto-bagging: implement data flow, access policy and acceptance test.
- Wire wcs-core → outbound-sortation: implement data flow, access policy and acceptance test.
- Wire wcs → wcs-core: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Design checks and decisions

### ADR-001 · First sketch of the AirRob warehouse control system

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r1 · **Subject:** `design.first-sketch-of-the-airrob-warehouse-control-system`

**Context**

The decanting and picking screens share one proposed warehouse control application. The application coordinates workstation work with the Libiao AirRob controller, exchanges JSON messages with the host, and records execution progress in a durable store. We treat the host and AirRob controller as external systems. The host remains connected through JSON, with message definitions, transport and stock allocation ownership open. The AirRob integration depends on the supported interface for the site's controller. Hosting is open. The diagram is a design sketch, and the WCS application and its integration adapters require custom implementation.

**Options considered**

—

**Decision**

Drawn while talking as design revision 2.

**Consequences**

—

### ADR-002 · Serve all three workstation workflows in kiosk mode

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r91 · **Subject:** `design.serve-all-three-workstation-workflows-in-kiosk-mode`

**Context**

Make the existing WCS component the shared web server. Keep decanting and picking as screens owned by the WCS, and add clearing as a third screen. Each workstation browser opens its assigned screen in kiosk mode over HTTPS. Hosting location and the clearing workflow rules are open. The JSON host connection, Libiao AirRob controller and durable execution records stay connected to the WCS. The browser flows and kiosk setup require implementation and testing.

**Options considered**

—

**Decision**

Drawn while talking as design revision 92.

**Consequences**

—

### ADR-003 · Add the warehouse host gateway

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r92 · **Subject:** `design.add-the-warehouse-host-gateway`

**Context**

Route the host exchange through a WCS-owned gateway. The gateway handles message validation and translation, while the WCS owns warehouse workflow decisions. Hosting, transport and service authentication remain open. The gateway and both interfaces require custom implementation and testing against the host contract.

**Options considered**

—

**Decision**

Drawn while talking as design revision 93.

**Consequences**

—

### ADR-004 · Add order planning, conveyor coordination and packing

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r93 · **Subject:** `design.add-order-planning-conveyor-coordination-and-packing`

**Context**

The WCS proposes a rules-based order planner within the shared application and a packing screen served by the same web server. Accepted host orders feed planning through the existing JSON gateway. The WCS coordinates conveyor routing through the site controller, which retains motion control, interlocks and emergency stops. Packing confirms package contents and requests the associated label through a print interface. Proposed execution records correlate orders, totes, packages and device jobs so operators can recover from jams, lost acknowledgements and printer faults. Stock allocation ownership, release rules, packing and label rules, equipment ownership and device interfaces remain open. The WCS workflows and equipment connections require custom implementation and site acceptance tests.

**Options considered**

—

**Decision**

Drawn while talking as design revision 94.

**Consequences**

—

### ADR-005 · Show RFID and complete the recorded warehouse workflows

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r97 · **Subject:** `design.show-rfid-and-complete-the-recorded-warehouse-workflows`

**Context**

Place RFID readers directly above the WCS web server and connect tag reads, reader faults and workstation checks. Draw local stock tracking, returns and counting, manual consolidation, auto-bagging, outbound sortation and supervisor controls from the recorded project requirements. Reuse the shared WCS application and execution store for its software modules. The WMS remains authoritative for warehouse-wide inventory and SKU master data, and site equipment retains motion and safety control. Reader locations, device contracts and installation ownership need site qualification. Individual dispatch-container contents and mandatory scanning at every chute are outside the initial sortation scope. This patch describes the design. WCS software and site integrations require implementation and acceptance testing.

**Options considered**

—

**Decision**

Drawn while talking as design revision 98.

**Consequences**

—

### ADR-006 · Group WCS business logic under Core

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-18 · **Design:** r99 · **Subject:** `design.group-wcs-business-logic-under-core`

**Context**

Add Core as the business logic boundary within the shared WCS deployment. Group order planning and local stock tracking with Core, keeping their existing blocks for traceability. Workstation screens send actions to the web server, which checks permissions and calls Core. Core owns the workflow rules and coordinates the execution store, host gateway and equipment interfaces. The canvas uses a shared group to represent this relationship. Native parent-child nesting is unavailable in the current diagram format.

**Options considered**

—

**Decision**

Drawn while talking as design revision 100.

**Consequences**

—


### Design checks

- [open] The design depends on existing systems; their failure behaviour is not described.
  Rationale: If an integration is down, requests may be lost or duplicated.
  Next action: State what happens when each existing system is unavailable (retry, queue, fallback).
  Source: AtMem AI Architect rule REL-002 v1.0.0

- [open] No availability target.
  Rationale: Without one, nobody can say whether a single region or a single endpoint is enough.
  Next action: Add a requirement such as “available 99.5% of the time” or “business hours only”.
  Source: AtMem AI Architect rule AVL-001 v1.0.0

- [open] Expected usage is unknown, so scale can't be assessed.
  Rationale: Usage drives capacity, limits and cost.
  Next action: Tell us in the chat roughly how many people use it and how often.
  Source: AtMem AI Architect rule SCL-001 v1.0.0

- [open] 1 quality requirement has no measurable target.
  Rationale: A target makes it testable and lets the review say met or not met.
  Next action: Add a metric and target to: “Persist task progress, confirmed quantities, message identifiers, package associations and equipment job references. On timeout or restart, reconcile uncertain outcomes before resubmitting host, motion or print work. Route unresolved cases to an authorised operator and retain the resolution history.”.
  Source: AtMem AI Architect rule MNT-001 v1.0.0

- [open] 6 accepted decisions have no owner.
  Rationale: Someone must be accountable for each choice before build.
  Next action: Assign an owner in Design → Decisions.
  Source: AtMem AI Architect rule MNT-002 v1.0.0

- [open] No budget stated.
  Rationale: Without one, the estimate can't flag an option as too expensive.
  Next action: Mention a monthly running budget, or a range, in the chat.
  Source: AtMem AI Architect rule CST-001 v1.0.0

- [open] 20 blocks are sketch-only and can't be test-run yet.
  Rationale: Sketch blocks describe intent; runnable fixtures exist only for some workflows.
  Next action: Keep designing; assign a runnable behaviour in block detail when one exists.
  Source: AtMem AI Architect rule DSN-001 v1.0.0

## Assumptions

None recorded.

## Questions to resolve

- [wcs-discovery-1] Which system or role is authorised to release a held tote after WMS and equipment outcomes disagree?
- [wcs-discovery-2] Who can provide the current WMS JSON schemas, sample exchanges and the authoritative acknowledgement and replay rules?
- [wcs-discovery-3] Which AirRob interface and job status lookup does the site support, and who can supply its official contract and simulator?
- [wcs-discovery-4] Which clearing workflows beyond sorter rejects belong in first release, and what should each confirmation trigger?
- [wcs-discovery-5] Which priority, readiness, batching and finishing-time rules are required at launch?
- [wcs-discovery-6] How should temporary stock unavailability appear in a standstill snapshot?
- [wcs-discovery-7] What event marks manual packing complete, and which role can authorise a reprint?
- [wcs-discovery-8] Where must WCS run, and what availability, recovery and site-network constraints apply?


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
