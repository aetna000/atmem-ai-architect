import unittest
class Counterexample(unittest.TestCase):
 def test_failure(self):self.fail("Deliberate failure must remain visible")
