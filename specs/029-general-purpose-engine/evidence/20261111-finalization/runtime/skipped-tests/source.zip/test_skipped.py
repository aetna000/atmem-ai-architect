import unittest
class Missing(unittest.TestCase):
 @unittest.skip("Missing evidence")
 def test_missing(self):pass
