import unittest
class Rainfall(unittest.TestCase):
 def test_total(self):self.assertEqual(sum([2,4,6]),12)
