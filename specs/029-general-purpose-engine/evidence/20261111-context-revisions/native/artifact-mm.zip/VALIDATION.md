# Validation evidence

Local execution on Node v26.5.0, macOS ARM64: all 8 tests passed, with no failures
or skips, using `OPENSSL_CONF=/dev/null ./.tools/node --test depth.test.mjs`.
The OpenSSL override avoided an inaccessible host configuration file; the library
does not use OpenSSL. The ordinary portable command is in the README.

The registered `node-browser-tests` check runs Node's tests on an immutable
snapshot. Its operator-pinned runtime observation identifies Node 26.13.0 on
Linux ARM64 (image
`sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128`,
runtime observation receipt
`4d7876ef1983bdcca7435bcacf53eda8bf75c7aa389031b08748b4e31538815d`).
The separate check receipt establishes that snapshot's outcome; the catalog
alone does not establish an application test pass. No Playwright dependency or
browser is used by these tests. Other runtime versions remain unverified.

Generated tests and local registered checks do not establish independent client
acceptance. No settled delivery package is implied by a working snapshot check.

No provider schemas or mocks apply to this standalone conversion library. No
cloud, gauge integration or browser checks are required by the saved scope.
The pinned knowledge search returned cloud-specific records; none applies to
this dependency-free local module. No mirrored dependencies were selected.
