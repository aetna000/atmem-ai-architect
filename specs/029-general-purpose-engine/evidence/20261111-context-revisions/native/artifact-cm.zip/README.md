# River depth conversion 🛰️

Independent, synchronous local CommonJS library. The client owns the existing river
gauge; this library neither connects to it nor changes it. No network, cloud,
credentials, persistent state, third-party dependencies or build step are needed.

```js
const { normalize, unit } = require('./depth.cjs');
console.log(normalize(1.25), unit); // 125 cm
```

`normalize(metres)` accepts every finite nonnegative JavaScript number primitive
and returns `metres * 100` in centimetres. All other inputs throw `TypeError`,
without coercion. It preserves JavaScript floating-point behavior: fractional
centimetres are retained, `-0` remains `-0`, and sufficiently large finite inputs
produce `Infinity`. No extra input cap or rounding is imposed.

From a fresh unpack with Node already installed, run:

```sh
node --test depth.test.mjs
node -e "console.log(require('./depth.cjs').normalize(1.25))"
```

The tests use only Node's built-in test runner and assertions. No install command
is required. Runtime execution evidence is recorded in `VALIDATION.md`; other
Node versions and platforms remain unverified.

Optional tool aliases for an exported copy can be prepared offline with the
supplied helper (requires existing Python 3 and Node executables):

```sh
python3 atmem-tools/prepare.py --node "$(command -v node)" --require node
OPENSSL_CONF="$PWD/.worker-tmp/openssl.cnf" ./.tools/node --test depth.test.mjs
```

Rollback: stop using this module and restore the consuming application's prior
module reference/version. There are no migrations or gauge changes to undo.

Delivery manifest: `depth.cjs` is the runtime file; `depth.test.mjs` contains tests;
`README.md` documents use; `VALIDATION.md` records execution and evidence limits.
The original `project-context.json`, `ATMEM_DELIVERY.md` and `atmem-tools/` inputs
are preserved. Current saved revision 2 changes the output from millimetres
(`×1000`, `mm`) to centimetres (`×100`, `cm`); the library follows revision 2.
The pinned revision 1 remains historical evidence. All other scope is retained;
there are no unresolved conflicts. Consumers of revision 1 must account for the
unit change. Worker-only directories are unnecessary for ordinary use.
