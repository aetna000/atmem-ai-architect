import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const depth = require('./depth.cjs');
const { normalize } = depth;

test('CommonJS exports normalize and the centimetre unit', () => {
  assert.deepEqual(Object.keys(depth).sort(), ['normalize', 'unit']);
  assert.equal(typeof normalize, 'function');
  assert.equal(depth.unit, 'cm');
});

test('converts whole and fractional metres without rounding', () => {
  for (const [metres, centimetres] of [
    [0, 0], [1, 100], [2.5, 250], [0.01, 1], [0.001, 0.1],
    [0.0005, 0.05], [123.456, 12345.6],
  ]) {
    assert.equal(normalize(metres), centimetres);
  }
});

test('accepts signed zero and preserves multiplication semantics', () => {
  assert.ok(Object.is(normalize(-0), -0));
  assert.ok(Object.is(normalize(0), 0));
});

test('accepts finite numeric extremes, including overflow of the result', () => {
  assert.equal(normalize(Number.MIN_VALUE), 4.94e-322);
  assert.equal(normalize(Number.MAX_SAFE_INTEGER), 900719925474099100);
  assert.equal(normalize(1e306), 1e308);
  assert.equal(normalize(Number.MAX_VALUE), Infinity);
});

test('rejects negative and nonfinite numbers with TypeError', () => {
  for (const value of [-Number.MIN_VALUE, -1, -Number.MAX_VALUE, NaN, Infinity, -Infinity]) {
    assert.throws(() => normalize(value), TypeError);
  }
});

test('rejects other primitive types and objects without numeric coercion', () => {
  for (const value of [
    undefined, null, true, false, '', '1', '0', 'Infinity', '🛰️',
    0n, 1n, Symbol('depth'), [], [1], {}, new Number(1),
    new Date(0), () => 1,
  ]) {
    assert.throws(() => normalize(value), TypeError);
  }
  assert.throws(() => normalize(), TypeError);
  let coercions = 0;
  const object = {
    [Symbol.toPrimitive]() { coercions += 1; return 1; },
  };
  assert.throws(() => normalize(object), TypeError);
  assert.equal(coercions, 0);
});

test('validates decoded JSON values without treating escaped strings as numbers', () => {
  assert.equal(normalize(JSON.parse('1.25')), 125);
  for (const json of ['"1.25"', '"\\u0031"', '"\\ud83d\\udef0\\ufe0f"', 'null', '1e400']) {
    assert.throws(() => normalize(JSON.parse(json)), TypeError);
  }
});

test('a rejected call leaves subsequent conversions usable and deterministic', () => {
  assert.equal(normalize(3.75), 375);
  assert.throws(() => normalize(-1), TypeError);
  assert.equal(normalize(3.75), 375);
  assert.equal(depth.unit, 'cm');
});
