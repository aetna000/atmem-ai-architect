'use strict';

/** Convert finite, nonnegative metre number primitives to centimetres. */
function normalize(metres) {
  if (typeof metres !== 'number' || !Number.isFinite(metres) || metres < 0) {
    throw new TypeError('metres must be a finite nonnegative number primitive');
  }
  return metres * 100;
}

module.exports = { normalize, unit: 'cm' };
