import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const { normalize, unit } = require('../readings.cjs');

test('CommonJS exports the converter and centimetre unit', () => {
  assert.equal(typeof normalize, 'function');
  assert.equal(unit, 'cm');
  assert.equal(normalize(25), 2.5);
  assert.equal(normalize(10), 1);
  assert.equal(normalize(0.5), 0.05);
});

test('accepts finite nonnegative limits with native IEEE-754 division', () => {
  for (const value of [0, -0, Number.MIN_VALUE, 1e-308, Number.EPSILON,
    1, Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER + 1, Number.MAX_VALUE]) {
    assert.ok(Object.is(normalize(value), value / 10));
  }
  assert.ok(Object.is(normalize(-0), -0));
  assert.equal(normalize(Number.MIN_VALUE), 0); // permitted floating-point underflow
  assert.equal(normalize(Number.MAX_VALUE), 1.7976931348623158e307);
});

test('covers the finite range across binary exponents', () => {
  for (let exponent = -1074; exponent <= 1023; exponent++) {
    for (const significand of [1, 1.25, 1.5, 1.75]) {
      const value = significand * 2 ** exponent;
      assert.ok(Object.is(normalize(value), value / 10));
      assert.throws(() => normalize(-value), TypeError);
    }
  }
});

test('rejects invalid values with TypeError without coercing objects', () => {
  const coercionTrap = {
    [Symbol.toPrimitive]() { throw new Error('must not coerce'); },
    valueOf() { throw new Error('must not coerce'); },
  };
  const revoked = Proxy.revocable({}, {});
  revoked.revoke();
  for (const value of [-Number.MIN_VALUE, -1, -Number.MAX_VALUE, NaN,
    Infinity, -Infinity, undefined, null, true, false, '', '10', '🛰️',
    0n, 10n, Symbol('rain'), [], [10], {}, new Number(10),
    () => 10, coercionTrap, revoked.proxy]) {
    assert.throws(() => normalize(value), TypeError);
  }
  assert.throws(() => normalize(), TypeError);
});

test('JSON transport does not make numeric strings or Unicode labels numbers', () => {
  assert.equal(normalize(JSON.parse('1e1')), 1);
  for (const encoded of ['"10"', '"\\u0031\\u0030"', '"🛰️"', '"\\ud83d\\udef0\\ufe0f"',
    'null', 'true', '[]', '{}', '1e400', '-1e-323']) {
    assert.throws(() => normalize(JSON.parse(encoded)), TypeError);
  }
});

test('a failed reading does not prevent subsequent valid conversions', () => {
  assert.throws(() => normalize('invalid'), TypeError);
  assert.equal(normalize(123), 12.3);
  assert.equal(normalize(123), 12.3);
});
