# Orchard rainfall readings 🛰️

An independent, synchronous CommonJS converter. Input is millimetres; output is
centimetres. The existing client-owned rain gauge and archive catalogue retain
their implementation and ownership. Neither system's implementation was supplied
in this workspace. Callers supply readings; this module does not connect to either
system, keep state, write files, or use a network.

## Run and test offline

Use an already installed Node.js executable. No package installation or build is
required. The runtime file is `readings.cjs`; copy it into the receiving project.
The test suite uses only Node built-ins:

```sh
node --test tests/readings.test.mjs
node -e "const {normalize, unit} = require('./readings.cjs'); console.log(normalize(25), unit)"
```

Expected example output: `2.5 cm`. Runtime verification and its limits are recorded
in `VERIFICATION.md`. Other runtime versions require qualification before use.
These commands work from a fresh unpack without worker files. If aliases are
preferred, the supplied helper can configure existing tools in a fresh unpack:

```sh
python3 atmem-tools/prepare.py --node /absolute/path/to/node --require node
export OPENSSL_CONF="$PWD/.worker-tmp/openssl.cnf"
.tools/node --test tests/readings.test.mjs
```

The helper requires an existing Python 3 installation; it installs nothing.
No SDKs, third-party packages, Terraform, cloud resources or browser are required.

## Contract

`require('./readings.cjs')` exports `normalize(millimetres)` and `unit`, equal to
`'cm'`. Every finite nonnegative JavaScript number primitive is accepted, including
negative zero and values above the safe-integer limit. All other inputs throw
`TypeError`, including numeric strings, boxed numbers, BigInt, NaN and infinities.
There is no coercion, rounding policy, upper cap or asynchronous initialization.
Errors leave the module ready for the next call.

The result is JavaScript's IEEE-754 `millimetres / 10`. Floating-point rounding and
subnormal underflow to zero apply; negative zero is preserved. Exact decimal
arithmetic is not promised. JSON is not an API of this module; a caller parsing
JSON must still supply a valid number primitive. Unicode labels such as 🛰️ remain
UTF-8 documentation text, without a string-length validation contract.

## Boundaries and rollback

The supplied frozen `project-context.json` and the server-supplied revision agree
on the converter and preservation requirements; their creation/update timestamps
differ. The original file is retained. `architecture-work-proposal.json` maps the
implementation to the saved design; these are proposed mappings, not acceptance.
The small reviewed knowledge corpus returned cloud practices, none applicable to
this local arithmetic module. No cloud guidance or dependencies were adopted.

The receiving application owner chooses when to call this module and how to
present invalid readings. Actual gauge integration and archive behavior cannot be
verified without their implementations. This delivery makes no changes to them.

To roll back, remove this module from the receiving application's imports and
restore its previous module/version if one existed. No data migration, remote
change or service restart is part of this standalone delivery. The files listed
in `MANIFEST.sha256` describe the handoff; the manifest excludes itself and worker
directories. Verify it after unpacking with `shasum -a 256 -c MANIFEST.sha256`
(or `sha256sum -c MANIFEST.sha256` on Linux).
