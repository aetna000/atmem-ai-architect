# Verification and limits

- Host local runtime: Node.js 26.5.0; all 6 `node:test` cases passed, no skips.
  The initial command failed before test execution because the sandbox denied
  access to Node's default host OpenSSL configuration. Rerunning with
  `OPENSSL_CONF=/dev/null .tools/node --test tests/readings.test.mjs` passed.
- Portable setup: a fresh temporary copy containing only the runtime file, test,
  delivery contract and supplied setup helper was configured with existing Node
  26.5.0 and Python 3.14.6. The documented helper, project-local OpenSSL config,
  all 6 tests and example invocation passed without downloads or original worker
  aliases. The example returned `2.5 cm`.
- Registered isolated runtime: check `697057bd-1f6a-4147-9bac-f89b5348e85f`
  passed all 6 tests, zero skips, exit 0. Checkpoint
  `cb7a8696-2c9b-434b-b783-d49b0c683f40`, SHA-256
  `93dbd89c74ff26833fa80be9fb2ee2771c28c4f9f093a8abca0db081f2bcfc67`.
  The full output was read with `nextOffset: null`. Operator-pinned observation
  identifies Node.js 26.13.0 on Linux ARM64 in image
  `sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128`.
  This checkpoint predates the final documentation and manifest; runtime and tests
  are unchanged. A subsequent working check covers the final files.
- Tested runtime versions are 26.5.0 and 26.13.0 only. No third-party dependencies
  are selected from the supplied mirror. Python is optional setup tooling rather
  than an application runtime dependency.
- Coverage includes signed zero, smallest subnormal, largest finite value,
  values above the safe-integer limit, binary exponents from -1074 through 1023,
  invalid primitives and objects (including coercion traps), escaped JSON text,
  non-BMP Unicode labels and continued use after errors. The contract is direct
  numeric input; JSON transport fixtures do not create a separate JSON API.
- Mocks: none used. Provider-schema checks: not applicable. Browser checks: not
  applicable to this synchronous module; the registered validator's browser
  capability was unused. Architecture proposal JSON Schema validation was not
  executed; no JSON Schema validator is installed in the host Python environment.
- The gauge and archive implementations were absent, so their live integration
  and behavior are unverified. Supplied inputs were preserved. No deployment,
  account access, infrastructure change or independent acceptance was performed.
  Local checks and working checkpoints are not a settled delivery package or
  whole-system acceptance.
