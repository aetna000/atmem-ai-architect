'use strict';

/** Convert a finite, nonnegative number primitive from millimetres to metres. */
function normalize(millimetres) {
  if (typeof millimetres !== 'number' || !Number.isFinite(millimetres) || millimetres < 0) {
    throw new TypeError('millimetres must be a finite nonnegative number primitive');
  }
  return millimetres / 1000;
}

module.exports = { normalize, unit: 'm' };
