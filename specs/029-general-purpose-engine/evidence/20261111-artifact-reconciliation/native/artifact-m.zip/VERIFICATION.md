# Verification and limits

## Current delivery: metres (saved context revision 2)

- Updated the tests to the user-edited metre contract before changing the module.
  They detected the existing centimetre implementation: 5 failures and 1 pass.
  After changing the divisor to 1000 and unit to `m`, all 6 tests passed with
  zero skips on host Node.js 26.5.0 using
  `OPENSSL_CONF=/dev/null .tools/node --test tests/readings.test.mjs`.
- A fresh temporary copy of the runtime, test, delivery contract and portable
  helper was configured using existing Node.js 26.5.0 and Python 3.14.6. With the
  helper's project-local OpenSSL configuration, all 6 tests and the example passed
  offline. `normalize(25)` produced `0.025` and `unit` was `m`.
- Registered isolated check `0348f504-fd53-49ac-b646-165b409db08f` passed all 6
  updated tests, zero skips, exit 0. Checkpoint
  `a736d68d-f195-461d-be47-eb3de460d0a5`, SHA-256
  `596e1d2596e48fe1c2645b879dc58f6ce28e9acde6b8117cba9e004d1b85d776`.
  Its complete report was read (`nextOffset: null`). The operator-pinned runtime
  is Node.js 26.13.0, Linux ARM64, in the same immutable image identified below.
  This check precedes this evidence update and manifest refresh; a final working
  check is required for the final file set. It is not a settled delivery package.
- Verified the frozen project context, delivery contract, setup helper, schema
  and dependency catalog against their previous manifest hashes before refreshing
  the manifest. All were unchanged. No gauge/archive code was present or modified.
- Rechecked the previous settled artifact
  `0c916a86-40bd-47c7-8bd1-4b23bb43e21d` (SHA-256
  `a1cebd7c20ad8e15c30d381778812093256e9e5b8507f8941745ba3031601040`)
  via check `eae7690e-0c62-40c4-ae42-b3c935da25d6` and read its complete report.
  Its 6 passing tests establish historical centimetre behavior only; they do not
  validate the revised requirement. The earlier evidence remains below.
- Current limits: proposal JSON Schema validation remains unexecuted. No mocks
  were used; provider-schema and browser checks are not applicable. Gauge/archive
  integration, other runtime versions and independent acceptance remain unverified.
  Local checks establish only the standalone numeric module's tested behavior.

## Historical delivery: centimetres (prior context revision 1)

The following results apply to the prior implementation, not the current metre
contract. Prior snapshots and checks are preserved as historical evidence.

- Host local runtime: Node.js 26.5.0; all 6 `node:test` cases passed, no skips.
  The initial command failed before test execution because the sandbox denied
  access to Node's default host OpenSSL configuration. Rerunning with
  `OPENSSL_CONF=/dev/null .tools/node --test tests/readings.test.mjs` passed.
- Portable setup: a fresh temporary copy containing only the runtime file, test,
  delivery contract and supplied setup helper was configured with existing Node
  26.5.0 and Python 3.14.6. The documented helper, project-local OpenSSL config,
  all 6 tests and example invocation passed without downloads or original worker
  aliases. The example returned `2.5 cm`.
- Registered isolated runtime: check `697057bd-1f6a-4147-9bac-f89b5348e85f`
  passed all 6 tests, zero skips, exit 0. Checkpoint
  `cb7a8696-2c9b-434b-b783-d49b0c683f40`, SHA-256
  `93dbd89c74ff26833fa80be9fb2ee2771c28c4f9f093a8abca0db081f2bcfc67`.
  The full output was read with `nextOffset: null`. Operator-pinned observation
  identifies Node.js 26.13.0 on Linux ARM64 in image
  `sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128`.
  This checkpoint predates the final documentation and manifest; runtime and tests
  are unchanged. A subsequent working check covers the final files.
- Tested runtime versions are 26.5.0 and 26.13.0 only. No third-party dependencies
  are selected from the supplied mirror. Python is optional setup tooling rather
  than an application runtime dependency.
- Coverage includes signed zero, smallest subnormal, largest finite value,
  values above the safe-integer limit, binary exponents from -1074 through 1023,
  invalid primitives and objects (including coercion traps), escaped JSON text,
  non-BMP Unicode labels and continued use after errors. The contract is direct
  numeric input; JSON transport fixtures do not create a separate JSON API.
- Mocks: none used. Provider-schema checks: not applicable. Browser checks: not
  applicable to this synchronous module; the registered validator's browser
  capability was unused. Architecture proposal JSON Schema validation was not
  executed; no JSON Schema validator is installed in the host Python environment.
- The gauge and archive implementations were absent, so their live integration
  and behavior are unverified. Supplied inputs were preserved. No deployment,
  account access, infrastructure change or independent acceptance was performed.
  Local checks and working checkpoints are not a settled delivery package or
  whole-system acceptance.
