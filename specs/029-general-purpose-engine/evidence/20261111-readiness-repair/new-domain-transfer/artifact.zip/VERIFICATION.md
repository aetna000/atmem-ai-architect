# Verification scope

Local verification performed on 2026-11-11. These checks establish behavior of
the captured source in a local environment, not independent client acceptance.

| Evidence | Result and limits |
| --- | --- |
| Native validation runtime | Node 26.5.0: 7 tests passed, no failures/skips. Worker OpenSSL configuration required `OPENSSL_CONF=/dev/null`; ordinary receiving environments can use the README commands. |
| Registered local browser/runtime | `node-browser-tests`: 17 tests passed, no failures/skips, in Linux/ARM64 image `sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128`, Playwright 1.64.1, sandboxed Chromium. Full report read through its final page. |
| Mocked failure/timing behavior | Real Chromium and native FileReader buffers, with a test-only completion gate and synthetic late/error/abort callbacks. This verifies application race/retry logic; it does not reproduce physical disk failures. Startup delay/failure uses held/aborted local script requests. |
| Privacy checks | Instrumented browser storage/network APIs and request monitoring found no app use of persistence or requests outside local static assets. This covers exercised paths; source review also found no storage or submission code. |
| Provider schema/cloud | Not applicable; no cloud resources, providers, backend, credentials or deployment. |
| Unresolved acceptance | Other browser engines, classroom hardware/policies, assistive technology and independent teacher acceptance were not exercised. No claim of those checks passing. |

Browser scenarios include direct `file://` use and immediate selection;
plain-text markup-like room names; arithmetic/one-decimal display; file
replacement; validation errors and recovery; strict UTF-8 and size rejection;
Clear during read; late callbacks after Clear and out-of-order selection;
read failure/interruption and same-file retry; pre-read size rejection; reload
and back navigation; delayed/failed initialization and recovery; keyboard
clearing and a narrow viewport. Pure validation tests additionally cover
field uniqueness, boundary lengths/counts/ranges, non-finite numbers, type
confusion, multibyte byte size and safe error text.

The registered service keeps receipts tied to immutable working snapshots.
Subsequent edits need a new snapshot/check. These are in-progress evidence,
not a settled delivery package or independent acceptance.

## Reviewed knowledge applicability

The pinned corpus was searched for offline browser/file/validation practices.
It returned cloud application records rather than an applicable offline static
browser practice. The closest broad composition record was read completely:
`azure-structured-application-composition`, reviewed 2026-11-10,
record SHA-256 `e2ff4752532ec93f71de3bcc6d39fe6c9be6e87ea13e1bc6ca049d32c89091b5`,
snapshot `8f8a64bbfc747fcc6a3ff9c352817cbf995ea01e0f6daafb13bf6eb008612d67`.
Its source is [Microsoft claims validation documentation](https://learn.microsoft.com/en-us/entra/identity-platform/claims-validation),
retrieved 2026-11-09; source SHA-256
`d1abf4203e2a234a5ec2f9467ca6c33a2d7685cff6c38c0fb54e55c4b98dbf87`.
Its identity, model, container and provider findings do not establish browser
file behavior and were not applied as requirements. The small reviewed corpus
is not exhaustive browser evidence. No external source was accessed for this
implementation.
