/* Pure validation shared by the browser and dependency-free Node tests. */
(function (root) {
  'use strict';
  const MAX_BYTES = 64 * 1024;

  class ValidationError extends Error {}

  // Called only after JSON.parse succeeds. Count root members without counting
  // colons in strings or nested values; JSON.parse alone hides duplicate keys.
  function rootMemberCount(text) {
    let depth = 0, inString = false, escaped = false, count = 0;
    for (const char of text) {
      if (inString) {
        if (escaped) escaped = false;
        else if (char === '\\') escaped = true;
        else if (char === '"') inString = false;
      } else if (char === '"') inString = true;
      else if (char === '{' || char === '[') depth++;
      else if (char === '}' || char === ']') depth--;
      else if (char === ':' && depth === 1) count++;
    }
    return count;
  }

  function summarize(text) {
    let data;
    try { data = JSON.parse(text); }
    catch { throw new ValidationError('This is not valid JSON. Check quotes, commas, and brackets, then choose the file again.'); }

    if (data === null || typeof data !== 'object' || Array.isArray(data)) {
      throw new ValidationError('The JSON must be an object with exactly two fields: room and samples.');
    }
    const keys = Object.keys(data);
    if (keys.length !== 2 || !Object.hasOwn(data, 'room') || !Object.hasOwn(data, 'samples') || rootMemberCount(text) !== 2) {
      throw new ValidationError('Use exactly the fields room and samples, once each. Remove extra or duplicate fields and add any missing fields.');
    }
    if (typeof data.room !== 'string' || data.room.trim().length === 0 || [...data.room].length > 80) {
      throw new ValidationError('room must be a nonblank string of at most 80 characters.');
    }
    if (!Array.isArray(data.samples) || data.samples.length < 1 || data.samples.length > 1000) {
      throw new ValidationError('samples must be an array containing 1–1000 numbers.');
    }
    let minimum = Infinity, maximum = -Infinity, total = 0;
    for (let index = 0; index < data.samples.length; index++) {
      const value = data.samples[index];
      if (typeof value !== 'number' || !Number.isFinite(value) || value < -50 || value > 70) {
        throw new ValidationError(`Sample ${index + 1} must be a finite number between −50 and 70 °C. Strings and booleans are not allowed.`);
      }
      minimum = Math.min(minimum, value);
      maximum = Math.max(maximum, value);
      total += value;
    }
    return { room: data.room, count: data.samples.length, minimum, maximum, mean: total / data.samples.length };
  }

  function checkSize(size) {
    if (size > MAX_BYTES) throw new ValidationError('The file is too large. Choose a file of at most 64 KiB (65,536 bytes).');
  }

  function decodeAndSummarize(buffer) {
    checkSize(buffer.byteLength);
    let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(buffer); }
    catch { throw new ValidationError('The file is not valid UTF-8. Save it as UTF-8 JSON, then choose it again.'); }
    return summarize(text);
  }

  function temperature(value) {
    // Avoid a confusing negative zero after rounding a small negative value.
    return Number(value.toFixed(1)).toFixed(1);
  }

  const api = Object.freeze({ MAX_BYTES, ValidationError, checkSize, summarize, decodeAndSummarize, temperature });
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Climate = api;
})(globalThis);
