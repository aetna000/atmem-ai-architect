# Classroom climate

An offline, static viewer for a teacher’s local UTF-8 JSON file. File data and
results live only in the open page. No accounts, backend, uploads, browser
storage, service worker, external assets, packages, or build step are used by
the application. Existing systems and supplied project inputs are unchanged.

## Open locally

1. Keep `index.html`, `styles.css`, `climate.js`, and `app.js` together.
2. Open `index.html` directly in a current desktop browser with JavaScript
   enabled. No server or network connection is needed.
3. Choose `example.json` or your own file. **Clear** removes the selected file,
   room, results, and errors. Choose another file to replace the summary.

Example:

```json
{"room":"Room 4","samples":[19.5,21,20.8]}
```

Expected: 3 samples, minimum 19.5 °C, maximum 21.0 °C, mean 20.4 °C.

The complete file must be at most 65,536 bytes, valid UTF-8 (an optional UTF-8
BOM is accepted), and a JSON object with exactly `room` and `samples`, once
each. `room` must be nonblank and at most 80 Unicode code points, counting
whitespace. Its text is displayed unchanged. `samples` must contain 1–1000
finite numbers in the inclusive range −50 to 70. Strings, booleans, nulls,
extra fields, duplicate root fields, and nonstandard JSON are rejected.

## Tests, entirely offline

Run from the unpacked project root. Use an already installed Node.js 22 or
newer (native unit run: Node 26.5.0). The validation tests need no packages:

```sh
node --test tests/validation.test.mjs
```

The complete suite additionally requires **playwright-core 1.64.1** and its
matching Chromium build, pre-provisioned from your approved offline tooling.
No package manager command or download is required or performed here. Set
`ATMEM_PLAYWRIGHT_MODULE` to an absolute path to that module’s `index.mjs`;
alternatively provide `playwright-core` through standard Node resolution.
The matching browser must already be in Playwright’s browser cache, or point
`PLAYWRIGHT_BROWSERS_PATH` to an existing offline cache.

```sh
ATMEM_PLAYWRIGHT_MODULE=/absolute/path/to/playwright-core/index.mjs \
  node --test --test-reporter=tap --test-concurrency=1
```

Browser tests launch Chromium with its sandbox enabled; the host must support
that sandbox. The reviewed run used isolated Linux/ARM64 with user namespaces.
The suite opens the real files using `file://`; initialization tests also use
an ephemeral container-local loopback HTTP fixture. No external network is
needed. Missing packages, browser binaries, or sandbox support are failures,
not skipped passes. These tools are test-only and are not shipped as app assets.
Other test platforms are not verified. Exact dependency provenance/checksums
are the receiving engineer’s responsibility; no dependency archive is supplied.

Ordinary commands above do not depend on worker aliases. If you choose to use
`.tools` aliases in a **fresh unpack**, the preserved helper can register
existing executables offline (it does not supply Node, Playwright, or Chromium):

```sh
python3 atmem-tools/prepare.py --require node --node /absolute/path/to/node
OPENSSL_CONF=.worker-tmp/openssl.cnf ./.tools/node --test tests/validation.test.mjs
```

## Design and recovery

The teacher owns the source file, which is never modified. `climate.js` checks
byte limits, decodes UTF-8 strictly, validates the complete schema, and computes
the summary in page memory. `app.js` owns UI state and asynchronous FileReader
reads. Each selection or Clear invalidates prior callbacks and aborts an active
read. Old results disappear immediately on selection, including invalid files.
Errors contain fixed guidance and sample positions, never raw file/parser text.
Room names use `textContent`. The page also blocks connections through CSP.

Controls are disabled in the initial HTML until both local scripts and the
browser’s FileReader/TextDecoder APIs are ready. If startup fails, the page
explains that the complete folder and JavaScript are needed; reopen in a
current browser. A read/validation error resets the file input, so selecting the
same file again works. The original on-disk file remains available for retry.
Reload, Clear, and navigation discard page data; `pagehide` also clears data
before a page can enter the back/forward cache.

There is no deployment or migration. To update, replace the four runtime files
together with a reviewed copy. To roll back, close the page, restore those four
files from the previous copy, and reopen `index.html`. No data recovery or
storage cleanup is needed.

## Verification and limits

The registered Node/Chromium check passed **17 tests, 0 failures, 0 skips**;
see [VERIFICATION.md](VERIFICATION.md) for scope and evidence limits.

Temperatures use JavaScript number arithmetic and one-decimal rounding, with
rounded negative zero displayed as `0.0`. Grapheme clusters such as combined
emoji can count as multiple Unicode code points. Only Chromium was exercised;
Firefox, Safari, assistive technologies, and managed classroom devices still
need acceptance testing. Current browsers need FileReader, TextDecoder, and
modern JavaScript support.

Clear removes application references and displayed values; it is not a secure
memory wipe. The browser/OS may manage file-picker history and memory outside
the page’s control. Untrusted extensions and a compromised browser are outside
this tool’s boundary. The application performs no browser-storage writes or
network submissions. Closing or reloading loses the summary by design.
