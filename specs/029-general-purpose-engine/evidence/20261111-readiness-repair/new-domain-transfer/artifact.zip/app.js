(function () {
  'use strict';
  // Native controls start disabled. No file intent can be lost during startup.
  if (!globalThis.Climate || !globalThis.FileReader || !globalThis.TextDecoder) return;
  const fileInput = document.getElementById('climate-file');
  const clearButton = document.getElementById('clear');
  const results = document.getElementById('results');
  const status = document.getElementById('status');
  const error = document.getElementById('error');
  const fields = Object.fromEntries(['room', 'count', 'minimum', 'maximum', 'mean'].map(id => [id, document.getElementById(id)]));
  let generation = 0;
  let activeReader = null;

  function invalidateRead() {
    generation++;
    const oldReader = activeReader;
    activeReader = null;
    if (oldReader && oldReader.readyState === FileReader.LOADING) oldReader.abort();
    return generation;
  }

  function emptyView() {
    results.hidden = true;
    for (const field of Object.values(fields)) field.textContent = '';
    error.textContent = '';
    error.hidden = true;
    status.textContent = '';
  }

  function clear() {
    invalidateRead();
    fileInput.value = '';
    emptyView();
  }

  function fail(message) {
    // Allow retrying the very same file after a transient read failure.
    fileInput.value = '';
    status.textContent = '';
    error.textContent = message;
    error.hidden = false;
  }

  fileInput.addEventListener('change', () => {
    const token = invalidateRead();
    emptyView();
    const file = fileInput.files[0];
    if (!file) return;
    try { Climate.checkSize(file.size); }
    catch (problem) { fail(problem.message); return; }

    status.textContent = 'Reading file…';
    const reader = new FileReader();
    activeReader = reader;
    reader.onload = () => {
      if (token !== generation) return;
      activeReader = null;
      try {
        const summary = Climate.decodeAndSummarize(reader.result);
        fields.room.textContent = summary.room;
        fields.count.textContent = String(summary.count);
        for (const key of ['minimum', 'maximum', 'mean']) fields[key].textContent = Climate.temperature(summary[key]);
        results.hidden = false;
        status.textContent = 'File ready. Room summary shown below.';
      } catch (problem) {
        fail(problem instanceof Climate.ValidationError ? problem.message : 'The file could not be processed. Choose it again to retry.');
      }
    };
    reader.onerror = () => {
      if (token !== generation) return;
      activeReader = null;
      fail('The file could not be read. Check that it is available and choose it again to retry.');
    };
    reader.onabort = () => {
      if (token !== generation) return;
      activeReader = null;
      fail('Reading was interrupted. Choose the file again to retry.');
    };
    try { reader.readAsArrayBuffer(file); }
    catch {
      if (token === generation) {
        activeReader = null;
        fail('The file could not be read. Check that it is available and choose it again to retry.');
      }
    }
  });
  clearButton.addEventListener('click', clear);
  // Drop data on navigation, including a page retained in the back/forward cache.
  window.addEventListener('pagehide', clear);
  clear(); // Also discard any file input restored by the browser on reload.
  document.getElementById('startup').hidden = true;
  fileInput.disabled = false;
  clearButton.disabled = false;
})();
