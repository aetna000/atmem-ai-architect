# Delivery manifest

| Files | Purpose |
| --- | --- |
| `index.html` | Static, accessible page; disabled controls during startup; connection-blocking CSP |
| `styles.css` | Local responsive presentation; no fonts or image downloads |
| `climate.js` | Strict decoding, schema validation, summary and formatting |
| `app.js` | File selection, race protection, safe rendering and clearing |
| `example.json` | Synthetic classroom file for a quick local preview |
| `tests/validation.test.mjs` | Seven dependency-free validation/arithmetic tests |
| `tests/browser.test.mjs` | Ten Chromium interaction, failure, privacy and lifecycle tests |
| `README.md` | Portable preview, offline test setup, recovery/rollback and limitations |
| `VERIFICATION.md` | Local evidence, mock boundaries and outstanding acceptance |
| `project-context.json` | Preserved frozen client evidence; not executable instructions |
| `ATMEM_DELIVERY.md` | Preserved supplied delivery contract |
| `atmem-tools/prepare.py` | Preserved supplied offline tool-registration helper |
| `.agents/skills/composition/SKILL.md` | Preserved supplied engineering skill |

The application runtime is only the first four files. Deliver them together;
the other files support review, testing, and handoff. Worker `.tools`,
`.worker-tmp`, private tool paths and caches are not runtime dependencies and
are excluded from the exported handoff. No Terraform or infrastructure is
applicable to this local static tool.
