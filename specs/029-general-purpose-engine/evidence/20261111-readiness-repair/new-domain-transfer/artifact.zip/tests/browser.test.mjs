import { test, before, after, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';

// Supply an already installed offline module. Missing browser tooling is a
// failure, never a skipped browser pass. The application itself has no packages.
const { chromium } = await import(process.env.ATMEM_PLAYWRIGHT_MODULE || 'playwright-core');
let browser, server, origin, context, page;
let unexpectedRequests, scriptErrors;
const fileURL = pathToFileURL(resolve('index.html')).href;
const payload = (room = 'Room 4', samples = [19.5, 21, 20.8]) => ({
  name: 'climate.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify({ room, samples })),
});
const select = file => page.locator('#climate-file').setInputFiles(file);
const shown = async () => { await page.waitForSelector('#results', { state: 'visible' }); };
const ready = async () => { await page.waitForFunction(() => !document.querySelector('#climate-file').disabled); };
const values = () => page.evaluate(() => Object.fromEntries(['room', 'count', 'minimum', 'maximum', 'mean'].map(id => [id, document.getElementById(id).textContent])));
async function assertEmpty() {
  assert.equal(await page.locator('#results').isVisible(), false);
  assert.deepEqual(await values(), { room: '', count: '', minimum: '', maximum: '', mean: '' });
}
async function assertCleared() {
  await assertEmpty();
  assert.equal(await page.locator('#error').isVisible(), false);
  assert.equal(await page.locator('#error').textContent(), '');
  assert.equal(await page.locator('#status').textContent(), '');
  assert.equal(await page.locator('#climate-file').inputValue(), '');
}

before(async () => {
  browser = await chromium.launch({ headless: true, chromiumSandbox: true });
  // Only the initialization tests need HTTP to hold/deny a script response.
  // This is an isolated test fixture, never part of the delivered runtime.
  const files = new Map(await Promise.all(['index.html', 'styles.css', 'climate.js', 'app.js'].map(async name => [
    '/' + name, await readFile(new URL('../' + name, import.meta.url)),
  ])));
  server = createServer((request, response) => {
    const body = files.get(request.url);
    response.writeHead(body ? 200 : 404, {
      'Content-Type': request.url.endsWith('.js') ? 'text/javascript' : request.url.endsWith('.css') ? 'text/css' : 'text/html',
      'Cache-Control': 'no-store',
    });
    response.end(body || 'Not found');
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
});
after(async () => {
  if (browser) await browser.close();
  if (server) await new Promise(resolve => server.close(resolve));
});
beforeEach(async () => {
  unexpectedRequests = [];
  scriptErrors = [];
  context = await browser.newContext({ serviceWorkers: 'block', offline: false });
  await context.route('**/*', route => {
    const url = route.request().url();
    if (url.startsWith('file:') || url.startsWith(origin + '/')) return route.continue();
    unexpectedRequests.push(url);
    return route.abort();
  });
  await context.addInitScript(() => {
    window.privacyCalls = [];
    const block = label => function () { window.privacyCalls.push(label); throw new Error('Unexpected persistence/network: ' + label); };
    for (const name of ['getItem', 'setItem', 'removeItem', 'clear', 'key']) Storage.prototype[name] = block('storage.' + name);
    for (const name of ['open', 'deleteDatabase']) IDBFactory.prototype[name] = block('indexedDB.' + name);
    if (globalThis.CacheStorage) for (const name of ['open', 'match', 'keys', 'delete', 'has']) CacheStorage.prototype[name] = block('caches.' + name);
    window.fetch = block('fetch');
    navigator.sendBeacon = block('sendBeacon');
    window.XMLHttpRequest = block('XMLHttpRequest');
    window.WebSocket = block('WebSocket');
  });
  page = await context.newPage();
  page.on('pageerror', error => scriptErrors.push(error.message));
  page.on('request', request => {
    const url = request.url();
    if (!url.startsWith('file:') && !url.startsWith(origin + '/')) unexpectedRequests.push(url);
  });
});
afterEach(async () => {
  try {
    assert.deepEqual(await page.evaluate(() => window.privacyCalls), [], 'No storage or programmatic network APIs used');
    assert.deepEqual(unexpectedRequests, [], 'No requests outside local static files');
    assert.deepEqual(scriptErrors, [], 'No unhandled browser errors');
  } finally { await context.close(); }
});

test('direct file opening, immediate selection, literal room text, summary and clearing', async () => {
  await page.goto(fileURL);
  // Select immediately after load; there are no later initialization prerequisites.
  const room = '<img src=x onerror="window.injected=true"> & Room 4';
  await select(payload(room));
  await shown();
  assert.deepEqual(await values(), { room, count: '3', minimum: '19.5', maximum: '21.0', mean: '20.4' });
  assert.equal(await page.locator('#room *').count(), 0);
  assert.equal(await page.evaluate(() => window.injected), undefined);
  await page.locator('#clear').click();
  await assertCleared();
  await select(payload('One', [-0.01]));
  await shown();
  assert.deepEqual(await values(), { room: 'One', count: '1', minimum: '0.0', maximum: '0.0', mean: '0.0' });
});

test('replacement and safe validation errors remove previous results; valid recovery', async () => {
  await page.goto(fileURL);
  await select(payload());
  await shown();
  const cases = [
    [Buffer.from('<script>private secret</script>'), /not valid JSON/],
    [Buffer.from('{"room":"x","samples":[2],"extra":true}'), /exactly the fields/],
    [Buffer.from('{"room":"x","samples":[2],"room":"y"}'), /once each/],
    [Buffer.from('{"room":" ","samples":[2]}'), /nonblank string/],
    [Buffer.from('{"room":"x","samples":[true]}'), /Sample 1/],
    [Buffer.from('{"room":"x","samples":[71]}'), /between/],
    [Buffer.from([0xff]), /valid UTF-8/],
    [Buffer.alloc(65537, 32), /too large/],
  ];
  for (const [buffer, message] of cases) {
    await select({ name: 'bad.json', mimeType: 'application/json', buffer });
    await page.waitForSelector('#error', { state: 'visible' });
    assert.match(await page.locator('#error').textContent(), message);
    assert.ok(!(await page.locator('#error').textContent()).includes('private secret'));
    assert.equal(await page.locator('#error *').count(), 0);
    await assertEmpty();
    assert.equal(await page.locator('#climate-file').inputValue(), '');
    await page.locator('#clear').click();
    await assertCleared();
  }
  const valid = payload('Boundary', [-50, 70]);
  valid.buffer = Buffer.concat([valid.buffer, Buffer.alloc(65536 - valid.buffer.length, 32)]);
  await select(valid);
  await shown();
  assert.deepEqual(await values(), { room: 'Boundary', count: '2', minimum: '-50.0', maximum: '70.0', mean: '10.0' });
  await select(payload('Replacement', [1]));
  await shown();
  assert.equal((await values()).room, 'Replacement');
});

// Delay completion of real native FileReader reads, and permit late callbacks
// even after abort. This exercises generation guards independently of abort.
async function controlledReads() {
  await context.addInitScript(() => {
    const NativeReader = window.FileReader;
    window.testReads = [];
    window.FileReader = class {
      static LOADING = 1;
      readyState = 0;
      result = null;
      readAsArrayBuffer(file) {
        this.readyState = 1;
        const native = new NativeReader();
        const completion = new Promise((resolve, reject) => {
          native.onload = () => resolve(native.result);
          native.onerror = reject;
        });
        const record = {
          aborted: false,
          release: async (kind = 'load') => {
            this.result = await completion;
            this.readyState = 2;
            this['on' + kind]?.();
          },
        };
        this.record = record;
        window.testReads.push(record);
        native.readAsArrayBuffer(file);
      }
      abort() {
        this.record.aborted = true;
        this.readyState = 2;
        this.onabort?.();
      }
    };
  });
}
const release = (index, kind = 'load') => page.evaluate(async ({ index, kind }) => window.testReads[index].release(kind), { index, kind });

test('clearing during a delayed read prevents a late result and error from returning', async () => {
  await controlledReads();
  await page.goto(fileURL);
  await select(payload('Old'));
  assert.equal(await page.locator('#status').textContent(), 'Reading file…');
  await page.locator('#clear').click();
  await assertCleared();
  assert.equal(await page.evaluate(() => window.testReads[0].aborted), true);
  await release(0);
  await release(0, 'error');
  await assertCleared();
});

test('replacement invalidates pending reads even when callbacks arrive out of order', async () => {
  await controlledReads();
  await page.goto(fileURL);
  await select(payload('Old'));
  await select(payload('New', [30]));
  await release(1);
  await shown();
  await release(0);
  await release(0, 'error');
  assert.equal((await values()).room, 'New');
  assert.equal(await page.locator('#error').isVisible(), false);
  await select(payload('Pending'));
  await select({ name: 'invalid.json', mimeType: 'application/json', buffer: Buffer.alloc(65537) });
  await release(2);
  await assertEmpty();
  assert.match(await page.locator('#error').textContent(), /too large/);
});

test('read failures and interruptions keep retry available for the same file', async () => {
  await controlledReads();
  await page.goto(fileURL);
  for (const [index, kind] of ['error', 'abort'].entries()) {
    await select(payload());
    await release(index, kind);
    await assertEmpty();
    assert.match(await page.locator('#error').textContent(), /retry/);
    assert.equal(await page.locator('#climate-file').inputValue(), '');
    assert.equal(await page.locator('#climate-file').isEnabled(), true);
  }
  await select(payload());
  await release(2);
  await shown();
  assert.equal(await page.locator('#error').isVisible(), false);
});

test('oversized files are rejected without starting a read', async () => {
  await controlledReads();
  await page.goto(fileURL);
  await select({ name: 'large.json', mimeType: '', buffer: Buffer.alloc(65537) });
  assert.equal(await page.evaluate(() => window.testReads.length), 0);
  assert.match(await page.locator('#error').textContent(), /65,536/);
});

test('reload and navigation drop data; reselecting works after reload', async () => {
  await page.goto(fileURL);
  await select(payload());
  await shown();
  assert.deepEqual(await page.evaluate(() => window.privacyCalls), []);
  await page.reload();
  await ready();
  await assertCleared();
  await select(payload('Again'));
  await shown();
  await page.goto('about:blank');
  await page.goBack();
  await ready();
  await assertCleared();
  await select(payload('After navigation'));
  await shown();
});

test('delayed startup keeps dependent controls unavailable until scripts are ready', async () => {
  let resume;
  const gate = new Promise(resolve => { resume = resolve; });
  await page.route('**/app.js', async route => { await gate; await route.continue(); });
  const navigation = page.goto(origin + '/index.html');
  try {
    await page.waitForSelector('#climate-file', { state: 'attached' });
    assert.equal(await page.locator('#climate-file').isEnabled(), false);
    assert.equal(await page.locator('#clear').isEnabled(), false);
    assert.equal(await page.locator('#startup').isVisible(), true);
  } finally { resume(); }
  await navigation;
  await select(payload('Immediate after startup'));
  await shown();
  assert.equal((await values()).room, 'Immediate after startup');
});

test('failed script initialization explains unavailable controls; reload recovers', async () => {
  await page.route('**/climate.js', route => route.abort());
  await page.goto(origin + '/index.html');
  assert.equal(await page.locator('#climate-file').isEnabled(), false);
  assert.equal(await page.locator('#clear').isEnabled(), false);
  assert.match(await page.locator('#startup').textContent(), /reopen the complete viewer folder/);
  await page.unroute('**/climate.js');
  await page.reload();
  await ready();
  await select(payload('Recovered'));
  await shown();
});

test('small viewport retains usable controls and readable results', async () => {
  await page.setViewportSize({ width: 360, height: 780 });
  await page.goto(fileURL);
  await select(payload('A'.repeat(80)));
  await shown();
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  await page.locator('#clear').focus();
  await page.keyboard.press('Enter');
  await assertCleared();
});
