import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { summarize, decodeAndSummarize, checkSize, temperature, ValidationError, MAX_BYTES } = require('../climate.js');
const bytes = text => new TextEncoder().encode(text);
const valid = (room = 'Room 4', samples = [19.5, 21, 20.8]) => JSON.stringify({ room, samples });

test('computes count, extrema, and arithmetic mean from all samples', () => {
  assert.deepEqual(summarize(valid('North', [-50, 70, 0, 10])), {
    room: 'North', count: 4, minimum: -50, maximum: 70, mean: 7.5,
  });
  assert.deepEqual(summarize(valid('One', [12.25])), {
    room: 'One', count: 1, minimum: 12.25, maximum: 12.25, mean: 12.25,
  });
  assert.equal(summarize(valid('Many', Array(1000).fill(70))).mean, 70);
  assert.equal(summarize(valid('Mixed', [-1.2, 1.4, 0.1])).mean.toFixed(1), '0.1');
});

test('one decimal place for integer, fractional, negative and rounded-zero temperatures', () => {
  for (const [value, expected] of [[70, '70.0'], [-50, '-50.0'], [20.26, '20.3'], [-2.26, '-2.3'], [-0.01, '0.0'], [-0, '0.0']]) {
    assert.equal(temperature(value), expected);
  }
});

test('strict JSON, object shape and exactly two unique root fields', () => {
  for (const text of ['', '{', '{"room":"x", "samples":[1,]}', 'null', '[]', '12', 'true', '"room"', '{}',
    '{"room":"x"}', '{"samples":[1]}', '{"room":"x","samples":[1],"extra":0}',
    '{"Room":"x","samples":[1]}', '{"room":"x","samples":[1],"room":"y"}',
    '{"room":"x","samples":[1],"samp\\u006ces":[2]}',
    '{"room":"x","samples":[1],"__proto__":{}}']) {
    assert.throws(() => summarize(text), ValidationError, text);
  }
  assert.equal(summarize('{"r\\u006fom":"literal : \\\" \\\\ { }", "samples":[1]}').count, 1);
});

test('room is nonblank text; 80 Unicode code points allowed, 81 rejected', () => {
  for (const room of [null, true, 1, [], {}, '', ' \t\n\r', 'x'.repeat(81), '🌡'.repeat(81)]) {
    assert.throws(() => summarize(valid(room)), /room must/);
  }
  for (const room of ['x'.repeat(80), '🌡'.repeat(80), '  Room 4  ', '<img src=x onerror=alert(1)>']) {
    assert.equal(summarize(valid(room)).room, room);
  }
});

test('sample type, length, finite numbers and inclusive range', () => {
  for (const samples of [null, {}, '1', 1, true, [], Array(1001).fill(1)]) {
    assert.throws(() => summarize(valid('Room', samples)), /1–1000/);
  }
  for (const sample of [true, false, '20', null, [], {}, -50.0001, 70.0001]) {
    assert.throws(() => summarize(valid('Room', [0, sample])), /Sample 2 must/);
  }
  assert.throws(() => summarize('{"room":"x","samples":[1e309]}'), /finite number/);
  for (const text of ['NaN', 'Infinity', '-Infinity', '01', '+1']) {
    assert.throws(() => summarize(`{"room":"x","samples":[${text}]}`), /valid JSON/);
  }
});

test('byte-size boundary, including multibyte UTF-8; encoding failures and BOM', () => {
  const text = valid('🌡');
  const padded = text + ' '.repeat(MAX_BYTES - bytes(text).length);
  assert.equal(decodeAndSummarize(bytes(padded)).room, '🌡');
  assert.throws(() => decodeAndSummarize(bytes(padded + ' ')), /too large/);
  assert.doesNotThrow(() => checkSize(65536));
  assert.throws(() => checkSize(65537), /65,536/);
  for (const data of [new Uint8Array([0xff]), new Uint8Array([0xc3, 0x28]), new Uint8Array([0xe2, 0x82])]) {
    assert.throws(() => decodeAndSummarize(data), /valid UTF-8/);
  }
  assert.equal(decodeAndSummarize(bytes('\uFEFF' + valid())).count, 3);
});

test('validation errors do not echo file contents or parser exception text', () => {
  const secret = '<script>private classroom data</script>';
  for (const text of [secret, valid(secret, ['private sample']), '{"room":"ok","samples":[1],"private secret":true}']) {
    assert.throws(() => summarize(text), problem => {
      assert.ok(problem instanceof ValidationError);
      assert.ok(!problem.message.includes(secret));
      assert.ok(!problem.message.includes('private'));
      return true;
    });
  }
});
