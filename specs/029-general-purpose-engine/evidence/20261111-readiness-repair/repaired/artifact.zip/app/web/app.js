const $ = id => document.getElementById(id);
let token = null, config, serial = 0, controller, expiryTimer;
const encoder = new TextEncoder();
const b64url = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
const random = () => b64url(crypto.getRandomValues(new Uint8Array(32)));
const callback = () => location.origin + '/';
function status(message) { $('status').textContent = message; }
function clear() {
  serial++; controller?.abort(); controller = null;
  $('ticket').value = ''; $('suggestion').hidden = true;
  for (const id of ['summary', 'topic', 'urgency', 'uncertainty', 'json']) $(id).textContent = '';
  $('reviewed').checked = false; $('submit').disabled = !token;
}
function signedIn(value) {
  $('ticket').disabled = !value; $('submit').disabled = !value;
  $('login').hidden = value; $('logout').hidden = !value;
  $('login').disabled = !config || value;
}
function forget() { clear(); token = null; clearTimeout(expiryTimer); signedIn(false); }
function valid(v) {
  const keys = (x, expected) => x && typeof x === 'object' && !Array.isArray(x) && Object.keys(x).sort().join() === expected.sort().join();
  const str = (s, n) => typeof s === 'string' && s.trim().length > 0 && [...s].length <= n;
  return keys(v, ['summary', 'topic', 'urgency', 'uncertainty']) && str(v.summary, 600)
    && ['access','billing','technical','account','other'].includes(v.topic)
    && ['low','normal','high','unknown'].includes(v.urgency)
    && keys(v.uncertainty, ['level','reason']) && ['low','medium','high'].includes(v.uncertainty.level)
    && str(v.uncertainty.reason, 300) && (v.urgency !== 'unknown' || v.uncertainty.level === 'high');
}
$('clear').onclick = () => { clear(); status('Ticket and suggestion cleared.'); };
$('login').onclick = async () => {
  // Configuration is a prerequisite, including for synthetic/programmatic clicks.
  if (!config || $('login').disabled) return;
  $('login').disabled = true;
  status('Opening sign-in…');
  try {
    const verifier = random(), state = random();
    sessionStorage.setItem('oauth', JSON.stringify({verifier, state, at: Date.now()}));
    const challenge = b64url(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(verifier))));
    const url = new URL(config.authOrigin + '/oauth2/authorize');
    url.search = new URLSearchParams({response_type:'code',client_id:config.clientId,redirect_uri:callback(),scope:'openid ticket-review/suggest',state,code_challenge:challenge,code_challenge_method:'S256'});
    location.assign(url);
  } catch {
    try { sessionStorage.removeItem('oauth'); } catch { /* Storage may be unavailable. */ }
    $('login').disabled = false;
    status('Sign-in unavailable. Try again or contact the operator.');
  }
};
$('logout').onclick = () => {
  forget(); sessionStorage.removeItem('oauth');
  const url = new URL(config.authOrigin + '/logout');
  url.search = new URLSearchParams({client_id:config.clientId,logout_uri:callback()});
  location.assign(url);
};
$('form').onsubmit = async event => {
  event.preventDefault();
  let text = $('ticket').value;
  clear();
  if (!token) { status('Sign in to begin.'); return; }
  if (!text.trim() || encoder.encode(text).length > 20480) { status('Paste 1–20,480 UTF-8 bytes of synthetic or redacted text.'); return; }
  const current = serial; controller = new AbortController();
  const activeController = controller;
  const timer = setTimeout(() => activeController.abort(), 25000);
  $('submit').disabled = true; status('Preparing a suggestion…');
  try {
    const pending = fetch('/suggest', {method:'POST', headers:{Authorization:'Bearer ' + token,'Content-Type':'application/json'},body:JSON.stringify({text}),signal:controller.signal,cache:'no-store',credentials:'omit'});
    text = null;
    const response = await pending;
    if (current !== serial) return;
    if (response.status === 401 || response.status === 403) { forget(); status('Access denied or sign-in expired. Contact the operator if needed.'); return; }
    if (!response.ok) throw Error('unavailable');
    const value = await response.json();
    if (current !== serial) return;
    if (!valid(value)) throw Error('invalid');
    for (const id of ['summary','topic','urgency']) $(id).textContent = value[id];
    $('uncertainty').textContent = `Uncertainty: ${value.uncertainty.level.toUpperCase()} — ${value.uncertainty.reason}`;
    $('uncertainty').dataset.level = value.uncertainty.level;
    $('json').textContent = JSON.stringify(value, null, 2);
    $('suggestion').hidden = false;
    status(value.uncertainty.level === 'low' ? 'Suggestion ready. Human review required.' : 'Uncertain suggestion. Check missing details before deciding urgency.');
  } catch { if (current === serial) status('No suggestion available. Check sign-in and service status, then paste again to retry.'); }
  finally { text = null; clearTimeout(timer); if (current === serial) { controller = null; $('submit').disabled = !token; } }
};
window.addEventListener('pagehide', forget);
window.addEventListener('pageshow', event => { if (event.persisted) { forget(); status('Sign in to begin.'); } });
async function start() {
  try {
    const query = new URLSearchParams(location.search);
    history.replaceState(null, '', '/'); // Remove authorization codes even on error.
    const loading = new AbortController();
    const timer = setTimeout(() => loading.abort(), 10000);
    try {
      const response = await fetch('/config.json', {cache:'no-store',signal:loading.signal});
      if (!response.ok) throw Error('configuration');
      const loaded = await response.json();
      if (!loaded || typeof loaded.authOrigin !== 'string' || typeof loaded.clientId !== 'string'
          || !/^https:\/\/[a-z0-9-]+\.auth\.ap-southeast-2\.amazoncognito\.com$/.test(loaded.authOrigin)
          || !/^[a-z0-9]+$/.test(loaded.clientId)) throw Error('configuration');
      config = {authOrigin:loaded.authOrigin, clientId:loaded.clientId};
    } finally { clearTimeout(timer); }
    if (query.has('code') || query.has('error')) {
      const saved = JSON.parse(sessionStorage.getItem('oauth') || 'null');
      sessionStorage.removeItem('oauth');
      if (query.has('error') || !saved || query.get('state') !== saved.state || Date.now() - saved.at > 300000) throw Error('sign-in');
      const response = await fetch(config.authOrigin + '/oauth2/token', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'authorization_code',client_id:config.clientId,redirect_uri:callback(),code:query.get('code'),code_verifier:saved.verifier}),cache:'no-store',credentials:'omit'});
      if (!response.ok) throw Error('sign-in');
      const result = await response.json();
      if (typeof result.access_token !== 'string' || !Number.isFinite(result.expires_in) || result.expires_in <= 0) throw Error('sign-in');
      token = result.access_token; signedIn(true); status('Signed in. Paste a synthetic or redacted ticket.');
      expiryTimer = setTimeout(() => { forget(); status('Session expired. Sign in again.'); }, Math.min(result.expires_in, 300) * 1000);
    } else { status('Sign in to begin.'); }
  } catch {
    try { sessionStorage.removeItem('oauth'); } catch { /* Storage may be unavailable. */ }
    forget();
    status(config ? 'Sign-in unavailable. Contact the operator or try signing in again.'
      : 'Sign-in configuration unavailable. Reload the page to try again or contact the operator.');
  } finally { signedIn(Boolean(token)); }
}
start();
