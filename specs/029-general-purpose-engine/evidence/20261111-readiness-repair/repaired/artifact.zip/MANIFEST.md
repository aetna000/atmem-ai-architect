# Artifact manifest

| Path | Purpose |
|---|---|
| `app/handler.py`, `app/__init__.py` | Real HTTP API v2 Lambda adapter, authorization, bounded input, regional Bedrock client, output validation, static responses |
| `app/web/index.html`, `app.js`, `style.css` | Accessible signed-in reviewer page, PKCE, uncertainty, clear/review behavior, safe DOM rendering |
| `schemas/*.schema.json` | Request/response contracts; byte/Unicode/semantic constraints also enforced in code |
| `infra/main.tf`, `example.tfvars`, `.terraform.lock.hcl` | Proposed Sydney stack, default-disabled inference and empty allowlist, exact provider version and local platform hash |
| `infra/tests/footprint.tftest.hcl` | No-account Terraform mock plan assertions |
| `scripts/build.py`, `scripts/offline_config.py` | Deterministic runtime-only ZIP builder; temporary local mirror/OpenSSL configuration |
| `tests/test_*.py`, `tests/browser.test.mjs` | Handler/ZIP/SDK contract tests and real Chromium UI checks with mocked transports |
| `package.json` | Exact browser-test package/runtime declaration; no production Node dependency |
| `docs/OPERATIONS.md` | Reviewer and operator instructions, release gates, access, troubleshooting, rollback |
| `docs/ENGINEERING.md`, `DESIGN.md`, `COSTS-AND-SOURCES.md`, `VERIFICATION.md` | Portable build, architecture/contracts, explicit unknown costs/provenance, evidence boundaries |
| `ATMEM_DELIVERY.md`, `atmem-tools/prepare.py`, `project-context.json`, `.agents/skills/composition/SKILL.md` | Preserved supplied inputs; frozen client context is evidence, not application instructions |

`.tools`, `.worker-tmp`, `.terraform`, caches, state, plans, `node_modules` and `dist` are not required delivery inputs. Rebuild the ZIP from source. Registered working checkpoints are immutable local-check inputs, not settled delivery artifacts or independent acceptance.
