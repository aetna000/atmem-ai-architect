terraform {
  required_version = "= 1.17.1"
  required_providers {
    aws = { source = "hashicorp/aws", version = "= 6.72.0" }
  }
}
provider "aws" {
  region = "ap-southeast-2"
  default_tags { tags = { Application = "ticket-review", ManagedBy = "Terraform" } }
}
data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

variable "name" {
  type    = string
  default = "ticket-review"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,30}$", var.name))
    error_message = "Use 3–31 lowercase letters, digits and hyphens."
  }
}
variable "allowed_subs" {
  type        = set(string)
  default     = []
  description = "Explicit Cognito subject IDs of approved staff. Empty denies everyone. Not a staffing quota."
  validation {
    condition     = alltrue([for s in var.allowed_subs : can(regex("^[a-f0-9-]{36}$", s))])
    error_message = "Use actual user-pool sub UUIDs."
  }
}
variable "inference_enabled" {
  type        = bool
  default     = false
  description = "Release gate: enable only after the documented account/model/residency/retention checks."
}
variable "retention_verified_until" {
  type        = number
  default     = 0
  description = "UTC epoch seconds. Operator attestation expiry, at most 24 hours ahead at invocation time. No automatic renewal."
}

resource "aws_cognito_user_pool" "staff" {
  name                     = var.name
  username_attributes      = ["email"]
  auto_verified_attributes = ["email"]
  deletion_protection      = "ACTIVE"
  mfa_configuration        = "ON"
  software_token_mfa_configuration { enabled = true }
  admin_create_user_config { allow_admin_create_user_only = true }
  password_policy {
    minimum_length                   = 14
    require_lowercase                = true
    require_uppercase                = true
    require_numbers                  = true
    require_symbols                  = true
    temporary_password_validity_days = 2
  }
  account_recovery_setting {
    recovery_mechanism {
      name     = "admin_only"
      priority = 1
    }
  }
}
resource "aws_cognito_resource_server" "review" {
  identifier   = "ticket-review"
  name         = "Ticket review"
  user_pool_id = aws_cognito_user_pool.staff.id
  scope {
    scope_name        = "suggest"
    scope_description = "Request a human-reviewed suggestion"
  }
}
resource "aws_cognito_user_pool_client" "web" {
  name                                 = "review-browser"
  user_pool_id                         = aws_cognito_user_pool.staff.id
  generate_secret                      = false
  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["code"]
  allowed_oauth_scopes                 = ["openid", "${aws_cognito_resource_server.review.identifier}/suggest"]
  supported_identity_providers         = ["COGNITO"]
  callback_urls                        = ["${aws_apigatewayv2_api.web.api_endpoint}/"]
  logout_urls                          = ["${aws_apigatewayv2_api.web.api_endpoint}/"]
  prevent_user_existence_errors        = "ENABLED"
  enable_token_revocation              = true
  access_token_validity                = 5
  id_token_validity                    = 5
  refresh_token_validity               = 1
  token_validity_units {
    access_token  = "minutes"
    id_token      = "minutes"
    refresh_token = "hours"
  }
}
resource "aws_cognito_user_pool_domain" "staff" {
  domain       = "${var.name}-${data.aws_caller_identity.current.account_id}"
  user_pool_id = aws_cognito_user_pool.staff.id
}
locals {
  issuer    = "https://cognito-idp.ap-southeast-2.amazonaws.com/${aws_cognito_user_pool.staff.id}"
  model_arn = "arn:${data.aws_partition.current.partition}:bedrock:ap-southeast-2::foundation-model/amazon.nova-lite-v1:0"
}
resource "aws_iam_role" "function" {
  name = "${var.name}-runtime"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{
    Effect = "Allow", Principal = { Service = "lambda.amazonaws.com" }, Action = "sts:AssumeRole"
  }] })
}
resource "aws_iam_role_policy" "model_only" {
  role = aws_iam_role.function.id
  policy = jsonencode({ Version = "2012-10-17", Statement = [
    { Effect = "Allow", Action = "bedrock:InvokeModel", Resource = local.model_arn },
    { Effect = "Allow", Action = "bedrock:GetModelInvocationLoggingConfiguration", Resource = "*" },
    { Effect = "Deny", Action = "bedrock:*", Resource = "*", Condition = { StringNotEquals = { "aws:RequestedRegion" = "ap-southeast-2" } } }
  ] })
  # Deliberately no Logs, S3, database, help desk, network secret or model profile permissions.
}
resource "aws_lambda_function" "web" {
  function_name                  = var.name
  role                           = aws_iam_role.function.arn
  runtime                        = "python3.12"
  architectures                  = ["arm64"]
  handler                        = "app.handler.handler"
  filename                       = "${path.module}/../dist/function.zip"
  source_code_hash               = filebase64sha256("${path.module}/../dist/function.zip")
  memory_size                    = 256
  timeout                        = 28
  reserved_concurrent_executions = 5
  environment {
    variables = {
      CLIENT_ID                = aws_cognito_user_pool_client.web.id
      ISSUER                   = local.issuer
      AUTH_ORIGIN              = "https://${aws_cognito_user_pool_domain.staff.domain}.auth.ap-southeast-2.amazoncognito.com"
      ALLOWED_SUBS             = jsonencode(sort(tolist(var.allowed_subs)))
      INFERENCE_ENABLED        = tostring(var.inference_enabled)
      RETENTION_VERIFIED_UNTIL = tostring(var.retention_verified_until)
    }
  }
}
resource "aws_apigatewayv2_api" "web" {
  name          = var.name
  protocol_type = "HTTP"
}
resource "aws_apigatewayv2_integration" "web" {
  api_id                 = aws_apigatewayv2_api.web.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.web.invoke_arn
  payload_format_version = "2.0"
  timeout_milliseconds   = 29000
}
resource "aws_apigatewayv2_authorizer" "staff" {
  api_id           = aws_apigatewayv2_api.web.id
  name             = "staff"
  authorizer_type  = "JWT"
  identity_sources = ["$request.header.Authorization"]
  jwt_configuration {
    audience = [aws_cognito_user_pool_client.web.id]
    issuer   = local.issuer
  }
}
resource "aws_apigatewayv2_route" "assets" {
  for_each  = toset(["GET /", "GET /app.js", "GET /style.css", "GET /config.json"])
  api_id    = aws_apigatewayv2_api.web.id
  route_key = each.value
  target    = "integrations/${aws_apigatewayv2_integration.web.id}"
}
resource "aws_apigatewayv2_route" "suggest" {
  api_id               = aws_apigatewayv2_api.web.id
  route_key            = "POST /suggest"
  target               = "integrations/${aws_apigatewayv2_integration.web.id}"
  authorization_type   = "JWT"
  authorizer_id        = aws_apigatewayv2_authorizer.staff.id
  authorization_scopes = ["ticket-review/suggest"]
}
resource "aws_apigatewayv2_stage" "web" {
  api_id      = aws_apigatewayv2_api.web.id
  name        = "$default"
  auto_deploy = true
  default_route_settings {
    throttling_burst_limit   = 10
    throttling_rate_limit    = 5
    detailed_metrics_enabled = false
  }
  route_settings {
    route_key              = aws_apigatewayv2_route.suggest.route_key
    throttling_burst_limit = 5
    throttling_rate_limit  = 2
  }
  # No request/response/access logging, tracing or data capture.
}
resource "aws_lambda_permission" "gateway" {
  statement_id   = "HttpApiOnly"
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.web.function_name
  principal      = "apigateway.amazonaws.com"
  source_arn     = "${aws_apigatewayv2_api.web.execution_arn}/*/*"
  source_account = data.aws_caller_identity.current.account_id
}
resource "aws_cloudwatch_metric_alarm" "throttles" {
  alarm_name          = "${var.name}-lambda-throttles"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Throttles"
  namespace           = "AWS/Lambda"
  period              = 300
  statistic           = "Sum"
  threshold           = 0
  treat_missing_data  = "notBreaching"
  dimensions          = { FunctionName = aws_lambda_function.web.function_name }
}
resource "aws_cloudwatch_metric_alarm" "api_failures" {
  alarm_name          = "${var.name}-api-failures"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "5xx"
  namespace           = "AWS/ApiGateway"
  period              = 300
  statistic           = "Sum"
  threshold           = 2
  treat_missing_data  = "notBreaching"
  dimensions          = { ApiId = aws_apigatewayv2_api.web.id }
}
output "url" { value = "${aws_apigatewayv2_api.web.api_endpoint}/" }
output "user_pool_id" { value = aws_cognito_user_pool.staff.id }
output "client_id" { value = aws_cognito_user_pool_client.web.id }
output "lambda_name" { value = aws_lambda_function.web.function_name }
