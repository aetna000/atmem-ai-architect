mock_provider "aws" {
  mock_data "aws_caller_identity" {
    defaults = { account_id = "123456789012" }
  }
  mock_data "aws_partition" {
    defaults = { partition = "aws" }
  }
  mock_resource "aws_iam_role" {
    defaults = { arn = "arn:aws:iam::123456789012:role/ticket-review-runtime" }
  }
  mock_resource "aws_apigatewayv2_api" {
    defaults = { api_endpoint = "https://example.execute-api.ap-southeast-2.amazonaws.com" }
  }
}
run "safe_starting_footprint" {
  command = plan
  assert {
    condition     = aws_lambda_function.web.reserved_concurrent_executions == 5 && aws_lambda_function.web.memory_size == 256
    error_message = "Keep the modest proposed starting footprint."
  }
  assert {
    condition     = aws_lambda_function.web.environment[0].variables.INFERENCE_ENABLED == "false" && aws_lambda_function.web.environment[0].variables.ALLOWED_SUBS == "[]"
    error_message = "Default deployment must deny inference and have no approved users."
  }
  assert {
    condition     = aws_apigatewayv2_route.suggest.authorization_type == "JWT" && contains(aws_apigatewayv2_route.suggest.authorization_scopes, "ticket-review/suggest")
    error_message = "The inference route must require JWT authorization and scope."
  }
  assert {
    condition     = aws_cognito_user_pool.staff.admin_create_user_config[0].allow_admin_create_user_only && aws_cognito_user_pool.staff.mfa_configuration == "ON"
    error_message = "Staff identities must be invited with mandatory MFA."
  }
  assert {
    condition     = jsondecode(aws_iam_role_policy.model_only.policy).Statement[0].Resource == "arn:aws:bedrock:ap-southeast-2::foundation-model/amazon.nova-lite-v1:0"
    error_message = "Only the direct Sydney model ARN may be invoked."
  }
}
