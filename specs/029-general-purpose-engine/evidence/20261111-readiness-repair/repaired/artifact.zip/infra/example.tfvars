# Copy to operator.tfvars and populate actual user sub IDs after creating staff.
name                     = "ticket-review"
allowed_subs             = []
inference_enabled        = false
retention_verified_until = 0
