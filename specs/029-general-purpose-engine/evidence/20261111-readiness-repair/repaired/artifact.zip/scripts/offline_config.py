"""Configure temporary files only; existing .tools registrations remain untouched."""
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
mirror = (root / '.tools/providerMirror').resolve(strict=True)
temporary = root / '.worker-tmp'
temporary.mkdir(exist_ok=True)
(temporary / 'openssl.cnf').write_text('# Empty project-local OpenSSL configuration.\n')
(temporary / 'terraform.rc').write_text('provider_installation {\n  filesystem_mirror {\n    path = '
    + json.dumps(str(mirror)) + '\n  }\n}\ndisable_checkpoint = true\n')
print('Temporary offline configuration prepared. No tools or cloud settings changed.')
