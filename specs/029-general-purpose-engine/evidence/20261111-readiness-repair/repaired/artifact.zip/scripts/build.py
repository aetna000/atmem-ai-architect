"""Deterministic application-only ZIP. Uses the AWS-managed Python 3.12 SDK."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

def build(destination):
    root = Path(__file__).resolve().parents[1]
    files = [root / 'app/__init__.py', root / 'app/handler.py',
             *sorted((root / 'app/web').glob('*'))]
    destination = Path(destination)
    destination.parent.mkdir(exist_ok=True, parents=True)
    with ZipFile(destination, 'w') as archive:
        for path in files:
            entry = ZipInfo(str(path.relative_to(root)), (2026, 1, 1, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, path.read_bytes())


if __name__ == '__main__':
    build(Path(__file__).resolve().parents[1] / 'dist/function.zip')
    print('Built dist/function.zip (application and browser assets only).')
