"""Real SDK shapes in the registered Lambda image; never sends network requests."""
import importlib.util
import unittest
from unittest.mock import patch


@unittest.skipUnless(importlib.util.find_spec('boto3'), 'AWS runtime SDK unavailable in host Python; run Lambda validator')
class SDKContract(unittest.TestCase):
    def test_real_clients_are_regional_bounded_and_do_not_retry(self):
        from app.handler import aws_clients
        with patch.dict('os.environ', {'AWS_ACCESS_KEY_ID':'testing', 'AWS_SECRET_ACCESS_KEY':'testing',
                                      'AWS_EC2_METADATA_DISABLED':'true'}):
            control, runtime = aws_clients()
        for client in (control, runtime):
            self.assertEqual(client.meta.region_name, 'ap-southeast-2')
            self.assertEqual(client.meta.config.retries['total_max_attempts'], 1)
            self.assertEqual(client.meta.config.connect_timeout, 2)
        self.assertEqual(control.meta.config.read_timeout, 3)
        self.assertEqual(runtime.meta.config.read_timeout, 18)

    def test_real_sdk_converse_and_control_shapes(self):
        import boto3
        from botocore.stub import Stubber
        from app.handler import suggest, MODEL, SYSTEM
        args = dict(region_name='ap-southeast-2', aws_access_key_id='testing', aws_secret_access_key='testing')
        control = boto3.client('bedrock', **args)
        runtime = boto3.client('bedrock-runtime', **args)
        cs, rs = Stubber(control), Stubber(runtime)
        cs.add_response('get_model_invocation_logging_configuration', {}, {})
        rs.add_response('converse', {
            'output': {'message': {'role': 'assistant', 'content': [{'text': '{"summary":"Synthetic issue","topic":"other","urgency":"unknown","uncertainty":{"level":"high","reason":"No detail"}}'}]}},
            'stopReason': 'end_turn', 'usage': {'inputTokens': 10, 'outputTokens': 10, 'totalTokens': 20},
            'metrics': {'latencyMs': 1}
        }, {'modelId': MODEL, 'system': [{'text': SYSTEM}],
            'messages': [{'role': 'user', 'content': [{'text': 'Synthetic'}]}],
            'inferenceConfig': {'maxTokens': 600, 'temperature': 0}})
        with cs, rs:
            self.assertEqual(suggest('Synthetic', (control, runtime))['urgency'], 'unknown')
        cs.assert_no_pending_responses(); rs.assert_no_pending_responses()
