import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZipFile
from scripts.build import build


class BuildTests(unittest.TestCase):
    def test_exact_zip_determinism_and_real_event_adapter(self):
        with tempfile.TemporaryDirectory() as directory:
            first, second = Path(directory) / 'first.zip', Path(directory) / 'second.zip'
            build(first); build(second)
            self.assertEqual(hashlib.sha256(first.read_bytes()).hexdigest(), hashlib.sha256(second.read_bytes()).hexdigest())
            with ZipFile(first) as archive:
                self.assertEqual(set(archive.namelist()), {'app/__init__.py','app/handler.py',
                    'app/web/index.html','app/web/app.js','app/web/style.css'})
                archive.extractall(Path(directory) / 'unpacked')
            # Import and serve the actual ZIP payload, without the source tree on sys.path.
            result = subprocess.run([sys.executable, '-c',
                'from app.handler import handler; '
                'r=handler({"rawPath":"/","requestContext":{"http":{"method":"GET"}}},None); '
                'assert r["statusCode"]==200 and "Support ticket review" in r["body"]'],
                cwd=Path(directory) / 'unpacked', env={**os.environ, 'PYTHONPATH':''},
                capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
