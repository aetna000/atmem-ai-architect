import base64
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stderr, redirect_stdout
import io
import json
import os
from pathlib import Path
import time
import unittest
from unittest.mock import patch
from app import handler as h

GOOD = {"summary": "A user cannot sign in.", "topic": "access", "urgency": "normal",
        "uncertainty": {"level": "medium", "reason": "Scope and duration are unknown."}}


class FakeControl:
    def get_model_invocation_logging_configuration(self):
        return {}


class FakeRuntime:
    def __init__(self, value=None, stop="end_turn"):
        self.value = json.dumps(GOOD) if value is None else value
        self.stop = stop
        self.calls = []

    def converse(self, **kwargs):
        self.calls.append(kwargs)
        return {"stopReason": self.stop, "output": {"message": {"content": [{"text": self.value}]}}}


def event(text="Cannot sign in."):
    return {"rawPath": "/suggest", "body": json.dumps({"text": text}),
            "headers": {"Content-Type": "application/json; charset=utf-8"},
            "requestContext": {"http": {"method": "POST"}, "authorizer": {"jwt": {"claims": {
                "sub": "staff-a", "token_use": "access", "client_id": "client", "iss": "issuer"}}}}}


class HandlerTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {"ALLOWED_SUBS": '["staff-a"]', "CLIENT_ID": "client",
            "ISSUER": "issuer", "INFERENCE_ENABLED": "true", "RETENTION_VERIFIED_UNTIL": str(int(time.time()) + 3600)})
        self.env.start()
        self.runtime = FakeRuntime()
        self.factory = lambda: (FakeControl(), self.runtime)

    def tearDown(self):
        self.env.stop()

    def call(self, e=None):
        return h.handler(e or event(), None, self.factory)

    def test_success_boundary_and_no_logs(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            response = self.call()
        self.assertEqual(response["statusCode"], 200)
        self.assertEqual(json.loads(response["body"]), GOOD)
        self.assertEqual(stdout.getvalue() + stderr.getvalue(), "")
        self.assertEqual(response["headers"]["Cache-Control"], "no-store, max-age=0")
        call = self.runtime.calls[0]
        self.assertEqual(call["modelId"], "amazon.nova-lite-v1:0")
        self.assertEqual(call["inferenceConfig"]["maxTokens"], 600)
        self.assertEqual(call["messages"][0]["content"], [{"text": "Cannot sign in."}])

    def test_denials_do_not_invoke(self):
        for field, value in [("sub", "outsider"), ("token_use", "id"), ("iss", "wrong"), ("client_id", "wrong")]:
            e = event()
            e["requestContext"]["authorizer"]["jwt"]["claims"][field] = value
            self.assertEqual(self.call(e)["statusCode"], 403)
        e = event(); e["requestContext"].pop("authorizer")
        e["headers"]["Authorization"] = "Bearer forged"
        self.assertEqual(self.call(e)["statusCode"], 403)
        with patch.dict(os.environ, {"ALLOWED_SUBS": "[]"}):
            self.assertEqual(self.call()["statusCode"], 403)
        self.assertEqual(self.runtime.calls, [])

    def test_malformed_input(self):
        bodies = ['{"text":"a","text":"b"}', '{', 'null', '[]', '{"text":true}',
                  '{"text":"ok","extra":1}', '{"text":NaN}', '{"text":"\\ud800"}']
        for body in bodies:
            with self.subTest(body=body):
                e = event(); e["body"] = body
                self.assertEqual(self.call(e)["statusCode"], 400)
        for value in [" ", "a" * 20481, "é" * 10241, "\x00"]:
            self.assertEqual(self.call(event(value))["statusCode"], 400)
        e = event(); e["isBase64Encoded"] = True; e["body"] = "!bad base64!"
        self.assertEqual(self.call(e)["statusCode"], 400)
        e = event(); e["headers"]["Content-Type"] = "text/plain"
        self.assertEqual(self.call(e)["statusCode"], 400)
        self.assertEqual(self.runtime.calls, [])

    def test_exact_utf8_boundary_and_base64(self):
        self.assertEqual(self.call(event("Synthetic\r\nWindows line ending"))["statusCode"], 200)
        self.assertEqual(self.call(event("é" * 10240))["statusCode"], 200)
        e = event("x" * 20480)
        e["isBase64Encoded"] = True; e["body"] = base64.b64encode(e["body"].encode()).decode()
        self.assertEqual(self.call(e)["statusCode"], 200)

    def test_model_failures_and_invalid_output(self):
        invalid = ['{}', '```json\n{}\n```', json.dumps({**GOOD, "topic": "injected"}),
                   json.dumps({**GOOD, "extra": "field"}), json.dumps({**GOOD, "summary": ""}),
                   json.dumps({**GOOD, "summary": "x" * 601}),
                   json.dumps({**GOOD, "summary": "x" + " " * 600}),
                   json.dumps({**GOOD, "uncertainty": {"level": "medium", "reason": ""}}),
                   json.dumps({**GOOD, "urgency": "unknown"}),
                   json.dumps(GOOD)[:-1] + ',"summary":"duplicate"}', 'null', 'x' * 9000]
        for value in invalid:
            with self.subTest(value=value[:40]):
                self.runtime.value = value
                result = self.call()
                self.assertEqual(result["statusCode"], 503)
                self.assertEqual(json.loads(result["body"]), {"error": {"code": "suggestion_unavailable"}})
        for stop in ["max_tokens", "content_filtered", "guardrail_intervened", "tool_use"]:
            self.runtime.stop = stop
            self.assertEqual(self.call()["statusCode"], 503)
        def failure():
            raise TimeoutError("sensitive text must not escape")
        self.factory = failure
        output = io.StringIO()
        with redirect_stdout(output), redirect_stderr(output):
            result = self.call()
        self.assertNotIn("sensitive", result["body"] + output.getvalue())
        self.assertEqual(result["statusCode"], 503)

    def test_retention_and_logging_gate(self):
        for env in [{"INFERENCE_ENABLED": "false"}, {"RETENTION_VERIFIED_UNTIL": "0"},
                    {"RETENTION_VERIFIED_UNTIL": "invalid"},
                    {"RETENTION_VERIFIED_UNTIL": str(int(time.time()) + 90000)}]:
            with patch.dict(os.environ, env):
                self.assertEqual(self.call()["statusCode"], 503)
        for config in [{"textDataDeliveryEnabled": True}, {}, "unexpected"]:
            control = FakeControl()
            control.get_model_invocation_logging_configuration = lambda: {"loggingConfig": config}
            self.factory = lambda: (control, self.runtime)
            self.assertEqual(self.call()["statusCode"], 503)
        self.assertEqual(self.runtime.calls, [])
        control.get_model_invocation_logging_configuration = lambda: {"loggingConfig": {"textDataDeliveryEnabled": False}}
        self.assertEqual(self.call()["statusCode"], 200)
        control.get_model_invocation_logging_configuration = lambda: (_ for _ in ()).throw(PermissionError())
        self.assertEqual(self.call()["statusCode"], 503)

    def test_five_parallel_requests_no_cross_ticket_response(self):
        class Echo(FakeRuntime):
            def converse(self, **kwargs):
                text = kwargs["messages"][0]["content"][0]["text"]
                return {"stopReason": "end_turn", "output": {"message": {"content": [{"text": json.dumps({**GOOD, "summary": text})}]}}}
        self.factory = lambda: (FakeControl(), Echo())
        with ThreadPoolExecutor(max_workers=5) as pool:
            results = list(pool.map(lambda n: self.call(event(f"Synthetic {n}")), range(5)))
        for n, response in enumerate(results):
            self.assertEqual(response["statusCode"], 200)
            self.assertEqual(json.loads(response["body"])["summary"], f"Synthetic {n}")

    def test_assets_and_unknown_routes(self):
        for path in ["/", "/app.js", "/style.css", "/config.json"]:
            e = {"rawPath": path, "requestContext": {"http": {"method": "GET"}}}
            self.assertEqual(self.call(e)["statusCode"], 200)
        self.assertEqual(self.call({"rawPath": "/../../project-context.json"})["statusCode"], 404)

    def test_schema_enums_match_validator(self):
        schema = json.loads((Path(__file__).resolve().parents[1] / "schemas/suggestion.schema.json").read_text())
        self.assertEqual(schema["properties"]["topic"]["enum"], list(h.TOPICS))
        self.assertEqual(schema["properties"]["urgency"]["enum"], list(h.URGENCIES))
