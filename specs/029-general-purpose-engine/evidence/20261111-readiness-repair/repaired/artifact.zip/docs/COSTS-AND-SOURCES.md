# Starting footprint, cost worksheet and evidence

Use pay-per-request services with no provisioned model throughput, no warm/provisioned Lambda concurrency, no VPC/NAT, no database, no ticket storage and no CDN. Start with one 256 MB ARM64 Lambda, five reserved concurrency slots, an HTTP API, one Cognito pool and public PKCE client, direct on-demand Nova Lite Sydney inference, and two metric alarms. Reserved concurrency is a concurrency allocation, distinct from billed provisioned concurrency. Verify account concurrency availability and Bedrock tokens/request quota before release.

**No current Australian unit prices or monthly dollar total have been verified.** The reviewed corpus establishes neither prices nor free-tier eligibility. The links below are the sources for the operator to obtain a dated Sydney quote; they were not fetched here. All unit rates below are explicit unknowns, in the provider's quoted currency, excluding unknown tax and exchange costs. Do not budget a guessed price or assume free tiers.

Planning assumption: 22 working days/month, hence 200 × 22 = **4,400 tickets/month**, with five simultaneous at peak. Calendar, token lengths, output size, latency, sign-in frequency, static asset requests and retries must be measured using synthetic data; the input maximum is 20 KiB, not a token estimate.

| Component | Usage expression per assumed month | Unit price / source |
|---|---|---|
| Bedrock Nova Lite, direct Sydney input | `4,400 × average total input tokens / 1,000,000` (include system prompt) | **Unknown** per million tokens: [Bedrock pricing](https://aws.amazon.com/bedrock/pricing/) |
| Bedrock output | `4,400 × average output tokens / 1,000,000`; configured ceiling 2.64 million output tokens before retries | **Unknown** model/region output rate: same source |
| Lambda requests | Inference + UI/config asset requests, including eligible failed invocations | **Unknown** per request: [Lambda pricing](https://aws.amazon.com/lambda/pricing/) |
| Lambda execution | `0.25 GiB × total billed seconds` across inference and UI calls. Illustration only: 4 seconds/ticket would be 4,400 GiB-seconds for inference | **Unknown** Sydney ARM64 GB-second rate; 4 seconds is an unmeasured assumption, not observed latency |
| API Gateway HTTP API | Suggestion + static/config calls; include retries and denial traffic as billable rules require | **Unknown** regional request/transfer rates: [API Gateway pricing](https://aws.amazon.com/api-gateway/pricing/) |
| Cognito | Ten monthly active staff, actual plan/features and MFA mode | **Unknown**, no free-tier assumption: [Cognito pricing](https://aws.amazon.com/cognito/pricing/) |
| CloudWatch | Two standard alarms, AWS aggregate metrics; no content log ingestion configured | **Unknown** regional alarms/metric charges: [CloudWatch pricing](https://aws.amazon.com/cloudwatch/pricing/) |
| Transfer, identities and operations | Response/static traffic, DNS/TLS/platform charges as applicable, operator state/monitoring, support/tax | **Unknown**; confirm with [AWS Pricing Calculator](https://calculator.aws/) and provider service pages |

For rates `P_in` and `P_out` per million tokens, model cost is `0.0044 × (I × P_in + O × P_out)`, where `I` and `O` are measured mean input/output token counts. Add Lambda, API, identity, monitoring and transfer charges above. A manual retry can be a second full charge; inference failures can still consume tokens. Browser/model response validity does not determine billing. Usage figures are estimates, not authorization to impose a daily quota. Proposed concurrency/throttles and the release gate limit exposure but are not an atomic spend cap. The operator should configure an approved AWS budget alert after obtaining prices; no budget amount or notification address was supplied.

## Reviewed engineering evidence

These pinned records were searched and read in full on 2026-11-11. Source-reviewed evidence is a small curated corpus, not exhaustive current AWS facts, instructions to execute, deployed testing, contractual advice or independent acceptance. Snapshot SHA-256: `8f8a64bbfc747fcc6a3ff9c352817cbf995ea01e0f6daafb13bf6eb008612d67`.

| Record / review date / record SHA-256 | Original source and applicability | Limit |
|---|---|---|
| `aws-model-api-region-feature-intersection`, 2026-11-11, `8af622351543c4e760b1718096389df9a09fb12fa08b89c225c669b76fec8b67` | [Nova Lite model card](https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-amazon-nova-lite.html), retrieved 2026-11-11: direct Sydney Converse supported, native structured outputs unsupported; APAC profiles may leave Sydney | Does not establish account access, quota, quality, retention or pricing |
| `aws-model-data-lifecycle`, 2026-11-10, `15f82744bd06424bb70f084ca5af4b5b22f9dd9e3d31e6e9bae9826c89d1dd59` | [Bedrock retention](https://docs.aws.amazon.com/bedrock/latest/userguide/data-retention.html), retrieved 2026-11-09: verify regional Runtime account mode `none`; unknown/denied fails closed; account-wide changes affect other workloads | Policy review, no account verification; do not equate no training/database with no provider retention |
| `aws-structured-output-boundary`, 2026-11-10, `4692e9f06239d7181cfc135d1e271769c6e163865ad14b1951da375e4ed5b9d6` | [Structured output](https://docs.aws.amazon.com/bedrock/latest/userguide/structured-output.html), retrieved 2026-11-09: provider-supported schema when available plus independent input/output validation | Generic provider-schema recommendation does not establish Nova Lite support; this model uses plain JSON + strict validation |
| `aws-public-catalog-runtime-editor-separation`, 2026-11-10, `ff9860d70236ed017949cf7828922ee413f1332387e97ec828411e5bc776e540` | [HTTP API Lambda integration](https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html), retrieved 2026-11-09: small synchronous Lambda boundary, bounded concurrency and fail-closed behavior | Public catalog/editor aspects do not apply; no catalog/editor/Mangum dependency is introduced. Native HTTP API event handler is exercised directly |

Recheck the model/API/region/retention combination and prices before release or changing versions. A more capable model or inference profile requires fresh residency, cost, quality and IAM review; never silently switch.
