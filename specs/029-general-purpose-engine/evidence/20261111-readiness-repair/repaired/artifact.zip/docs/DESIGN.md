# Design and contracts

The team owns review decisions; the existing help desk remains unchanged. This tool suggests information only. The review checkbox records a temporary acknowledgement in the page, with no backend effect or durable audit record. No requirement for durable review records was supplied.

```mermaid
flowchart LR
    Staff[Australian staff browser] -->|OAuth code + PKCE, mandatory TOTP| Auth[Cognito Sydney]
    Staff -->|HTTPS: public static assets| API[HTTP API Sydney]
    Staff -->|HTTPS: access JWT + scope, POST JSON| API
    API -->|Trusted HTTP API v2 event| Lambda[Lambda Sydney: staff sub allowlist + validation]
    Lambda -->|Read logging setting, no writes| Control[Bedrock Sydney control plane]
    Lambda -->|Converse: direct foundation model ARN| Model[Nova Lite Sydney]
    Model -->|Untrusted model JSON| Lambda
    Lambda -->|Validated suggestion JSON| Staff
    Existing[Existing help desk: unchanged, no connection]
```

## Responsibilities, identity and state

| Block | Ownership and identity | State and capacity | Failure and recovery |
|---|---|---|---|
| Browser | Team reviewer; OAuth public client, code flow and S256 PKCE | Text and suggestions only in page memory; text clears on submit; access token only in memory; state/verifier in sessionStorage only during OAuth | Clear, sign-out, expiry, page exit and errors discard visible results; no automatic retry |
| Cognito | AWS operates service; operator invites ten staff, administers TOTP and resets | Regional identity store only; no ticket text; self-sign-up disabled | Invalid identity cannot get a usable scoped access token; operator restores access |
| HTTP API | Operator owns routes and JWT authorizer | Public HTTPS ingress, no CORS, no access/body logging; audience, issuer, expiry and required scope enforced by gateway | 401/403 denies, 429 throttles; browser offers manual retry |
| Lambda | Operator owns code/config; dedicated IAM role, only gateway service invoke permission | 256 MB ARM64, reserved concurrency 5, timeout 28 s; no persistent state, content logs, /tmp writes, trace or event capture | Invalid/denied requests never invoke model; model/validation/preflight failures return fixed 503 JSON with no partial suggestion |
| Bedrock | AWS operates chosen direct regional model; operator verifies access, quota and retention | No application history or model conversation state; one call per request; max 600 output tokens; no inference profile permissions | No fallback model/region, streaming, tool use or automatic retry; failed/ambiguous outcomes are discarded |
| CloudWatch | Operator checks AWS service aggregate metrics and two alarms | Counts/status/timings only; alarms have no notification recipient | Check dashboard each working day; configure an approved monitoring destination separately if desired |

Static files share Lambda's five concurrency slots. A burst of five inference requests fits the proposed concurrency when no other invocation occupies a slot; excess requests can safely throttle. Static traffic can compete during bursts. Measure cold starts and actual model quota before deciding whether to increase concurrency. Five requests is a sizing input, not a guaranteed latency SLA or a customer quota. API throttles (2 suggestion requests/s, burst 5) are a proposed operational guard; account throttles are best effort and are not a spending ceiling. There is no durable daily quota or atomic spending counter.

## Connections and JSON

`POST /suggest` accepts `Content-Type: application/json`, `Authorization: Bearer <access token>` and exactly `{"text":"synthetic or redacted ticket"}`. The UTF-8 ticket limit is 20,480 bytes, including whitespace. Empty/whitespace-only text, duplicate keys, invalid Unicode, NUL and unwanted control characters, additional fields, malformed JSON/base64, incorrect content type and oversized input are rejected. A 130 KiB JSON envelope cap accommodates JSON escaping; byte validation still applies to the decoded text. CRLF, LF and tabs are accepted.

Successful JSON conforms to [the schema](../schemas/suggestion.schema.json), independently enforced in Python before it reaches the browser:

```json
{"summary":"A user reports difficulty signing in.","topic":"access","urgency":"unknown","uncertainty":{"level":"high","reason":"Scope, duration and business impact are missing."}}
```

Topics: `access`, `billing`, `technical`, `account`, `other`. Urgency: `low`, `normal`, `high`, `unknown`. Summary is 1–600 characters; uncertainty reason 1–300 characters and nonblank. Uncertainty level is `low`, `medium`, `high`; unknown urgency requires high uncertainty. Every suggestion requires review, including low uncertainty. Uncertainty is model self-assessment, not a calibrated probability or assurance of accuracy. The proposed urgency rubric is in the system prompt; the team should confirm it against its own procedures before release.

Nova Lite's reviewed regional/API combination has no native structured output contract. The prompt requests JSON; application validation rejects malformed output, extra fields, invalid enums, truncated output, refusals and filtered/tool output. No JSON repair or second paid generation is attempted. Input instructions are treated as untrusted ticket content. Validation controls shape and bounds, not factual accuracy or prompt-injection immunity. Human review remains essential. Rendering uses `textContent`, so model-supplied HTML is inert.

Lambda errors are `{"error":{"code":"invalid_input|denied|not_ready|suggestion_unavailable|not_found"}}`, using 400/403/503/404 respectively. Gateway-generated 401/403/404/429/5xx can have AWS's own JSON error shape; the UI handles status before attempting suggestion validation. No error includes ticket/model text. Application responses use no-store headers; gateway denial responses contain no ticket content.

The browser times out after 25 seconds and never automatically retries. The SDK has one total attempt, a 2-second connect timeout, a 3-second control read timeout and an 18-second model read timeout; the gateway timeout is 29 seconds. These are upper-level budgets, not a latency promise. A cancelled or timed-out invocation may still complete and cost money. A reviewer can manually resubmit; this can incur a second inference charge. No business side effects need idempotency or compensation. There is no queue, dead-letter store, cross-request model state or durable outcome to reconcile.

## Authorization and data lifecycle

Public assets contain configuration identifiers only. API Gateway validates the signed access token, issuer/audience/expiry and custom scope before Lambda. Lambda additionally checks trusted gateway claims (`token_use`, `client_id`, `iss`) and an explicit subject allowlist. Claims copied into headers by a client cannot authorize a request. Direct function invocation requires separate AWS IAM permission; do not grant it to staff. Administration and deployment IAM roles are out-of-band operator responsibilities, separate from the function role. No group claim, browser control or email domain grants application access.

Sign-in is disabled in the initial HTML and until `/config.json` returns a successful response with a validated Sydney Cognito origin and client ID. Configuration loading has a ten-second timeout and no automatic retries. A failed load keeps authentication and ticket entry disabled, removes any callback code from the address bar, and asks the user to reload. Sign-in also guards early synthetic events and disables itself during redirect preparation. These startup controls prevent lost actions; server authorization remains independent of them.

Access tokens last five minutes and are not refreshed/stored; the UI clears at expiry. Cognito logout also ends the hosted session. JWT verification does not consult token revocation or user disabled status on every request. To revoke application access promptly, remove a subject from `allowed_subs` and apply; disabling a Cognito user alone can leave an existing JWT usable until expiry. For immediate whole-tool shutdown disable the gateway stage/route or concurrency, using the runbook. In-flight invocations may finish.

The app never persists, hashes, logs or queues ticket text or outputs. The text exists transiently in browser/network/Lambda/model processing memory. No promises are made about physical memory zeroization, a user's clipboard, extensions, developer tools, screenshots, OS swap or unmanaged endpoint backups. Require managed staff devices. Suggestions contain derived ticket content and remain visible in the page until cleared, closed, signed out or expired; clearing also removes pasted text and invalidates pending results. There is no history or recovery of a lost suggestion.

No CloudWatch Logs permissions are attached, and no API access logs or X-Ray tracing are configured. SDK/model exceptions are discarded without logging. Bedrock account-level invocation logging is read on every model attempt; enabled text logging, denied reads or an unknown configuration fail closed. This read is not atomic with model invocation: the operator must keep account settings controlled during use. Do not attach broad logging/APM extensions or inherited capture policies without reviewing content exposure.

Provider retention is distinct from logging. The reviewed evidence requires regional account mode `none`. This package deliberately does not invent an unverified retention API name/response shape. Its **explicit unresolved integration** is automatic live retention-state verification. Instead, inference remains disabled until the operator verifies the current account/model/API policy and mode, with a short-lived `retention_verified_until` attestation (maximum 24 hours). Verification unknown/denied/expired means no inference. The attestation does not itself prove settings or prevent drift; operators must restrict configuration changes and disable the tool if settings change. If that control cannot meet your retention obligation, keep the tool disabled and implement a documented, tested live read before launch. Terraform never changes account-wide Bedrock logging/retention settings, which could affect existing workloads.

## Australia boundary and alternatives

The reviewed model card supports `amazon.nova-lite-v1:0` Converse with direct inference in `ap-southeast-2`. The code fixes both model and region, and IAM permits only that model ARN and denies Bedrock operations outside Sydney. APAC/global profiles and other model resources are not permitted. No CloudFront, external fonts, analytics, third-party model API or customer-record destination is present. Cognito/API/Lambda regional availability, actual direct-model quota, account access, retention policy and effective inherited IAM controls still require account verification.

Ticket processing is designed to stay in Sydney; internet routing from Australian users is not a residency guarantee. **Potentially outside Australia:** AWS global IAM/control/billing/support metadata, public DNS/TLS infrastructure, operator Terraform state/backups, identity-service supporting assets, user identity emails if invitations are sent, staff endpoint/browser services and any operator monitoring destination. No ticket payload is intentionally sent to these. Use suppressed Cognito invitations and approved credential handoff; inspect hosted-login network requests in the release check. Do not claim an end-to-end Australia-only guarantee until those dependencies and AWS contractual boundaries are reviewed. No cross-region fallback is allowed.

A single EC2/container server would add patching, always-on cost and process capacity work for this low intermittent load. S3/CloudFront would reduce static contention but add a global distribution boundary. A database/queue would conflict with the simple no-retention synchronous workflow. Corporate federation could replace the small dedicated Cognito pool later; existing IdP/ownership and federation were not specified, so no existing system is modified. These choices keep the proposed starting footprint modest while making its trade-offs visible.
