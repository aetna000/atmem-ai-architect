# Internal support ticket review

A small AWS tool for ten signed-in staff to paste synthetic or redacted support tickets and review a suggested summary, topic and urgency. Uncertainty is always shown with a reason. Reviewers can clear the suggestion; a late response cannot restore it. There is no help desk integration, reply function or customer-record write path.

The implementation uses Sydney (`ap-southeast-2`): Cognito, API Gateway HTTP API, one ARM64 Python Lambda, and direct regional Bedrock Nova Lite (`amazon.nova-lite-v1:0`, Converse). The Lambda also serves the browser files, avoiding a global content CDN. No database, queue, ticket bucket, analytics or ticket logs are provisioned.

Start with [the operator guide](docs/OPERATIONS.md). Engineers should read [setup and verification](docs/ENGINEERING.md), [architecture and contracts](docs/DESIGN.md), and [costs and sources](docs/COSTS-AND-SOURCES.md). The [artifact manifest](MANIFEST.md) identifies the delivered files.

Inference defaults to **disabled** and the staff allowlist defaults to empty. An operator must verify Australian regional support, model access, provider retention mode `none`, and logging settings in the target account before enabling a short-lived release gate. Provider retention has no automatic live reader in this implementation: the dated operator check expires within 24 hours. Unknown or denied verification means leave inference disabled. See the guide for this release limitation and checks requiring an AWS account.

Local tests and provider-schema checks are engineering evidence; they do not establish independent acceptance, model accuracy, real AWS authorization, pricing or residency. No deployment or cloud-account access was performed.
