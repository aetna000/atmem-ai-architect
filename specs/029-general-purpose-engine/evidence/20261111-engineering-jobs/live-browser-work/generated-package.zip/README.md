# Inventory normalizer

Independent CommonJS library. No packages, services, network access, or build step
are required. The existing warehouse API remains outside this module's ownership;
no warehouse implementation was supplied or changed.

```js
const { normalize, normalizeBatch } = require('./inventory-normalizer.cjs');

normalize(1.5, 'kg'); // 1500
normalizeBatch([{ value: 5, unit: 'g' }, { value: 2, unit: 'kg' }]); // [5, 2000]
```

`normalize(value, unit)` accepts only finite, nonnegative primitive numbers and
the exact case-sensitive strings `g` and `kg`. Invalid inputs throw `TypeError`;
there is no coercion. Conversion uses JavaScript number arithmetic without
rounding, so sufficiently large kilogram values can overflow to `Infinity`.

`normalizeBatch(items)` accepts an array of `{ value, unit }` objects and returns
a new array in input order, using the same scalar validation. Empty arrays return
`[]`. Non-arrays, malformed items, and sparse entries throw `TypeError`.
Arrays longer than 100 throw `RangeError` before item validation. A failed batch
throws without returning partial results. Neither function mutates its inputs or
stores state.

Run locally from this directory with Node.js 18 or later (no install needed):

```sh
./.tools/node --openssl-config=/dev/null --test test/inventory-normalizer.test.cjs
./.tools/node --openssl-config=/dev/null -e "console.log(require('./inventory-normalizer.cjs').normalize(2, 'kg'))"
```

Outside the supplied tool environment, replace `./.tools/node` with `node`.
The OpenSSL flag avoids the supplied runtime's inaccessible system config; it
can be omitted in a normal local installation.
Rollback: remove this module, its test, and this README; remove any caller imports
you have added. No infrastructure, migrations, or persisted data are involved.

Verification: all 9 built-in tests and the smoke command passed locally on Node
v26.5.0 using the commands above. Mock checks and provider-schema checks are not
applicable. Warehouse integration and client acceptance remain unverified because
no warehouse implementation was supplied.
