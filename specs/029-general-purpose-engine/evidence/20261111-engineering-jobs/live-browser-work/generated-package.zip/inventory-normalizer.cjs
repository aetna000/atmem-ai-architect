'use strict';

/** Convert a finite, nonnegative number in g or kg to grams. */
function normalize(value, unit) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new TypeError('value must be a finite nonnegative number');
  }
  if (unit !== 'g' && unit !== 'kg') {
    throw new TypeError('unit must be exactly g or kg');
  }
  return unit === 'kg' ? value * 1000 : value;
}

/** Convert up to 100 { value, unit } items without modifying the input. */
function normalizeBatch(items) {
  if (!Array.isArray(items)) {
    throw new TypeError('items must be an array');
  }
  if (items.length > 100) {
    throw new RangeError('a batch must contain at most 100 items');
  }

  const grams = [];
  for (const item of items) {
    if (item === null || typeof item !== 'object' || Array.isArray(item)) {
      throw new TypeError('each item must be an object with value and unit');
    }
    grams.push(normalize(item.value, item.unit));
  }
  return grams;
}

module.exports = { normalize, normalizeBatch };
