'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { normalize, normalizeBatch } = require('../inventory-normalizer.cjs');

test('normalize converts supported units, including zero and fractional values', () => {
  for (const [value, unit, expected] of [
    [0, 'g', 0], [0, 'kg', 0], [42, 'g', 42],
    [0.125, 'g', 0.125], [2, 'kg', 2000], [1.25, 'kg', 1250],
    [Number.MIN_VALUE, 'g', Number.MIN_VALUE],
    [Number.MAX_VALUE, 'g', Number.MAX_VALUE],
  ]) {
    assert.equal(normalize(value, unit), expected);
  }
  assert.equal(normalize(-0, 'g'), -0);
  assert.equal(normalize(-0, 'kg'), -0);
});

test('normalize rejects invalid values without coercion in either unit', () => {
  const invalid = [true, false, '1', '', null, undefined, {}, [],
    new Number(1), 1n, Symbol('value'), -1, -Number.MIN_VALUE,
    NaN, Infinity, -Infinity];
  for (const value of invalid) {
    for (const unit of ['g', 'kg']) {
      assert.throws(() => normalize(value, unit), TypeError);
    }
  }
});

test('normalize accepts only exact case-sensitive unit strings', () => {
  for (const unit of ['G', 'KG', 'Kg', 'mg', 'lb', '', ' g', 'kg ',
    null, undefined, true, 1, {}, [], new String('g'), Symbol('g')]) {
    assert.throws(() => normalize(1, unit), TypeError);
  }
  assert.throws(() => normalize(), TypeError);
});

test('finite inputs use ordinary JavaScript multiplication, including overflow', () => {
  assert.equal(normalize(Number.MAX_VALUE, 'kg'), Infinity);
});

test('normalizeBatch returns ordered grams without mutating inputs', () => {
  const items = Object.freeze([
    Object.freeze({ value: 2.5, unit: 'kg' }),
    Object.freeze({ value: 3, unit: 'g' }),
    Object.freeze({ value: 0, unit: 'kg' }),
  ]);
  assert.deepEqual(normalizeBatch(items), [2500, 3, 0]);
  assert.deepEqual(items, [
    { value: 2.5, unit: 'kg' }, { value: 3, unit: 'g' },
    { value: 0, unit: 'kg' },
  ]);
});

test('normalizeBatch accepts empty and exactly 100-item batches', () => {
  const empty = [];
  const result = normalizeBatch(empty);
  assert.deepEqual(result, []);
  assert.notStrictEqual(result, empty);
  assert.deepEqual(
    normalizeBatch(Array.from({ length: 100 }, () => ({ value: 1, unit: 'kg' }))),
    Array(100).fill(1000),
  );
});

test('normalizeBatch rejects batches exceeding 100 before inspecting items', () => {
  for (const length of [101, 1000]) {
    assert.throws(() => normalizeBatch(new Array(length)), RangeError);
  }
});

test('normalizeBatch rejects non-array batches and malformed items', () => {
  for (const items of [undefined, null, {}, '[]', 1, true, new Set()]) {
    assert.throws(() => normalizeBatch(items), TypeError);
  }
  for (const item of [undefined, null, 1, true, '1', [], {},
    { value: 1 }, { unit: 'g' }]) {
    assert.throws(() => normalizeBatch([item]), TypeError);
  }
  assert.throws(() => normalizeBatch(new Array(1)), TypeError);
});

test('normalizeBatch applies scalar validation even after valid items', () => {
  for (const item of [
    { value: '1', unit: 'g' }, { value: true, unit: 'kg' },
    { value: -1, unit: 'g' }, { value: NaN, unit: 'g' },
    { value: Infinity, unit: 'kg' }, { value: 1, unit: 'KG' },
  ]) {
    assert.throws(
      () => normalizeBatch([{ value: 1, unit: 'g' }, item]), TypeError,
    );
  }
});
