"""Behavioral tests; run with python3 -m unittest -v."""

import unittest
from decimal import Decimal
from fractions import Fraction

from measurement import convert


class MeasurementTests(unittest.TestCase):
    def test_all_length_directions(self):
        cases = (
            (25, "mm", "cm", 2.5),
            (2500, "mm", "m", 2.5),
            (2.5, "cm", "mm", 25),
            (250, "cm", "m", 2.5),
            (2.5, "m", "mm", 2500),
            (2.5, "m", "cm", 250),
        )
        for value, source, target, expected in cases:
            with self.subTest(source=source, target=target):
                self.assertAlmostEqual(convert(value, source, target), expected)

    def test_temperature_reference_points(self):
        for celsius, fahrenheit in ((0, 32), (100, 212), (-40, -40), (37, 98.6)):
            with self.subTest(celsius=celsius):
                self.assertAlmostEqual(convert(celsius, "C", "F"), fahrenheit)
                self.assertAlmostEqual(convert(fahrenheit, "F", "C"), celsius)

    def test_identity_for_every_unit_and_numeric_type(self):
        for unit in ("mm", "cm", "m", "C", "F"):
            for value in (0, -12, 2.5, -0.0, 10**400):
                with self.subTest(unit=unit, value=value):
                    self.assertIs(convert(value, unit, unit), value)

    def test_zero_and_negative_lengths(self):
        self.assertEqual(convert(0, "m", "mm"), 0)
        self.assertEqual(convert(-1.25, "m", "cm"), -125)

    def test_round_trips(self):
        for source, target in (("m", "mm"), ("cm", "mm"), ("C", "F")):
            for value in (-273.15, -1, 0, 0.125, 12345.5):
                with self.subTest(source=source, target=target, value=value):
                    self.assertAlmostEqual(
                        convert(convert(value, source, target), target, source),
                        value,
                    )

    def test_rejects_non_numeric_values_and_booleans(self):
        for value in (True, False, "1", "", None, [], {}, 1j, Decimal("1"), Fraction(1, 2)):
            for source, target in (("m", "cm"), ("C", "C")):
                with self.subTest(value=value, source=source, target=target):
                    with self.assertRaises(ValueError):
                        convert(value, source, target)

    def test_rejects_nonfinite_numbers_even_for_identity(self):
        for value in (float("nan"), float("inf"), float("-inf")):
            for source, target in (("m", "cm"), ("F", "C"), ("m", "m")):
                with self.subTest(value=value, source=source, target=target):
                    with self.assertRaises(ValueError):
                        convert(value, source, target)

    def test_rejects_unknown_units_in_either_position(self):
        for unit in ("M", "MM", "Cm", "c", "f", "K", "inch", "", " m", None, [], {}):
            for source, target in ((unit, "m"), ("m", unit), (unit, unit)):
                with self.subTest(source=source, target=target):
                    with self.assertRaises(ValueError):
                        convert(1, source, target)

    def test_rejects_all_cross_dimension_pairs(self):
        for length in ("mm", "cm", "m"):
            for temperature in ("C", "F"):
                for source, target in ((length, temperature), (temperature, length)):
                    with self.subTest(source=source, target=target):
                        with self.assertRaises(ValueError):
                            convert(1, source, target)


if __name__ == "__main__":
    unittest.main()
