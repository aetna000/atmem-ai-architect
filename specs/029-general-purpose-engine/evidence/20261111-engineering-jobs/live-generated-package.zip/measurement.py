"""Local, dependency-free length and temperature conversion."""

import math

__all__ = ["convert"]

_LENGTH_MM = {"mm": 1, "cm": 10, "m": 1000}
_TEMPERATURE = ("C", "F")


def convert(value: int | float, source: str, target: str) -> int | float:
    """Convert a finite number between case-sensitive units of one dimension.

    Supported units are mm/cm/m for length and C/F for temperature.
    Invalid values, unknown units and cross-dimension conversions raise
    ValueError. Identity conversion returns the original numeric value.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("value must be a finite int or float, excluding bool")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("value must be finite")

    for unit in (source, target):
        if not isinstance(unit, str) or (
            unit not in _LENGTH_MM and unit not in _TEMPERATURE
        ):
            raise ValueError(f"unknown unit: {unit!r}")

    source_is_length = source in _LENGTH_MM
    if source_is_length != (target in _LENGTH_MM):
        raise ValueError("source and target must have the same dimension")
    if source == target:
        return value

    if source_is_length:
        source_scale = _LENGTH_MM[source]
        target_scale = _LENGTH_MM[target]
        if source_scale > target_scale:
            return value * (source_scale // target_scale)
        return value / (target_scale // source_scale)

    if source == "C":
        return value * 1.8 + 32
    return (value - 32) / 1.8
