# Measurement conversion

Independent, stateless pure-Python library for Python 3.10+. It uses only the
standard library, performs no networking and has no cloud, AI or third-party
runtime dependencies. No telemetry integration or service changes are included.

```python
from measurement import convert

convert(1.5, "m", "cm")  # 150.0
convert(32, "F", "C")    # 0.0
convert(7, "mm", "mm")   # 7
```

Units are case-sensitive: `mm`, `cm`, `m` for length; `C`, `F` for temperature.
Only conversions within one dimension are supported. Inputs must be finite
`int` or `float` values; booleans, strings, other types, nonfinite numbers,
unknown units and incompatible units raise `ValueError`. Identity conversions
validate the inputs and return the original number. Floating-point results
follow Python floating-point precision.

From this directory, run locally without installing anything:

```sh
python3 -m unittest -v
python3 -c 'from measurement import convert; print(convert(100, "C", "F"))'
```

There is no build or deployment step. Consumers can place `measurement.py` on
their Python import path. Roll back by removing that file from the consuming
application and reverting its import/call sites; this library owns no persistent
state or infrastructure. The supplied project snapshot remains unchanged.
