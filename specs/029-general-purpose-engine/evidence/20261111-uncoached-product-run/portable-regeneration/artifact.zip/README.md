# Internal ticket review

A small AWS tool for ten signed-in staff. Paste synthetic or redacted ticket text, get a short **summary, topic, suggested urgency and uncertainty**, then review it yourself. **Clear text and suggestion** removes the current result and prevents an in-flight response from restoring it. There is no help desk integration, outgoing reply function, customer-record access, ticket database or suggestion history. Your existing help desk remains unchanged.

The implementation uses **AWS Sydney (`ap-southeast-2`)** with Cognito, a regional HTTP API, two small Lambda functions and direct regional Bedrock inference. No cloud resources have been deployed. Application code and offline checks are delivered; operator acceptance remains outstanding.

## Start here

1. The person using the tool: read [the short user guide](docs/USER_GUIDE.md).
2. The person running it: follow [setup, deployment, maintenance and rollback](docs/OPERATIONS.md).
3. Review [the architecture and data boundaries](docs/DESIGN.md), [cost worksheet and source links](docs/COSTS.md), and [verification results and unresolved checks](docs/VERIFICATION.md).

The starting model is Claude 3 Haiku, direct model ID `anthropic.claude-3-haiku-20240307-v1:0`. Its **current Sydney direct on-demand availability, lifecycle, entitlement and price are unverified offline**. The deployment must stop if this model is unavailable; substituting a cross-region inference profile is not allowed by this design. The operator must select and review a replacement in-region model if necessary, update the coupled code/IAM/tests, and repeat acceptance.

## Build and check an unpacked project

There are no npm or Python packages to install for local checks. Supply Python 3.12+, Node.js 22+, Terraform **1.17.1** and an approved offline mirror of `hashicorp/aws` **6.72.0** for the operator's platform. The supplied helper registers existing tools; it does not install anything or configure AWS credentials. In a fresh unpack:

```sh
python3 atmem-tools/prepare.py --python /absolute/path/to/python3 \
  --node /absolute/path/to/node --terraform /absolute/path/to/terraform \
  --provider-mirror /absolute/path/to/approved/provider-mirror \
  --require python --require node --require terraform --require providerMirror
export OPENSSL_CONF="$PWD/.worker-tmp/openssl.cnf"
export TF_CLI_CONFIG_FILE="$PWD/.worker-tmp/terraform.rc"
export TMPDIR="$PWD/.worker-tmp"
export CHECKPOINT_DISABLE=1
./.tools/python scripts/build.py
./.tools/python -m unittest discover -s tests -v
./.tools/node --check app/static/app.js
./.tools/node --test tests/*.test.js
./.tools/terraform -chdir=infra init -backend=false -input=false -lockfile=readonly
./.tools/terraform -chdir=infra fmt -check -recursive
./.tools/terraform -chdir=infra validate
./.tools/terraform -chdir=infra test -no-color
```

The lock file currently has a locally calculated **darwin_arm64** provider checksum. It is not a publisher signature or Linux checksum. For another platform, use an approved mirror containing that exact provider/platform and extend the lock file offline with `terraform -chdir=infra providers lock -fs-mirror=/absolute/path/to/approved/provider-mirror -platform=linux_amd64` (substitute the actual platform); review its provenance/checksum before initialization. No registry fallback is configured. Missing tools, providers or runtime dependencies are failures, never skipped passes.

Tests run in-process and use synthetic AWS transports and Terraform mocks; they do not open a local network port or contact AWS. The real Lambda runtime is **Python 3.12 on Amazon Linux 2023, arm64**. It uses the AWS-managed `boto3`/`botocore` included in that runtime, including Converse; these SDK versions are **not pinned by this archive**. Record them and prove compatibility in AWS acceptance, and repeat after managed runtime changes. The Python/Node tools used offline are engineering tools, not a copy of that runtime. See verification for exact versions and limits.

## Handoff contents

| Path | Purpose |
|---|---|
| `app/worker.py`, `app/contract.py` | Authorized processing and strict JSON validation |
| `app/web.py`, `app/static/` | Regional UI, PKCE sign-in, uncertainty display and Clear |
| `schemas/` | Request, response and application error contracts |
| `infra/`, including `.terraform.lock.hcl` and `tests/` | AWS resources, locked provider and infrastructure mock checks |
| `scripts/build.py`, `scripts/preflight.py` | Deterministic runtime packaging; separate operator-only AWS read checks |
| `tests/` | Synthetic cases for validation, denial, failures, SDK adapter, packaging and Clear races |
| `dist/manifest.json` | SHA-256s and exact runtime archive membership; regenerate with build |
| `docs/` | Operator/user instructions, decisions, costs and evidence |
| `ATMEM_DELIVERY.md`, `atmem-tools/prepare.py`, `project-context.json`, `.agents/skills/composition/SKILL.md` | Preserved delivery inputs and frozen client evidence |

`dist/worker.zip` and `dist/web.zip` are generated locally; rebuilding is required after unpacking or editing. Only application runtime files enter those ZIPs. `.tools`, `.worker-tmp`, `.terraform`, caches and private worker paths are not application dependencies and are not part of the exported handoff.
