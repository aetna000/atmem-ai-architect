"""Serve the small UI from the regional API, without a global CDN."""
import json
import os
from pathlib import Path

STATIC = Path(__file__).parent / "static"
FILES = {"/": ("index.html", "text/html; charset=utf-8"),
         "/app.js": ("app.js", "text/javascript; charset=utf-8"),
         "/core.js": ("core.js", "text/javascript; charset=utf-8"),
         "/style.css": ("style.css", "text/css; charset=utf-8")}


def handler(event, context):
    path = event.get("rawPath", "")
    domain = os.environ["AUTH_DOMAIN"]
    headers = {"cache-control": "no-store", "x-content-type-options": "nosniff",
               "referrer-policy": "no-referrer", "permissions-policy": "camera=(), microphone=(), geolocation=()",
               "strict-transport-security": "max-age=31536000",
               "content-security-policy": "default-src 'none'; script-src 'self'; style-src 'self'; "
               f"connect-src 'self' {domain}; img-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"}
    if path == "/config.json":
        headers["content-type"] = "application/json; charset=utf-8"
        return {"statusCode": 200, "headers": headers, "body": json.dumps({
            "clientId": os.environ["CLIENT_ID"], "authDomain": domain,
            "redirectUri": os.environ["BASE_URL"] + "/", "scope": "openid support-review/suggest"})}
    if path not in FILES:
        headers["content-type"] = "application/json"
        return {"statusCode": 404, "headers": headers, "body": '{"error":{"code":"not_found"}}'}
    filename, content_type = FILES[path]
    headers["content-type"] = content_type
    return {"statusCode": 200, "headers": headers, "body": (STATIC / filename).read_text(encoding="utf-8")}
