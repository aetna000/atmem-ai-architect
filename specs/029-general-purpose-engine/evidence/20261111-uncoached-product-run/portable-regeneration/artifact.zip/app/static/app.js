import {createReview, validTicket} from './core.js';
const $ = id => document.getElementById(id);
let token = null, expiryTimer, config, busy = false;
const pendingKey = 'ticket-review-login';
function render(state) {
  busy = state.kind === 'loading';
  $('result').hidden = true;
  for (const id of ['summary','topic','urgency','uncertainty','reason']) $(id).textContent = '';
  $('status').textContent = state.kind === 'loading' ? 'Preparing a suggestion…' : state.message || '';
  if (state.kind === 'result') {
    const v = state.value;
    $('summary').textContent = v.summary;
    $('topic').textContent = v.topic.replaceAll('_',' ');
    $('urgency').textContent = v.urgency;
    $('uncertainty').textContent = `${v.uncertainty.level.toUpperCase()} UNCERTAINTY — human review required`;
    $('uncertainty').dataset.level = v.uncertainty.level;
    $('reason').textContent = v.uncertainty.reason;
    $('result').hidden = false;
  }
  update();
}
const review = createReview((...args) => fetch(...args), render);
function update() {
  $('ticket').disabled = !token || busy;
  $('submit').disabled = !token || busy || !validTicket($('ticket').value);
  $('size').textContent = `${new TextEncoder().encode($('ticket').value).length.toLocaleString('en-AU')} / 20,480 UTF-8 bytes`;
  $('signin').hidden = !!token;
  $('signout').hidden = !token;
}
function clear() { $('ticket').value = ''; review.clear(); }
function endSession(message) {
  clearTimeout(expiryTimer); token = null; clear();
  $('session').textContent = message; update();
}
const b64 = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
const random = () => b64(crypto.getRandomValues(new Uint8Array(32)));
async function signIn() {
  endSession('Redirecting to sign in…');
  try {
    const verifier = random(), state = random();
    const challenge = b64(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))));
    sessionStorage.setItem(pendingKey, JSON.stringify({verifier,state,created:Date.now()}));
    const url = new URL(config.authDomain + '/oauth2/authorize');
    url.search = new URLSearchParams({response_type:'code',client_id:config.clientId,redirect_uri:config.redirectUri,
      scope:config.scope,state,code_challenge:challenge,code_challenge_method:'S256'});
    location.assign(url);
  } catch (_) { endSession('Sign-in could not start. Check that browser session storage is available.'); }
}
async function start() {
  const params = new URLSearchParams(location.search);
  history.replaceState(null,'',location.pathname);
  try {
    const c = await fetch('/config.json',{cache:'no-store',credentials:'omit'});
    if (!c.ok) throw new Error('configuration');
    config = await c.json();
    $('signin').disabled = false;
    const pending = sessionStorage.getItem(pendingKey);
    sessionStorage.removeItem(pendingKey);
    if (params.has('error')) throw new Error('sign-in denied');
    if (!params.has('code')) return;
    const p = JSON.parse(pending);
    if (!p || p.state !== params.get('state') || Date.now()-p.created > 300000 || Date.now()<p.created) throw new Error('state');
    const r = await fetch(config.authDomain + '/oauth2/token', {method:'POST',cache:'no-store',credentials:'omit',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({grant_type:'authorization_code',client_id:config.clientId,code:params.get('code'),
        redirect_uri:config.redirectUri,code_verifier:p.verifier})});
    if (!r.ok) throw new Error('token');
    const t = await r.json();
    if (typeof t.access_token !== 'string' || t.token_type?.toLowerCase() !== 'bearer' || !Number.isFinite(t.expires_in) || t.expires_in < 1 || t.expires_in > 300) throw new Error('token');
    token = t.access_token;
    $('session').textContent = 'Signed in. Sessions last up to five minutes; text and suggestions are not saved.';
    expiryTimer = setTimeout(() => endSession('Sign-in expired. Sign in again.'), Math.max(0,t.expires_in-5)*1000);
  } catch (_) { endSession('Sign-in failed. Try again; contact the operator if it persists.'); }
  finally { update(); }
}
$('signin').disabled = true;
$('signin').addEventListener('click',signIn);
$('signout').addEventListener('click',() => {
  endSession('Signed out.'); sessionStorage.removeItem(pendingKey);
  const url = new URL(config.authDomain + '/logout');
  url.search = new URLSearchParams({client_id:config.clientId,logout_uri:config.redirectUri}); location.assign(url);
});
$('clear').addEventListener('click',clear);
$('ticket').addEventListener('input',update);
$('form').addEventListener('submit',event => {
  event.preventDefault();
  if (!token || busy || !validTicket($('ticket').value)) return;
  const text = $('ticket').value;
  $('ticket').value = '';
  void review.suggest(text,token);
});
addEventListener('pagehide',() => { endSession('Sign in to request a suggestion.'); });
addEventListener('pageshow',e => { if (e.persisted) location.reload(); });
void start();
