export const MAX_BYTES = 20480;
const exact = (obj, keys) => obj && typeof obj === 'object' && !Array.isArray(obj) &&
  Object.keys(obj).sort().join(',') === [...keys].sort().join(',');
const bounded = (s, max) => typeof s === 'string' && s.trim().length > 0 &&
  [...s].length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ud800-\udfff]/u.test(s);
export function validSuggestion(v) {
  return exact(v, ['summary','topic','urgency','uncertainty']) && bounded(v.summary,600) &&
    ['billing','account_access','technical_issue','feature_request','other'].includes(v.topic) &&
    ['low','normal','high','critical'].includes(v.urgency) &&
    exact(v.uncertainty, ['level','reason']) &&
    ['low','medium','high'].includes(v.uncertainty.level) && bounded(v.uncertainty.reason,240);
}
export function validTicket(text) {
  return typeof text === 'string' && text.trim().length > 0 && !/[\ud800-\udfff]/u.test(text) &&
    !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(text) && new TextEncoder().encode(text).length <= MAX_BYTES;
}

// Generation checks stop a late response from undoing Clear, even if abort arrives too late.
export function createReview(fetcher, onState) {
  let generation = 0, active;
  function clear() {
    generation++;
    if (active) active.abort();
    active = undefined;
    onState({kind:'empty'});
  }
  async function suggest(text, token) {
    clear();
    if (!validTicket(text)) { onState({kind:'error', message:'Enter non-empty text of at most 20,480 UTF-8 bytes.'}); return; }
    const own = generation;
    active = new AbortController();
    const timer = setTimeout(() => { if (own === generation) active?.abort(); }, 30000);
    onState({kind:'loading'});
    try {
      const r = await fetcher('/suggest', {method:'POST', cache:'no-store', credentials:'omit',
        headers:{'Content-Type':'application/json', Authorization:`Bearer ${token}`},
        body:JSON.stringify({text}), signal:active.signal});
      if (own !== generation) return;
      if (!r.ok) {
        const message = r.status === 401 || r.status === 403 ? 'Access denied or sign-in expired. Sign in again; ask the operator if access is still denied.' :
          r.status === 429 ? 'The tool is busy. Wait a few seconds and submit again if needed.' :
          r.status === 400 || r.status === 413 || r.status === 415 ? 'The ticket was rejected. Check its format and size.' :
          'No suggestion is available. Review the ticket yourself, or submit again later.';
        onState({kind:'error', message}); return;
      }
      const v = await r.json();
      if (own !== generation) return;
      if (!validSuggestion(v)) throw new Error('invalid response');
      onState({kind:'result', value:v});
    } catch (_) {
      if (own === generation) onState({kind:'error', message:'No suggestion is available. Review the ticket yourself, or submit again later.'});
    } finally {
      clearTimeout(timer);
      if (own === generation) active = undefined;
    }
  }
  return {clear, suggest};
}
