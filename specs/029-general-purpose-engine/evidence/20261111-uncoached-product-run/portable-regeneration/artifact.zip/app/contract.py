"""Small explicit JSON contract; no coercion, repairs or additional fields."""
import json

TOPICS = ("billing", "account_access", "technical_issue", "feature_request", "other")
URGENCIES = ("low", "normal", "high", "critical")
LEVELS = ("low", "medium", "high")
MAX_TICKET_BYTES = 20 * 1024
MAX_WIRE_BYTES = MAX_TICKET_BYTES * 6 + 128


class Invalid(ValueError):
    pass


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise Invalid("duplicate key")
        result[key] = value
    return result


def _constant(_):
    raise Invalid("non-finite JSON number")


def strict_json(value):
    try:
        return json.loads(value, object_pairs_hook=_pairs, parse_constant=_constant)
    except (ValueError, TypeError, RecursionError) as exc:
        raise Invalid("invalid JSON") from exc


def exact(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        raise Invalid("invalid fields")


def bounded_string(value, maximum):
    if type(value) is not str or not value.strip() or len(value) > maximum:
        raise Invalid("invalid string")
    try:
        value.encode("utf-8")
    except UnicodeError as exc:
        raise Invalid("invalid Unicode") from exc
    if any(ord(c) < 32 and c not in "\n\r\t" for c in value):
        raise Invalid("invalid control character")


def validate_ticket(value):
    exact(value, ("text",))
    bounded_string(value["text"], MAX_TICKET_BYTES)
    if len(value["text"].encode("utf-8")) > MAX_TICKET_BYTES:
        raise Invalid("ticket too large")
    return value["text"]


def validate_suggestion(value):
    exact(value, ("summary", "topic", "urgency", "uncertainty"))
    bounded_string(value["summary"], 600)
    if type(value["topic"]) is not str or value["topic"] not in TOPICS:
        raise Invalid("invalid topic")
    if type(value["urgency"]) is not str or value["urgency"] not in URGENCIES:
        raise Invalid("invalid urgency")
    uncertainty = value["uncertainty"]
    exact(uncertainty, ("level", "reason"))
    if type(uncertainty["level"]) is not str or uncertainty["level"] not in LEVELS:
        raise Invalid("invalid uncertainty")
    bounded_string(uncertainty["reason"], 240)
    return value
