"""Internal, human-reviewed ticket suggestions. No persistence or help desk client."""
