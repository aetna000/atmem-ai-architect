import copy
import hashlib
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import zipfile
from scripts.build import build
from scripts.preflight import assess, MODEL


class DeliveryTests(unittest.TestCase):
    def test_runtime_archives_are_reproducible_and_isolated(self):
        first = build()
        self.assertEqual(first, build())
        for name, info in first.items():
            with zipfile.ZipFile(Path("dist") / f"{name}.zip") as archive:
                self.assertEqual(sorted(archive.namelist()), info["files"])
                self.assertTrue(all(p.startswith("app/") for p in archive.namelist()))
                self.assertTrue(all("test" not in p and ".tools" not in p for p in archive.namelist()))
                for filename in archive.namelist():
                    if filename.endswith(".py"):
                        compile(archive.read(filename), filename, "exec")
                if name == "worker": self.assertNotIn("app/web.py", archive.namelist())

    def test_operator_preflight_fails_closed(self):
        account = "123456789012"
        identity = {"Account": account}
        model = {"modelDetails": {"modelId": MODEL, "modelArn": f"arn:aws:bedrock:ap-southeast-2::foundation-model/{MODEL}",
                                  "inferenceTypesSupported": ["ON_DEMAND"], "modelLifecycle": {"status": "ACTIVE"}}}
        capacity = {"UnreservedConcurrentExecutions": 1000}
        self.assertEqual(assess(account, identity, {}, model, capacity), [])
        self.assertTrue(assess(account, {"Account": "wrong"}, {}, model, capacity))
        self.assertTrue(assess(account, identity, {"loggingConfig": {"textDataDeliveryEnabled": True}}, model, capacity))
        self.assertTrue(assess(account, identity, {}, {}, capacity))
        self.assertTrue(assess(account, identity, {}, model, {"UnreservedConcurrentExecutions": 106}))
        for field, value in (("inferenceTypesSupported", ["PROVISIONED"]), ("modelLifecycle", {"status": "LEGACY"})):
            changed = copy.deepcopy(model); changed["modelDetails"][field] = value
            self.assertTrue(assess(account, identity, {}, changed, capacity))


if __name__ == "__main__": unittest.main()
