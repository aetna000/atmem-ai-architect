import test from 'node:test';
import assert from 'node:assert/strict';
import {createReview, validSuggestion, validTicket} from '../app/static/core.js';
const good = {summary:'A synthetic ticket.',topic:'other',urgency:'normal',uncertainty:{level:'high',reason:'Too little context.'}};
test('UTF-8 byte boundary including non-ASCII and escaped control data', () => {
  for (const text of ['a'.repeat(20480),'é'.repeat(10240),'😀'.repeat(5120)]) assert.ok(validTicket(text));
  for (const text of ['', ' ', 'é'.repeat(10241), '😀'.repeat(5121), '\ud800','a\u0000']) assert.equal(validTicket(text),false);
});
test('response validation includes uncertainty and forbids extra fields', () => {
  assert.ok(validSuggestion(good));
  for (const v of [null, [], {...good, extra:1}, {...good, urgency:'urgent'}, {...good, uncertainty:{level:'certain',reason:'yes'}}, {...good,summary:'x'.repeat(601)}]) assert.ok(!validSuggestion(v));
  assert.ok(validSuggestion({...good,summary:'😀'.repeat(600)}));
});
test('result carries uncertainty; no automatic retry', async () => {
  const states = []; let requests = 0;
  const review = createReview(async (_,o) => { requests++; assert.equal(o.credentials,'omit'); assert.equal(o.cache,'no-store'); return {ok:true,json:async()=>good}; }, s=>states.push(s));
  await review.suggest('synthetic','token');
  assert.equal(requests,1); assert.deepEqual(states.at(-1),{kind:'result',value:good});
  review.clear(); assert.equal(states.at(-1).kind,'empty');
});
test('clear during fetch prevents a late response from reappearing', async () => {
  const states = []; let resolve, signal;
  const review = createReview((_,o)=>{signal=o.signal; return new Promise(r=>resolve=r);}, s=>states.push(s));
  const pending = review.suggest('synthetic','token');
  review.clear(); assert.ok(signal.aborted);
  resolve({ok:true,json:async()=>good}); await pending;
  assert.equal(states.at(-1).kind,'empty'); assert.ok(!states.some(s=>s.kind==='result'));
});
test('clear while JSON is being read also wins', async () => {
  const states = []; let resolve;
  const review = createReview(async()=>({ok:true,json:()=>new Promise(r=>resolve=r)}),s=>states.push(s));
  const pending = review.suggest('synthetic','token'); await Promise.resolve();
  review.clear(); resolve(good); await pending; assert.equal(states.at(-1).kind,'empty');
});
test('denial, overload, model failure, invalid output and timeout discard suggestion', async () => {
  for (const status of [401,403,400,413,415,429,500,503]) {
    const states=[]; let count=0;
    const review=createReview(async()=>{count++; return {ok:false,status};},s=>states.push(s));
    await review.suggest('synthetic','token'); assert.equal(states.at(-1).kind,'error'); assert.equal(count,1);
  }
  for (const fetcher of [async()=>{throw new Error('PRIVATE');},async()=>({ok:true,json:async()=>({...good,extra:1})})]) {
    const states=[]; await createReview(fetcher,s=>states.push(s)).suggest('synthetic','token');
    assert.equal(states.at(-1).kind,'error'); assert.ok(!states.at(-1).message.includes('PRIVATE'));
  }
});
