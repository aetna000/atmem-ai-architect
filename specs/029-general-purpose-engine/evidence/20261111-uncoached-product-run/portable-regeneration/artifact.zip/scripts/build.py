"""Reproducible runtime-only Lambda archives. Standard library; no downloads."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def build():
    output = ROOT / "dist"
    output.mkdir(exist_ok=True)
    bundles = {
        "worker": ["app/__init__.py", "app/contract.py", "app/worker.py"],
        "web": ["app/__init__.py", "app/web.py"] +
               [p.relative_to(ROOT).as_posix() for p in sorted((ROOT / "app/static").glob("*")) if p.is_file()],
    }
    manifest = {}
    for name, files in bundles.items():
        target = output / f"{name}.zip"
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            for filename in sorted(files):
                info = zipfile.ZipInfo(filename, date_time=(2020, 1, 1, 0, 0, 0))
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, (ROOT / filename).read_bytes())
        manifest[name] = {"sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "files": sorted(files)}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    print(json.dumps(build(), indent=2))
