"""Operator-only read checks. Never invoked by build/tests, and never changes AWS."""
import argparse
import json
import os
import subprocess

REGION = "ap-southeast-2"
MODEL = "anthropic.claude-3-haiku-20240307-v1:0"


def assess(account, identity, logging, model, concurrency):
    failures = []
    if identity.get("Account") != account:
        failures.append("Account does not match the approved account.")
    if logging.get("loggingConfig"):
        failures.append("Bedrock invocation logging is configured. Stop; do not disable shared logging automatically.")
    details = model.get("modelDetails", {})
    if details.get("modelId") != MODEL or details.get("modelArn") != f"arn:aws:bedrock:{REGION}::foundation-model/{MODEL}":
        failures.append("Expected direct Sydney model is not available.")
    if "ON_DEMAND" not in details.get("inferenceTypesSupported", []):
        failures.append("Direct on-demand invocation is unavailable; no inference-profile fallback is allowed.")
    if details.get("modelLifecycle", {}).get("status") != "ACTIVE":
        failures.append("Model is not ACTIVE. Reassess the model choice and regional availability.")
    # New reservations need at least seven spare slots above Lambda's 100 unreserved minimum.
    if concurrency.get("UnreservedConcurrentExecutions", 0) < 107:
        failures.append("First deployment needs 7 reservable Lambda slots above the 100 unreserved minimum; inspect quotas/reservations.")
    return failures


def read(service, operation, *args):
    env = {**os.environ, "AWS_STS_REGIONAL_ENDPOINTS": "regional", "AWS_PAGER": ""}
    completed = subprocess.run(["aws", "--region", REGION, service, operation, *args, "--output", "json"],
                               capture_output=True, text=True, timeout=30, check=False, env=env)
    if completed.returncode:
        raise RuntimeError("An AWS read failed. Check credentials/permissions in the approved operator environment; no service diagnostics were printed.")
    return json.loads(completed.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--read-aws", action="store_true", help="Explicitly permit read-only AWS API calls")
    parser.add_argument("--account", required=True)
    args = parser.parse_args()
    if not args.read_aws:
        parser.error("No AWS access without --read-aws. Run only in an approved operator environment.")
    try:
        failures = assess(args.account, read("sts", "get-caller-identity"),
                          read("bedrock", "get-model-invocation-logging-configuration"),
                          read("bedrock", "get-foundation-model", "--model-identifier", MODEL),
                          read("lambda", "get-account-settings").get("AccountLimit", {}))
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
        parser.exit(1, f"Preflight could not complete ({type(exc).__name__}). No deployment performed.\n")
    print(json.dumps({"region": REGION, "failures": failures,
                      "remaining": ["Review current pricing, model entitlement/lifecycle, Bedrock RPM/TPM quotas and privacy terms.",
                                    "This check is for first deployment. An existing stack may already reserve its seven slots.",
                                    "Read checks do not prove real invocation, sign-in, latency, data residency or acceptance."]}, indent=2))
    return 1 if failures else 0


if __name__ == "__main__": raise SystemExit(main())
