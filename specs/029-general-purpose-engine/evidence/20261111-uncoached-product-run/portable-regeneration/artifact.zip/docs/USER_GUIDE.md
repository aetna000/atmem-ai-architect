# For reviewers

1. Open the URL your operator provides. Select **Sign in**, enter your staff username and password, and complete the authenticator-app code. On first use, change your temporary password and enrol the authenticator when prompted. Ask the operator if you need access or an MFA reset.
2. Paste **synthetic or redacted text only**. Remove names, contact details, account identifiers, credentials and other customer information before pasting. The maximum is 20,480 UTF-8 bytes (some characters use more than one byte); the page shows the count.
3. Select **Suggest**. The source text immediately disappears from the page. It is processed by AWS in Sydney; no ticket or suggestion is saved by the application. If the request fails, re-paste only if you choose to try again.
4. Read the summary, topic, suggested urgency, and **uncertainty level and reason**. Medium/high uncertainty calls out missing or ambiguous information. Low uncertainty can still be wrong. Apply your team's own urgency policy and judgement. There is no accept/send/update operation; any subsequent work in your existing help desk is your own separate action.
5. Select **Clear text and suggestion** when finished. It clears both the source and result, including hiding any late response. Clearing cannot undo processing already received by AWS. Sign out when leaving. Sessions expire after about five minutes and clear the page; refreshing also loses the result and sign-in token.

If access is denied, sign in again and contact the operator if it persists. If the tool is busy or cannot provide a suggestion, review the ticket yourself or wait a few seconds and explicitly try again. Requests are not retried automatically. The tool never creates a made-up fallback suggestion.

Avoid shared screens and browser extensions that capture page content. This tool does not erase your system clipboard or control your browser/OS history, extensions or screenshots. See the operator's data-handling notes for the distinction between transient processing and durable retention.
