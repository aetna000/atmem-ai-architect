output "url" { value = aws_apigatewayv2_api.review.api_endpoint }
output "user_pool_id" { value = aws_cognito_user_pool.staff.id }
output "client_id" { value = aws_cognito_user_pool_client.browser.id }
output "functions" {
  value = { for key, unit in aws_lambda_function.unit : key => { name = unit.function_name, published_version = unit.version } }
}
