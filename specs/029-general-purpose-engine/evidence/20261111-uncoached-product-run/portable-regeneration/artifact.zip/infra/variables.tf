variable "account_id" {
  description = "Explicit target account; no accidental deployment into another account."
  type        = string
  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "Supply a twelve-digit AWS account ID."
  }
}
variable "name" {
  type    = string
  default = "ticket-review"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,30}$", var.name))
    error_message = "Use 3–31 lower-case letters, digits and hyphens."
  }
}
variable "owner" {
  description = "Operator/team accountable for access, costs and incidents."
  type        = string
  validation {
    condition     = length(trimspace(var.owner)) > 0
    error_message = "Name the responsible operator/team."
  }
}
variable "cognito_domain_prefix" {
  description = "Globally unique Cognito domain prefix; no customer or ticket data."
  type        = string
  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{2,50}$", var.cognito_domain_prefix))
    error_message = "Use a unique lower-case alphanumeric/hyphen prefix."
  }
}
variable "worker_version_override" {
  description = "Rollback only: published numeric worker version, otherwise null."
  type        = string
  default     = null
  validation {
    condition     = var.worker_version_override == null ? true : can(regex("^[1-9][0-9]*$", var.worker_version_override))
    error_message = "Use a published numeric version."
  }
}
variable "web_version_override" {
  description = "Rollback only: published numeric UI version, otherwise null."
  type        = string
  default     = null
  validation {
    condition     = var.web_version_override == null ? true : can(regex("^[1-9][0-9]*$", var.web_version_override))
    error_message = "Use a published numeric version."
  }
}
