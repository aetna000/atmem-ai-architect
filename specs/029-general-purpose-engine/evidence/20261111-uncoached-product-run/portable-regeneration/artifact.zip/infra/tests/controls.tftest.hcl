mock_provider "aws" {}

variables {
  account_id            = "123456789012"
  owner                 = "test-operator"
  cognito_domain_prefix = "synthetic-ticket-review-tests"
}

run "regional_controls" {
  command = plan
  assert {
    condition     = aws_lambda_function.unit["worker"].reserved_concurrent_executions == 5 && aws_lambda_function.unit["worker"].memory_size == 512
    error_message = "Reserve capacity for five simultaneous model requests."
  }
  assert {
    condition     = aws_apigatewayv2_route.suggest.authorization_type == "JWT" && aws_apigatewayv2_route.suggest.authorization_scopes == toset(["support-review/suggest"])
    error_message = "Suggestion route requires a scoped access token."
  }
  assert {
    condition     = aws_cognito_user_pool.staff.admin_create_user_config[0].allow_admin_create_user_only && aws_cognito_user_pool.staff.mfa_configuration == "ON"
    error_message = "Staff are operator-provisioned and must use TOTP MFA."
  }
  assert {
    condition     = aws_cognito_user_pool_client.browser.allowed_oauth_flows == toset(["code"]) && !aws_cognito_user_pool_client.browser.generate_secret && aws_cognito_user_pool_client.browser.access_token_validity == 5
    error_message = "Public browser client uses code flow and short-lived access tokens."
  }
  assert {
    condition     = jsondecode(aws_iam_role_policy.model.policy).Statement[0].Resource == "arn:aws:bedrock:ap-southeast-2::foundation-model/anthropic.claude-3-haiku-20240307-v1:0"
    error_message = "Inference is limited to one direct Sydney foundation model."
  }
  assert {
    condition     = length(jsondecode(aws_iam_role_policy.model.policy).Statement[0].Action) == 1 && jsondecode(aws_iam_role_policy.model.policy).Statement[0].Action[0] == "bedrock:InvokeModel"
    error_message = "No cross-region inference profile or other integration permission."
  }
  assert {
    condition     = jsondecode(aws_iam_role_policy.model.policy).Statement[1].Action == ["bedrock:GetModelInvocationLoggingConfiguration"]
    error_message = "Worker must check regional invocation logging before each ticket."
  }
  assert {
    condition     = length(aws_apigatewayv2_stage.live.access_log_settings) == 0 && aws_cloudwatch_log_group.runtime["worker"].retention_in_days == 1
    error_message = "No API content logging; only short-lived runtime logs."
  }
  assert {
    condition     = aws_lambda_function.unit["worker"].timeout == 30 && aws_apigatewayv2_integration.lambda["worker"].timeout_milliseconds == 29000
    error_message = "Timeouts must stay bounded."
  }
}

run "rollback_aliases" {
  command = plan
  variables {
    worker_version_override = "2"
    web_version_override    = "3"
  }
  assert {
    condition     = aws_lambda_alias.live["worker"].function_version == "2" && aws_lambda_alias.live["web"].function_version == "3"
    error_message = "Operator must be able to select previously accepted versions."
  }
}
