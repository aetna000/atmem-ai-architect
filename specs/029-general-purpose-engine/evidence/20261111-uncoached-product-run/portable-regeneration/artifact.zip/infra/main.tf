locals {
  region   = "ap-southeast-2"
  model_id = "anthropic.claude-3-haiku-20240307-v1:0"
  issuer   = "https://cognito-idp.${local.region}.amazonaws.com/${aws_cognito_user_pool.staff.id}"
  domain   = "https://${var.cognito_domain_prefix}.auth.${local.region}.amazoncognito.com"
  units = {
    worker = { handler = "app.worker.handler", memory = 512, timeout = 30, concurrency = 5 }
    web    = { handler = "app.web.handler", memory = 128, timeout = 5, concurrency = 2 }
  }
}

resource "aws_cognito_user_pool" "staff" {
  name                = "${var.name}-staff"
  deletion_protection = "ACTIVE"
  mfa_configuration   = "ON"
  user_pool_tier      = "LITE"
  admin_create_user_config { allow_admin_create_user_only = true }
  username_configuration { case_sensitive = false }
  software_token_mfa_configuration { enabled = true }
  account_recovery_setting {
    recovery_mechanism {
      name     = "admin_only"
      priority = 1
    }
  }
  password_policy {
    minimum_length                   = 16
    require_lowercase                = true
    require_uppercase                = true
    require_numbers                  = true
    require_symbols                  = true
    temporary_password_validity_days = 1
  }
  lifecycle { prevent_destroy = true }
}

resource "aws_cognito_user_group" "reviewers" {
  name         = "reviewers"
  user_pool_id = aws_cognito_user_pool.staff.id
  description  = "Operator-approved staff who may request advisory suggestions."
}

resource "aws_cognito_resource_server" "review" {
  identifier   = "support-review"
  name         = "Ticket suggestion"
  user_pool_id = aws_cognito_user_pool.staff.id
  scope {
    scope_name        = "suggest"
    scope_description = "Request a human-reviewed ticket suggestion"
  }
}

resource "aws_cognito_user_pool_client" "browser" {
  name                                 = "${var.name}-browser"
  user_pool_id                         = aws_cognito_user_pool.staff.id
  generate_secret                      = false
  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["code"]
  allowed_oauth_scopes                 = ["openid", "${aws_cognito_resource_server.review.identifier}/suggest"]
  callback_urls                        = ["${aws_apigatewayv2_api.review.api_endpoint}/"]
  logout_urls                          = ["${aws_apigatewayv2_api.review.api_endpoint}/"]
  supported_identity_providers         = ["COGNITO"]
  prevent_user_existence_errors        = "ENABLED"
  enable_token_revocation              = true
  explicit_auth_flows                  = ["ALLOW_REFRESH_TOKEN_AUTH"]
  access_token_validity                = 5
  id_token_validity                    = 5
  refresh_token_validity               = 1
  token_validity_units {
    access_token  = "minutes"
    id_token      = "minutes"
    refresh_token = "days"
  }
}

resource "aws_cognito_user_pool_domain" "staff" {
  domain                = var.cognito_domain_prefix
  user_pool_id          = aws_cognito_user_pool.staff.id
  managed_login_version = 1
}

resource "aws_apigatewayv2_api" "review" {
  name          = var.name
  protocol_type = "HTTP"
  # Regional endpoint, no global CDN, custom domain or broad CORS policy.
}

resource "aws_apigatewayv2_authorizer" "staff" {
  api_id           = aws_apigatewayv2_api.review.id
  name             = "staff-access-token"
  authorizer_type  = "JWT"
  identity_sources = ["$request.header.Authorization"]
  jwt_configuration {
    audience = [aws_cognito_user_pool_client.browser.id]
    issuer   = local.issuer
  }
}

resource "aws_cloudwatch_log_group" "runtime" {
  for_each          = local.units
  name              = "/aws/lambda/${var.name}-${each.key}"
  retention_in_days = 1
}

resource "aws_iam_role" "lambda" {
  for_each = local.units
  name     = "${var.name}-${each.key}"
  assume_role_policy = jsonencode({ Version = "2012-10-17", Statement = [{
    Effect = "Allow", Action = "sts:AssumeRole", Principal = { Service = "lambda.amazonaws.com" }
  }] })
}

resource "aws_iam_role_policy" "logs" {
  for_each = local.units
  role     = aws_iam_role.lambda[each.key].id
  policy = jsonencode({ Version = "2012-10-17", Statement = [{
    Effect   = "Allow", Action = ["logs:CreateLogStream", "logs:PutLogEvents"],
    Resource = "${aws_cloudwatch_log_group.runtime[each.key].arn}:*"
  }] })
}

resource "aws_iam_role_policy" "model" {
  role = aws_iam_role.lambda["worker"].id
  policy = jsonencode({ Version = "2012-10-17", Statement = [{
    Effect   = "Allow", Action = ["bedrock:InvokeModel"],
    Resource = "arn:aws:bedrock:${local.region}::foundation-model/${local.model_id}"
    }, {
    Effect = "Allow", Action = ["bedrock:GetModelInvocationLoggingConfiguration"], Resource = "*",
    Condition = { StringEquals = { "aws:RequestedRegion" = local.region } }
  }] })
}

resource "aws_lambda_function" "unit" {
  for_each                       = local.units
  function_name                  = "${var.name}-${each.key}"
  role                           = aws_iam_role.lambda[each.key].arn
  runtime                        = "python3.12"
  architectures                  = ["arm64"]
  handler                        = each.value.handler
  memory_size                    = each.value.memory
  timeout                        = each.value.timeout
  reserved_concurrent_executions = each.value.concurrency
  filename                       = "${path.module}/../dist/${each.key}.zip"
  source_code_hash               = filebase64sha256("${path.module}/../dist/${each.key}.zip")
  publish                        = true
  tracing_config { mode = "PassThrough" }
  environment {
    variables = merge({ CLIENT_ID = aws_cognito_user_pool_client.browser.id }, each.key == "worker" ? {
      ISSUER = local.issuer, MODEL_ID = local.model_id
      } : {
      AUTH_DOMAIN = local.domain, BASE_URL = aws_apigatewayv2_api.review.api_endpoint
    })
  }
  depends_on = [aws_iam_role_policy.logs, aws_iam_role_policy.model]
}

resource "aws_lambda_alias" "live" {
  for_each      = local.units
  name          = "live"
  function_name = aws_lambda_function.unit[each.key].function_name
  function_version = each.key == "worker" ? coalesce(var.worker_version_override, aws_lambda_function.unit[each.key].version) : coalesce(
    var.web_version_override, aws_lambda_function.unit[each.key].version
  )
}

resource "aws_apigatewayv2_integration" "lambda" {
  for_each               = local.units
  api_id                 = aws_apigatewayv2_api.review.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_alias.live[each.key].invoke_arn
  payload_format_version = "2.0"
  timeout_milliseconds   = each.key == "worker" ? 29000 : 6000
}

resource "aws_apigatewayv2_route" "suggest" {
  api_id               = aws_apigatewayv2_api.review.id
  route_key            = "POST /suggest"
  target               = "integrations/${aws_apigatewayv2_integration.lambda["worker"].id}"
  authorization_type   = "JWT"
  authorizer_id        = aws_apigatewayv2_authorizer.staff.id
  authorization_scopes = ["support-review/suggest"]
}

resource "aws_apigatewayv2_route" "web" {
  for_each           = toset(["/", "/app.js", "/core.js", "/style.css", "/config.json"])
  api_id             = aws_apigatewayv2_api.review.id
  route_key          = "GET ${each.key}"
  target             = "integrations/${aws_apigatewayv2_integration.lambda["web"].id}"
  authorization_type = "NONE"
}

resource "aws_lambda_permission" "worker" {
  statement_id   = "RegionalApiSuggestOnly"
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.unit["worker"].function_name
  qualifier      = aws_lambda_alias.live["worker"].name
  principal      = "apigateway.amazonaws.com"
  source_arn     = "${aws_apigatewayv2_api.review.execution_arn}/*/POST/suggest"
  source_account = var.account_id
}

resource "aws_lambda_permission" "web" {
  for_each       = aws_apigatewayv2_route.web
  statement_id   = "Web${substr(sha256(each.key), 0, 12)}"
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.unit["web"].function_name
  qualifier      = aws_lambda_alias.live["web"].name
  principal      = "apigateway.amazonaws.com"
  source_arn     = "${aws_apigatewayv2_api.review.execution_arn}/*/GET${each.key}"
  source_account = var.account_id
}

resource "aws_apigatewayv2_stage" "live" {
  api_id      = aws_apigatewayv2_api.review.id
  name        = "$default"
  auto_deploy = true
  default_route_settings {
    throttling_burst_limit   = 20
    throttling_rate_limit    = 10
    detailed_metrics_enabled = false
  }
  route_settings {
    route_key                = aws_apigatewayv2_route.suggest.route_key
    throttling_burst_limit   = 5
    throttling_rate_limit    = 2
    detailed_metrics_enabled = false
  }
  depends_on = [aws_lambda_permission.worker, aws_lambda_permission.web]
  # No access-log body/token/query recording or data trace configuration.
}

resource "aws_cloudwatch_metric_alarm" "worker" {
  for_each            = toset(["Errors", "Throttles"])
  alarm_name          = "${var.name}-${lower(each.key)}"
  alarm_description   = "Operator: inspect metrics only; never paste ticket text into diagnostics."
  namespace           = "AWS/Lambda"
  metric_name         = each.key
  dimensions          = { FunctionName = aws_lambda_function.unit["worker"].function_name }
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = 1
  treat_missing_data  = "notBreaching"
}

resource "aws_cloudwatch_metric_alarm" "api" {
  alarm_name          = "${var.name}-api-5xx"
  namespace           = "AWS/ApiGateway"
  metric_name         = "5xx"
  dimensions          = { ApiId = aws_apigatewayv2_api.review.id }
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = 1
  treat_missing_data  = "notBreaching"
}
