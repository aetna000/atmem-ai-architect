"""Import and exercise the built ZIP in a fresh process, using only a model fixture."""
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tests.test_handler import ENV, GOOD, event

with tempfile.TemporaryDirectory(dir=root / ".worker-tmp") as directory:
    with zipfile.ZipFile(root / "build/support-review.zip") as archive:
        archive.extractall(directory)
    # Run outside the source tree, importing the packaged handler and bundled schema/assets.
    code = '''
import json, sys
import handler
class Fixture:
    def converse(self, **kwargs):
        return {"stopReason":"end_turn","output":{"message":{"role":"assistant","content":[{"text":json.dumps(INPUT["good"])}]}}}
INPUT=json.load(sys.stdin)
handler._bedrock=lambda: Fixture()
result=handler.handler(INPUT["event"],None)
assert result["statusCode"] == 200
assert json.loads(result["body"]) == INPUT["good"]
assert handler.handler({"rawPath":"/","requestContext":{"http":{"method":"GET"}}},None)["statusCode"] == 200
print("Packaged handler/schema/assets: PASS (local Python; Bedrock fixture)")
'''
    subprocess.run([sys.executable, "-c", code], cwd=directory, env={**os.environ, **ENV},
                   input=json.dumps({"good": GOOD, "event": event()}), text=True, check=True)
