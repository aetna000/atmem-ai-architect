"""A transparent worksheet, never a guessed quote. Uses no network or credentials."""
from decimal import Decimal
import json
from pathlib import Path
import sys


def estimate(config):
    def number(value):
        if value is None:
            return None
        if isinstance(value, bool):
            raise ValueError("not a numeric quantity")
        result = Decimal(str(value))
        if not result.is_finite() or result < 0:
            raise ValueError("quantities must be finite and non-negative")
        return result

    def rate(key):
        item = config["rates"][key]
        if item["value"] is None:
            return None
        if not config.get("currency") or not item.get("source") or not item.get("as_of"):
            raise ValueError(f"rate {key} needs currency, source and quoted date")
        return number(item["value"])

    def product(*values):
        if any(v is None for v in values):
            return None
        result = Decimal(1)
        for value in values:
            result *= value
        return result

    def add(*values):
        return None if any(v is None for v in values) else sum(values, Decimal(0))

    calls = number(config["working_days"]) * number(config["tickets_per_day"])
    m = {key: number(value) for key, value in config["measurements"].items()}
    requests = add(calls, m["static_requests"])
    million = Decimal("0.000001")
    components = {
        "model_input": product(calls, m["mean_input_tokens"], million, rate("model_input_per_million")),
        "model_output": product(calls, m["mean_output_tokens"], million, rate("model_output_per_million")),
        "lambda_requests": product(requests, million, rate("lambda_per_million_requests")),
        "lambda_compute": product(add(product(calls, m["mean_lambda_seconds"], Decimal("0.25")), m["static_gb_seconds"]), rate("lambda_per_gb_second")),
        "http_api": product(requests, million, rate("http_api_per_million_requests")),
        "cognito": product(number(config["monthly_active_users"]), rate("cognito_per_mau")),
        "other": rate("other_monthly"),
    }
    return {"model_requests": str(calls), "currency": config.get("currency") or "UNKNOWN",
            "components": {k: str(v) if v is not None else "UNKNOWN" for k, v in components.items()},
            "total": str(add(*components.values())) if all(v is not None for v in components.values()) else "UNKNOWN — incomplete rates or measurements"}


if __name__ == "__main__":
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "docs/cost-inputs.json"
    print(json.dumps(estimate(json.loads(path.read_text())), indent=2))
