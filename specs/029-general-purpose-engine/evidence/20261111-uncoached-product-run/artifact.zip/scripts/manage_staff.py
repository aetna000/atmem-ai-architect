"""Operator-only Cognito administration; never packaged with the app. No SDK installation."""
import argparse
import getpass
import re


def manage(client, operation, pool, username, password=None):
    if not re.fullmatch(r"ap-southeast-2_[A-Za-z0-9]+", pool):
        raise ValueError("Only an approved Sydney user pool is supported")
    if operation == "create":
        enabled = 0
        for page in client.get_paginator("list_users").paginate(UserPoolId=pool):
            enabled += sum(bool(user.get("Enabled")) for user in page["Users"])
        if enabled >= 10:
            raise ValueError("Ten enabled staff accounts already exist; review the roster first")
        client.admin_create_user(UserPoolId=pool, Username=username,
                                 TemporaryPassword=password, MessageAction="SUPPRESS")
        try:
            client.admin_add_user_to_group(UserPoolId=pool, Username=username, GroupName="Reviewers")
        except Exception:
            client.admin_disable_user(UserPoolId=pool, Username=username)
            raise
    elif operation == "disable":
        # Disable first: if a later step fails, new sign-ins remain blocked.
        client.admin_disable_user(UserPoolId=pool, Username=username)
        client.admin_remove_user_from_group(UserPoolId=pool, Username=username, GroupName="Reviewers")
        client.admin_user_global_sign_out(UserPoolId=pool, Username=username)
    else:
        raise ValueError("Unsupported operation")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["create", "disable"])
    parser.add_argument("--pool-id", required=True)
    parser.add_argument("--username", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"ap-southeast-2_[A-Za-z0-9]+", args.pool_id):
        parser.error("Only a Sydney pool ID is accepted")
    # Imports only after explicit operator invocation; no cloud operations on import.
    import boto3
    from botocore.config import Config
    client = boto3.client("cognito-idp", region_name="ap-southeast-2",
                          config=Config(retries={"total_max_attempts": 1}))
    password = getpass.getpass("Temporary password (not saved): ") if args.operation == "create" else None
    try:
        manage(client, args.operation, args.pool_id, args.username, password)
    except Exception:
        raise SystemExit("Operation failed. Check roster/account state through the approved console; no credentials were printed.") from None
    finally:
        password = None
    print("Completed. Record the identity change through the existing staff access process.")


if __name__ == "__main__":
    main()
