"""Generate workspace-only offline CLI configuration; never contacts a registry."""
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
temporary = root / ".worker-tmp"
temporary.mkdir(exist_ok=True)
mirror = root / ".tools/providerMirror"
if not mirror.is_dir():
    raise SystemExit("Registered offline provider mirror is missing; no network fallback allowed.")
(temporary / "terraform.rc").write_text(
    "provider_installation {\n  filesystem_mirror {\n    path = " + json.dumps(str(mirror)) +
    '\n    include = ["registry.terraform.io/hashicorp/aws"]\n  }\n}\ndisable_checkpoint = true\n')
(temporary / "openssl.cnf").write_text("# Empty local OpenSSL config for sandboxed native Node.\n")
print("Prepared workspace-only Terraform/OpenSSL configuration.")
