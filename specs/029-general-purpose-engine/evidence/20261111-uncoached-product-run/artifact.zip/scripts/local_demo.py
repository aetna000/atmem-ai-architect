"""Exercise the real handler with a clearly labelled local model fixture; no sockets or AWS."""
from pathlib import Path
import json
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.handler import handler
from tests.test_handler import ENV, FakeBedrock, event

with patch.dict("os.environ", ENV), patch("app.handler._bedrock", return_value=FakeBedrock()):
    print("LOCAL FIXTURE ONLY — not a live model or AWS result", file=sys.stderr)
    print(json.dumps(handler(event(), None), indent=2))
