#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
./.tools/python scripts/prepare_local.py
export TMPDIR="$PWD/.worker-tmp"
export TF_CLI_CONFIG_FILE="$PWD/.worker-tmp/terraform.rc"
export CHECKPOINT_DISABLE=1
export OPENSSL_CONF="$PWD/.worker-tmp/openssl.cnf"
./.tools/python -m unittest discover -s tests -v
./.tools/node --test tests/review.test.mjs
./.tools/node --check app/web/app.js
./.tools/python scripts/build.py
./.tools/python scripts/packaged_smoke.py
./.tools/terraform -chdir=infra init -backend=false -input=false -lockfile=readonly
./.tools/terraform -chdir=infra fmt -check -recursive
./.tools/terraform -chdir=infra validate -no-color
./.tools/terraform -chdir=infra test -no-color
