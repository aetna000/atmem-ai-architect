"""Deterministic, dependency-free Lambda packaging. Run from the repository root."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def build():
    output = ROOT / "build"
    output.mkdir(exist_ok=True)
    target = output / "support-review.zip"
    files = {"handler.py": ROOT / "app/handler.py",
             "suggestion.schema.json": ROOT / "contracts/suggestion.schema.json"}
    files.update({"web/" + p.name: p for p in (ROOT / "app/web").iterdir() if p.is_file()})
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as package:
        for name, path in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            package.writestr(info, path.read_bytes())
    manifest = {"artifact": target.name, "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                "files": sorted(files), "runtime": "python3.12", "sdk": "AWS Lambda runtime boto3 (not vendored)"}
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    build()
