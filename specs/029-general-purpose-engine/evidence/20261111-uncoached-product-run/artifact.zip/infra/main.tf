provider "aws" {
  region              = "ap-southeast-2"
  allowed_account_ids = [var.aws_account_id]
  default_tags {
    tags = { Application = var.name, ManagedBy = "Terraform", Data = "synthetic-or-redacted-transient" }
  }
}

locals {
  region    = "ap-southeast-2"
  model_id  = "amazon.nova-lite-v1:0"
  model_arn = "arn:aws:bedrock:${local.region}::foundation-model/${local.model_id}"
  login_url = "https://${aws_cognito_user_pool_domain.staff.domain}.auth.${local.region}.amazoncognito.com"
  issuer    = "https://cognito-idp.${local.region}.amazonaws.com/${aws_cognito_user_pool.staff.id}"
}

resource "aws_cognito_user_pool" "staff" {
  name                = "${var.name}-staff"
  user_pool_tier      = "ESSENTIALS"
  deletion_protection = "ACTIVE"
  mfa_configuration   = "ON"
  software_token_mfa_configuration { enabled = true }
  username_configuration { case_sensitive = false }
  admin_create_user_config { allow_admin_create_user_only = true }
  account_recovery_setting {
    recovery_mechanism {
      name     = "admin_only"
      priority = 1
    }
  }
  password_policy {
    minimum_length                   = 14
    require_lowercase                = true
    require_uppercase                = true
    require_numbers                  = true
    require_symbols                  = true
    temporary_password_validity_days = 2
  }
}

resource "aws_cognito_user_group" "reviewers" {
  name         = "Reviewers"
  user_pool_id = aws_cognito_user_pool.staff.id
  description  = "Approved human reviewers. Operator provisions up to ten named staff."
}

resource "aws_cognito_user_pool_domain" "staff" {
  domain                = var.cognito_domain_prefix
  user_pool_id          = aws_cognito_user_pool.staff.id
  managed_login_version = 2
}

resource "aws_cognito_user_pool_client" "web" {
  name                                 = "${var.name}-browser"
  user_pool_id                         = aws_cognito_user_pool.staff.id
  generate_secret                      = false
  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["code"]
  allowed_oauth_scopes                 = ["openid"]
  supported_identity_providers         = ["COGNITO"]
  callback_urls                        = ["${aws_apigatewayv2_api.web.api_endpoint}/auth/callback"]
  logout_urls                          = ["${aws_apigatewayv2_api.web.api_endpoint}/"]
  prevent_user_existence_errors        = "ENABLED"
  enable_token_revocation              = true
  explicit_auth_flows                  = ["ALLOW_REFRESH_TOKEN_AUTH"]
  access_token_validity                = 5
  id_token_validity                    = 5
  refresh_token_validity               = 60
  token_validity_units {
    access_token  = "minutes"
    id_token      = "minutes"
    refresh_token = "minutes"
  }
}

resource "aws_cognito_managed_login_branding" "web" {
  user_pool_id                = aws_cognito_user_pool.staff.id
  client_id                   = aws_cognito_user_pool_client.web.id
  use_cognito_provided_values = true
  depends_on                  = [aws_cognito_user_pool_domain.staff]
}

resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${var.name}"
  retention_in_days = 7
}

resource "aws_cloudwatch_log_group" "api" {
  name              = "/aws/apigateway/${var.name}"
  retention_in_days = 7
}

resource "aws_iam_role" "runtime" {
  name = "${var.name}-runtime"
  assume_role_policy = jsonencode({
    Version   = "2012-10-17"
    Statement = [{ Effect = "Allow", Principal = { Service = "lambda.amazonaws.com" }, Action = "sts:AssumeRole" }]
  })
}

resource "aws_iam_role_policy" "runtime" {
  role = aws_iam_role.runtime.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      { Effect = "Allow", Action = ["bedrock:InvokeModel"], Resource = local.model_arn },
      { Effect = "Deny", Action = ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"], NotResource = local.model_arn },
      { Effect = "Allow", Action = ["logs:CreateLogStream", "logs:PutLogEvents"], Resource = "${aws_cloudwatch_log_group.lambda.arn}:*" }
    ]
  })
}

resource "aws_lambda_function" "web" {
  function_name                  = var.name
  role                           = aws_iam_role.runtime.arn
  filename                       = var.package_path
  source_code_hash               = filebase64sha256(var.package_path)
  runtime                        = "python3.12"
  architectures                  = ["arm64"]
  handler                        = "handler.handler"
  memory_size                    = 256
  timeout                        = 25
  reserved_concurrent_executions = var.service_enabled ? 5 : 0
  publish                        = true
  ephemeral_storage { size = 512 }
  logging_config {
    log_format            = "JSON"
    application_log_level = "ERROR"
    system_log_level      = "WARN"
    log_group             = aws_cloudwatch_log_group.lambda.name
  }
  environment {
    variables = {
      MODEL_ID       = local.model_id
      CLIENT_ID      = aws_cognito_user_pool_client.web.id
      COGNITO_ISSUER = local.issuer
      COGNITO_DOMAIN = local.login_url
    }
  }
  depends_on = [aws_iam_role_policy.runtime]
}

resource "aws_lambda_alias" "live" {
  name             = "live"
  function_name    = aws_lambda_function.web.function_name
  function_version = coalesce(var.live_version, aws_lambda_function.web.version)
}

resource "aws_apigatewayv2_api" "web" {
  name          = var.name
  protocol_type = "HTTP"
  # Regional execute-api endpoint; no custom CDN, CORS, tracing, caching or payload logs.
}

resource "aws_apigatewayv2_authorizer" "staff" {
  api_id           = aws_apigatewayv2_api.web.id
  name             = "staff-access-token"
  authorizer_type  = "JWT"
  identity_sources = ["$request.header.Authorization"]
  jwt_configuration {
    audience = [aws_cognito_user_pool_client.web.id]
    issuer   = local.issuer
  }
}

resource "aws_apigatewayv2_integration" "web" {
  api_id                 = aws_apigatewayv2_api.web.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_alias.live.invoke_arn
  payload_format_version = "2.0"
  timeout_milliseconds   = 29000
}

resource "aws_apigatewayv2_route" "public" {
  for_each           = toset(["GET /", "GET /auth/callback", "GET /config.json", "GET /app.js", "GET /core.js", "GET /style.css"])
  api_id             = aws_apigatewayv2_api.web.id
  route_key          = each.value
  target             = "integrations/${aws_apigatewayv2_integration.web.id}"
  authorization_type = "NONE"
}

resource "aws_apigatewayv2_route" "suggest" {
  api_id             = aws_apigatewayv2_api.web.id
  route_key          = "POST /api/suggest"
  target             = "integrations/${aws_apigatewayv2_integration.web.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.staff.id
}

resource "aws_apigatewayv2_stage" "live" {
  api_id      = aws_apigatewayv2_api.web.id
  name        = "$default"
  auto_deploy = true
  default_route_settings {
    throttling_burst_limit = 20
    throttling_rate_limit  = 10
  }
  route_settings {
    route_key              = aws_apigatewayv2_route.suggest.route_key
    throttling_burst_limit = 5
    throttling_rate_limit  = 2
  }
  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api.arn
    # No body, query, Authorization header, user identifiers or model output.
    format = jsonencode({ requestId = "$context.requestId", status = "$context.status", route = "$context.routeKey", latency = "$context.responseLatency", integrationStatus = "$context.integration.status" })
  }
}

resource "aws_lambda_permission" "gateway" {
  statement_id   = "RegionalGatewayOnly"
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.web.function_name
  qualifier      = aws_lambda_alias.live.name
  principal      = "apigateway.amazonaws.com"
  source_arn     = "${aws_apigatewayv2_api.web.execution_arn}/*/*"
  source_account = var.aws_account_id
}

resource "aws_cloudwatch_metric_alarm" "api_failures" {
  alarm_name          = "${var.name}-api-failures"
  alarm_description   = "Check API metadata and Bedrock quotas; never enable request body logging. No notification destination is configured."
  namespace           = "AWS/ApiGateway"
  metric_name         = "5xx"
  dimensions          = { ApiId = aws_apigatewayv2_api.web.id, Stage = aws_apigatewayv2_stage.live.name }
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = 3
  evaluation_periods  = 1
  period              = 300
  statistic           = "Sum"
  treat_missing_data  = "notBreaching"
}

resource "aws_cloudwatch_metric_alarm" "throttles" {
  alarm_name          = "${var.name}-lambda-throttles"
  namespace           = "AWS/Lambda"
  metric_name         = "Throttles"
  dimensions          = { FunctionName = aws_lambda_function.web.function_name }
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = 1
  evaluation_periods  = 1
  period              = 300
  statistic           = "Sum"
  treat_missing_data  = "notBreaching"
}
