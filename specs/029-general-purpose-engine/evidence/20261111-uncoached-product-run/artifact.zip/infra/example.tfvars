# Copy to operator.auto.tfvars and replace with approved identifiers. Never add credentials.
aws_account_id        = "123456789012"
cognito_domain_prefix = "replace-with-team-unique-prefix"
