variable "aws_account_id" {
  description = "Approved deployment account; also constrains the provider. No credentials belong here."
  type        = string
  validation {
    condition     = can(regex("^[0-9]{12}$", var.aws_account_id))
    error_message = "Use the approved 12-digit AWS account ID."
  }
}

variable "name" {
  type    = string
  default = "support-review"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,29}$", var.name))
    error_message = "Use 3–30 lowercase letters, numbers and hyphens, starting with a letter."
  }
}

variable "cognito_domain_prefix" {
  description = "Unique Cognito domain prefix in Sydney, e.g. team-support-review-123456."
  type        = string
  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{2,50}$", var.cognito_domain_prefix))
    error_message = "Use a unique 3–51 character lowercase Cognito prefix."
  }
}

variable "package_path" {
  type    = string
  default = "../build/support-review.zip"
}

variable "live_version" {
  description = "Null promotes the built version. To roll back, use a previously recorded published numeric version."
  type        = string
  default     = null
  nullable    = true
  validation {
    condition     = var.live_version == null ? true : can(regex("^[1-9][0-9]*$", var.live_version))
    error_message = "A rollback must reference a numeric published Lambda version."
  }
}

variable "service_enabled" {
  description = "Emergency stop: false disables Lambda concurrency, including the static UI."
  type        = bool
  default     = true
}
