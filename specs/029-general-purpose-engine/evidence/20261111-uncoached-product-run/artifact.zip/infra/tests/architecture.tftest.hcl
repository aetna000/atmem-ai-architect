mock_provider "aws" {
  mock_resource "aws_apigatewayv2_api" {
    defaults = {
      id            = "testapi"
      api_endpoint  = "https://testapi.execute-api.ap-southeast-2.amazonaws.com"
      execution_arn = "arn:aws:execute-api:ap-southeast-2:123456789012:testapi"
    }
  }
  mock_resource "aws_cognito_user_pool" {
    defaults = {
      id  = "ap-southeast-2_test"
      arn = "arn:aws:cognito-idp:ap-southeast-2:123456789012:userpool/ap-southeast-2_test"
    }
  }
  mock_resource "aws_cloudwatch_log_group" {
    defaults = { arn = "arn:aws:logs:ap-southeast-2:123456789012:log-group:test" }
  }
  mock_resource "aws_iam_role" {
    defaults = { arn = "arn:aws:iam::123456789012:role/support-review-runtime" }
  }
  mock_resource "aws_lambda_function" {
    defaults = { arn = "arn:aws:lambda:ap-southeast-2:123456789012:function:support-review", version = "1" }
  }
  mock_resource "aws_lambda_alias" {
    defaults = { invoke_arn = "arn:aws:apigateway:ap-southeast-2:lambda:path/2015-03-31/functions/arn:aws:lambda:ap-southeast-2:123456789012:function:support-review:live/invocations" }
  }
}

variables {
  aws_account_id        = "123456789012"
  cognito_domain_prefix = "test-support-review"
}

run "regional_review_boundary" {
  # apply here operates ONLY against mock_provider, never an AWS endpoint.
  command = apply

  assert {
    condition     = aws_apigatewayv2_route.suggest.authorization_type == "JWT" && aws_apigatewayv2_route.suggest.authorizer_id == aws_apigatewayv2_authorizer.staff.id
    error_message = "Suggestion requests must be protected by the JWT authorizer."
  }
  assert {
    condition     = aws_lambda_function.web.reserved_concurrent_executions == 5 && aws_lambda_function.web.memory_size == 256 && aws_lambda_function.web.timeout == 25
    error_message = "Preserve the modest initial footprint and five-request ceiling."
  }
  assert {
    condition     = aws_lambda_function.web.environment[0].variables.MODEL_ID == "amazon.nova-lite-v1:0" && local.region == "ap-southeast-2"
    error_message = "Use direct Sydney inference, never a cross-region profile."
  }
  assert {
    condition     = jsondecode(aws_iam_role_policy.runtime.policy).Statement[0].Resource == "arn:aws:bedrock:ap-southeast-2::foundation-model/amazon.nova-lite-v1:0" && length(jsondecode(aws_iam_role_policy.runtime.policy).Statement) == 3
    error_message = "Runtime rights must stay limited to the selected model and metadata logs."
  }
  assert {
    condition     = aws_cognito_user_pool.staff.admin_create_user_config[0].allow_admin_create_user_only && aws_cognito_user_pool.staff.mfa_configuration == "ON" && !aws_cognito_user_pool_client.web.generate_secret && aws_cognito_user_pool_client.web.access_token_validity == 5
    error_message = "Invite-only accounts, MFA, public PKCE client and short access tokens are required."
  }
  assert {
    condition     = toset(keys(jsondecode(aws_apigatewayv2_stage.live.access_log_settings[0].format))) == toset(["requestId", "status", "route", "latency", "integrationStatus"])
    error_message = "Logs must not contain payload, query, identity or authorization data."
  }
}

run "emergency_stop" {
  command = plan
  variables { service_enabled = false }
  assert {
    condition     = aws_lambda_function.web.reserved_concurrent_executions == 0
    error_message = "Emergency stop must halt new Lambda invocations."
  }
}

run "rollback_alias" {
  command = plan
  variables { live_version = "7" }
  assert {
    condition     = aws_lambda_alias.live.function_version == "7"
    error_message = "Rollback must move the API alias to the recorded published version."
  }
}
