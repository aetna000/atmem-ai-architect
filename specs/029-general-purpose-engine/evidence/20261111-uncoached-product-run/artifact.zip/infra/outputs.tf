output "app_url" { value = "${aws_apigatewayv2_api.web.api_endpoint}/" }
output "user_pool_id" { value = aws_cognito_user_pool.staff.id }
output "client_id" { value = aws_cognito_user_pool_client.web.id }
output "function_name" { value = aws_lambda_function.web.function_name }
output "published_version" { value = aws_lambda_function.web.version }
output "live_version" { value = aws_lambda_alias.live.function_version }
output "region" { value = local.region }
output "model_id" { value = local.model_id }
