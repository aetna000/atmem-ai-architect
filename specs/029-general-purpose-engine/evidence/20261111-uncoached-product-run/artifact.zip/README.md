# Internal support review

A small AWS tool for ten signed-in reviewers. Paste synthetic or redacted text, receive a short summary, topic, suggested urgency and explicit uncertainty, then review or clear it. There is no help desk connection, reply sender, customer record API, ticket database or suggestion history.

The implementation is in [app](app/), AWS resources in [infra](infra/), and the response contract in [contracts/suggestion.schema.json](contracts/suggestion.schema.json). The frozen `project-context.json` and supplied tools/skill are unchanged.

Start with the [operator guide](docs/OPERATIONS.md). Read [architecture and residency](docs/ARCHITECTURE.md), [costs and sources](docs/COSTS.md), and [verification and release checks](docs/VERIFICATION.md) before release. No cloud deployment or cloud account access was performed for this delivery. Completion of local work is not user acceptance.

## Run locally without AWS or downloads

From the repository root:

```sh
./.tools/python -m unittest discover -s tests -v
OPENSSL_CONF="$PWD/.worker-tmp/openssl.cnf" ./.tools/node --test tests/review.test.mjs
./.tools/python scripts/local_demo.py
./.tools/python scripts/build.py
./.tools/python scripts/costs.py
```

The demo invokes the real handler with a **fake model** and a synthetic ticket. It prints JSON; it does not launch a browser server. The browser app runs behind the AWS HTTP API after deployment. No live Bedrock quality, browser OAuth, cloud load or residency claim is established by this demo.

For offline Terraform validation use the setup in the operator guide. Only the supplied offline AWS provider is used. There are no network-installed packages or JavaScript dependencies. The build packages code, assets and the response schema into `build/support-review.zip` and records a SHA-256 manifest.
