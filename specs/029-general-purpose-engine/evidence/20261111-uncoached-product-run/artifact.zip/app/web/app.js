import {ReviewSession, ticketBytes} from "/core.js";

const $ = id => document.getElementById(id);
let token = null;
let config = null;
let expiryTimer = null;
let expiresAt = 0;
const session = new ReviewSession({onChange: state => {
  $("status").textContent = state.message;
  $("suggest").disabled = state.busy || !token;
  $("ticket").disabled = state.busy || !token;
  $("suggestion").hidden = !state.suggestion;
  for (const key of ["summary", "topic", "urgency"]) $(key).textContent = state.suggestion?.[key] ?? "";
  const uncertainty = state.suggestion?.uncertainty;
  $("uncertainty").textContent = uncertainty ? `Uncertainty: ${uncertainty.level.toUpperCase()} — ${uncertainty.reason}` : "";
  $("uncertainty").dataset.level = uncertainty?.level ?? "";
}});

function clear() {
  $("ticket").value = "";
  $("byte-count").textContent = "0 / 20,480 bytes";
  session.clear();
}
function signedOut(message) {
  token = null;
  expiresAt = 0;
  clearTimeout(expiryTimer);
  clear();
  $("ticket").disabled = true;
  $("suggest").disabled = true;
  $("signin").hidden = false;
  $("signin").disabled = !config;
  $("signout").hidden = true;
  $("identity").textContent = message;
}
function base64url(bytes) {
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

$("ticket").addEventListener("input", () => { $("byte-count").textContent = `${ticketBytes($("ticket").value).toLocaleString("en-AU")} / 20,480 bytes`; });
$("clear").addEventListener("click", clear);
$("review-form").addEventListener("submit", async event => {
  event.preventDefault();
  if (!token || Date.now() >= expiresAt) { signedOut("Session expired. Sign in again."); return; }
  let ticket = $("ticket").value;
  clear();
  await session.suggest(ticket, token);
  ticket = null;
});
$("signin").addEventListener("click", async () => {
  try {
    const verifier = base64url(crypto.getRandomValues(new Uint8Array(32)));
    const state = base64url(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = base64url(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
    sessionStorage.setItem("review.pkce", JSON.stringify({verifier, state, created: Date.now()}));
    const params = new URLSearchParams({client_id: config.clientId, response_type: "code", scope: "openid",
      redirect_uri: `${location.origin}/auth/callback`, state, code_challenge: challenge, code_challenge_method: "S256"});
    location.assign(`${config.domain}/oauth2/authorize?${params}`);
  } catch { signedOut("Sign-in could not start. Check browser storage and try again."); }
});
$("signout").addEventListener("click", () => {
  signedOut("Signed out.");
  sessionStorage.removeItem("review.pkce");
  const params = new URLSearchParams({client_id: config.clientId, logout_uri: `${location.origin}/`});
  location.assign(`${config.domain}/logout?${params}`);
});

window.addEventListener("pagehide", () => {
  token = null;
  clearTimeout(expiryTimer);
  clear();
});
window.addEventListener("pageshow", event => { if (event.persisted) signedOut("Sign in to review tickets."); });

async function start() {
  const query = new URLSearchParams(location.search);
  history.replaceState(null, "", "/"); // promptly remove OAuth codes/errors from the address bar
  try {
    const result = await fetch("/config.json", {cache: "no-store", credentials: "omit"});
    if (!result.ok) throw new Error("configuration");
    config = await result.json();
    signedOut("Sign in to review tickets.");
    if (!query.has("code") && !query.has("error")) return;
    const pending = JSON.parse(sessionStorage.getItem("review.pkce") || "null");
    sessionStorage.removeItem("review.pkce");
    if (query.has("error") || !pending || pending.state !== query.get("state") ||
        Date.now() - pending.created > 600000 || pending.created > Date.now()) throw new Error("state");
    const body = new URLSearchParams({grant_type: "authorization_code", client_id: config.clientId,
      code: query.get("code"), redirect_uri: `${location.origin}/auth/callback`, code_verifier: pending.verifier});
    const exchange = await fetch(`${config.domain}/oauth2/token`, {method: "POST", cache: "no-store", credentials: "omit",
      headers: {"content-type": "application/x-www-form-urlencoded"}, body});
    if (!exchange.ok) throw new Error("exchange");
    const tokens = await exchange.json();
    if (typeof tokens.access_token !== "string" || !Number.isFinite(tokens.expires_in) || tokens.expires_in <= 0) throw new Error("token");
    token = tokens.access_token; // never persist access, ID or refresh tokens
    const lifetime = Math.min(tokens.expires_in, 300) * 1000;
    expiresAt = Date.now() + lifetime;
    expiryTimer = setTimeout(() => signedOut("Session expired. Sign in again."), lifetime);
    $("signin").hidden = true;
    $("signout").hidden = false;
    $("ticket").disabled = false;
    $("suggest").disabled = false;
    $("identity").textContent = "Signed in · 5-minute session";
    $("ticket").focus();
  } catch { signedOut("Sign-in is unavailable or expired. Try signing in again."); }
}
start();
