// Pure browser logic also exercised by the native Node test runner.
const exactKeys = (value, keys) => value && typeof value === "object" && !Array.isArray(value) &&
  Object.keys(value).sort().join(",") === [...keys].sort().join(",");
const text = (value, max) => typeof value === "string" && value.trim().length > 0 &&
  [...value].length <= max && !/[\u0000-\u0008\u000b-\u001f]/u.test(value);
export const ticketBytes = value => new TextEncoder().encode(value).length;
export function validateSuggestion(value) {
  if (!exactKeys(value, ["summary", "topic", "urgency", "uncertainty"]) ||
      !text(value.summary, 600) || !["account", "billing", "technical", "feedback", "other"].includes(value.topic) ||
      !["low", "normal", "high", "critical"].includes(value.urgency) ||
      !exactKeys(value.uncertainty, ["level", "reason"]) ||
      !["low", "medium", "high"].includes(value.uncertainty.level) || !text(value.uncertainty.reason, 300)) {
    throw new Error("Invalid suggestion");
  }
  return value;
}

export class ReviewSession {
  constructor({fetcher = fetch, onChange = () => {}} = {}) {
    this.fetcher = fetcher;
    this.onChange = onChange;
    this.sequence = 0;
    this.abort = null;
    this.timer = null;
    this.state = {busy: false, suggestion: null, message: ""};
  }
  emit(state) { this.state = state; this.onChange(state); }
  clear() {
    this.sequence += 1;
    this.abort?.abort();
    this.abort = null;
    clearTimeout(this.timer);
    this.emit({busy: false, suggestion: null, message: "Cleared. No suggestion is saved."});
  }
  async suggest(ticket, token) {
    this.clear();
    if (!token || !ticket.trim() || ticket.includes("\0") || ticketBytes(ticket) > 20480) {
      this.emit({busy: false, suggestion: null, message: "Sign in and enter non-empty redacted text up to 20 KiB."});
      return;
    }
    const sequence = this.sequence;
    const controller = new AbortController();
    this.abort = controller;
    this.timer = setTimeout(() => controller.abort(), 28000);
    this.emit({busy: true, suggestion: null, message: "Preparing a suggestion for your review…"});
    try {
      const result = await this.fetcher("/api/suggest", {
        method: "POST", cache: "no-store", credentials: "omit", signal: controller.signal,
        headers: {"content-type": "application/json", authorization: `Bearer ${token}`},
        body: JSON.stringify({ticket}),
      });
      ticket = null;
      if (sequence !== this.sequence) return;
      if (!result.ok) {
        const message = result.status === 401 || result.status === 403 ? "Sign in again or ask the operator for Reviewer access." :
          result.status === 429 ? "The service is busy. Wait before trying again." :
          result.status === 400 || result.status === 413 ? "The input was rejected. Use redacted text up to 20 KiB." :
          "No suggestion is available. Review manually or try again later.";
        this.emit({busy: false, suggestion: null, message});
        return;
      }
      const suggestion = validateSuggestion(await result.json());
      if (sequence !== this.sequence) return;
      this.emit({busy: false, suggestion, message: "Suggestion ready. Human review is required."});
    } catch {
      if (sequence === this.sequence) this.emit({busy: false, suggestion: null,
        message: "No suggestion is available. The request may have finished. Review manually or try again later."});
    } finally {
      ticket = null;
      if (sequence === this.sequence) { clearTimeout(this.timer); this.abort = null; }
    }
  }
}
