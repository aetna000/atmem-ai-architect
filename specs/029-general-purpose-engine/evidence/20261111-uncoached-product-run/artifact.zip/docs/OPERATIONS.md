# Operator guide

## What the reviewer does

1. Open the app URL, sign in with the issued username/password, and enrol/use the authenticator when prompted.
2. Paste **synthetic or redacted** text only, up to 20 KiB. Remove names, contact details, customer identifiers, secrets and other personal data first. This tool is not an automatic redactor.
3. Select **Suggest triage**. The pasted text clears immediately. Review the short summary, topic, suggested urgency and uncertainty reason. A high-uncertainty banner means evidence is weak or ambiguous; even low uncertainty requires your judgement.
4. Select **Clear text & suggestion** when finished. It also cancels the browser wait and prevents a late response appearing. A request already running in AWS can finish. No suggestion or ticket history can be recovered.
5. Continue normal work in the existing help desk yourself. This tool never connects to it. Sign out when finished; the app also clears at its five-minute access-token expiry.

If the tool is busy, denied, unavailable or gives a questionable suggestion, use normal human triage. It has no automatic escalation, fallback urgency, customer reply or update action. Do not screenshot/copy ticket text into fault reports.

## Local build and checks (no AWS)

Use the registered tools from the repository root. No package installation is needed. The helper creates local temporary configuration inside the workspace; it does not edit `.tools` or supplied inputs.

```sh
./.tools/python scripts/prepare_local.py
./scripts/check.sh
./.tools/python scripts/local_demo.py
./.tools/python scripts/costs.py
```

`check.sh` runs native Python and Node checks, builds the ZIP, imports the packaged handler, then initializes Terraform **only from the offline mirror**, validates it and runs mocked infrastructure tests. Terraform's mocked `apply` in the test file is in-memory simulation, not deployment. The offline provider lock contains only a locally calculated `darwin_arm64` hash and was installed unauthenticated; verify provider provenance/checksums through the organisation's approved process before release. Another OS needs an approved offline mirror/checksums for that OS; do not fall back to a registry in this environment.

The local fixture demo calls the real handler but substitutes Bedrock and auth claims. It prints the HTTP-style JSON result. Python 3.14.6 and Node 26.5.0 were available locally; the deployed target is Python 3.12. No live AWS behavior or real browser sign-in is proven by these checks.

## Before first deployment

The account/service owner must complete [the release checklist](VERIFICATION.md). In particular: confirm the exact direct model works in Sydney with the Python 3.12 runtime's SDK, inspect Bedrock invocation logging (off), review existing body capture/log exports, check Cognito MFA onboarding and approve cost/residency notes. App sign-in is internet-accessible; it is not network-private ingress. Authentication and server group authorization provide the internal-use boundary. If private network ingress is required, redesign before release.

Name a primary and backup operator; obtain least-privilege deployment/identity-administration roles through existing account processes. Do not give staff AWS console/IAM access just to use this app. Application IAM cannot administer Cognito or access other models, customer stores, email or help desk systems. Keep the admin roster at ten approved named reviewers; the ten-user limit is an operator policy, not an automatic Cognito cap. No identities/passwords are created by Terraform.

Decide protected Terraform state ownership before use. This configuration defaults to local state to avoid claiming an existing backend. Store it on an approved encrypted Australian operator system with access control and backup, or configure an approved regional remote backend with locking before the first apply. There is no shared-state locking with a bare local backend: only one operator may run Terraform. Do not commit state, plans, passwords or personal `.tfvars`. State does not contain ticket text but is still sensitive. Review planned IAM/Cognito replacements; the pool has deletion protection.

## Deployment procedure (instructions only; not executed here)

Run in an approved AWS-capable operator environment, after release checks. Continue to use the registered Terraform/provider installation for that environment. Authenticate through the organisation's established AWS profile/role process; never put keys in this repository. The provider pins the account supplied below and the Sydney region.

1. Build and run checks. Record the source revision and save `build/manifest.json`, ZIP and the previous live version in an approved Australian artifact store. Keep versioned artifacts for rollback; never put ticket examples into release bundles.
2. Copy `infra/example.tfvars` to `infra/operator.auto.tfvars`. Replace the example account ID and pick a unique Cognito domain prefix. No credentials go in this file. Set `service_enabled = false` for the first infrastructure creation so unaccepted code cannot process tickets.
3. Review a plan, then apply that exact reviewed plan. These commands access AWS; they have **not** been run by this job:

```sh
export TF_CLI_CONFIG_FILE="$PWD/.worker-tmp/terraform.rc"
export CHECKPOINT_DISABLE=1
export TMPDIR="$PWD/.worker-tmp"
./.tools/terraform -chdir=infra plan -out=release.tfplan
./.tools/terraform -chdir=infra apply release.tfplan
./.tools/terraform -chdir=infra output
```

4. Record `app_url`, `user_pool_id`, `client_id`, `published_version` and `live_version`. Configure named users using the approved helper below. Keep emergency shutdown in place until ready for synthetic smoke testing; temporarily enabling for tests exposes only public assets and the authenticated/group-protected route. The first lambda build creates a published version and API `live` alias. Managed-login branding is separately created for the client.
5. Set `service_enabled = true`, review/apply a new plan, and execute the synthetic release checklist including five concurrent calls and denied-user tests. Restrict group membership to test operators until accepted. Confirm no input/output in logs, then let the service owner record acceptance and provision the ten real reviewers. Local completion alone is not acceptance.

CloudWatch alarms are visible in the console but have no email/chat notification actions. Select an approved destination and operator rota before relying on unattended alerts; do not assume anyone is notified. Any overseas notification route must carry metadata only and receive its own residency review.

## Add/remove a reviewer

Use `scripts/manage_staff.py` in the approved AWS-capable environment, with an AWS SDK already supplied by that environment. This job did **not** install or run that SDK. The helper prompts for a temporary password without echoing it, suppresses email/SMS invitations and adds the exact `Reviewers` group. Use a password meeting the policy: at least 14 characters with upper/lowercase, digit and symbol. The user changes it at first managed-login sign-in and enrols TOTP. Distribute credentials through the existing approved channel; do not add them to chat logs, Terraform or command-line arguments.

```sh
python3 scripts/manage_staff.py create --pool-id YOUR_SYDNEY_POOL --username staff01
python3 scripts/manage_staff.py disable --pool-id YOUR_SYDNEY_POOL --username staff01
```

The helper checks for the Sydney pool prefix. Creation checks the current enabled account count and refuses at ten, but this is **not atomic**: use one identity operator at a time. Group-add failure leaves the new user disabled for recovery; fix the cause before re-enabling. Username records are retained for audit/recovery when disabled. Remove group membership, sign out globally and disable leavers. Already-issued JWTs can still be accepted until the five-minute token expiry and gateway clock tolerance; use the service-wide emergency stop for immediate suspension. Do not promise instant token revocation through API Gateway.

Password/MFA recovery is admin-only. Verify the person's identity using the existing staff process, then use Cognito administrative password/MFA recovery through the operator console or approved identity procedure. Do not disable pool-wide MFA to solve one user's problem. Test first-use TOTP enrolment and recovery before admitting staff. Check the roster monthly; use separate named accounts, never a shared login.

## Daily and monthly maintenance

Daily: check the two CloudWatch alarms, HTTP 5xx/latency, Lambda throttles/duration and AWS service health. A 503 can indicate model refusal, invalid output, timeout, regional quota or permission problems; investigate metadata and a fresh synthetic reproduction. Do not enable payload/debug/Bedrock invocation logging for diagnosis. A sign-in denial needs group/issuer/client/expiry checks by the operator, not weaker authorization.

Monthly: check billed Bedrock tokens, API/Lambda request volume, log volumes and current Sydney prices; update the cost worksheet with sources/dates and review manual retry frequency. Check regional model deprecations, Lambda runtime/SDK patches, staff access and whether current latency/concurrency is sufficient. Test a build/rollback with synthetic data after model/prompt/runtime/provider changes. Preserve seven-day metadata retention and inspect log subscriptions/exports for unwanted destinations. Model-output failures are intentionally not logged; reproduce with synthetic tickets and compare model/schema offline.

## Emergency stop and rollback

For an immediate service stop in an approved AWS CLI environment (not executed here):

```sh
aws lambda put-function-concurrency --region ap-southeast-2 --function-name YOUR_FUNCTION --reserved-concurrent-executions 0
```

This stops new invocations, including static assets; running requests can finish within their timeouts. Then set `service_enabled = false` in Terraform and review/apply to reconcile drift. Leave it off until the cause and privacy implications are understood. Disabling a single account does not invalidate already-issued JWTs immediately.

For a code/prompt rollback, use a previously recorded **numeric published version**, which includes its matching web assets/schema/environment. Set `live_version = "PREVIOUS_NUMBER"`, keep `service_enabled = true` only if safe, and review/apply a plan. The API integration always targets alias `live`, so no client URL change is needed. Previous published versions are retained by this configuration; independently deleting them destroys that rollback path. Re-test sign-in, synthetic input and Clear. No ticket records need restoration. This alias rollback does not undo Cognito, IAM, API or logging configuration: restore the reviewed source/config and apply separately for those, paying attention to destructive pool changes. Later remove `live_version` only when deliberately promoting the current build.

Do not run `terraform destroy` as a routine rollback: it removes the service and requires deliberately handling protected identity data. Retirement is a separate owner decision; keep the existing help desk untouched.
