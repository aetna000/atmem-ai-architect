import unittest
from unittest.mock import Mock

from scripts.manage_staff import manage


class StaffTests(unittest.TestCase):
    def setUp(self):
        self.client = Mock()
        self.client.get_paginator.return_value.paginate.return_value = [{"Users": []}]
        self.pool = "ap-southeast-2_TestPool"

    def test_create_suppresses_invites_and_assigns_only_reviewers(self):
        manage(self.client, "create", self.pool, "synthetic-staff", "temporary-fixture")
        self.client.admin_create_user.assert_called_once_with(UserPoolId=self.pool, Username="synthetic-staff",
            TemporaryPassword="temporary-fixture", MessageAction="SUPPRESS")
        self.client.admin_add_user_to_group.assert_called_once_with(UserPoolId=self.pool, Username="synthetic-staff", GroupName="Reviewers")

    def test_roster_limit_and_region_reject_before_writes(self):
        self.client.get_paginator.return_value.paginate.return_value = [{"Users": [{"Enabled": True}] * 10}]
        with self.assertRaises(ValueError):
            manage(self.client, "create", self.pool, "staff", "fixture")
        with self.assertRaises(ValueError):
            manage(self.client, "create", "us-east-1_pool", "staff", "fixture")
        self.client.admin_create_user.assert_not_called()

    def test_group_failure_disables_partial_account(self):
        self.client.admin_add_user_to_group.side_effect = RuntimeError("simulated group failure")
        with self.assertRaises(RuntimeError):
            manage(self.client, "create", self.pool, "staff", "fixture")
        self.client.admin_disable_user.assert_called_once_with(UserPoolId=self.pool, Username="staff")

    def test_disable_blocks_signin_before_other_cleanup(self):
        self.client.admin_remove_user_from_group.side_effect = RuntimeError("simulated cleanup failure")
        with self.assertRaises(RuntimeError):
            manage(self.client, "disable", self.pool, "staff")
        self.assertEqual(self.client.method_calls[0][0], "admin_disable_user")
