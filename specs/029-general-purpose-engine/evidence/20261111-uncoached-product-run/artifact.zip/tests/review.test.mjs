import test from "node:test";
import assert from "node:assert/strict";
import {ReviewSession, ticketBytes, validateSuggestion} from "../app/web/core.js";

const good = {summary: "A synthetic login failure was reported.", topic: "account", urgency: "normal",
  uncertainty: {level: "high", reason: "The impact is unknown."}};
const ok = value => ({ok: true, status: 200, json: async () => value});
const deferred = () => { let resolve; const promise = new Promise(r => resolve = r); return {promise, resolve}; };

test("UTF-8 boundary and malformed input never reach API", async () => {
  assert.equal(ticketBytes("é".repeat(10240)), 20480);
  let calls = 0;
  const session = new ReviewSession({fetcher: async () => { calls++; return ok(good); }});
  for (const [ticket, token] of [["é".repeat(10241), "t"], [" ", "t"], ["a\0b", "t"], ["valid", null]]) {
    await session.suggest(ticket, token);
    assert.equal(session.state.suggestion, null);
  }
  assert.equal(calls, 0);
  await session.suggest("é".repeat(10240), "t");
  assert.equal(calls, 1);
});

test("high uncertainty remains visible with a reason", async () => {
  const session = new ReviewSession({fetcher: async (url, options) => {
    assert.equal(url, "/api/suggest");
    assert.equal(options.cache, "no-store");
    assert.equal(options.credentials, "omit");
    assert.equal(options.headers.authorization, "Bearer t");
    return ok(good);
  }});
  await session.suggest("synthetic", "t");
  assert.equal(session.state.suggestion.uncertainty.level, "high");
  assert.match(session.state.suggestion.uncertainty.reason, /unknown/);
  session.clear();
  assert.equal(session.state.suggestion, null);
});

test("clear aborts pending fetch and ignores late success", async () => {
  const pending = deferred();
  let signal;
  const session = new ReviewSession({fetcher: async (_url, options) => { signal = options.signal; return pending.promise; }});
  const work = session.suggest("synthetic", "t");
  session.clear();
  assert.equal(signal.aborted, true);
  pending.resolve(ok(good)); // simulate a transport that completes despite cancellation
  await work;
  assert.equal(session.state.suggestion, null);
  assert.match(session.state.message, /Cleared/);
});

test("clear during JSON decoding cannot resurrect a suggestion", async () => {
  const pending = deferred();
  const session = new ReviewSession({fetcher: async () => ({ok: true, json: () => pending.promise})});
  const work = session.suggest("synthetic", "t");
  await Promise.resolve();
  session.clear();
  pending.resolve(good);
  await work;
  assert.equal(session.state.suggestion, null);
});

test("failure clears prior output, no retries, no raw server errors", async () => {
  let response = ok(good);
  let calls = 0;
  const session = new ReviewSession({fetcher: async () => { calls++; return response; }});
  await session.suggest("synthetic", "t");
  for (const status of [400, 401, 403, 413, 429, 502, 503, 504]) {
    response = {ok: false, status, json: async () => ({message: "PRIVATE PROVIDER DETAIL"})};
    await session.suggest("synthetic", "t");
    assert.equal(session.state.suggestion, null);
    assert.doesNotMatch(session.state.message, /PRIVATE/);
  }
  assert.equal(calls, 9);
});

test("client validates response shape and displays model text as data", () => {
  assert.equal(validateSuggestion({...good, summary: "<script>unsafe()</script>"}).summary, "<script>unsafe()</script>");
  for (const value of [null, [], {}, {...good, extra: true}, {...good, urgency: "urgent"},
    {...good, summary: "x".repeat(601)}, {...good, uncertainty: {level: "high", reason: ""}}]) {
    assert.throws(() => validateSuggestion(value));
  }
});

test("malformed JSON or invalid model response cannot produce a suggestion", async () => {
  for (const response of [ok({reply: "sent"}), {ok: true, json: async () => { throw new Error("invalid JSON"); }}]) {
    const session = new ReviewSession({fetcher: async () => response});
    await session.suggest("synthetic", "t");
    assert.equal(session.state.suggestion, null);
    assert.equal(session.state.busy, false);
  }
});
