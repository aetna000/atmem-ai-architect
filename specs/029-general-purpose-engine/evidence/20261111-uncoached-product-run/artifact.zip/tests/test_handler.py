import base64
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stderr, redirect_stdout
import copy
import io
import json
import os
from pathlib import Path
import sys
import time
import types
import unittest
from unittest.mock import patch

from app import handler as app

ENV = {"COGNITO_ISSUER": "https://cognito-idp.ap-southeast-2.amazonaws.com/ap-southeast-2_test",
       "CLIENT_ID": "testclient", "AWS_REGION": "ap-southeast-2", "MODEL_ID": "amazon.nova-lite-v1:0",
       "COGNITO_DOMAIN": "https://test.auth.ap-southeast-2.amazoncognito.com"}
GOOD = {"summary": "A redacted user reports a login failure.", "topic": "account", "urgency": "normal",
        "uncertainty": {"level": "high", "reason": "Impact and affected user count are missing."}}


def event(ticket="Synthetic user cannot sign in."):
    return {"version": "2.0", "rawPath": "/api/suggest", "headers": {"content-type": "application/json"},
            "body": json.dumps({"ticket": ticket}), "isBase64Encoded": False,
            "requestContext": {"http": {"method": "POST"}, "authorizer": {"jwt": {"claims": {
                "iss": ENV["COGNITO_ISSUER"], "client_id": ENV["CLIENT_ID"], "token_use": "access",
                "sub": "reviewer-1", "exp": str(int(time.time()) + 300), "cognito:groups": '["Reviewers"]'}}}}}


class FakeBedrock:
    def __init__(self, value=None, failure=None, stop="end_turn"):
        self.value = value if value is not None else json.dumps(GOOD)
        self.failure = failure
        self.stop = stop
        self.calls = []

    def converse(self, **kwargs):
        self.calls.append(kwargs)
        if self.failure:
            raise self.failure
        return {"stopReason": self.stop, "output": {"message": {"role": "assistant", "content": [{"text": self.value}]}}}


class HandlerTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, ENV)
        self.env.start()
        self.addCleanup(self.env.stop)
        self.fake = FakeBedrock()
        self.provider = patch.object(app, "_bedrock", return_value=self.fake)
        self.provider.start()
        self.addCleanup(self.provider.stop)

    def call(self, request):
        return app.handler(request, None)

    def test_valid_response_and_request_contract(self):
        result = self.call(event())
        self.assertEqual(result["statusCode"], 200)
        self.assertEqual(json.loads(result["body"]), GOOD)
        self.assertEqual(result["headers"]["cache-control"], "no-store, max-age=0")
        call = self.fake.calls[0]
        self.assertEqual(call["modelId"], ENV["MODEL_ID"])
        self.assertEqual(call["inferenceConfig"], {"maxTokens": 700, "temperature": 0})
        self.assertIn("untrusted", call["system"][0]["text"])

    def test_denied_requests_never_invoke_model(self):
        mutations = [{"cognito:groups": "Other"}, {"cognito:groups": "NotReviewers"}, {"cognito:groups": []},
                     {"token_use": "id"}, {"client_id": "another-client"}, {"iss": "other-pool"},
                     {"exp": "1"}, {"exp": "bad"}, {"exp": "NaN"}, {"sub": ""}]
        for mutation in mutations:
            with self.subTest(mutation=mutation):
                request = event()
                request["requestContext"]["authorizer"]["jwt"]["claims"].update(mutation)
                self.assertEqual(self.call(request)["statusCode"], 403)
        request = event()
        del request["requestContext"]["authorizer"]
        self.assertEqual(self.call(request)["statusCode"], 403)
        self.assertFalse(self.fake.calls)

    def test_gateway_group_encodings(self):
        for groups in ["Reviewers", "[Reviewers, Other]", '["Reviewers", "Other"]', ["Other", "Reviewers"]]:
            request = event()
            request["requestContext"]["authorizer"]["jwt"]["claims"]["cognito:groups"] = groups
            self.assertEqual(self.call(request)["statusCode"], 200)

    def test_input_boundaries_and_encoding(self):
        for text in ["a" * 20480, "é" * 10240, "\n" * 20479 + "x"]:
            self.assertEqual(self.call(event(text))["statusCode"], 200)
        for text in ["a" * 20481, "é" * 10241, "", " \n\t", "nul\0text", "\ud800"]:
            self.assertEqual(self.call(event(text))["statusCode"], 400)
        request = event()
        request["body"] = base64.b64encode(request["body"].encode()).decode()
        request["isBase64Encoded"] = True
        self.assertEqual(self.call(request)["statusCode"], 200)
        request["body"] = "%%%%"
        self.assertEqual(self.call(request)["statusCode"], 400)

    def test_malformed_input_is_rejected_before_model(self):
        for body in ['{"ticket":"x","ticket":"y"}', '{"ticket": NaN}', '{"ticket": 3}',
                     '{"ticket":"x","sendReply":true}', '["x"]', "null", "{", '"x"',
                     "[" * 2000, " " * 131073]:
            request = event()
            request["body"] = body
            self.assertEqual(self.call(request)["statusCode"], 400)
        request = event()
        request["headers"] = {"content-type": "text/plain"}
        self.assertEqual(self.call(request)["statusCode"], 400)
        self.assertFalse(self.fake.calls)

    def test_model_failures_are_safe_and_not_retried(self):
        for failure in [TimeoutError("PRIVATE TICKET"), RuntimeError("provider quota PRIVATE TICKET")]:
            self.fake.failure = failure
            self.fake.calls.clear()
            result = self.call(event("PRIVATE TICKET"))
            self.assertEqual(result["statusCode"], 503)
            self.assertNotIn("PRIVATE TICKET", result["body"])
            self.assertEqual(len(self.fake.calls), 1)

    def test_invalid_model_output_fails_closed(self):
        values = ["```json\n" + json.dumps(GOOD) + "\n```", "null", "{}", "[{}]", json.dumps({**GOOD, "reply": "sent"}),
                  json.dumps({**GOOD, "summary": " "}), json.dumps({**GOOD, "summary": "x" * 601}),
                  json.dumps({**GOOD, "urgency": "urgent"}), json.dumps({**GOOD, "topic": 1}),
                  json.dumps({**GOOD, "uncertainty": {"level": "high", "reason": ""}}),
                  json.dumps({**GOOD, "uncertainty": {"level": "maybe", "reason": "unknown"}}),
                  json.dumps({**GOOD, "summary": "\ud800"}), '{"summary":"a","summary":"b"}', "x" * 8193]
        for value in values:
            with self.subTest(value=value[:80]):
                self.fake.value = value
                self.assertEqual(self.call(event())["statusCode"], 503)
        for stop in ["max_tokens", "content_filtered", "tool_use", "guardrail_intervened"]:
            self.fake.stop = stop
            self.assertEqual(self.call(event())["statusCode"], 503)

    def test_no_ticket_in_logs_or_failure_responses(self):
        output = io.StringIO()
        with redirect_stdout(output), redirect_stderr(output):
            self.fake.failure = RuntimeError("SENSITIVE_SENTINEL")
            response = self.call(event("SENSITIVE_SENTINEL"))
        self.assertEqual(output.getvalue(), "")
        self.assertNotIn("SENSITIVE_SENTINEL", response["body"])

    def test_five_concurrent_calls_do_not_share_ticket_data(self):
        tickets = [f"Synthetic ticket {i}" for i in range(5)]
        with ThreadPoolExecutor(max_workers=5) as pool:
            results = list(pool.map(lambda t: self.call(event(t)), tickets))
        self.assertTrue(all(r["statusCode"] == 200 for r in results))
        self.assertCountEqual([c["messages"][0]["content"][0]["text"] for c in self.fake.calls], tickets)

    def test_public_assets_and_method_boundaries(self):
        for path in ["/", "/auth/callback", "/app.js", "/core.js", "/style.css", "/config.json"]:
            result = self.call({"rawPath": path, "requestContext": {"http": {"method": "GET"}}})
            self.assertEqual(result["statusCode"], 200)
            self.assertIn("no-store", result["headers"]["cache-control"])
        result = self.call({"rawPath": "/", "requestContext": {"http": {"method": "GET"}}})
        self.assertIn("frame-ancestors 'none'", result["headers"]["content-security-policy"])
        for method, path in [("GET", "/api/suggest"), ("POST", "/"), ("GET", "/../../handler.py")]:
            self.assertEqual(self.call({"rawPath": path, "requestContext": {"http": {"method": method}}})["statusCode"], 404)


class SDKConfigurationTests(unittest.TestCase):
    def test_regional_endpoint_and_no_sdk_retries(self):
        captured = {}
        def config(**kwargs):
            captured.update(kwargs)
            return kwargs
        def client(service, **kwargs):
            captured["service"] = service
            captured.update(kwargs)
            return "client"
        modules = {"boto3": types.SimpleNamespace(client=client),
                   "botocore": types.ModuleType("botocore"), "botocore.config": types.SimpleNamespace(Config=config)}
        with patch.dict(os.environ, ENV), patch.dict(sys.modules, modules):
            self.assertEqual(app._bedrock(), "client")
            self.assertEqual(captured["region_name"], "ap-southeast-2")
            self.assertEqual(captured["retries"]["total_max_attempts"], 1)
            os.environ["MODEL_ID"] = "au.cross-region-inference-profile"
            with self.assertRaises(RuntimeError):
                app._bedrock()


if __name__ == "__main__":
    unittest.main()
