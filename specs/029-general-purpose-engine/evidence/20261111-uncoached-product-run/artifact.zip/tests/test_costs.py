import copy
import json
from pathlib import Path
import unittest

from scripts.costs import estimate


class CostTests(unittest.TestCase):
    def setUp(self):
        self.config = json.loads((Path(__file__).resolve().parents[1] / "docs/cost-inputs.json").read_text())

    def test_unknown_rates_withhold_total(self):
        result = estimate(self.config)
        self.assertEqual(result["model_requests"], "4400")
        self.assertTrue(result["total"].startswith("UNKNOWN"))
        self.assertTrue(all(value == "UNKNOWN" for value in result["components"].values()))

    def test_unsourced_rate_is_rejected(self):
        self.config["rates"]["model_input_per_million"]["value"] = "1"
        with self.assertRaises(ValueError):
            estimate(self.config)

    def test_complete_artificial_rates_calculate_without_free_tier_assumptions(self):
        # Pure arithmetic fixture; these are deliberately NOT AWS prices.
        self.config["currency"] = "TEST-UNITS"
        self.config["measurements"] = {"mean_input_tokens": 1000, "mean_output_tokens": 200,
                                       "mean_lambda_seconds": 5, "static_requests": 100, "static_gb_seconds": 1}
        for item in self.config["rates"].values():
            item.update(value="1", source="artificial arithmetic fixture", as_of="2026-11-11")
        result = estimate(self.config)
        self.assertEqual(result["components"]["model_input"], "4.400000")
        self.assertEqual(result["components"]["lambda_compute"], "5501.00")
        self.assertEqual(result["total"], "5517.289000")
        self.config["rates"]["other_monthly"]["value"] = None
        self.assertTrue(estimate(self.config)["total"].startswith("UNKNOWN"))

    def test_invalid_measurements_cannot_make_a_misleading_total(self):
        for value in [-1, "NaN", "Infinity", True]:
            self.config["measurements"]["mean_input_tokens"] = value
            with self.assertRaises(ValueError):
                estimate(self.config)
