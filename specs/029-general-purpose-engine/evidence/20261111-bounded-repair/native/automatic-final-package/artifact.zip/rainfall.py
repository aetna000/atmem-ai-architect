"""Daily rainfall totals for the local controller qualification fixture."""

import math


def total_mm(readings):
    """Return the sum of up to 366 finite, nonnegative int/float readings.

    Invalid elements raise TypeError. A non-list raises TypeError and a list
    longer than 366 raises ValueError. Empty lists return zero.
    """
    if not isinstance(readings, list):
        raise TypeError("readings must be a list")
    if len(readings) > 366:
        raise ValueError("readings must contain at most 366 entries")

    for value in readings:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("each reading must be a finite, nonnegative int or float")
        # Integers are finite; avoid converting arbitrarily large ints to float.
        if value < 0 or (isinstance(value, float) and not math.isfinite(value)):
            raise TypeError("each reading must be a finite, nonnegative int or float")

    return sum(readings)
