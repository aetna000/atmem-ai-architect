# Rainfall qualification fixture

Requires Python 3.10+ and only its standard library. No installation, build,
network, cloud, or deployment steps are required. Commands work from a fresh
unpack without `.tools` aliases or private worker files.

`rainfall.total_mm(readings)` accepts a list of 0–366 finite, nonnegative
`int`/`float` readings. Empty returns `0`. Booleans and other invalid elements,
including negative and nonfinite numbers, raise `TypeError`. Non-list arguments
raise `TypeError`; lists longer than 366 raise `ValueError`.

**Repair status:** the initial fixture deliberately used `sum(readings[:-1])`.
The retained check reported three failures: the single-reading, three-reading,
and 366-reading totals. The implementation now uses `sum(readings)` after the
same validation. All original tests and assertions are unchanged.

Run the tests locally from the project directory:

```sh
python3 -m unittest -v test_rainfall.py
```

Example invocation (prints `6`):

```sh
python3 -c 'from rainfall import total_mm; print(total_mm([1, 2, 3]))'
```

Files added: `rainfall.py` (implementation), `test_rainfall.py` (contract tests),
and `README.md` (instructions). Backend-supplied `ATMEM_DELIVERY.md`,
`atmem-tools/prepare.py`, `project-context.json`, the composition skill, and
worker registrations are preserved. Rollback consists of restoring these
three added files from a chosen snapshot; there is no external state.

Verification uses the standard-library unittest suite above. Registered working
checks exercise a captured snapshot in an isolated Linux runtime; results apply
only to that snapshot and are reported separately. Mock and provider-schema
checks do not apply. Independent acceptance remains outstanding; a local test
pass alone does not establish whole-system or independent acceptance.
