"""Tests of the correct contract, including the intentional fixture failure."""

import unittest
from decimal import Decimal
from fractions import Fraction

from rainfall import total_mm


class TotalMmTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(total_mm([]), 0)

    def test_three_readings(self):
        self.assertEqual(total_mm([1, 2, 3]), 6)

    def test_single_reading(self):
        self.assertEqual(total_mm([4]), 4)

    def test_two_zeroes(self):
        self.assertEqual(total_mm([0, 0]), 0)

    def test_exactly_366_readings(self):
        self.assertEqual(total_mm([1] * 366), 366)

    def test_mixed_ints_and_floats(self):
        self.assertEqual(total_mm([1, 2.5, 0.25, 0]), 3.75)

    def test_large_integer(self):
        self.assertEqual(total_mm([10**400, 0]), 10**400)

    def test_reject_booleans(self):
        for value in (True, False):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    total_mm([0, value])

    def test_reject_strings_and_other_types(self):
        for value in ("1", "", None, 1j, [], {}, Decimal("1"), Fraction(1, 2)):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    total_mm([0, value])

    def test_reject_negative_values(self):
        for value in (-1, -0.5):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    total_mm([0, value])

    def test_reject_nonfinite_values(self):
        for value in (float("nan"), float("inf"), float("-inf")):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    total_mm([0, value])

    def test_reject_non_list(self):
        for value in (None, (), (1, 2), "123", 1, 1.0, True, {}, {1, 2}, range(3)):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    total_mm(value)

    def test_reject_367_entries(self):
        with self.assertRaises(ValueError):
            total_mm([0] * 367)


if __name__ == "__main__":
    unittest.main()
