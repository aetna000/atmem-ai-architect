# Rainfall qualification fixture

Requires Python 3.10+ and only its standard library. No installation, build,
network, cloud, or deployment steps are required. Commands work from a fresh
unpack without `.tools` aliases or private worker files.

`rainfall.total_mm(readings)` accepts a list of 0–366 finite, nonnegative
`int`/`float` readings. Empty returns `0`. Booleans and other invalid elements,
including negative and nonfinite numbers, raise `TypeError`. Non-list arguments
raise `TypeError`; lists longer than 366 raise `ValueError`.

**Initial fixture status:** the implementation deliberately uses
`sum(readings[:-1])`, dropping the last reading after validation. It is defective
and is not an accepted deliverable. Tests assert the correct contract; the
three-reading, single-reading, and 366-reading tests are expected to fail.
No tests or working checks were run during the first fixture turn. The engine
is expected to capture/check this snapshot and request a separate repair turn.
That repair must preserve the contract and all existing test assertions.

Run the tests locally from the project directory:

```sh
python3 -m unittest -v test_rainfall.py
```

After the separate repair, an example invocation is:

```sh
python3 -c 'from rainfall import total_mm; print(total_mm([1, 2, 3]))'
```

Files added: `rainfall.py` (implementation), `test_rainfall.py` (contract tests),
and `README.md` (instructions). Backend-supplied `ATMEM_DELIVERY.md`,
`atmem-tools/prepare.py`, `project-context.json`, the composition skill, and
worker registrations are preserved. Rollback consists of restoring these
three added files from a chosen snapshot; there is no external state.

Validation evidence: local runtime tests remain unexecuted on this first turn.
Mock and provider-schema checks do not apply. Independent acceptance remains
outstanding; fixture creation alone does not establish acceptance.
