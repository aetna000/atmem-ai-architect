const form = document.querySelector('#note-form');
const note = document.querySelector('#note');
const preview = document.querySelector('#preview');
const status = document.querySelector('#status');
const submit = document.querySelector('#submit');
const empty = document.querySelector('#empty');
const count = document.querySelector('#count');
let generation = 0;
let pending;

function invalidate() {
  generation += 1;
  pending?.abort();
  pending = undefined;
  submit.disabled = false;
  submit.textContent = 'Preview note';
  preview.textContent = '';
  preview.hidden = true;
  empty.hidden = false;
  status.textContent = '';
  status.className = '';
  note.removeAttribute('aria-invalid');
}

function clear() {
  invalidate();
  note.value = '';
  count.textContent = '0 / 2,000';
}

note.addEventListener('input', () => {
  invalidate();
  count.textContent = `${note.value.length.toLocaleString('en')} / 2,000`;
});
document.querySelector('#clear').addEventListener('click', () => { clear(); note.focus(); });
// Also erase values retained by history navigation / the back-forward cache.
window.addEventListener('pagehide', clear);
window.addEventListener('pageshow', clear);

form.addEventListener('submit', async event => {
  event.preventDefault();
  invalidate();
  const text = note.value;
  if (!text.trim() || text.length > 2000) {
    status.textContent = 'Enter a note of 1–2000 characters.';
    status.className = 'error';
    note.setAttribute('aria-invalid', 'true');
    note.focus();
    return;
  }
  const current = generation;
  const controller = new AbortController();
  pending = controller;
  submit.disabled = true;
  submit.textContent = 'Preparing…';
  status.textContent = 'Preparing your preview…';
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch('/api/preview', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note: text }),
      signal: controller.signal,
      cache: 'no-store',
      credentials: 'omit',
    });
    if (!response.ok) throw new Error('Preview failed');
    const data = await response.json();
    if (typeof data.preview !== 'string' || data.preview.length > 2000) throw new Error('Invalid preview');
    if (current !== generation) return;
    preview.textContent = data.preview;
    preview.hidden = false;
    empty.hidden = true;
    status.textContent = 'Preview ready. Select the text below to copy it.';
  } catch {
    if (current !== generation) return;
    status.className = 'error';
    status.textContent = controller.signal.aborted
      ? 'The preview took too long. Please try again.'
      : 'Could not prepare your preview. Please try again.';
  } finally {
    clearTimeout(timeout);
    if (current === generation) {
      pending = undefined;
      submit.disabled = false;
      submit.textContent = 'Preview note';
    }
  }
});
