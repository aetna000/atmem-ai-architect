import http from 'node:http';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const assets = new Map([
  ['/', ['text/html; charset=utf-8', 'index.html']],
  ['/app.js', ['text/javascript; charset=utf-8', 'app.js']],
  ['/style.css', ['text/css; charset=utf-8', 'style.css']],
].map(([route, [type, file]]) => [route, { type, body: readFileSync(new URL(`./public/${file}`, import.meta.url)) }]));

function reply(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(value));
}

// The optional function is a dependency seam for tests, never an HTTP feature.
export function createApp({ previewNote = async note => note } = {}) {
  const server = http.createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
    if (req.method === 'GET' && assets.has(req.url)) {
      const asset = assets.get(req.url);
      res.writeHead(200, { 'Content-Type': asset.type });
      res.end(asset.body);
      return;
    }
    if (req.url !== '/api/preview') return reply(res, 404, { error: 'Not found.' });
    if (req.method !== 'POST') {
      res.setHeader('Allow', 'POST');
      return reply(res, 405, { error: 'Use POST.' });
    }
    if (req.headers['content-type']?.split(';')[0].trim().toLowerCase() !== 'application/json') {
      return reply(res, 415, { error: 'Send application/json.' });
    }
    try {
      const chunks = [];
      let bytes = 0;
      for await (const chunk of req) {
        bytes += chunk.length;
        if (bytes > 32768) {
          reply(res, 413, { error: 'Request is too large.' });
          return;
        }
        chunks.push(chunk);
      }
      let input;
      try { input = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { return reply(res, 400, { error: 'Send valid JSON.' }); }
      if (!input || Array.isArray(input) || typeof input !== 'object' ||
          Object.keys(input).length !== 1 || !Object.hasOwn(input, 'note') ||
          typeof input.note !== 'string' || !input.note.trim() || input.note.length > 2000) {
        return reply(res, 400, { error: 'Enter a note of 1–2000 characters, with no extra fields.' });
      }
      const preview = await previewNote(input.note);
      if (typeof preview !== 'string' || preview.length > 2000) throw new Error('Invalid preview');
      if (!res.destroyed) reply(res, 200, { preview });
    } catch {
      // Never log request content or reflect internal errors.
      if (!res.destroyed && !res.headersSent) reply(res, 500, { error: 'Preview is unavailable. Please try again.' });
    }
  });
  server.requestTimeout = 15000;
  server.headersTimeout = 10000;
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const port = Number(process.env.PORT ?? 3000);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be 1–65535');
  const server = createApp();
  server.listen(port, '127.0.0.1', () => console.log(`Open http://127.0.0.1:${port}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
    server.close();
    server.closeAllConnections();
  });
}
