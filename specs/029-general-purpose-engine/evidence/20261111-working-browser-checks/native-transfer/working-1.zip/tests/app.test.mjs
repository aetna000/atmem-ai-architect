import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { existsSync } from 'node:fs';
import { createApp } from '../server.mjs';

async function start(t, options) {
  const server = createApp(options);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(async () => {
    const closed = new Promise(resolve => server.close(resolve));
    server.closeAllConnections();
    await closed;
  });
  return `http://127.0.0.1:${server.address().port}`;
}

test('real HTTP contract, boundaries and recovery', async t => {
  let fail = false;
  const origin = await start(t, { previewNote: async note => {
    if (fail) throw new Error('Private failure detail');
    return note;
  } });
  const post = body => fetch(`${origin}/api/preview`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  for (const note of ['Handover\n  Keep spacing.  ', '<script>alert("hi")</script>', 'x'.repeat(2000), '😀'.repeat(1000)]) {
    const response = await post({ note });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('cache-control'), 'no-store');
    assert.deepEqual(await response.json(), { preview: note });
  }
  for (const body of [{ note: '' }, { note: ' \n\t' }, { note: 1 }, { note: null },
    { note: true }, { note: [] }, { note: {} }, {}, [], null, 'text',
    { note: 'ok', extra: true }, { note: 'x'.repeat(2001) }, { note: '😀'.repeat(1001) }]) {
    assert.equal((await post(body)).status, 400);
  }
  // The maximum valid length also fits when every code unit is JSON-escaped.
  const escaped = await fetch(`${origin}/api/preview`, { method: 'POST',
    headers: { 'Content-Type': 'application/json' }, body: '{"note":"' + '\\u0061'.repeat(2000) + '"}' });
  assert.equal(escaped.status, 200);
  assert.equal((await escaped.json()).preview.length, 2000);
  assert.equal((await fetch(`${origin}/api/preview`, { method: 'POST',
    headers: { 'Content-Type': 'application/json' }, body: '{' })).status, 400);
  assert.equal((await fetch(`${origin}/api/preview`, { method: 'POST', body: 'note' })).status, 415);
  assert.equal((await post({ note: 'x'.repeat(40000) })).status, 413);
  assert.equal((await fetch(`${origin}/api/preview`)).status, 405);
  assert.equal((await fetch(`${origin}/missing`)).status, 404);
  fail = true;
  const failed = await post({ note: 'Recoverable note' });
  assert.equal(failed.status, 500);
  assert.deepEqual(await failed.json(), { error: 'Preview is unavailable. Please try again.' });
  fail = false;
  assert.deepEqual(await (await post({ note: 'Try again' })).json(), { preview: 'Try again' });
});

test('actual Chromium page against real loopback service', async t => {
  const { chromium } = await import(process.env.ATMEM_PLAYWRIGHT_MODULE || 'playwright-core');
  const executablePath = process.env.CHROMIUM_EXECUTABLE_PATH ||
    ['/usr/bin/chromium', '/usr/bin/chromium-browser'].find(path => existsSync(path));
  const browser = await chromium.launch({ headless: true, chromiumSandbox: true,
    ...(executablePath ? { executablePath } : {}) });
  t.after(() => browser.close());
  console.log(`Runtime evidence: Node ${process.version}; Chromium ${browser.version()}; Playwright 1.64.1; sandbox requested`);
  let behavior = async note => note;
  const origin = await start(t, { previewNote: note => behavior(note) });
  async function pageFor(t, init) {
    const context = await browser.newContext();
    t.after(() => context.close());
    if (init) await context.addInitScript(init);
    const page = await context.newPage();
    await page.goto(origin);
    return page;
  }
  async function ready(page, text) {
    await page.waitForFunction(value => document.querySelector('#preview').textContent === value &&
      !document.querySelector('#preview').hidden, text);
    assert.equal(await page.locator('#submit').isEnabled(), true);
  }

  await t.test('normal preview, exact POST schema, safe text, clear and no browser storage', async t => {
    const page = await pageFor(t);
    const text = '<img src=x onerror="window.unsafe=true">\nNext shift: refill tea.  ';
    await page.locator('#note').fill(text);
    const request = page.waitForRequest(request => request.url() === `${origin}/api/preview`);
    await page.getByRole('button', { name: 'Preview note', exact: true }).click();
    const sent = await request;
    assert.equal(sent.method(), 'POST');
    assert.deepEqual(sent.postDataJSON(), { note: text });
    await ready(page, text);
    assert.equal(await page.locator('#preview img').count(), 0);
    assert.equal(await page.evaluate(() => window.unsafe), undefined);
    assert.deepEqual(await page.evaluate(() => ({ local: localStorage.length, session: sessionStorage.length })),
      { local: 0, session: 0 });
    assert.deepEqual(await page.context().cookies(), []);
    await page.getByRole('button', { name: 'Clear everything' }).click();
    assert.equal(await page.locator('#note').inputValue(), '');
    assert.equal(await page.locator('#preview').textContent(), '');
    assert.equal(await page.locator('#preview').isHidden(), true);
    await page.locator('#note').fill('After clear');
    await page.locator('#submit').click();
    await ready(page, 'After clear');
    await page.reload();
    assert.equal(await page.locator('#note').inputValue(), '');
    assert.equal(await page.locator('#preview').textContent(), '');
  });

  await t.test('rejected input stays usable', async t => {
    const page = await pageFor(t);
    await page.locator('#note').fill('   ');
    await page.locator('#submit').click();
    assert.match(await page.locator('#status').textContent(), /Enter a note/);
    assert.equal(await page.locator('#note').getAttribute('aria-invalid'), 'true');
    // Exercise the server denial through the page as well as direct HTTP above.
    const denied = await page.evaluate(async () => {
      const response = await fetch('/api/preview', { method: 'POST',
        headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ note: '', extra: 1 }) });
      return response.status;
    });
    assert.equal(denied, 400);
    await page.locator('#note').fill('Valid after rejection');
    await page.locator('#submit').click();
    await ready(page, 'Valid after rejection');
  });

  await t.test('server failure is visible and retry succeeds without reload', async t => {
    const page = await pageFor(t);
    behavior = async () => { throw new Error('Simulated internal failure'); };
    await page.locator('#note').fill('Retain this for retry');
    await page.locator('#submit').click();
    await page.waitForFunction(() => document.querySelector('#status').textContent.includes('Could not prepare'));
    assert.equal(await page.locator('#submit').isEnabled(), true);
    assert.equal(await page.locator('#note').inputValue(), 'Retain this for retry');
    assert.equal(await page.locator('#preview').textContent(), '');
    behavior = async note => note;
    await page.locator('#submit').click();
    await ready(page, 'Retain this for retry');
  });

  for (const ignoreCancellation of [false, true]) {
    await t.test(`in-flight clear race (cancellation ${ignoreCancellation ? 'ignored' : 'enabled'})`, async t => {
      // Ignoring the signal deliberately proves generation guarding, beyond abort().
      // This still makes a real HTTP request; no response or route is mocked.
      const page = await pageFor(t, ignoreCancellation ? () => {
        const nativeFetch = window.fetch.bind(window);
        window.responsesRead = 0;
        window.fetch = async (url, options) => {
          const { signal, ...rest } = options;
          const response = await nativeFetch(url, rest);
          const json = response.json.bind(response);
          response.json = async () => {
            const value = await json();
            window.responsesRead++;
            return value;
          };
          return response;
        };
      } : undefined);
      let release;
      let entered;
      let finished;
      const started = new Promise(resolve => { entered = resolve; });
      const completed = new Promise(resolve => { finished = resolve; });
      const gate = new Promise(resolve => { release = resolve; });
      t.after(() => release());
      behavior = async note => { entered(); await gate; finished(); return note; };
      await page.locator('#note').fill('Slow old note');
      await page.locator('#submit').click();
      await started;
      await page.getByRole('button', { name: 'Clear everything' }).click();
      assert.equal(await page.locator('#submit').isEnabled(), true);
      release();
      await completed;
      if (ignoreCancellation) await page.waitForFunction(() => window.responsesRead === 1);
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      assert.equal(await page.locator('#note').inputValue(), '');
      assert.equal(await page.locator('#preview').textContent(), '');
      assert.equal(await page.locator('#status').textContent(), '');
      assert.equal(await page.locator('#preview').isHidden(), true);
      behavior = async note => note;
      await page.locator('#note').fill('Fresh note');
      await page.locator('#submit').click();
      await ready(page, 'Fresh note');
    });
  }
});
