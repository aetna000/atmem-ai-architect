# Check evidence

Registered validator: `node-browser-tests`, Node and Chromium tests (Playwright 1.64.1).

- Contract SHA-256: `7bd721ce44a40f09e99f282970bf7fd36c7336f495038f2f201beb0a6603a21e`.
- Isolated Linux/ARM64 image: `sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128`.
- Profile: `chromium-userns-v1`; runner: `node:test`.
- Supplied module environment: `ATMEM_PLAYWRIGHT_MODULE` (image-internal path).

Execution status: awaiting the initial registered working-snapshot check. This status will be updated after the complete report is read. No unexecuted checks are claimed as passes.

Provider-schema checks: not applicable. Provider mocks: not applicable. Local runtime/browser results: pending. Independent system acceptance: not performed. A working snapshot is in-progress evidence and is not a settled delivery package.
