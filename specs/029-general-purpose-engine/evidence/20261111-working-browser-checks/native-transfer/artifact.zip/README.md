# Shift note preview

A local web tool for volunteer handovers. Enter a note, choose **Preview note**, then select and copy the plain text. **Clear everything** erases the input and preview, including while a request is pending. Nothing is stored by the application. No accounts, publishing, cloud resources or Terraform are needed.

## Run from a fresh unpack

Use an existing Node.js **26.13.0** installation. Runtime dependencies: Node standard library only. No build, package installation, environment secrets or network download is required.

```sh
node --version
node server.mjs
```

Open `http://127.0.0.1:3000` on the same machine. The server binds only IPv4 loopback. To choose another port, run `PORT=3001 node server.mjs` (POSIX shell). Stop with Ctrl+C. Node 26.13.0 is the delivery runtime pin, matching the tested isolated runtime.

## Test dependencies and offline setup

Tests use Node's built-in `node:test`, **playwright-core 1.64.1**, and **Chromium 156.0.8078.80**, matching the executed isolated runtime. The registered validator supplies its reviewed Playwright module through `ATMEM_PLAYWRIGHT_MODULE`; tests use that variable directly. The validator catalog pins the complete test image by digest, including its browser. Exact observed Node and Chromium versions are printed by the test. Chromium launches headlessly with `chromiumSandbox: true`; sandbox availability is required, and tests must fail rather than disable it.

For a receiving engineer, provision the pinned Playwright package and its compatible Chromium from an approved offline distribution. Point `ATMEM_PLAYWRIGHT_MODULE` at that package's `index.mjs` and, if needed, `CHROMIUM_EXECUTABLE_PATH` at the Chromium executable. Alternatively put exactly `playwright-core@1.64.1` in local `node_modules` using an existing offline package cache; no install step is needed to run the app. The tests try operator-selected Chromium first, then Linux `/usr/bin/chromium` or `/usr/bin/chromium-browser`, otherwise Playwright's provisioned browser location. No browser or package download is performed by tests. On Linux run as an unprivileged user with working Chromium/user-namespace sandbox support. On other platforms provide a compatible sandboxed Chromium and qualify that combination separately.

```sh
export ATMEM_PLAYWRIGHT_MODULE=/absolute/path/to/playwright-core/index.mjs
export CHROMIUM_EXECUTABLE_PATH=/absolute/path/to/chromium
node --test tests/*.test.mjs
```

Do not copy the validator's internal module path into receiving-machine setup. Runtime paths inside its image are not host dependencies. Playwright package/version pins and the validator image digest are provenance limits, not independent checksum verification of an engineer's offline distribution.

The implementation uses ordinary `node` commands and has no dependency on hidden `.tools` aliases. The preserved `atmem-tools/prepare.py` is available if an exported copy needs tool aliases; it configures existing executables only. It does not vendor Node, browsers or packages. Do not run it against backend tool registrations in this workspace.

## Contract and behavior

`POST /api/preview` accepts `Content-Type: application/json` and exactly `{"note":"text"}`. Success is HTTP 200 with `{"preview":"text"}`. The preview preserves the submitted text exactly, including spaces and line breaks; it does not interpret HTML or Markdown. Empty/whitespace-only strings, nonstrings, nonobject bodies, extra fields and values above 2,000 UTF-16 code units receive HTTP 400. This character-count convention matches browser `maxlength` and JavaScript string length; an emoji outside the BMP counts as two. Malformed JSON receives 400, unsupported content type 415, oversized request bodies (over 32 KiB) 413, wrong methods 405 and unknown routes 404. Server failures receive a generic 500 response.

The browser renders with `textContent`. A generation token protects every asynchronous result; clear and edits invalidate the token and abort the old request. Submit is disabled only while the current request is pending; clear remains available. A ten-second timeout restores usability and displays a retry message. There is no automatic retry. Failures keep the entered note available for manual retry and remove the previous preview so it cannot be mistaken for a current result.

Notes exist transiently in the page and in a request's process memory. There are no databases, note files, browser storage, cookies, service workers, third-party assets or request-content logs. All HTTP responses carry `Cache-Control: no-store`; history lifecycle handlers erase page values. Clearing a page cannot retract a request already received by the process, but its late response cannot repopulate the page. Browser extensions, OS memory/swap, developer tools and manually copied text are outside application ownership. Closing the tab and stopping the server ends the application's state lifetime.

## Verification and operating limits

`tests/app.test.mjs` starts actual ephemeral loopback servers. HTTP tests cover validation boundaries, exact text, error statuses and recovery. Browser tests cover actual submission, safe rendering, visible failures and successful retry, clear, reload/storage behavior and delayed clear races. The race is also run with browser cancellation deliberately ignored, so a late real HTTP response exercises the generation guard. Failure/delay injection is only an imported function dependency in the test process; the executable app has no test routes or runtime failure switches.

The worker cannot bind host loopback or run Docker. Use the server-registered `node-browser-tests` isolated validator for its permitted loopback and sandboxed Chromium. Registered checks capture an immutable working snapshot. Read all report pages; a pass applies only to that snapshot. See `CHECKS.md` for recorded evidence. These authored tests and local checks are component evidence, not independent system acceptance.

This is a single-user local tool, not a public server or authenticated multiuser service. No remote access or deployment is authorized. Browser timeouts bound the page's wait; the production preview is a direct in-memory echo with no external operation.

## Rollback and troubleshooting

If a preview fails, retry with the same note; clear remains usable. If the service is unavailable, restart `node server.mjs` and reload the page (reloading erases the entered note). If the port is occupied, choose another `PORT`. A sandbox startup failure means the browser runtime needs repair; do not add `--no-sandbox`.

To roll back an implementation update, stop the server, restore the previous reviewed source bundle, and restart it with its pinned runtime. There is no database or persistent application state to migrate or undo. Removing the project files after stopping the process removes the tool.

## Artifact manifest

| Files | Purpose |
| --- | --- |
| `server.mjs` | Loopback HTTP service, schema validation and static file whitelist |
| `public/index.html`, `public/app.js`, `public/style.css` | Browser UI and request lifecycle |
| `tests/app.test.mjs` | Real HTTP and sandboxed Chromium tests |
| `package.json`, `.node-version`, `.gitignore` | Dependency pins, optional npm commands, exclusions |
| `README.md`, `CHECKS.md`, `EVIDENCE.md` | Handoff, execution evidence and reviewed-source limits |
| `ATMEM_DELIVERY.md`, `atmem-tools/prepare.py`, `project-context.json`, `.agents/skills/composition/SKILL.md` | Preserved backend inputs |

Worker `.tools`, `.worker-tmp`, caches, local test dependencies and browser binaries are not application artifacts and need not be exported.
