# Check evidence

Registered validator: `node-browser-tests`, Node and Chromium tests (Playwright 1.64.1).

- Contract SHA-256: `7bd721ce44a40f09e99f282970bf7fd36c7336f495038f2f201beb0a6603a21e`.
- Isolated Linux/ARM64 image: `sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128`.
- Profile: `chromium-userns-v1`; runner: `node:test`.
- Supplied module environment: `ATMEM_PLAYWRIGHT_MODULE` (image-internal path).

Initial registered working-snapshot check completed successfully; the complete report was read with `nextOffset: null` and no truncation:

- Check ID: `77a8f9ea-84b1-47d3-9bfd-ccda2660c909`.
- Checkpoint ID: `b6cd1be4-9884-4294-a379-a54b79f30492`.
- Source SHA-256: `b51e25d288ee332dbb9a17e485daa0a29fec18797ac2581484e8c9967aa0cd76`.
- Result: exit 0; 7 tests passed; 0 failed, skipped or cancelled.
- Actual runtime: Node **26.13.0**, Chromium **156.0.8078.80**, Playwright **1.64.1**; sandbox explicitly enabled.
- Coverage: actual HTTP validation/boundaries and recovery; browser submission, safe text, empty input, server failure/retry, clearing, no storage/reload behavior, delayed clear with cancellation enabled and ignored.

The initial snapshot preceded these evidence notes and the update of the runtime pin to the exact observed version. A new registered check is required for the revised files; its result is reported in the final handoff message. No failures were hidden or tests weakened.

Native worker checks: Node 26.5.0 parsed `server.mjs`, `public/app.js` and `tests/app.test.mjs` successfully with `--check`. Initial attempts were blocked by the worker's restricted OpenSSL configuration path; reruns used `OPENSSL_CONF=/dev/null`. These are syntax checks only; the worker did not bind a host server, launch a browser or use Docker.

Provider-schema checks: not applicable. Provider mocks: not applicable. Local runtime/browser results: passed on the recorded initial checkpoint. Independent system acceptance: not performed. A working snapshot is in-progress evidence and is not a settled delivery package. Receiving-platform execution and independent acceptance remain the receiving engineer's work.
