"""Behavior and boundary tests for the independent summary library."""

import unittest

from line_summary import summarize


class SummarizeTests(unittest.TestCase):
    def test_empty_list(self):
        self.assertEqual(
            summarize([]),
            {"count": 0, "total_characters": 0, "nonempty_count": 0},
        )

    def test_mixed_lines_return_exact_fields(self):
        self.assertEqual(
            summarize(["audit", "", " \t", " ok "]),
            {"count": 4, "total_characters": 11, "nonempty_count": 2},
        )

    def test_unicode_characters_are_counted_as_code_points(self):
        # A supplementary character is one code point; combining marks count
        # separately from their base character.
        self.assertEqual(
            summarize(["\U0001f600", "e\u0301", "\u754c"]),
            {"count": 3, "total_characters": 4, "nonempty_count": 3},
        )

    def test_unicode_and_ascii_whitespace(self):
        self.assertEqual(
            summarize(["", " \t\r\n", "\u2003\u00a0", "\u2003x\n", "\u200b"]),
            {"count": 5, "total_characters": 10, "nonempty_count": 2},
        )

    def test_non_lists_raise_type_error(self):
        for value in (None, "text", b"text", ("line",), {"line"}, {}, 42,
                      iter(["line"])):
            with self.subTest(value=type(value).__name__):
                with self.assertRaises(TypeError):
                    summarize(value)

    def test_non_string_entries_raise_type_error(self):
        for value in (None, 1, True, b"line", [], {}, ("line",)):
            with self.subTest(value=repr(value)):
                with self.assertRaises(TypeError):
                    summarize(["valid", value])

    def test_maximum_line_count_is_accepted(self):
        self.assertEqual(
            summarize([""] * 1000),
            {"count": 1000, "total_characters": 0, "nonempty_count": 0},
        )

    def test_excessive_line_count_raises_value_error(self):
        with self.assertRaises(ValueError):
            summarize([""] * 1001)

    def test_maximum_character_count_is_accepted(self):
        self.assertEqual(
            summarize(["\U0001f600" * 4096, " " * 4096]),
            {"count": 2, "total_characters": 8192, "nonempty_count": 1},
        )

    def test_excessive_character_count_raises_value_error(self):
        for character in ("a", "\U0001f600", " "):
            with self.subTest(character=repr(character)):
                with self.assertRaises(ValueError):
                    summarize(["valid", character * 4097])

    def test_input_is_unchanged_after_success(self):
        lines = [" padded ", "", "\t", "\U0001f600"]
        original = lines.copy()
        first = summarize(lines)
        self.assertEqual(lines, original)
        first["count"] = -1
        self.assertEqual(summarize(lines)["count"], 4)

    def test_input_is_unchanged_after_failure(self):
        for lines, exception in ((["valid", None], TypeError),
                                 (["valid", "x" * 4097], ValueError),
                                 ([""] * 1001, ValueError)):
            with self.subTest(exception=exception.__name__, count=len(lines)):
                original = lines.copy()
                with self.assertRaises(exception):
                    summarize(lines)
                self.assertEqual(lines, original)


if __name__ == "__main__":
    unittest.main()
