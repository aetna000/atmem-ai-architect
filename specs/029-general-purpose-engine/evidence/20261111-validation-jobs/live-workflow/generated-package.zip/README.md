# Audit line summary

Independent, pure-Python library using only the standard library. The caller
owns the input list; the function keeps no state, performs no I/O, and does not
modify the input. No audit collector integration or infrastructure is required.

```python
from line_summary import summarize

summarize(["audit", "", "  "])
# {"count": 3, "total_characters": 7, "nonempty_count": 1}
```

Input must be a list of strings with at most 1000 entries and at most 4096
Unicode code points per entry. Whitespace and newline characters contribute to
`total_characters`. `nonempty_count` counts entries containing at least one
non-whitespace character according to Python's Unicode whitespace rules.
Invalid input types raise `TypeError`; exceeded limits raise `ValueError`.
Validation stops at the first error; the list type and count are checked first.

No build or installation is needed. From the workspace root, run:

```sh
./.tools/python -m unittest -v test_line_summary.py
./.tools/python -c 'from line_summary import summarize; print(summarize(["audit", ""]))'
```

For another local Python 3 environment, replace `./.tools/python` with `python3`.
Runtime is linear in the total number of input characters, with bounded
temporary storage for processing a line. Errors propagate directly to the caller;
there are no external services, retries, or persistent state to recover.

Rollback: remove `line_summary.py`, `test_line_summary.py`, and this README
(and their generated `__pycache__` entries, if any). Existing collector systems,
the supplied project snapshot, skill, and tool configuration remain untouched.
