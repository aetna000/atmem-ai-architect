"""Summarize bounded lists of audit lines without changing them."""


def summarize(lines):
    """Return count, total_characters, and nonempty_count for a list of strings.

    Character counts use Unicode code points, including whitespace. A line is
    nonempty when it contains a character Python does not consider whitespace.
    Raise TypeError for invalid types and ValueError for exceeded limits.
    """
    if not isinstance(lines, list):
        raise TypeError("lines must be a list of strings")
    if len(lines) > 1000:
        raise ValueError("lines must contain at most 1000 entries")

    total_characters = 0
    nonempty_count = 0
    for line in lines:
        if not isinstance(line, str):
            raise TypeError("each line must be a string")
        length = len(line)
        if length > 4096:
            raise ValueError("each line must contain at most 4096 characters")
        total_characters += length
        if line.strip():
            nonempty_count += 1

    return {
        "count": len(lines),
        "total_characters": total_characters,
        "nonempty_count": nonempty_count,
    }
