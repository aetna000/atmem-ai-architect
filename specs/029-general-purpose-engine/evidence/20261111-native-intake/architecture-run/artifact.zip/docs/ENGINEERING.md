# Portable setup, build and verification

The exported project contains source, schemas, tests and instructions. It does not include `.tools`, `.worker-tmp`, `.terraform`, `dist`, a provider binary, Node modules, AWS credentials or a private worker filesystem. `atmem-tools/prepare.py` and `ATMEM_DELIVERY.md` are supplied inputs and remain unchanged. The helper configures already-installed tools offline; it does not install anything or grant cloud access.

## Dependencies and platforms

- Production: AWS Lambda `python3.12`, Linux ARM64, standard library plus AWS-managed **boto3/botocore** supplied by the Lambda runtime. No pip dependencies are packaged. `Converse` and `GetModelInvocationLoggingConfiguration` SDK shapes were exercised in the pinned local Lambda image, with stubbed transport. Managed-runtime SDK patch versions and actual AWS runtime version ARN remain operator-controlled release dependencies; this source does not pin those versions. Verify them in the target runtime before launch and after AWS updates; for stricter reproducibility vendor an approved, hash-pinned SDK offline and rerun the contract/ZIP checks. Do not assume host Python supplies the SDK.
- Local Python tests/build: CPython 3.12 target; also exercised on host CPython 3.14.6. Standard-library `unittest`, `zipfile`, `subprocess` only. No installation needed for ordinary tests. The SDK contract test explicitly skips on a host without boto3; that skip is not a pass for SDK compatibility. Run it in the Lambda Python 3.12 ARM64 environment with its managed SDK for the complete Python suite.
- Infrastructure: Terraform **1.17.1**, HashiCorp AWS **6.72.0**, an operator-approved offline filesystem mirror. Native provider schema/mock checks used macOS ARM64. The checked-in lock contains a locally computed `darwin_arm64` hash, not authenticated upstream signed checksums. On Linux obtain/verify that platform's provider through your approved process and extend the lock offline with `terraform providers lock -fs-mirror=/absolute/approved/mirror -platform=linux_amd64` (or `linux_arm64` as appropriate). A mirror and local hash alone do not prove publisher authenticity. Do not fall back to a registry.
- Browser tests only: Node **26.5.0**, `playwright-core` **1.64.1**, its compatible preinstalled Chromium and Linux browser system dependencies. `package.json` pins the Playwright package. Obtain them through your approved offline software supply chain; this project does not download them or supply binary checksums. Set `ATMEM_PLAYWRIGHT_MODULE` to that installed package's absolute `index.mjs` path. The reviewed validator supplies this environment variable itself. Tests launch Chromium with `chromiumSandbox:true`; use a Linux environment permitting its sandbox, never turn it off to get a pass. The product has no Node runtime dependency or JS build step.

## Fresh unpack, offline

Use your approved installed executable paths and mirror in place of the example paths below. Do not copy private worker paths.

```sh
python3 atmem-tools/prepare.py --python /approved/bin/python3 --node /approved/bin/node --terraform /approved/bin/terraform --provider-mirror /approved/provider-mirror --require python --require node --require terraform --require providerMirror
export OPENSSL_CONF="$PWD/.worker-tmp/openssl.cnf"
export TF_CLI_CONFIG_FILE="$PWD/.worker-tmp/terraform.rc"
export TMPDIR="$PWD/.worker-tmp"
.tools/python -m unittest discover -v
.tools/python scripts/build.py
.tools/node --check app/web/app.js
.tools/terraform -chdir=infra init -backend=false -input=false
.tools/terraform -chdir=infra fmt -check -recursive
.tools/terraform -chdir=infra validate
.tools/terraform -chdir=infra test -no-color
```

The provider init uses only the offline mirror, and the Terraform test uses `mock_provider`, with no credentials or AWS calls. No arbitrary `terraform plan` against a real account is part of local verification. In this worker the existing tool registrations were preserved; `scripts/offline_config.py` wrote only temporary OpenSSL/mirror configuration because the initial aliases lacked those files. A fresh receiving environment should use the supplied helper first.

To run the browser tests after preparing the exact offline dependency and Chromium:

```sh
export ATMEM_PLAYWRIGHT_MODULE=/approved/node_modules/playwright-core/index.mjs
.tools/node --test --test-reporter=tap --test-concurrency=1 tests/browser.test.mjs
```

Those tests start a loopback-only local HTTP server and mock OAuth/model transport. They do not run Cognito or Bedrock. A missing browser dependency is a failing prerequisite, not a skipped browser check. For a quick static inspection, `python3 -m http.server 8080 --bind 127.0.0.1 --directory app/web` displays the page, but it cannot sign in or produce suggestions; the actual web runtime is the emitted Lambda/HTTP API integration.

`scripts/build.py` emits a deterministic application-only `dist/function.zip`. It contains just `app/__init__.py`, `app/handler.py` and three browser assets. It excludes tests, tooling, client snapshots, provider files, schemas, local credentials and mock transports. The ZIP test builds in a temporary directory, checks exact contents and deterministic hashes, unpacks it, imports the actual handler without the source tree and exercises the real HTTP API event adapter. Build before Terraform plan/test; Terraform hashes that ZIP. Never ship a local fake SDK as runtime behavior.

## Deployment and rollback commands (operator only; not executed here)

First complete the operator release gates in [OPERATIONS.md](OPERATIONS.md). Configure an authorized AWS operator identity externally, targeting the intended Australian account. The function's IAM role is not a deployment role. No credentials belong in source or tfvars. Configure the approved encrypted state/backend before an actual deployment; local state otherwise remains on the operator machine.

```sh
cp infra/example.tfvars infra/operator.tfvars
.tools/python scripts/build.py
.tools/terraform -chdir=infra plan -var-file=operator.tfvars -out=review.tfplan
.tools/terraform -chdir=infra apply review.tfplan
.tools/terraform -chdir=infra output
```

Review every real plan for account/region, public route authorization, exact model IAM, lack of content storage/logging, and changes to existing resources. Create staff and update allowed subs after the initial disabled deployment. Do not enable inference until provider retention/residency/quality gates are satisfied. Plan files/state may contain identity/config metadata; store them securely in Australia, exclude them from delivery/version control and delete stale plans. The operator owns AWS account settings and must not change shared Bedrock logging/retention without the existing owner's authorization. Rollback restores the previous reviewed source and tfvars, rebuilds and reapplies with inference disabled until verified. Details and emergency shutdown are in the operator guide.

## Evidence boundaries

`docs/VERIFICATION.md` records local results. Host syntax/unit, real provider-schema validation, mock plans, SDK shape tests and browser runtime checks answer different questions. SDK Stubber validates the actual SDK's request/response shapes without a service request. Five-thread tests validate separation of synthetic request results; they do not establish five concurrent AWS inferences. Tests cannot establish native structured output on a model that lacks it, end-to-end retention, inherited IAM, latency, regional quota, model correctness, current pricing, hosted-login assets or actual AWS deployment. Those require the explicit real-account acceptance checks, which remain unexecuted.
