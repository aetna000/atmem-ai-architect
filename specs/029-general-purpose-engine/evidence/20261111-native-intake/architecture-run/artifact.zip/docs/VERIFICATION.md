# Verification record

Executed 2026-11-11 without AWS credentials, cloud account access, deployment or network installation. No independent acceptance is established.

| Evidence class | Executed result | Scope |
|---|---|---|
| Host Python, CPython 3.14.6 | 10 tests passed; 2 SDK tests explicitly skipped because host boto3 is unavailable | Standard-library handler/validation/failure/parallel isolation and deterministic ZIP checks |
| Target local runtime: Linux ARM64 Lambda Python 3.12 | **12 passed, 0 skipped**, registered `lambda-python312-tests` | Actual handler, unpacked ZIP assets/event adapter, real SDK shapes via Stubber, regional endpoint configuration and retry/time budgets; no actual AWS/model request |
| Browser local runtime: Node and Chromium, Playwright 1.64.1 | **5 passed, 0 skipped**, registered `node-browser-tests`, Chromium sandbox enabled | PKCE redirect and denied state, visible uncertainty, inert HTML rendering, clear/review, stale-response suppression, UTF-8 limits and safe errors, with mocked OAuth/model transport |
| Provider schema | `terraform validate` passed, Terraform 1.17.1 / AWS 6.72.0 | Real offline provider schema, not account IAM/access or service behavior |
| Provider mock | `terraform test` **1 passed, 0 failed** | No-account plan assertions for bounded footprint, default disabled/empty allowlist, JWT/scope, invited staff/MFA and exact regional model ARN |
| Native build/syntax | Deterministic ZIP generated; JavaScript syntax check and recursive Terraform format check passed | Runtime-only ZIP; no private tools/client snapshot/test transport in payload |

The complete registered output pages were read to `nextOffset=null`. Checks used working checkpoint `c5f9c75d-54b6-4970-be9e-d3d75d2c3761`, SHA-256 `9abad9851f9b4e9d36fed01bed658a890fb663b617d62a6966721e5ec7037070`, before this evidence document was added. Backend receipt: `69576b1b-8720-4a52-8a89-f8da59ce3f78`; browser receipt: `2359184c-503c-421f-84fd-a04fd8257b82`. Local runtime image IDs were `sha256:cdb746c1eb56b61de56e1b5e78f6194392eb00494a1bb257a592852e72d8314b` (Lambda) and `sha256:df7f71a8588253403dfa833c5c4aacc95ca340204a88d5483edd58131c7f1128` (browser). These are reviewed local image identifiers, not publicly downloadable dependency paths. Subsequent file edits require a new working check; working checkpoints are not settled delivery packages. Final working checks are reported in the session receipts.

Initial host checks encountered denied global OpenSSL/Terraform configuration paths. Temporary project-local configuration fixed them; final syntax/schema/mock commands passed using it. The initial smaller backend/browser checks also passed; the later suite added ZIP, SDK-configuration and OAuth-state coverage rather than removing requirements.

## Unexecuted and unresolved

- No real Terraform account plan/apply, Cognito sign-in/MFA flow, effective IAM denial, endpoint availability, model invocation, measured latency or five-inference regional load test was executed. Browser identity/model responses were fixtures; SDK Stubber enforces SDK shapes only.
- Current regional model/account access and quota, real managed SDK/runtime version, provider retention mode, inherited logging and actual Australia boundary remain release checks. No ticket/model-quality assessment or independent human acceptance was performed.
- **Automatic live provider retention verification is unresolved.** Runtime checks invocation logging, but inference additionally relies on a bounded operator attestation of retention mode `none` (maximum 24 hours), default disabled. Unknown/denied/expired checks must remain disabled; settings must remain controlled during the window. If this operational check is insufficient, implement/test a supported live read before release. Do not infer no provider retention from application storage behavior.
- No Australian prices, free-tier eligibility, token/latency measurements or total bill were verified. The cost worksheet contains formulas, source URLs and explicit unknowns, with a stated 22-working-day assumption.
- The offline provider lock has a locally computed macOS ARM64 checksum, with no upstream authenticity proof or Linux hashes. The exported helper and dependency notes explain receiving-engineer setup; unexported worker paths are not runtime prerequisites.

The real-account acceptance procedure, owners and rollback controls are in [OPERATIONS.md](OPERATIONS.md). The existing help desk remains unchanged and unconnected.
