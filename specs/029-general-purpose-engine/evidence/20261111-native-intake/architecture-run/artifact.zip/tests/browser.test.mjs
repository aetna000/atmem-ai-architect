import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';

const modulePath = process.env.ATMEM_PLAYWRIGHT_MODULE;
if (!modulePath) throw Error('Set ATMEM_PLAYWRIGHT_MODULE to the approved Playwright 1.64.1 index.mjs.');
const {chromium} = await import(pathToFileURL(modulePath).href);
const good = {summary:'Synthetic sign-in issue',topic:'access',urgency:'unknown',uncertainty:{level:'high',reason:'Scope and impact are missing.'}};
let server, browser, origin;
test.before(async () => {
  server = http.createServer(async (req, res) => {
    const path = new URL(req.url, 'http://local').pathname;
    if (path === '/config.json') { res.setHeader('Content-Type','application/json'); res.end(JSON.stringify({clientId:'testclient',authOrigin:'https://test.auth.ap-southeast-2.amazoncognito.com'})); return; }
    const asset = {'/':'index.html','/app.js':'app.js','/style.css':'style.css'}[path];
    if (!asset) { res.writeHead(404); res.end(); return; }
    res.setHeader('Content-Type', path.endsWith('.js') ? 'text/javascript' : path.endsWith('.css') ? 'text/css' : 'text/html');
    res.setHeader('Cache-Control','no-store');
    res.end(await readFile(new URL('../app/web/' + asset, import.meta.url)));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({headless:true,chromiumSandbox:true});
});
test.after(async () => { await browser?.close(); await new Promise(resolve => server?.close(resolve)); });
async function signedIn() {
  const context = await browser.newContext();
  await context.addInitScript(() => sessionStorage.setItem('oauth',JSON.stringify({state:'teststate',verifier:'v'.repeat(43),at:Date.now()})));
  await context.route('https://test.auth.ap-southeast-2.amazoncognito.com/oauth2/token', route => route.fulfill({json:{access_token:'synthetic-token',expires_in:300}}));
  const page = await context.newPage();
  await page.goto(origin + '/?code=synthetic&state=teststate');
  await page.waitForFunction(() => !document.querySelector('#ticket').disabled);
  assert.equal(new URL(page.url()).search, '');
  return {context,page};
}
test('sign-in required, PKCE redirect and no saved ticket', async () => {
  const context = await browser.newContext(), page = await context.newPage();
  await page.goto(origin);
  assert.equal(await page.locator('#ticket').isDisabled(),true);
  await page.route('https://test.auth.ap-southeast-2.amazoncognito.com/oauth2/authorize?**', async route => {
    const u = new URL(route.request().url());
    assert.equal(u.searchParams.get('code_challenge_method'),'S256');
    assert.equal(u.searchParams.get('response_type'),'code');
    assert.equal(u.searchParams.get('code_challenge').length,43);
    await route.fulfill({body:'Mock identity provider'});
  });
  await page.click('#login');
  await page.waitForURL('https://test.auth.ap-southeast-2.amazoncognito.com/**');
  await context.close();
});
test('visible uncertainty, review and clearing; HTML is inert', async () => {
  const {context,page} = await signedIn();
  const value = {...good,summary:'<img src=x onerror="window.injected=true">'};
  await page.route('**/suggest', async route => {
    assert.equal(route.request().headers().authorization,'Bearer synthetic-token');
    assert.equal(JSON.parse(route.request().postData()).text,'Synthetic outage');
    await route.fulfill({json:value});
  });
  await page.fill('#ticket','Synthetic outage'); await page.click('#submit');
  await page.locator('#suggestion').waitFor({state:'visible'});
  assert.match(await page.textContent('#uncertainty'), /HIGH.*Scope/);
  assert.equal(await page.locator('#summary img').count(),0);
  assert.equal(await page.inputValue('#ticket'),'');
  await page.check('#reviewed'); await page.click('#clear');
  assert.equal(await page.locator('#suggestion').isHidden(),true);
  assert.equal(await page.textContent('#json'),'');
  assert.equal(await page.locator('#reviewed').isChecked(),false);
  assert.equal(await page.evaluate(() => JSON.stringify(localStorage)), '{}');
  assert.equal(await page.evaluate(() => JSON.stringify(sessionStorage)), '{}');
  await context.close();
});
test('clear cancels late results and allows a fresh request', async () => {
  const {context,page} = await signedIn();
  let release;
  const held = new Promise(resolve => { release=resolve; });
  let count=0;
  await page.route('**/suggest', async route => { count++; if(count===1) await held; await route.fulfill({json:good}).catch(()=>{}); });
  await page.fill('#ticket','First'); await page.click('#submit');
  await page.waitForFunction(() => document.querySelector('#status').textContent.includes('Preparing'));
  await page.click('#clear'); release();
  await page.waitForTimeout(100);
  assert.equal(await page.locator('#suggestion').isHidden(),true);
  await page.fill('#ticket','Second'); await page.click('#submit');
  await page.locator('#suggestion').waitFor({state:'visible'});
  assert.equal(count,2); await context.close();
});
test('UTF-8 limit, invalid response, denied user and service failure stay safe', async () => {
  const {context,page} = await signedIn();
  let calls=0, mode='invalid';
  await page.route('**/suggest', async route => { calls++; await route.fulfill(mode==='denied' ? {status:403,json:{error:{code:'denied'}}} : mode==='failure' ? {status:503,json:{error:{code:'suggestion_unavailable'}}} : {json:{summary:'bad'}}); });
  await page.fill('#ticket','é'.repeat(10241)); await page.click('#submit');
  assert.equal(calls,0); assert.match(await page.textContent('#status'),/UTF-8/);
  for (const next of ['invalid','failure','denied']) {
    mode=next; await page.fill('#ticket','Synthetic'); await page.click('#submit');
    await page.waitForFunction(() => !document.querySelector('#status').textContent.includes('Preparing'));
    assert.equal(await page.locator('#suggestion').isHidden(),true);
  }
  assert.equal(await page.locator('#ticket').isDisabled(),true);
  await context.close();
});
test('OAuth state mismatch denies access and removes code from address bar', async () => {
  const context = await browser.newContext();
  let tokenCalls = 0;
  await context.route('**/oauth2/token', async route => { tokenCalls++; await route.abort(); });
  const page = await context.newPage();
  await page.goto(origin + '/?code=wrong&state=wrong');
  await page.waitForFunction(() => document.querySelector('#status').textContent.includes('unavailable'));
  assert.equal(await page.locator('#ticket').isDisabled(),true);
  assert.equal(tokenCalls,0);
  assert.equal(new URL(page.url()).search,'');
  await context.close();
});
