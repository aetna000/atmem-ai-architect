
import test from 'node:test';import assert from 'node:assert/strict';import http from 'node:http';
const {chromium}=await import(process.env.ATMEM_PLAYWRIGHT_MODULE);
test('Museum notice reaches actual Chromium through local HTTP',async()=>{
 const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><button id="show">Show notice</button><output id="notice"></output><script>document.querySelector("#show").onclick=()=>document.querySelector("#notice").textContent="Gallery opens at 10"</script>');});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser;
 try{browser=await chromium.launch({headless:true,chromiumSandbox:true});const page=await browser.newPage();await page.goto(`http://127.0.0.1:${server.address().port}/`);assert.equal(await page.locator('#notice').textContent(),'');await page.locator('#show').click();assert.equal(await page.locator('#notice').textContent(),'Gallery opens at 10');}
 finally{await browser?.close();await new Promise(resolve=>server.close(resolve));}
});
