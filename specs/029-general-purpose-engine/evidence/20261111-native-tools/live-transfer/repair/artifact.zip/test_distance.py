"""Run with python3 -m unittest -v or python3 test_distance.py."""

from decimal import Decimal
from fractions import Fraction
import sys
import unittest

from distance import convert


class ConversionTests(unittest.TestCase):
    def test_known_conversions(self):
        self.assertEqual(convert(1, "ft", "m"), 0.3048)
        self.assertEqual(convert(0.3048, "m", "ft"), 1.0)
        self.assertAlmostEqual(convert(10, "m", "ft"), 32.80839895013123)

    def test_identity_and_zero(self):
        for source in ("m", "ft", "cm"):
            for destination in ("m", "ft", "cm"):
                with self.subTest(source=source, destination=destination):
                    self.assertEqual(convert(0, source, destination), 0.0)
            self.assertEqual(convert(2.5, source, source), 2.5)
            self.assertIsInstance(convert(2, source, source), float)

    def test_real_numeric_types(self):
        for value in (1, 1.0, Decimal("1"), Fraction(1, 1)):
            with self.subTest(value=value):
                self.assertEqual(convert(value, "ft", "m"), 0.3048)
                self.assertEqual(convert(value, "m", "cm"), 100.0)
                self.assertEqual(convert(value, "cm", "m"), 0.01)

    def test_centimetre_conversions(self):
        self.assertEqual(convert(100, "cm", "m"), 1.0)
        self.assertEqual(convert(1, "m", "cm"), 100.0)
        self.assertEqual(convert(1, "ft", "cm"), 30.48)
        self.assertEqual(convert(30.48, "cm", "ft"), 1.0)

    def test_round_trip(self):
        for value in (0.001, 1, 12345.678):
            for source in ("m", "ft", "cm"):
                for destination in ("m", "ft", "cm"):
                    with self.subTest(value=value, source=source, destination=destination):
                        self.assertAlmostEqual(
                            convert(convert(value, source, destination), destination, source), value
                        )

    def test_invalid_units_in_both_positions(self):
        for unit in ("mm", "km", "feet", "M", "FT", "CM", " m", "ft ", " cm", "cm ", "", None, 1, [], {}):
            for valid in ("m", "ft", "cm"):
                for source, destination in ((unit, valid), (valid, unit)):
                    with self.subTest(source=source, destination=destination):
                        with self.assertRaises(ValueError):
                            convert(1, source, destination)

    def test_nonnumeric_and_boolean_values(self):
        for value in (True, False, "1", None, [], {}, object(), 1 + 0j):
            for source in ("m", "ft", "cm"):
                for destination in ("m", "ft", "cm"):
                    with self.subTest(value=value, source=source, destination=destination):
                        with self.assertRaises(TypeError):
                            convert(value, source, destination)

    def test_nonfinite_and_negative_values_even_for_identity(self):
        values = (
            float("nan"), float("inf"), float("-inf"),
            Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity"),
            -1, -0.01, Decimal("-1e-1000"), Fraction(-1, 100),
        )
        for value in values:
            for source in ("m", "ft", "cm"):
                for destination in ("m", "ft", "cm"):
                    with self.subTest(value=value, source=source, destination=destination):
                        with self.assertRaises(ValueError):
                            convert(value, source, destination)

    def test_float_range_overflow(self):
        for value in (10 ** 1000, Decimal("1e1000")):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    convert(value, "m", "m")
        with self.assertRaises(ValueError):
            convert(sys.float_info.max, "m", "ft")
        for source in ("m", "ft"):
            with self.subTest(source=source):
                with self.assertRaises(ValueError):
                    convert(sys.float_info.max, source, "cm")
        self.assertEqual(convert(sys.float_info.max, "cm", "m"), sys.float_info.max / 100)


if __name__ == "__main__":
    unittest.main()
