"""Validated conversions between metres (m), feet (ft) and centimetres (cm)."""

from decimal import Decimal
import math
from numbers import Real


def convert(value, source, destination):
    """Return a float, using exactly 1 ft = 0.3048 m and 100 cm = 1 m.

    Accept real numbers (including Decimal), excluding bool. Units must be
    exactly 'm', 'ft' or 'cm'. Raise TypeError for non-real values and ValueError
    for invalid units, negative/nonfinite values or float range overflow.
    """
    for unit in (source, destination):
        if not isinstance(unit, str) or unit not in ("m", "ft", "cm"):
            raise ValueError("units must be exactly 'm', 'ft' or 'cm'")
    if isinstance(value, bool) or not isinstance(value, (Real, Decimal)):
        raise TypeError("value must be a real number, excluding bool")
    try:
        amount = float(value)
    except (OverflowError, ValueError) as error:
        raise ValueError("value must fit in a finite float") from error
    if not math.isfinite(amount):
        raise ValueError("value must be finite")
    # Check the original value so tiny negative Decimals cannot underflow to -0.
    if value < 0:
        raise ValueError("value must be nonnegative")

    if source == destination:
        result = amount
    elif source == "cm":
        result = amount / (100 if destination == "m" else 30.48)
    elif destination == "cm":
        result = amount * (100 if source == "m" else 30.48)
    elif source == "ft":
        result = amount * 0.3048
    else:
        result = amount / 0.3048
    if not math.isfinite(result):
        raise ValueError("converted value must fit in a finite float")
    return result
