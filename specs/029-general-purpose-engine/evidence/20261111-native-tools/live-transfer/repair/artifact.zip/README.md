# Distance conversion

Standard-library-only Python 3.10+ module. No installation, build, network,
cloud service or persistent state is required. From a fresh unpack, use an
installed Python interpreter:

```sh
python3 -m unittest -v
python3 -c 'from distance import convert; print(convert(1, "ft", "m"))'
```

`convert(value, source, destination)` supports exactly the case-sensitive units
`m`, `ft` and `cm`, with 1 ft = 0.3048 m and 100 cm = 1 m.
For example, `convert(1, "ft", "cm")` returns `30.48`.
It accepts nonnegative real numbers (including
`Decimal` and `Fraction`) and returns a float. Floating-point rounding and
underflow apply. Input and output must fit in finite floats.

Invalid units, negative/nonfinite values and float overflow raise `ValueError`.
Booleans, complex numbers, strings and other nonnumeric values raise `TypeError`.
Validation also applies to same-unit conversions.

Artifact manifest: `distance.py` is the runtime module; `test_distance.py` is
the executable test suite; `README.md` documents use; `EVIDENCE.md` records
qualification provenance and verification limits. Backend-supplied files are
preserved. Commands use ordinary Python and need no `.tools` aliases or private
worker files. To roll back centimetre support, restore `distance.py`,
`test_distance.py` and `README.md` from the previous m/ft package; retain
`EVIDENCE.md` as verification history. There is no data or infrastructure migration.
