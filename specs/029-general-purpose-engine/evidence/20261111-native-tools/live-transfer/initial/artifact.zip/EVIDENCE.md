# Qualification evidence

Before implementation, the offered AtMem tools returned:

- Check catalog: `python-tests`, `lambda-python312-tests`, `distance-base`.
- Settled artifact list: empty. There was no prior package to inspect or check.
- Search: `interface validation data lifetime` against the pinned reviewed corpus.
- Complete record read: `aws-structured-output-boundary`, source-reviewed,
  active, reviewed 2026-11-10; retrieved 2026-11-09T16:52:14.475436+00:00.

Source: <https://docs.aws.amazon.com/bedrock/latest/userguide/structured-output.html>

- Source SHA-256: `cdbf4b796ed8c9e6e3be430a1fa086710916cb9ce2c27b16f9a87ed6ca4b4432`
- Record SHA-256: `4692e9f06239d7181cfc135d1e271769c6e163865ad14b1951da375e4ed5b9d6`
- Corpus snapshot SHA-256: `6be9a1984e95243aa88cce045f2a6a500258b007b4dbd5cdd31a094fcfc59742`

The authored practice discusses Bedrock Converse JSON-schema output contracts
and independent input/output validation. Its cloud/model/service scope does
not apply to this local arithmetic module. No cloud pattern was adopted.
The record qualifies provenance retrieval only: it is documentation review,
not account, combined-system or deployed validation. It also requires checking
actual model/service versions, regional support and application behavior for
uses within its domain. The corpus is small and not exhaustive vendor knowledge.

Verification categories: native Python tests exercise the actual module.
Executed locally with Python 3.14.6: `.tools/python -B -m unittest -v`
passed all 8 test methods, including invalid-input cases and float overflow.
A separate native invocation returned `0.3048` for 1 ft in m and
`3.280839895013123` for 1 m in ft. Other Python versions were not executed.
No mocks or provider schemas apply. Registered checks have not run because
there is no immutable artifact available. Local tests and agent completion do
not establish independent acceptance; the independent distance contract remains
unexecuted until a package is captured and checked separately.
