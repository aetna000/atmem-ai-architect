"""Run with python3 -m unittest -v or python3 test_distance.py."""

from decimal import Decimal
from fractions import Fraction
import sys
import unittest

from distance import convert


class ConversionTests(unittest.TestCase):
    def test_known_conversions(self):
        self.assertEqual(convert(1, "ft", "m"), 0.3048)
        self.assertEqual(convert(0.3048, "m", "ft"), 1.0)
        self.assertAlmostEqual(convert(10, "m", "ft"), 32.80839895013123)

    def test_identity_and_zero(self):
        for source in ("m", "ft"):
            for destination in ("m", "ft"):
                with self.subTest(source=source, destination=destination):
                    self.assertEqual(convert(0, source, destination), 0.0)
            self.assertEqual(convert(2.5, source, source), 2.5)
            self.assertIsInstance(convert(2, source, source), float)

    def test_real_numeric_types(self):
        for value in (1, 1.0, Decimal("1"), Fraction(1, 1)):
            with self.subTest(value=value):
                self.assertEqual(convert(value, "ft", "m"), 0.3048)

    def test_round_trip(self):
        for value in (0.001, 1, 12345.678):
            with self.subTest(value=value):
                self.assertAlmostEqual(
                    convert(convert(value, "m", "ft"), "ft", "m"), value
                )

    def test_invalid_units_in_both_positions(self):
        for unit in ("cm", "km", "feet", "M", "FT", " m", "ft ", "", None, 1, [], {}):
            for source, destination in ((unit, "m"), ("ft", unit)):
                with self.subTest(source=source, destination=destination):
                    with self.assertRaises(ValueError):
                        convert(1, source, destination)

    def test_nonnumeric_and_boolean_values(self):
        for value in (True, False, "1", None, [], {}, object(), 1 + 0j):
            with self.subTest(value=value):
                with self.assertRaises(TypeError):
                    convert(value, "m", "ft")

    def test_nonfinite_and_negative_values_even_for_identity(self):
        values = (
            float("nan"), float("inf"), float("-inf"),
            Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity"),
            -1, -0.01, Decimal("-1e-1000"), Fraction(-1, 100),
        )
        for value in values:
            for destination in ("m", "ft"):
                with self.subTest(value=value, destination=destination):
                    with self.assertRaises(ValueError):
                        convert(value, "m", destination)

    def test_float_range_overflow(self):
        for value in (10 ** 1000, Decimal("1e1000")):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    convert(value, "m", "m")
        with self.assertRaises(ValueError):
            convert(sys.float_info.max, "m", "ft")


if __name__ == "__main__":
    unittest.main()
