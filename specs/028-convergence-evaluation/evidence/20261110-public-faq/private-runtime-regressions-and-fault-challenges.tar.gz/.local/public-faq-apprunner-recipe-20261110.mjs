export function awsPublicFaqTerraform(project,plan,environment='staging'){
 const b=builder(project,plan,environment,'aws'),{input,add}=b;
 const account=input('account_id','Expected destination AWS account; approved operator credential chain only.','123456789012','^[0-9]{12}$');
 const region=input('region','Reviewed commercial AWS region with App Runner and the direct Bedrock model; no cross-region inference fallback.','ap-southeast-2','^[a-z]{2}-[a-z]+-[0-9]$');
 const entries=plan.publicFaqPlan.entries;
 if(entries.every(e=>e.row.region===entries[0].row.region)&&/^[a-z]{2}-[a-z]+-[0-9]$/.test(entries[0].row.region)){b.variable.region.default=entries[0].row.region;b.examples.region=entries[0].row.region;}
 b.data.aws_caller_identity={destination:{}};
 b.resource.terraform_data.review_gate.lifecycle.precondition.push({condition:'${data.aws_caller_identity.destination.account_id == var.account_id}',error_message:'Approved operator must target the reviewed AWS account.'});
 b.data.aws_ecr_repository={};b.data.aws_ecr_image={};
 const trust=service=>JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Principal:{Service:service},Action:'sts:AssumeRole'}]});
 for(const {row}of entries){
  const n=row.address,name=input(n+'_name','Unique short application/IAM role name.','reviewed-public-help','^[a-z][a-z0-9-]{3,28}[a-z0-9]$');
  const repository=input(n+'_repository','Existing PRIVATE ECR repository in the reviewed account/region, with IMMUTABLE tags and no exclusions.','architect/public-help','^[a-z0-9]+(?:[._/-][a-z0-9]+)*$');
  const tag=input(n+'_image_tag','Unique reviewed build tag in that immutable repository; auto deployments stay disabled.','reviewed-build-001','^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$');
  const digest=input(n+'_image_digest','Exact digest of the built, scanned, tested and authorized-published image; checked against the tag before deployment.','sha256:'+'0'.repeat(64),'^sha256:[0-9a-f]{64}$');
  const model=input(n+'_model_id','Reviewed direct regional Converse foundation model ID; verify availability, model terms, quotas and retention-none compatibility.','anthropic.reviewed-model-v1:0','^[a-z0-9][a-z0-9.-]*:[0-9]+$');
  const editor=input(n+'_editor_principal_arn','Existing authorized same-account company editor role; it alone may assume the generated catalog editor role.','arn:aws:iam::123456789012:role/reviewed-company-editors','^arn:aws:iam::[0-9]{12}:role/[A-Za-z0-9_+=,.@/-]{1,512}$');
  b.resource.terraform_data.review_gate.lifecycle.precondition.push({condition:'${split(":", var.'+n+'_editor_principal_arn)[4] == var.account_id}',error_message:'Existing editor role must belong to this reviewed account.'});
  b.data.aws_ecr_repository[n]={name:repository,registry_id:account};
  b.data.aws_ecr_image[n]={repository_name:repository,registry_id:account,image_tag:tag};
  b.resource.terraform_data.review_gate.lifecycle.precondition.push({condition:'${data.aws_ecr_repository.'+n+'.image_tag_mutability == "IMMUTABLE" && length(data.aws_ecr_repository.'+n+'.image_tag_mutability_exclusion_filter) == 0 && data.aws_ecr_image.'+n+'.image_digest == var.'+n+'_image_digest}',error_message:'Use an immutable ECR repository without exclusions and a tag resolving to the exact qualified image digest.'});
  add('aws_s3_bucket',n,{bucket:account+'-'+name+'-catalog',force_destroy:false,lifecycle:{prevent_destroy:true}});
  const bucket=ref('aws_s3_bucket',n,'id'),bucketArn=ref('aws_s3_bucket',n,'arn'),objectArn=bucketArn+'/catalog.json';
  add('aws_s3_bucket_public_access_block',n,{bucket,block_public_acls:true,block_public_policy:true,ignore_public_acls:true,restrict_public_buckets:true});
  add('aws_s3_bucket_ownership_controls',n,{bucket,rule:{object_ownership:'BucketOwnerEnforced'}});
  add('aws_s3_bucket_server_side_encryption_configuration',n,{bucket,rule:{apply_server_side_encryption_by_default:{sse_algorithm:'AES256'},bucket_key_enabled:false}});
  add('aws_s3_bucket_versioning',n,{bucket,versioning_configuration:{status:'Enabled'}});
  add('aws_s3_bucket_lifecycle_configuration',n,{bucket,rule:{id:'expire-old-catalog-versions',status:'Enabled',filter:{prefix:''},noncurrent_version_expiration:{noncurrent_days:7},abort_incomplete_multipart_upload:{days_after_initiation:1}},depends_on:['aws_s3_bucket_versioning.'+n]});
  add('aws_s3_bucket_policy',n,{bucket,policy:JSON.stringify({Version:'2012-10-17',Statement:[{Sid:'RequireTLS',Effect:'Deny',Principal:'*',Action:'s3:*',Resource:[bucketArn,bucketArn+'/*'],Condition:{Bool:{'aws:SecureTransport':'false'}}}]}),depends_on:['aws_s3_bucket_public_access_block.'+n]});
  add('aws_iam_role',n,{name:name+'-runtime',assume_role_policy:trust('tasks.apprunner.amazonaws.com')});
  add('aws_iam_role_policy',n,{role:ref('aws_iam_role',n,'id'),policy:JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Action:['s3:GetObject'],Resource:objectArn},{Effect:'Allow',Action:['bedrock:InvokeModel'],Resource:'arn:aws:bedrock:'+region+'::foundation-model/'+model},{Effect:'Allow',Action:['bedrock:GetAccountDataRetention','bedrock:GetModelInvocationLoggingConfiguration'],Resource:'*',Condition:{StringEquals:{'aws:RequestedRegion':region}}}]})});
  add('aws_iam_role',n+'_pull',{name:name+'-pull',assume_role_policy:trust('build.apprunner.amazonaws.com')});
  add('aws_iam_role_policy',n+'_pull',{role:ref('aws_iam_role',n+'_pull','id'),policy:JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Action:['ecr:GetAuthorizationToken'],Resource:'*'},{Effect:'Allow',Action:['ecr:BatchCheckLayerAvailability','ecr:GetDownloadUrlForLayer','ecr:BatchGetImage','ecr:DescribeImages'],Resource:'${data.aws_ecr_repository.'+n+'.arn}'}]})});
  add('aws_iam_role',n+'_editor',{name:name+'-catalog-editor',assume_role_policy:JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Principal:{AWS:editor},Action:'sts:AssumeRole'}]})});
  add('aws_iam_role_policy',n+'_editor',{role:ref('aws_iam_role',n+'_editor','id'),policy:JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Action:['s3:GetObject','s3:PutObject'],Resource:objectArn}]})});
  add('aws_apprunner_auto_scaling_configuration_version',n,{auto_scaling_configuration_name:name,max_concurrency:5,min_size:1,max_size:2});
  const settings={REGION:region,ACCOUNT_ID:account,MODEL_ID:model,MAX_OUTPUT_TOKENS:'1024',CATALOG_BUCKET:bucket};
  add('aws_apprunner_service',n,{service_name:name,auto_scaling_configuration_arn:ref('aws_apprunner_auto_scaling_configuration_version',n,'arn'),instance_configuration:{cpu:'256',memory:'512',instance_role_arn:ref('aws_iam_role',n,'arn')},source_configuration:{auto_deployments_enabled:false,authentication_configuration:{access_role_arn:ref('aws_iam_role',n+'_pull','arn')},image_repository:{image_repository_type:'ECR',image_identifier:'${data.aws_ecr_repository.'+n+'.repository_url}:'+tag,image_configuration:{port:'8080',runtime_environment_variables:settings}}},health_check_configuration:{protocol:'HTTP',path:'/healthz',interval:5,timeout:2,healthy_threshold:1,unhealthy_threshold:5},network_configuration:{ingress_configuration:{is_publicly_accessible:true},egress_configuration:{egress_type:'DEFAULT'}},depends_on:['aws_iam_role_policy.'+n,'aws_iam_role_policy.'+n+'_pull','aws_s3_bucket_policy.'+n,'aws_s3_bucket_server_side_encryption_configuration.'+n,'aws_s3_bucket_versioning.'+n]});
  b.assertions.push(`run "${n}_mutable_repository_blocked" {
 command = plan
 override_data {
 target = data.aws_ecr_repository.${n}
 values = { image_tag_mutability = "MUTABLE", image_tag_mutability_exclusion_filter = [] }
 }
 expect_failures = [terraform_data.review_gate]
}
run "${n}_wrong_image_blocked" {
 command = plan
 override_data {
 target = data.aws_ecr_image.${n}
 values = { image_digest = "sha256:${'1'.repeat(64)}" }
 }
 expect_failures = [terraform_data.review_gate]
}`);
  b.output[n+'_url']={value:'https://'+ref('aws_apprunner_service',n,'service_url')+'/'};b.output[n+'_catalog']={value:{bucket,region}};b.output[n+'_editor_role_arn']={value:ref('aws_iam_role',n+'_editor','arn')};b.source(row);
  b.assertions.push(`run "${n}_public_boundary" {\n command = plan\n assert {\n condition = aws_s3_bucket_public_access_block.${n}.block_public_policy && aws_s3_bucket_public_access_block.${n}.restrict_public_buckets && !aws_s3_bucket.${n}.force_destroy\n error_message = "Public app must not grant anonymous object-store access or destructive bucket deletion."\n }\n assert {\n condition = jsondecode(aws_iam_role_policy.${n}.policy).Statement[0].Action == ["s3:GetObject"] && toset(jsondecode(aws_iam_role_policy.${n}_editor.policy).Statement[0].Action) == toset(["s3:GetObject", "s3:PutObject"])\n error_message = "Runtime and separate editor roles must retain exact catalog read versus conditional edit authority."\n }\n assert {\n condition = !aws_apprunner_service.${n}.source_configuration[0].auto_deployments_enabled && aws_apprunner_auto_scaling_configuration_version.${n}.max_concurrency == 5 && aws_apprunner_auto_scaling_configuration_version.${n}.max_size == 2\n error_message = "No unreviewed automatic image release or unbounded configured scaling."\n }\n}\nrun "${n}_mutable_image_blocked" {\n command = plan\n variables { ${n}_image_digest = "latest" }\n expect_failures = [var.${n}_image_digest]\n}`);
 }
 const config={terraform:{required_version:'>= 1.17.1, < 2.0.0',required_providers:{aws:{source:'hashicorp/aws',version:'6.72.0'}}},provider:{aws:{region,allowed_account_ids:[account],default_tags:{tags:{ManagedBy:'AtMem AI Architect',Environment:environment}}}}};
 const repositoryMocks=entries.map(({row:{address:n}})=>` override_data {\n target = data.aws_ecr_repository.${n}\n values = { arn = "arn:aws:ecr:${b.examples.region}:${b.examples.account_id}:repository/${b.examples[n+'_repository']}", repository_url = "${b.examples.account_id}.dkr.ecr.${b.examples.region}.amazonaws.com/${b.examples[n+'_repository']}", image_tag_mutability = "IMMUTABLE", image_tag_mutability_exclusion_filter = [] }\n }\n override_data {\n target = data.aws_ecr_image.${n}\n values = { image_digest = "${b.examples[n+'_image_digest']}" }\n }`).join('\n');
 const mocks=`mock_provider "aws" {\n override_during = plan\n mock_data "aws_caller_identity" { defaults = { account_id = "${b.examples.account_id}" } }\n mock_resource "aws_iam_role" { defaults = { arn = "arn:aws:iam::${b.examples.account_id}:role/mock-role" } }\n mock_resource "aws_s3_bucket" { defaults = { id = "mock-catalog", arn = "arn:aws:s3:::mock-catalog" } }\n mock_resource "aws_apprunner_auto_scaling_configuration_version" { defaults = { arn = "arn:aws:apprunner:${b.examples.region}:${b.examples.account_id}:autoscalingconfiguration/mock/1/12345678901234567890123456789012" } }\n${repositoryMocks}\n}\n`;
 b.assertions.push(`run "wrong_account_blocked" {\n command = plan\n variables { account_id = "999999999999" }\n expect_failures = [terraform_data.review_gate]\n}`);
 return b.finish(config,CLOUD_PROVIDER_LOCKS.aws,mocks,AWS_PUBLIC_FAQ_GUIDE);
}

export const AWS_PUBLIC_FAQ_GUIDE=`# AWS public-only FAQ composition

The generated anonymous browser/API runs on App Runner. Its instance role has only
GetObject on this private bucket's catalog.json, direct regional Bedrock InvokeModel
on the selected foundation model and regional read-only retention/logging checks.
A separate editor role, assumed by an existing reviewed company role, has Get/Put
only on catalog.json. Article deletion rewrites the manifest; object DELETE and
bucket administration are absent. Existing permissions can broaden effective
access and must be reviewed. No HTTP editing route, arbitrary source fetch, user
login or private knowledge authorization is implied by this public-only module.

The new bucket has all public-access blocks, owner-enforced ownership, AES256
encryption, TLS-only policy, versioning, seven-day noncurrent expiry and protected
deletion. Recovery versions are not an immediate-erasure guarantee. Only current
articles are retrieved and the source version is rechecked before returning an
answer. Questions/answers are not persisted or written to application logs; review
platform logs separately. Public endpoints use IAM rather than private networking.

App Runner uses an existing PRIVATE ECR repository with IMMUTABLE tags and no
exclusions. The precondition verifies the chosen build tag resolves to the exact
qualified digest and automatic deployments are disabled. This uses a verified tag,
not an unsupported claim that App Runner accepts a digest-form image identifier.
Protect registry deletion/tag-policy administration and retain the source, scan and
image evidence. The separate image-pull role has repository-scoped reads plus the
required account-level ECR token operation. Service-linked role creation may be
required by App Runner; review the destination operator's permissions.

See applications/*/BUILD.md for source, tests, build and conditional editor steps.
The synchronous Converse operation requests JSON and strictly validates returned
fields, source IDs and quoted evidence. It does not claim Bedrock constrained JSON
grammar: first-time grammar compilation can exceed the HTTP deadline. Bad output
fails closed; real model citation/answer/abstention and latency checks are required.
Before inference the app requires retention mode none and text logging disabled,
and never changes those account-wide controls. Verify model/region availability,
terms, quotas and current prices. A minimum warm App Runner instance incurs cost;
instance/concurrency/token bounds are not an invoice cap or anonymous abuse control.

Use Terraform 1.17.1+, init -backend=false, validate and test. Local provider mocks
are not real IAM, ECR, model or account-plan evidence. Build/scan/test the exact image,
seed only genuinely public articles and review budgets/abuse controls before traffic.
Protect state/variables and obtain authorization before registry publication, cloud
access, real plans or deployment. Production state/backup/operations remain gated.

References:
- https://docs.aws.amazon.com/apprunner/latest/dg/security_iam_service-with-iam.html
- https://docs.aws.amazon.com/bedrock/latest/userguide/structured-output.html
`;

