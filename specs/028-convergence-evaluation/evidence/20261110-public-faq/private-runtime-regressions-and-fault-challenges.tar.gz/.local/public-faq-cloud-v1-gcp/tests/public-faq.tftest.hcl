mock_provider "google" {
 override_during = plan
 mock_data "google_project" { defaults = { number = "123456789012" } }
 mock_resource "google_service_account" { defaults = { email = "runtime@reviewed-project.iam.gserviceaccount.com" } }
}
mock_provider "google-beta" {
 override_during = plan
 mock_resource "google_project_service_identity" { defaults = { email = "service-123456789012@serverless-robot-prod.iam.gserviceaccount.com", member = "serviceAccount:service-123456789012@serverless-robot-prod.iam.gserviceaccount.com" } }
}

variables {
review_approved = true
project_id = "reviewed-project"
registry_location = "australia-southeast1"
registry_repository = "reviewed-images"
block_666171_name = "reviewed-public-help"
block_666171_region = "australia-southeast1"
block_666171_image_repository = "architect/public-help"
block_666171_image_digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
block_666171_model_id = "gemini-reviewed-version"
block_666171_editor_group = "help-editors@example.test"
block_666171_policy_review = {"projectId":"reviewed-project","region":"australia-southeast1","model":"gemini-reviewed-version","abuseLogging":"REVIEW_REQUIRED","approvedBy":"REVIEW_REQUIRED","evidenceSha256":"0000000000000000000000000000000000000000000000000000000000000000","expiresAt":"REPLACE_AFTER_REVIEW"}
}
run "block_666171_public_boundary" {
 command = plan
 assert {
 condition = google_storage_bucket.block_666171.public_access_prevention == "enforced" && google_storage_bucket.block_666171.uniform_bucket_level_access && !google_storage_bucket.block_666171.force_destroy
 error_message = "Only the app is public; the catalog bucket stays private and protected."
 }
 assert {
 condition = google_cloud_run_v2_service_iam_member.block_666171.member == "allUsers" && google_cloud_run_v2_service_iam_member.block_666171.role == "roles/run.invoker" && !google_cloud_run_v2_service.block_666171.iap_enabled
 error_message = "This explicit public-only application has anonymous invocation, not an invented end-user identity."
 }
 assert {
 condition = google_project_iam_custom_role.block_666171_catalog.permissions == tolist(["storage.objects.get"]) && google_storage_bucket_iam_member.block_666171_editor.member == "group:${var.block_666171_editor_group}"
 error_message = "Runtime read and native editor write authority must remain separate."
 }
}
run "block_666171_mutable_image_blocked" {
 command = plan
 variables { block_666171_image_digest = "latest" }
 expect_failures = [var.block_666171_image_digest]
}
run "unapproved_blocked" {
 command = plan
 variables { review_approved = false }
 expect_failures = [terraform_data.review_gate]
}
