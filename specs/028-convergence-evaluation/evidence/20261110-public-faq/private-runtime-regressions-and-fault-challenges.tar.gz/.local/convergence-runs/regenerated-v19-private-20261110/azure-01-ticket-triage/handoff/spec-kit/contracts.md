# Component and interface contracts

Snapshot 6ef5b170-fd1b-49d7-be53-4a19517c92e2 · design r4 · generated 2026-11-09T22:00:24.812Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-browser: Team browser

- Responsibility: Existing team browser, outside provisioning scope. Staff paste a support ticket and review the returned summary, topic and suggested urgency. The browser does not enforce application authorization.
- Service: Web browser
- Provider / placement: tools / Existing client location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component ticket-triage-app: Ticket triage application

- Responsibility: Proposed composed azure-structured-app module on Azure App Service. Owns browser/API runtime, App Service plan, regional Azure OpenAI account/deployment, workload identity and single-tenant Entra application registrations; do not duplicate internal resources. Scope: ten signed-in staff paste synthetic or user-redacted tickets and review a short summary, topic, suggested urgency and uncertainty. No replies, customer-record changes, action tools, automatic redaction, source-system integration or durable ticket history. Browser remains an existing client outside provisioning scope. Propose one Linux App Service Basic B1 instance initially, subject to native module support, regional checks and load testing; no high-availability claim. Workload is about 200 tickets per working day with bursts of five simultaneous requests. Propose application admission control for five active inference requests per instance, bounded model calls and explicit retryable overload responses; config.concurrency records this target and does not prove App Service or application enforcement. Verify model quota against measured token usage and five-request bursts. Keep the 1024-token output bound. Propose Australia East for application and regional model processing, conditional on compatible model/version, quota and availability checks; region is not approved. No silent global model deployment, overseas fallback or cross-region failover. Review identity metadata, telemetry, model-provider handling, support paths and all other potential processing outside Australia before deployment. Australian resource placement alone does not prove residency. Accept only non-empty text in a validated request, up to 20000 UTF-8 bytes, rejecting larger inputs without truncation. Treat ticket text as untrusted. Validate model JSON server-side for required summary/topic/urgency/uncertainty fields, types and urgency vocabulary before returning it; invalid output must never become a fabricated suggestion. Proposed API behavior: 400 malformed/empty input, 413 oversized input, 401 unauthenticated, 403 unauthorized, 429 capacity exceeded, and bounded 502/503/504 inference or dependency failures as appropriate. Use content-free error codes and request identifiers; never echo ticket content or raw provider errors. Authorize users server-side before inference through proposed existing company-group assignment, subject to Entra group and licensing suitability. JWT authorization can persist until token expiry; immediate revocation and MFA policy are not established. Keep ticket text and generated suggestions transient; exclude them from server logs, traces, telemetry, caches, temporary files and browser persistent storage. Release request content after success or failure; propose clearing displayed content when review finishes. Model-side handling must satisfy no retention: ContentLogging=false approval must already exist before inference, and provider handling requires independent verification. Engineering must build and test an immutable image using an existing suitable RBAC-mode ACR, supply reviewed destination inputs, verify logging approval and regional model compatibility, and validate generated artifacts. Acceptance evidence must cover successful four-field responses, signed-out and denied users without model calls, malformed and oversized inputs, schema-invalid model output, prompt injection, model timeout/unavailability, five simultaneous requests, overload recovery and non-retention. Representative synthetic/redacted-ticket review must assess semantic quality separately from JSON validity. Propose content-free operational metrics for request totals, latency, errors and throttling; operating ownership and recovery needs remain open. Monthly charges for the plan, model tokens, ACR, identity licensing, monitoring and transfer are unknown without sourced rates and usage assumptions; one-off build effort/rates are separately unknown. Graph intent and compiler capability are not deployment or runtime evidence.
- Service: Azure App Service
- Provider / placement: azure / australiaeast
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7469636b65742d7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-triage-https: team-browser → ticket-triage-app

- Drawn payload/purpose: HTTPS: signed-in ticket submission; validated JSON suggestions or safe error
- Contract task: TASK-CONTRACT-62726f777365722d7472696167652d6874747073
- Integration task: TASK-INTEGRATION-62726f777365722d7472696167652d6874747073
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
