# Questions and assumptions to resolve

Snapshot 104d8dca-4994-4c9a-a567-a30146568a4b · design r4 · generated 2026-11-09T22:00:24.812Z

- [ai-ticket-suggestions] Confirm REQ-002: The application shall accept a pasted support ticket and display a short summary, topic and suggested urgency for human review; invalid or failed generation shall produce an explicit error rather than a fabricated suggestion.
- [ai-internal-ticket-access] Confirm REQ-003: Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open.
- [ai-ticket-input-bound] Confirm REQ-004: Accept pasted synthetic or redacted tickets up to 20,000 UTF-8 bytes, interpreting 20 KB as decimal; reject larger requests explicitly without truncating them.
- [ai-ticket-australian-processing] Confirm REQ-005: Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints.
- [ai-ticket-scope-boundary] Confirm REQ-006: The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version.
- [ai-ticket-capacity] Confirm REQ-007: Support ten signed-in staff processing approximately 200 tickets per working day and bursts of five simultaneous requests; demonstrate bounded resource use and explicit overload behavior through load tests. Response-time and availability targets remain unspecified.
- [ai-ticket-safe-failures] Confirm REQ-008: Reject malformed or oversized input and unauthorized users before inference; validate successful output against the four-field JSON contract and return safe explicit errors on timeout, provider failure or invalid output, without fabricated suggestions or ticket content in errors.
- [ai-ticket-cost-transparency] Confirm REQ-009: Document proposed runtime limits and itemize recurring cloud/AI cost drivers with sources or explicit unknowns; keep one-off build costs separate and do not treat daily ticket volume as monthly usage without a stated working-day assumption.
- [acceptance-req-8b32575a] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-suggestions] Agree a measurable acceptance check for REQ-002: The application shall accept a pasted support ticket and display a short summary, topic and suggested urgency for human review; invalid or failed generation shall produce an explicit error rather than a fabricated suggestion.
- [acceptance-ai-internal-ticket-access] Agree a measurable acceptance check for REQ-003: Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open.
- [acceptance-ai-ticket-australian-processing] Agree a measurable acceptance check for REQ-005: Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints.
- [acceptance-ai-ticket-scope-boundary] Agree a measurable acceptance check for REQ-006: The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version.
- [acceptance-ai-ticket-safe-failures] Agree a measurable acceptance check for REQ-008: Reject malformed or oversized input and unauthorized users before inference; validate successful output against the four-field JSON contract and return safe explicit errors on timeout, provider failure or invalid output, without fabricated suggestions or ticket content in errors.
- [acceptance-ai-ticket-cost-transparency] Agree a measurable acceptance check for REQ-009: Document proposed runtime limits and itemize recurring cloud/AI cost drivers with sources or explicit unknowns; keep one-off build costs separate and do not treat daily ticket volume as monthly usage without a stated working-day assumption.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d696e7465726e616c2d7469636b65742d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6175737472616c69616e2d70726f63657373696e67] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6361706163697479] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d636f73742d7472616e73706172656e6379] REQ-009 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d696e7075742d626f756e64] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d736166652d6661696c75726573] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d73636f70652d626f756e64617279] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d73756767657374696f6e73] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
