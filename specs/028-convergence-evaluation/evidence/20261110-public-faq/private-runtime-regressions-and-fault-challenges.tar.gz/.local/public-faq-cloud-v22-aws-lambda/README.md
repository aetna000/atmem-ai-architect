# AWS public-only FAQ: Lambda and HTTP API

This small synchronous public assistant uses generated Python 3.13 source with the
hash-pinned Mangum ASGI adapter, a published Lambda version/live alias and HTTP API
v2. It has no App Runner eligibility requirement, ECR dependency, always-on task or
load balancer. AWS closed App Runner to new customers; do not silently substitute
it or ask a basic visitor to resolve that restriction.

Run python3 build-runtime.py first. It builds the exact Linux x86_64 wheel closure
and deterministic ZIP from applications/* source, metadata and web assets. Retain
build/artifact-hashes.json. Run emitted faq_acceptance.py and the real Mangum HTTP
API event tests in a matching isolated Python environment; qualify the exact ZIP
inside the reviewed AWS Python 3.13 Linux runtime. Schema/mock/local tests never
establish real Lambda, IAM or model behavior. There is no Terraform execution hook.

The private S3 catalog has public-access blocks, TLS-only policy, AES256 encryption,
owner-enforced ownership, versioning and seven-day noncurrent expiry. Runtime has
GetObject only on catalog.json, direct selected regional Bedrock InvokeModel and
read-only regional retention/logging checks. A separate role assumed by the
existing reviewed company editor has Get/Put only on catalog.json. Article removal
conditionally rewrites the manifest; no object DELETE or bucket administration
is granted. Review inherited IAM and recovery/version-erasure requirements.

Seed genuinely public articles via the separate operator CLI before traffic. No
private source, arbitrary URL fetch, editing HTTP endpoint, end-user sign-in,
question/answer persistence or content-bearing application log is implemented.
Only the owned account/API receives permission to invoke the published live alias.
Same-origin checks are browser hygiene, not visitor authentication. Runtime logs
are WARN-only with seven-day retention; review all platform/audit logging separately.

Converse requests JSON with independently checked schema, source IDs and exact
quotes. It does not claim constrained Bedrock grammar, whose first compilation
can exceed this 29-second boundary. The app fails closed on invalid output, stale
or inaccessible source, unknown retention or enabled model text logging. It never
changes account-wide model policy. Verify actual model availability, retention-none
eligibility, region/context/quota/terms and real answer/citation/abstention/latency.
Long-running work requires the separate durable workflow contract, not a longer
synchronous timeout or a falsely successful response.

Reserved Lambda concurrency is five, with bounded HTTP API throttles. These are
capacity controls, not an invoice cap, anonymous abuse protection or SLA. Verify
destination concurrency quota, cold starts, current prices, budgets and abuse policy.
No prices are invented. Protect state and variable files. Review account/region,
native Terraform schemas/tests and a separately authorized real plan before apply.
No export proves deployment; production state/backup/operations remain gated.

References:
- https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html
- https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html
- https://mangum.fastapiexpert.com/adapter/
