mock_provider "aws" {
 override_during = plan
 mock_data "aws_caller_identity" { defaults = { account_id = "123456789012" } }
 mock_resource "aws_iam_role" { defaults = { arn = "arn:aws:iam::123456789012:role/mock-role" } }
 mock_resource "aws_s3_bucket" { defaults = { id = "mock-catalog", arn = "arn:aws:s3:::mock-catalog" } }
 mock_resource "aws_cloudwatch_log_group" { defaults = { arn = "arn:aws:logs:ap-southeast-2:123456789012:log-group:/aws/lambda/mock" } }
 mock_resource "aws_lambda_function" { defaults = { arn = "arn:aws:lambda:ap-southeast-2:123456789012:function:mock", version = "1" } }
 mock_resource "aws_lambda_alias" { defaults = { arn = "arn:aws:lambda:ap-southeast-2:123456789012:function:mock:live", invoke_arn = "arn:aws:apigateway:ap-southeast-2:lambda:path/2015-03-31/functions/arn:aws:lambda:ap-southeast-2:123456789012:function:mock:live/invocations" } }
 mock_resource "aws_apigatewayv2_api" { defaults = { id = "mockapi1234", api_endpoint = "https://mockapi1234.execute-api.ap-southeast-2.amazonaws.com", execution_arn = "arn:aws:execute-api:ap-southeast-2:123456789012:mockapi1234" } }
}

variables {
review_approved = true
account_id = "123456789012"
region = "ap-southeast-2"
block_666171_name = "reviewed-public-help"
block_666171_model_id = "anthropic.reviewed-model-v1:0"
block_666171_editor_principal_arn = "arn:aws:iam::123456789012:role/reviewed-company-editors"
}
run "block_666171_public_boundary" {
 command = plan
 assert {
 condition = aws_s3_bucket_public_access_block.block_666171.block_public_policy && aws_s3_bucket_public_access_block.block_666171.restrict_public_buckets && !aws_s3_bucket.block_666171.force_destroy
 error_message = "Only the app is public; catalog storage remains private and protected."
 }
 assert {
 condition = jsondecode(aws_iam_role_policy.block_666171.policy).Statement[0].Action == ["s3:GetObject"] && toset(jsondecode(aws_iam_role_policy.block_666171_editor.policy).Statement[0].Action) == toset(["s3:GetObject", "s3:PutObject"])
 error_message = "Workload read and separate conditional editor write authority must stay distinct."
 }
 assert {
 condition = aws_lambda_function.block_666171.reserved_concurrent_executions == 5 && aws_lambda_function.block_666171.timeout == 29 && aws_apigatewayv2_integration.block_666171.payload_format_version == "2.0" && aws_apigatewayv2_route.block_666171.authorization_type == "NONE"
 error_message = "This explicit public-only synchronous module uses bounded Lambda concurrency and the implemented HTTP API v2 event contract."
 }
 assert {
 condition = aws_lambda_permission.block_666171.source_account == var.account_id && aws_lambda_permission.block_666171.qualifier == "live"
 error_message = "Only the owned account/API may invoke the published live alias."
 }
}
run "wrong_account_blocked" {
 command = plan
 variables { account_id = "999999999999" }
 expect_failures = [terraform_data.review_gate]
}
run "unapproved_blocked" {
 command = plan
 variables { review_approved = false }
 expect_failures = [terraform_data.review_gate]
}
