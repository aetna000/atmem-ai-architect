Snapshot 3d02b058-6119-4b77-b103-d415acb58fad · design r5 · generated 2026-11-09T22:04:57.708Z

# Cited public FAQ — deployment document

Generated 2026-11-09 22:04 UTC from design revision r5 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** 30,000 requests/month (discovery (2026-11-10))
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 6 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. About 1,000 questions per day and five at once. Answers need valid source citations; unsupported questions must abstain; updates and deletions must affect retrieval. Recommend the simplest suitable retrieval approach and a small footprint. Show assumptions and missing current price evidence.
- **Systems it connects to:** —
- **How good, fast and safe:** Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. Australia is preferred; make model/data-location limitations explicit.
- **Cloud preference:** AWS Anonymous website visitors; an authorized editor manages the articles.
- **Budget and timeline:** —

## 3. Architecture

**Public access**

- Anonymous website visitors (Tools & data, existing) — Existing visitor browsers outside provisioning scope. Submit questions and receive cited answers or an explicit abstention over HTTPS; no visitor account is proposed.

**Public answers**

- Public help assistant (AWS, sketch) — Proposed public-faq-app module: public browser/API, private regional Amazon S3 article catalog, read-only runtime identity, separate authorized publishing identity and regional Amazon Bedrock model transport. AWS App Runner hosting is conditional on existing-customer eligibility: supplied reviewed guidance reports closure to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html, reviewed 2026-11-07); account eligibility has not been verified. If unavailable, preserve the full FAQ scope and implement an alternative AWS hosting adapter rather than substituting a container footprint alone. Internal catalog, model transport and identities belong to this module. Initial collection: twenty public UTF-8 articles supplied as files, each under 30 KB. Includes questions, cited answers with supporting quotes, explicit abstention, and authorized article publication, updates and deletion. Excludes private-source retrieval, private connectors and arbitrary URL fetching. Article content is untrusted data. Conditional versioned publishing rejects conflicting edits; in-flight source changes withhold answers without cached-source fallback. Built-in bounds remain 100 articles of at most 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Validate file byte sizes during publication; reject oversized inputs explicitly. Sydney (ap-southeast-2) is proposed because Australia is preferred, not approved regional placement or proof of Australian-only processing. Verify hosting eligibility, direct regional model availability, model retention/logging policy, processing geography and any global routing before deployment; no cross-region inference fallback is proposed. Single-region operation is proposed without cross-region disaster recovery. Visitor questions may contain personal information despite the public article collection; question logging and retention need review. Public abuse controls, inherited permissions and operational ownership remain unresolved. Build, scan and test the emitted image and validate artifact-bound behavior, including deletion and failure paths; citations alone do not establish answer accuracy. Recommended retrieval: bounded keyword ranking over the current published catalog, supplying at most two complete articles to the model; no embeddings, separate vector database or additional deployment is proposed. Lexical retrieval can miss paraphrases, so representative questions must establish suitability before handoff. Expected demand is about 1000 questions/day and five simultaneous questions; a 30-day estimating month gives about 30000 questions/month. The five-request admission bound is not demonstrated capacity or an invoice cap; test five concurrent requests and controlled overload without assuming a latency target. Validate citation source membership and exact supporting quotes against the current catalog revision; separately evaluate whether the cited text actually supports the answer. Unsupported questions must abstain; catalog/model failures and malformed outputs must fail safely without unsupported answers. Acceptance evidence must include answerable and unsupported questions, paraphrases, unauthorized publishing, conflicting edits, updates, deletions during requests, stale-source rejection, concurrency and dependency failures. Model accuracy, live permissions, hosting eligibility and production behavior remain unverified.

**Article publishing**

- Authorized article editor (Tools & data, existing) — Reference to the client's authorized publishing operator, outside provisioning scope. Uses the generated operator CLI to publish, update and delete public articles through conditional catalog changes. Requires an explicitly supplied authorized native identity; no identity or permission has been verified. Publishing authorization must be enforced by the storage service: anonymous visitors and the read-only application runtime must not modify the article catalog. Reject unauthorized publishing attempts without changing articles. This management interface is separate from the public visitor website.

```mermaid
flowchart LR
  n0["Anonymous website visitors<br/>Tools & data"]
  n1["Public help assistant<br/>AWS"]
  n2["Authorized article editor<br/>Tools & data"]
  n0 -->|Anonymous HTTPS questions; cited answers or abstention| n1
  n2 -->|Authorized CLI: publish, update and delete articles| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitors | Anonymous website visitors | tools | Web browser | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public help assistant | aws | AWS App Runner | ap-southeast-2 | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article editor | tools | Operator CLI | Not applicable | Existing | Existing public catalog editor — provider-native role/group input and separate conditional editor CLI generated; actual access unverified |

### Resources and cost dimensions

- **Anonymous website visitors** (faq-visitors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public help assistant** (faq-app): aws_apprunner_service, aws_s3_bucket, aws_iam_role. Provisioned and active compute, builds, logs and transfer. Depends on: faq-visitors, faq-editor.
- **Authorized article editor** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Anonymous website visitors | Public help assistant | Anonymous HTTPS questions; cited answers or abstention | Public |
| Authorized article editor | Public help assistant | Authorized CLI: publish, update and delete articles | Public |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved. (must)
- Requirement: Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia. (should)
- Requirement: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia. | compliance | not measurable yet | Open |
| The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks. | performance | simultaneous_questions_supported >= 5questions | Open |

**Functional**

- Every answer shows its sources (should, open)
- The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved. (must, open)
- An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers. (must, open)
- Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 1 block is sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Authorized article editor | Data processed | needs data_gb | price needed | — | — |

**Usage inputs:** Data stored: — (needed).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Anonymous website visitors, Public help assistant.

**Estimate gaps:**

- Authorized article editor / Data processed: input needed (data_gb).
- Anonymous website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public help assistant: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public answers: Public help assistant.
4. Connect existing systems: Anonymous website visitors, Authorized article editor; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
- Authorized article editor: needs data_gb _(estimate)_
