# Component and interface contracts

Snapshot 3d02b058-6119-4b77-b103-d415acb58fad · design r5 · generated 2026-11-09T22:04:57.708Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-visitors: Anonymous website visitors

- Responsibility: Existing visitor browsers outside provisioning scope. Submit questions and receive cited answers or an explicit abstention over HTTPS; no visitor account is proposed.
- Service: Web browser
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d76697369746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public help assistant

- Responsibility: Proposed public-faq-app module: public browser/API, private regional Amazon S3 article catalog, read-only runtime identity, separate authorized publishing identity and regional Amazon Bedrock model transport. AWS App Runner hosting is conditional on existing-customer eligibility: supplied reviewed guidance reports closure to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html, reviewed 2026-11-07); account eligibility has not been verified. If unavailable, preserve the full FAQ scope and implement an alternative AWS hosting adapter rather than substituting a container footprint alone. Internal catalog, model transport and identities belong to this module. Initial collection: twenty public UTF-8 articles supplied as files, each under 30 KB. Includes questions, cited answers with supporting quotes, explicit abstention, and authorized article publication, updates and deletion. Excludes private-source retrieval, private connectors and arbitrary URL fetching. Article content is untrusted data. Conditional versioned publishing rejects conflicting edits; in-flight source changes withhold answers without cached-source fallback. Built-in bounds remain 100 articles of at most 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Validate file byte sizes during publication; reject oversized inputs explicitly. Sydney (ap-southeast-2) is proposed because Australia is preferred, not approved regional placement or proof of Australian-only processing. Verify hosting eligibility, direct regional model availability, model retention/logging policy, processing geography and any global routing before deployment; no cross-region inference fallback is proposed. Single-region operation is proposed without cross-region disaster recovery. Visitor questions may contain personal information despite the public article collection; question logging and retention need review. Public abuse controls, inherited permissions and operational ownership remain unresolved. Build, scan and test the emitted image and validate artifact-bound behavior, including deletion and failure paths; citations alone do not establish answer accuracy. Recommended retrieval: bounded keyword ranking over the current published catalog, supplying at most two complete articles to the model; no embeddings, separate vector database or additional deployment is proposed. Lexical retrieval can miss paraphrases, so representative questions must establish suitability before handoff. Expected demand is about 1000 questions/day and five simultaneous questions; a 30-day estimating month gives about 30000 questions/month. The five-request admission bound is not demonstrated capacity or an invoice cap; test five concurrent requests and controlled overload without assuming a latency target. Validate citation source membership and exact supporting quotes against the current catalog revision; separately evaluate whether the cited text actually supports the answer. Unsupported questions must abstain; catalog/model failures and malformed outputs must fail safely without unsupported answers. Acceptance evidence must include answerable and unsupported questions, paraphrases, unauthorized publishing, conflicting edits, updates, deletions during requests, stale-source rejection, concurrency and dependency failures. Model accuracy, live permissions, hosting eligibility and production behavior remain unverified.
- Service: AWS App Runner
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Verify account eligibility before retaining App Runner; it is closed to new customers. Record the hosting decision and current official availability evidence.
- Specify one deployment unit per actual application, immutable image, registry access, instance role, ingress/egress, health checks and scaling.
- Design identity sessions, secrets, custom domain/TLS, logs and rollback; test deployment health and source dependency failures.

## Component faq-editor: Authorized article editor

- Responsibility: Reference to the client's authorized publishing operator, outside provisioning scope. Uses the generated operator CLI to publish, update and delete public articles through conditional catalog changes. Requires an explicitly supplied authorized native identity; no identity or permission has been verified. Publishing authorization must be enforced by the storage service: anonymous visitors and the read-only application runtime must not modify the article catalog. Reject unauthorized publishing attempts without changing articles. This management interface is separate from the public visitor website.
- Service: Operator CLI
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-visitors-app: faq-visitors → faq-app

- Drawn payload/purpose: Anonymous HTTPS questions; cited answers or abstention
- Contract task: TASK-CONTRACT-6661712d76697369746f72732d617070
- Integration task: TASK-INTEGRATION-6661712d76697369746f72732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-app: faq-editor → faq-app

- Drawn payload/purpose: Authorized CLI: publish, update and delete articles
- Contract task: TASK-CONTRACT-6661712d656469746f722d617070
- Integration task: TASK-INTEGRATION-6661712d656469746f722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
