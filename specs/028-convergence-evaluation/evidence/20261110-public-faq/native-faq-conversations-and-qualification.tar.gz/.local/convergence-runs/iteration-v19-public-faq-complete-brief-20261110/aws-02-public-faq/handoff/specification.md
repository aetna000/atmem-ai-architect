Snapshot 3d02b058-6119-4b77-b103-d415acb58fad · design r5 · generated 2026-11-09T22:04:57.708Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-002] The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved. (must, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Prevents private information from entering a public answer and makes unsupported questions fail safely.

Basis: “answers questions from our twenty public help articles” and “It must not answer from private sources.”
- [REQ-003] An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers. (must, open); target: acceptance target needed; linked blocks: faq-editor, faq-app

Design explanation: Keeps published answers aligned with current articles and prevents visitors from altering the collection; separate authorized publishing is a proposed control.

Basis: “We need to update and remove articles.”
- [REQ-004] Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia. (should, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Proposed processing-location safeguard: an Australian region label alone cannot establish where model inference, logs or routing process data.

Basis: “Australia is preferred; make model/data-location limitations explicit.”
- [REQ-005] Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission. (must, open); target: acceptance target needed; linked blocks: faq-visitors, faq-editor, faq-app

Design explanation: Separating anonymous questions from authenticated publishing prevents visitors or the answering runtime from changing the public knowledge collection. Enforcement and denied-access behavior require independent tests.

Basis: “Anonymous website visitors; an authorized editor manages the articles.” Existing faq-visitors and faq-editor paths connect to faq-app.
- [REQ-006] The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks. (must, open); target: simultaneous_questions_supported >= 5questions; linked blocks: faq-app, faq-visitors

Design explanation: Preserves the stated peak demand as a capacity acceptance target; a configured admission limit alone does not establish successful concurrent operation.

Basis: About 1,000 questions per day and five at once.

## How the system works

The current design contains 3 components and 2 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Anonymous website visitors → Public help assistant

Anonymous HTTPS questions; cited answers or abstention

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Authorized article editor → Public help assistant

Authorized CLI: publish, update and delete articles

Integration contract: public-catalog-edit.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Anonymous website visitors

Web browser · tools · region: Not applicable · classification: Public

Existing visitor browsers outside provisioning scope. Submit questions and receive cited answers or an explicit abstention over HTTPS; no visitor account is proposed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Anonymous website visitors → Public help assistant: Anonymous HTTPS questions; cited answers or abstention (integration: browser-https)

Requirement traceability: REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.; REQ-006: The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public help assistant

AWS App Runner · aws · region: ap-southeast-2 · classification: Public

Proposed public-faq-app module: public browser/API, private regional Amazon S3 article catalog, read-only runtime identity, separate authorized publishing identity and regional Amazon Bedrock model transport. AWS App Runner hosting is conditional on existing-customer eligibility: supplied reviewed guidance reports closure to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html, reviewed 2026-11-07); account eligibility has not been verified. If unavailable, preserve the full FAQ scope and implement an alternative AWS hosting adapter rather than substituting a container footprint alone. Internal catalog, model transport and identities belong to this module. Initial collection: twenty public UTF-8 articles supplied as files, each under 30 KB. Includes questions, cited answers with supporting quotes, explicit abstention, and authorized article publication, updates and deletion. Excludes private-source retrieval, private connectors and arbitrary URL fetching. Article content is untrusted data. Conditional versioned publishing rejects conflicting edits; in-flight source changes withhold answers without cached-source fallback. Built-in bounds remain 100 articles of at most 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Validate file byte sizes during publication; reject oversized inputs explicitly. Sydney (ap-southeast-2) is proposed because Australia is preferred, not approved regional placement or proof of Australian-only processing. Verify hosting eligibility, direct regional model availability, model retention/logging policy, processing geography and any global routing before deployment; no cross-region inference fallback is proposed. Single-region operation is proposed without cross-region disaster recovery. Visitor questions may contain personal information despite the public article collection; question logging and retention need review. Public abuse controls, inherited permissions and operational ownership remain unresolved. Build, scan and test the emitted image and validate artifact-bound behavior, including deletion and failure paths; citations alone do not establish answer accuracy. Recommended retrieval: bounded keyword ranking over the current published catalog, supplying at most two complete articles to the model; no embeddings, separate vector database or additional deployment is proposed. Lexical retrieval can miss paraphrases, so representative questions must establish suitability before handoff. Expected demand is about 1000 questions/day and five simultaneous questions; a 30-day estimating month gives about 30000 questions/month. The five-request admission bound is not demonstrated capacity or an invoice cap; test five concurrent requests and controlled overload without assuming a latency target. Validate citation source membership and exact supporting quotes against the current catalog revision; separately evaluate whether the cited text actually supports the answer. Unsupported questions must abstain; catalog/model failures and malformed outputs must fail safely without unsupported answers. Acceptance evidence must include answerable and unsupported questions, paraphrases, unauthorized publishing, conflicting edits, updates, deletions during requests, stale-source rejection, concurrency and dependency failures. Model accuracy, live permissions, hosting eligibility and production behavior remain unverified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Anonymous website visitors → Public help assistant: Anonymous HTTPS questions; cited answers or abstention (integration: browser-https); Authorized article editor → Public help assistant: Authorized CLI: publish, update and delete articles (integration: public-catalog-edit)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved.; REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.; REQ-004: Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia.; REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.; REQ-006: The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks.

Implementation status: Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Verify account eligibility before retaining App Runner; it is closed to new customers. Record the hosting decision and current official availability evidence.
- Specify one deployment unit per actual application, immutable image, registry access, instance role, ingress/egress, health checks and scaling.
- Design identity sessions, secrets, custom domain/TLS, logs and rollback; test deployment health and source dependency failures.

### Authorized article editor

Operator CLI · tools · region: Not applicable · classification: Public

Reference to the client's authorized publishing operator, outside provisioning scope. Uses the generated operator CLI to publish, update and delete public articles through conditional catalog changes. Requires an explicitly supplied authorized native identity; no identity or permission has been verified. Publishing authorization must be enforced by the storage service: anonymous visitors and the read-only application runtime must not modify the article catalog. Reject unauthorized publishing attempts without changing articles. This management interface is separate from the public visitor website.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorized article editor → Public help assistant: Authorized CLI: publish, update and delete articles (integration: public-catalog-edit)

Requirement traceability: REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.; REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.

Implementation status: Existing public catalog editor — provider-native role/group input and separate conditional editor CLI generated; actual access unverified

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Anonymous website visitors<br/>Tools & data"]
  n1["Public help assistant<br/>AWS"]
  n2["Authorized article editor<br/>Tools & data"]
  n0 -->|Anonymous HTTPS questions; cited answers or abstention| n1
  n2 -->|Authorized CLI: publish, update and delete articles| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitors | Anonymous website visitors | tools | Web browser | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public help assistant | aws | AWS App Runner | ap-southeast-2 | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article editor | tools | Operator CLI | Not applicable | Existing | Existing public catalog editor — provider-native role/group input and separate conditional editor CLI generated; actual access unverified |

### Resources and cost dimensions

- **Anonymous website visitors** (faq-visitors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public help assistant** (faq-app): aws_apprunner_service, aws_s3_bucket, aws_iam_role. Provisioned and active compute, builds, logs and transfer. Depends on: faq-visitors, faq-editor.
- **Authorized article editor** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
