# Detailed implementation tasks

Snapshot 3d02b058-6119-4b77-b103-d415acb58fad · design r5 · generated 2026-11-09T22:04:57.708Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use emitted Python 3.13 applications/* source and BUILD.md. Install hash-locked runtime and test requirements in isolated provider environments and run faq_acceptance.py -v. Build, scan and test the exact Linux/amd64 image; obtain authorization before registry publication. Supply reviewed destination, image and model/policy inputs from deployment.tfvars.json.example. The runtime, port 8080, public-only retrieval, citations/abstention, source freshness, private catalog read role and separate editor grants are generated; do not ask the user to invent them. Seed the catalog only from a reviewed genuinely public UTF-8 directory using public_catalog_admin.py init. For updates/deletions inspect the current version, review and confirm the conditional write. Test unknown questions, prompt injection, concurrent edits and in-flight source changes. Source fixtures/schema/mock plans are not real cloud IAM, model quality or deployed evidence. Keep AWS versus IBM SDK dependency environments separate.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d76697369746f72732d617070 — Define Anonymous website visitors → Public help assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-visitors, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-visitors-app: Anonymous HTTPS questions; cited answers or abstention. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-visitors-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d656469746f722d617070 — Define Authorized article editor → Public help assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-editor, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-editor-app: Authorized CLI: publish, update and delete articles. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-editor-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d76697369746f7273 — Integrate existing Anonymous website visitors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d76697369746f72732d617070
- Components: faq-visitors
- Generated files: No implementation files generated yet
- Requirements: ai-public-access, ai-public-capacity

### Implementation steps

1. Responsibility from the board: Existing visitor browsers outside provisioning scope. Submit questions and receive cited answers or an explicit abstention over HTTPS; no visitor account is proposed.
2. Verify Web browser on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.; REQ-006: The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-visitors
- Application/configuration and tests for Anonymous website visitors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Validate generated Public help assistant

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d76697369746f72732d617070, TASK-CONTRACT-6661712d656469746f722d617070
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-grounding, ai-public-publishing, ai-public-location, ai-public-access, ai-public-capacity

### Implementation steps

1. Responsibility from the board: Proposed public-faq-app module: public browser/API, private regional Amazon S3 article catalog, read-only runtime identity, separate authorized publishing identity and regional Amazon Bedrock model transport. AWS App Runner hosting is conditional on existing-customer eligibility: supplied reviewed guidance reports closure to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html, reviewed 2026-11-07); account eligibility has not been verified. If unavailable, preserve the full FAQ scope and implement an alternative AWS hosting adapter rather than substituting a container footprint alone. Internal catalog, model transport and identities belong to this module. Initial collection: twenty public UTF-8 articles supplied as files, each under 30 KB. Includes questions, cited answers with supporting quotes, explicit abstention, and authorized article publication, updates and deletion. Excludes private-source retrieval, private connectors and arbitrary URL fetching. Article content is untrusted data. Conditional versioned publishing rejects conflicting edits; in-flight source changes withhold answers without cached-source fallback. Built-in bounds remain 100 articles of at most 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Validate file byte sizes during publication; reject oversized inputs explicitly. Sydney (ap-southeast-2) is proposed because Australia is preferred, not approved regional placement or proof of Australian-only processing. Verify hosting eligibility, direct regional model availability, model retention/logging policy, processing geography and any global routing before deployment; no cross-region inference fallback is proposed. Single-region operation is proposed without cross-region disaster recovery. Visitor questions may contain personal information despite the public article collection; question logging and retention need review. Public abuse controls, inherited permissions and operational ownership remain unresolved. Build, scan and test the emitted image and validate artifact-bound behavior, including deletion and failure paths; citations alone do not establish answer accuracy. Recommended retrieval: bounded keyword ranking over the current published catalog, supplying at most two complete articles to the model; no embeddings, separate vector database or additional deployment is proposed. Lexical retrieval can miss paraphrases, so representative questions must establish suitability before handoff. Expected demand is about 1000 questions/day and five simultaneous questions; a 30-day estimating month gives about 30000 questions/month. The five-request admission bound is not demonstrated capacity or an invoice cap; test five concurrent requests and controlled overload without assuming a latency target. Validate citation source membership and exact supporting quotes against the current catalog revision; separately evaluate whether the cited text actually supports the answer. Unsupported questions must abstain; catalog/model failures and malformed outputs must fail safely without unsupported answers. Acceptance evidence must include answerable and unsupported questions, paraphrases, unauthorized publishing, conflicting edits, updates, deletions during requests, stale-source rejection, concurrency and dependency failures. Model accuracy, live permissions, hosting eligibility and production behavior remain unverified.
2. Verify AWS App Runner on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Verify account eligibility before retaining App Runner; it is closed to new customers. Record the hosting decision and current official availability evidence.
5. Specify one deployment unit per actual application, immutable image, registry access, instance role, ingress/egress, health checks and scaling.
6. Design identity sessions, secrets, custom domain/TLS, logs and rollback; test deployment health and source dependency failures.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved.; REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.; REQ-004: Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia.; REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.; REQ-006: The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for Public help assistant

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d656469746f72 — Integrate existing Authorized article editor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d656469746f722d617070
- Components: faq-editor
- Generated files: No implementation files generated yet
- Requirements: ai-public-publishing, ai-public-access

### Implementation steps

1. Responsibility from the board: Reference to the client's authorized publishing operator, outside provisioning scope. Uses the generated operator CLI to publish, update and delete public articles through conditional catalog changes. Requires an explicitly supplied authorized native identity; no identity or permission has been verified. Publishing authorization must be enforced by the storage service: anonymous visitors and the read-only application runtime must not modify the article catalog. Reject unauthorized publishing attempts without changing articles. This management interface is separate from the public visitor website.
2. Verify Operator CLI on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.; REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-editor
- Application/configuration and tests for Authorized article editor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d76697369746f72732d617070 — Wire Anonymous website visitors to Public help assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d76697369746f72732d617070, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070
- Components: faq-visitors, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge faq-visitors-app in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-visitors-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d656469746f722d617070 — Wire Authorized article editor to Public help assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d656469746f722d617070, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72
- Components: faq-editor, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated public-catalog-edit contract for edge faq-editor-app in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-editor-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070 — Verify live Anonymous website visitors → Public help assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d76697369746f72732d617070
- Components: faq-visitors, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-visitors-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-visitors-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d656469746f722d617070 — Verify live Authorized article editor → Public help assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d656469746f722d617070
- Components: faq-editor, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-editor-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-editor-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3561323963373331 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-5a29c731

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67 — Verify REQ-002: The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-grounding

### Implementation steps

1. Basis: “answers questions from our twenty public help articles” and “It must not answer from private sources.”; rationale: Prevents private information from entering a public answer and makes unsupported questions fail safely.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d7075626c697368696e67 — Verify REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: faq-editor, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-publishing

### Implementation steps

1. Basis: “We need to update and remove articles.”; rationale: Keeps published answers aligned with current articles and prevents visitors from altering the collection; separate authorized publishing is a proposed control.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d6c6f636174696f6e — Verify REQ-004: Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-location

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.”; rationale: Proposed processing-location safeguard: an Australian region label alone cannot establish where model inference, logs or routing process data.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d616363657373 — Verify REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: faq-visitors, faq-editor, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-access

### Implementation steps

1. Basis: “Anonymous website visitors; an authorized editor manages the articles.” Existing faq-visitors and faq-editor paths connect to faq-app.; rationale: Separating anonymous questions from authenticated publishing prevents visitors or the answering runtime from changing the public knowledge collection. Enforcement and denied-access behavior require independent tests.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d6361706163697479 — Verify REQ-006: The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: faq-app, faq-visitors
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/aws_json_model.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-capacity

### Implementation steps

1. Basis: About 1,000 questions per day and five at once.; rationale: Preserves the stated peak demand as a capacity acceptance target; a configured admission limit alone does not establish successful concurrent operation.
2. Implement a check for simultaneous_questions_supported >= 5 questions; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-6661712d76697369746f72732d617070, TASK-INTEGRATION-6661712d656469746f722d617070
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3561323963373331, TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67, TASK-ACCEPTANCE-61692d7075626c69632d7075626c697368696e67, TASK-ACCEPTANCE-61692d7075626c69632d6c6f636174696f6e, TASK-ACCEPTANCE-61692d7075626c69632d616363657373, TASK-ACCEPTANCE-61692d7075626c69632d6361706163697479, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
