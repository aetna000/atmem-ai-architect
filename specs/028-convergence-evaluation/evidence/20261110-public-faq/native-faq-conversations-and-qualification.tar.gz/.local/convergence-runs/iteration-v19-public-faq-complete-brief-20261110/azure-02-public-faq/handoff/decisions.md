Snapshot a92ec325-3ec2-4852-8a2a-4b7e1d2baf42 · design r4 · generated 2026-11-09T22:08:04.731Z

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—
