# Questions and assumptions to resolve

Snapshot 3d02b058-6119-4b77-b103-d415acb58fad · design r5 · generated 2026-11-09T22:04:57.708Z

- [ai-public-grounding] Confirm REQ-002: The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved.
- [ai-public-publishing] Confirm REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.
- [ai-public-location] Confirm REQ-004: Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia.
- [ai-public-access] Confirm REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.
- [ai-public-capacity] Confirm REQ-006: The public assistant must support five simultaneous visitor questions at an expected volume of about 1,000 questions per day; acceptance testing must demonstrate concurrent handling and controlled overload without weakening citation, abstention or source-freshness checks.
- [acceptance-req-5a29c731] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-public-grounding] Agree a measurable acceptance check for REQ-002: The public assistant must answer only from the explicitly published public article collection and state that it does not know when the collection provides insufficient support; private sources must not be retrieved.
- [acceptance-ai-public-publishing] Agree a measurable acceptance check for REQ-003: An authorized publishing operator must be able to add, update and remove public articles through a separate management interface; conflicting edits must be rejected and changed or removed sources must not support subsequent answers.
- [acceptance-ai-public-location] Agree a measurable acceptance check for REQ-004: Prefer Australian storage and processing; document actual article, question, model and log processing locations and retention before deployment, and obtain a business decision for any proposed processing outside Australia.
- [acceptance-ai-public-access] Agree a measurable acceptance check for REQ-005: Visitors must be able to ask questions without signing in. Only an authorized publishing identity may add, update or delete articles; anonymous visitors and the answering runtime must have no catalog-write permission.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [service-lifecycle-apprunner] App Runner eligibility needs verification. AWS closed App Runner to new customers. Verify existing-customer eligibility or agree an alternative. Source: https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html (reviewed 2026-11-07).
- [requirement-proposed-61692d7075626c69632d616363657373] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d6361706163697479] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d67726f756e64696e67] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d6c6f636174696f6e] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d7075626c697368696e67] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
