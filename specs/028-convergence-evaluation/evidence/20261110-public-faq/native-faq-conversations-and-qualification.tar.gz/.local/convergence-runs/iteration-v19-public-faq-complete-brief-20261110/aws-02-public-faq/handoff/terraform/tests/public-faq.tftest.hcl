mock_provider "aws" {
 override_during = plan
 mock_data "aws_caller_identity" { defaults = { account_id = "123456789012" } }
 mock_resource "aws_iam_role" { defaults = { arn = "arn:aws:iam::123456789012:role/mock-role" } }
 mock_resource "aws_s3_bucket" { defaults = { id = "mock-catalog", arn = "arn:aws:s3:::mock-catalog" } }
 mock_resource "aws_apprunner_auto_scaling_configuration_version" { defaults = { arn = "arn:aws:apprunner:ap-southeast-2:123456789012:autoscalingconfiguration/mock/1/12345678901234567890123456789012" } }
 override_data {
 target = data.aws_ecr_repository.block_6661712d617070
 values = { arn = "arn:aws:ecr:ap-southeast-2:123456789012:repository/architect/public-help", repository_url = "123456789012.dkr.ecr.ap-southeast-2.amazonaws.com/architect/public-help", image_tag_mutability = "IMMUTABLE", image_tag_mutability_exclusion_filter = [] }
 }
 override_data {
 target = data.aws_ecr_image.block_6661712d617070
 values = { image_digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000" }
 }
}

variables {
review_approved = true
account_id = "123456789012"
region = "ap-southeast-2"
block_6661712d617070_name = "reviewed-public-help"
block_6661712d617070_repository = "architect/public-help"
block_6661712d617070_image_tag = "reviewed-build-001"
block_6661712d617070_image_digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
block_6661712d617070_model_id = "anthropic.reviewed-model-v1:0"
block_6661712d617070_editor_principal_arn = "arn:aws:iam::123456789012:role/reviewed-company-editors"
}
run "block_6661712d617070_mutable_repository_blocked" {
 command = plan
 override_data {
 target = data.aws_ecr_repository.block_6661712d617070
 values = { image_tag_mutability = "MUTABLE", image_tag_mutability_exclusion_filter = [] }
 }
 expect_failures = [terraform_data.review_gate]
}
run "block_6661712d617070_wrong_image_blocked" {
 command = plan
 override_data {
 target = data.aws_ecr_image.block_6661712d617070
 values = { image_digest = "sha256:1111111111111111111111111111111111111111111111111111111111111111" }
 }
 expect_failures = [terraform_data.review_gate]
}
run "block_6661712d617070_public_boundary" {
 command = plan
 assert {
 condition = aws_s3_bucket_public_access_block.block_6661712d617070.block_public_policy && aws_s3_bucket_public_access_block.block_6661712d617070.restrict_public_buckets && !aws_s3_bucket.block_6661712d617070.force_destroy
 error_message = "Public app must not grant anonymous object-store access or destructive bucket deletion."
 }
 assert {
 condition = jsondecode(aws_iam_role_policy.block_6661712d617070.policy).Statement[0].Action == ["s3:GetObject"] && toset(jsondecode(aws_iam_role_policy.block_6661712d617070_editor.policy).Statement[0].Action) == toset(["s3:GetObject", "s3:PutObject"])
 error_message = "Runtime and separate editor roles must retain exact catalog read versus conditional edit authority."
 }
 assert {
 condition = !aws_apprunner_service.block_6661712d617070.source_configuration[0].auto_deployments_enabled && aws_apprunner_auto_scaling_configuration_version.block_6661712d617070.max_concurrency == 5 && aws_apprunner_auto_scaling_configuration_version.block_6661712d617070.max_size == 2
 error_message = "No unreviewed automatic image release or unbounded configured scaling."
 }
}
run "block_6661712d617070_mutable_image_blocked" {
 command = plan
 variables { block_6661712d617070_image_digest = "latest" }
 expect_failures = [var.block_6661712d617070_image_digest]
}
run "wrong_account_blocked" {
 command = plan
 variables { account_id = "999999999999" }
 expect_failures = [terraform_data.review_gate]
}
run "unapproved_blocked" {
 command = plan
 variables { review_approved = false }
 expect_failures = [terraform_data.review_gate]
}
