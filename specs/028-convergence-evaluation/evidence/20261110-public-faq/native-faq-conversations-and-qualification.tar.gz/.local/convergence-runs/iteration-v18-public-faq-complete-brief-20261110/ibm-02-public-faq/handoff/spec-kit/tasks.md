# Detailed implementation tasks

Snapshot 49e015ab-57a2-4a4d-a118-e59e79bf86e0 · design r4 · generated 2026-11-09T22:05:33.257Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use emitted Python 3.13 applications/* source and BUILD.md. Install hash-locked runtime and test requirements in isolated provider environments and run faq_acceptance.py -v. Build, scan and test the exact Linux/amd64 image; obtain authorization before registry publication. Supply reviewed destination, image and model/policy inputs from deployment.tfvars.json.example. The runtime, port 8080, public-only retrieval, citations/abstention, source freshness, private catalog read role and separate editor grants are generated; do not ask the user to invent them. Seed the catalog only from a reviewed genuinely public UTF-8 directory using public_catalog_admin.py init. For updates/deletions inspect the current version, review and confirm the conditional write. Test unknown questions, prompt injection, concurrent edits and in-flight source changes. Source fixtures/schema/mock plans are not real cloud IAM, model quality or deployed evidence. Keep AWS versus IBM SDK dependency environments separate.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d62726f777365722d6874747073 — Define Public visitor browser → Public FAQ website and assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-browser-https: HTTPS question → cited answer or “I don’t know”. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-browser-https
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d7075626c69736865722d636174616c6f67 — Define Authorized article publisher → Public FAQ website and assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-publisher, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-publisher-catalog: Operator CLI → conditional catalog publish/update/delete. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-publisher-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d62726f77736572 — Integrate existing Public visitor browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d6874747073
- Components: faq-browser
- Generated files: No implementation files generated yet
- Requirements: ai-faq-capacity, ai-faq-scope

### Implementation steps

1. Responsibility from the board: Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the application's answer, article citations or abstention. Public visitors have no publishing access.
2. Verify Web browser on tools in Visitor location; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified.; REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-browser
- Application/configuration and tests for Public visitor browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Validate generated Public FAQ website and assistant

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d6874747073, TASK-CONTRACT-6661712d7075626c69736865722d636174616c6f67
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-grounding, ai-controlled-publication, ai-location-transparency, ai-faq-capacity, ai-faq-scope

### Implementation steps

1. Responsibility from the board: Proposed composed public-faq-app module on IBM Code Engine: Python browser/API, private IBM Cloud Object Storage catalog containing only approved public article text and URLs, read-only runtime identity and regional watsonx Text Chat transport. Internal catalog, model transport and identities belong to this module; do not duplicate them as independent canvas resources. Anonymous visitors may ask questions but cannot publish. Initial corpus: twenty public UTF-8 files under 30 KB each, supplied by an authorized editor; no private content. Recommend deterministic keyword ranking over this small catalog, retrieving at most two complete articles, without embeddings or a vector database. Lexical matching may miss paraphrases; assess representative questions before adding retrieval complexity. Confirm this recommendation against emitted application code rather than assuming the implementation from the graph. Return answers with supporting quotes and valid article citations; abstain for insufficient support, invalid source references or source changes during a request. Quote validation alone does not establish factual entailment. Treat articles and questions as untrusted data, never as publishing authority or model instructions. Authorized operator CLI conditionally publishes, updates and deletes approved articles with reviewed public source URLs; stale edits conflict. Updates and deletions must affect subsequent retrieval, and source revision rechecks must withhold in-flight answers based on changed or removed articles. Catalog failure has no cached-source fallback; model failure returns an unavailable response rather than an invented answer. Supported contract bounds: at most 100 UTF-8 articles of 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Required workload: about 1000 questions/day and five simultaneous requests; approximately 30000/month assumes a 30-day planning month. Capacity and answer quality remain untested. Prefer a single application deployment with its owned catalog and model transport; propose scale-to-zero where supported and accept possible cold starts as an unresolved latency tradeoff, with no latency or availability guarantee. Private sources, arbitrary URL fetching, visitor accounts and automated actions are proposed exclusions. Australia is preferred, not a mandatory Australia-only boundary. Assess IBM Sydney (au-syd) as a candidate; Code Engine, Object Storage, watsonx model/version, plans, quotas and interoperability have not been verified. Australian storage does not establish Australian inference: questions and retrieved excerpts go to the selected model endpoint. Independently establish locations and retention for inference, abuse monitoring, application/platform logs, backups and global routing or support processing. No model, overseas fallback or cross-region recovery is selected. Obtain client agreement before proposing overseas processing; do not enable inference until destination model data-use and retention policy is reviewed. Proposed application logs exclude raw questions and article bodies; enforcement and provider-side retention need evidence. Verify scoped publisher/runtime permissions, immutable image, destination configuration, denial/failure/recovery paths and source-change behavior. Publisher maintains the source files; operational ownership, catalog recovery and rollback procedures remain to be assigned and tested. Current native price evidence, model token usage, runtime sizing and autoscaling costs are missing; no monthly estimate or one-off build estimate is established. Compiler capability is not evidence of deployed behavior or a completed handoff.
2. Verify IBM Code Engine on ibm in Australia preferred; destination region unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope.; REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.; REQ-004: Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement.; REQ-005: The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified.; REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for Public FAQ website and assistant

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d7075626c6973686572 — Integrate existing Authorized article publisher

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d7075626c69736865722d636174616c6f67
- Components: faq-publisher
- Generated files: terraform/main.tf.json
- Requirements: ai-controlled-publication, ai-faq-scope

### Implementation steps

1. Responsibility from the board: Reference to the client's authorized editor/operator identity, outside provisioning scope; exact native IBM identity and permissions are not supplied or verified. Supplies twenty public UTF-8 help-article files under 30 KB each and reviewed public source URLs. Uses the module's generated operator CLI to publish, conditionally update and remove articles in the owned catalog. Proposed publishing validation rejects oversized files and invalid source metadata explicitly. Requires separate scoped native IBM catalog permissions; anonymous visitors and the read-only application runtime receive no publication authority. Preserve conditional-write conflicts and source revision checks. No public editor endpoint, private-source connector or credentials are represented. Source-file retention, operational owner and tested catalog recovery remain to be documented.
2. Verify Authorized publishing operator on tools in Operator location; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.; REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-publisher
- Application/configuration and tests for Authorized article publisher

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d62726f777365722d6874747073 — Wire Public visitor browser to Public FAQ website and assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d62726f777365722d6874747073, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge faq-browser-https in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-browser-https
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d7075626c69736865722d636174616c6f67 — Wire Authorized article publisher to Public FAQ website and assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d7075626c69736865722d636174616c6f67, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d7075626c6973686572
- Components: faq-publisher, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-publisher-catalog carrying Operator CLI → conditional catalog publish/update/delete, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-publisher-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073 — Verify live Public visitor browser → Public FAQ website and assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d62726f777365722d6874747073
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-browser-https with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-browser-https

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67 — Verify live Authorized article publisher → Public FAQ website and assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d7075626c69736865722d636174616c6f67
- Components: faq-publisher, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-publisher-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-publisher-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3061326566383462 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-0a2ef84b

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67 — Verify REQ-002: The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-grounding

### Implementation steps

1. Basis: “says when it does not know” and “It must not answer from private sources.”; rationale: Restricting retrieval to an explicitly published public catalog prevents private sources from entering public answers; abstention limits unsupported responses.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d636f6e74726f6c6c65642d7075626c69636174696f6e — Verify REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d7075626c6973686572, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: faq-publisher, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-controlled-publication

### Implementation steps

1. Basis: “We need to update and remove articles.” The proposed faq-publisher path separates publication from public question access.; rationale: Controlled publication and source revision checks reduce unauthorized changes and prevent removed or superseded content from supporting new answers.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379 — Verify REQ-004: Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-location-transparency

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.” The faq-app module stores articles and sends questions and retrieved excerpts to watsonx.; rationale: Public articles do not make visitor questions public, and local storage alone cannot establish the model's processing geography.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6661712d6361706163697479 — Verify REQ-005: The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-faq-capacity

### Implementation steps

1. Basis: “About 1,000 questions per day and five at once.” Monthly planning uses a stated 30-day assumption.; rationale: Preserves the stated simultaneous workload; an application admission bound alone does not demonstrate that the model and destination can serve it.
2. Implement a check for simultaneous_questions_supported >= 5 questions; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6661712d73636f7065 — Verify REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d7075626c6973686572, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: faq-browser, faq-app, faq-publisher
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/ibm_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-faq-scope

### Implementation steps

1. Basis: “Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content.”; rationale: Makes the handoff boundary explicit without adding services or silently assuming private integrations and business workflows.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d7075626c6973686572, TASK-INTEGRATION-6661712d62726f777365722d6874747073, TASK-INTEGRATION-6661712d7075626c69736865722d636174616c6f67
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d7075626c6973686572, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3061326566383462, TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67, TASK-ACCEPTANCE-61692d636f6e74726f6c6c65642d7075626c69636174696f6e, TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379, TASK-ACCEPTANCE-61692d6661712d6361706163697479, TASK-ACCEPTANCE-61692d6661712d73636f7065, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d636174616c6f67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
