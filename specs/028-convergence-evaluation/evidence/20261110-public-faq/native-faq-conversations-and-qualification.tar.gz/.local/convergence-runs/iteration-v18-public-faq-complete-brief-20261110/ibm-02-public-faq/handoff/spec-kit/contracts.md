# Component and interface contracts

Snapshot 49e015ab-57a2-4a4d-a118-e59e79bf86e0 · design r4 · generated 2026-11-09T22:05:33.257Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-browser: Public visitor browser

- Responsibility: Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the application's answer, article citations or abstention. Public visitors have no publishing access.
- Service: Web browser
- Provider / placement: tools / Visitor location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public FAQ website and assistant

- Responsibility: Proposed composed public-faq-app module on IBM Code Engine: Python browser/API, private IBM Cloud Object Storage catalog containing only approved public article text and URLs, read-only runtime identity and regional watsonx Text Chat transport. Internal catalog, model transport and identities belong to this module; do not duplicate them as independent canvas resources. Anonymous visitors may ask questions but cannot publish. Initial corpus: twenty public UTF-8 files under 30 KB each, supplied by an authorized editor; no private content. Recommend deterministic keyword ranking over this small catalog, retrieving at most two complete articles, without embeddings or a vector database. Lexical matching may miss paraphrases; assess representative questions before adding retrieval complexity. Confirm this recommendation against emitted application code rather than assuming the implementation from the graph. Return answers with supporting quotes and valid article citations; abstain for insufficient support, invalid source references or source changes during a request. Quote validation alone does not establish factual entailment. Treat articles and questions as untrusted data, never as publishing authority or model instructions. Authorized operator CLI conditionally publishes, updates and deletes approved articles with reviewed public source URLs; stale edits conflict. Updates and deletions must affect subsequent retrieval, and source revision rechecks must withhold in-flight answers based on changed or removed articles. Catalog failure has no cached-source fallback; model failure returns an unavailable response rather than an invented answer. Supported contract bounds: at most 100 UTF-8 articles of 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Required workload: about 1000 questions/day and five simultaneous requests; approximately 30000/month assumes a 30-day planning month. Capacity and answer quality remain untested. Prefer a single application deployment with its owned catalog and model transport; propose scale-to-zero where supported and accept possible cold starts as an unresolved latency tradeoff, with no latency or availability guarantee. Private sources, arbitrary URL fetching, visitor accounts and automated actions are proposed exclusions. Australia is preferred, not a mandatory Australia-only boundary. Assess IBM Sydney (au-syd) as a candidate; Code Engine, Object Storage, watsonx model/version, plans, quotas and interoperability have not been verified. Australian storage does not establish Australian inference: questions and retrieved excerpts go to the selected model endpoint. Independently establish locations and retention for inference, abuse monitoring, application/platform logs, backups and global routing or support processing. No model, overseas fallback or cross-region recovery is selected. Obtain client agreement before proposing overseas processing; do not enable inference until destination model data-use and retention policy is reviewed. Proposed application logs exclude raw questions and article bodies; enforcement and provider-side retention need evidence. Verify scoped publisher/runtime permissions, immutable image, destination configuration, denial/failure/recovery paths and source-change behavior. Publisher maintains the source files; operational ownership, catalog recovery and rollback procedures remain to be assigned and tested. Current native price evidence, model token usage, runtime sizing and autoscaling costs are missing; no monthly estimate or one-off build estimate is established. Compiler capability is not evidence of deployed behavior or a completed handoff.
- Service: IBM Code Engine
- Provider / placement: ibm / Australia preferred; destination region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-publisher: Authorized article publisher

- Responsibility: Reference to the client's authorized editor/operator identity, outside provisioning scope; exact native IBM identity and permissions are not supplied or verified. Supplies twenty public UTF-8 help-article files under 30 KB each and reviewed public source URLs. Uses the module's generated operator CLI to publish, conditionally update and remove articles in the owned catalog. Proposed publishing validation rejects oversized files and invalid source metadata explicitly. Requires separate scoped native IBM catalog permissions; anonymous visitors and the read-only application runtime receive no publication authority. Preserve conditional-write conflicts and source revision checks. No public editor endpoint, private-source connector or credentials are represented. Source-file retention, operational owner and tested catalog recovery remain to be documented.
- Service: Authorized publishing operator
- Provider / placement: tools / Operator location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d7075626c6973686572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-https: faq-browser → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d62726f777365722d6874747073
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d6874747073
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-publisher-catalog: faq-publisher → faq-app

- Drawn payload/purpose: Operator CLI → conditional catalog publish/update/delete
- Contract task: TASK-CONTRACT-6661712d7075626c69736865722d636174616c6f67
- Integration task: TASK-INTEGRATION-6661712d7075626c69736865722d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
