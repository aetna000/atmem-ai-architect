Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-002] The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried. (must, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Restricting retrieval to approved public material prevents private-source disclosure; abstention reduces unsupported answers.

Basis: “our twenty public help articles”; “says when it does not know”; “It must not answer from private sources.”
- [REQ-003] Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation. (must, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Proposed editor-only mutation and conflict handling prevent unauthorized changes and answers based on withdrawn content.

Basis: “We need to update and remove articles.” Editor authorization and conditional changes are proposed engineering controls.
- [REQ-004] The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback. (should, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: An Australian application region alone does not establish where model inference, retained prompts, logs or backups are processed; checking each boundary prevents an unsupported residency claim.

Basis: “Australia is preferred; make model/data-location limitations explicit.”
- [REQ-005] Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission. (must, open); target: acceptance target needed; linked blocks: faq-browser, faq-editor, faq-app

Design explanation: Preserves the public visitor journey while separating article-writing authority from anonymous access; prevents visitors from changing the answer sources.

Basis: “Anonymous website visitors; an authorized editor manages the articles.” Components faq-browser, faq-editor and faq-app.
- [REQ-006] The application shall support five simultaneous questions while preserving grounding, citation and abstention checks. Capacity qualification shall use the expected approximately 1,000 questions per day; latency and availability targets remain unspecified. (must, open); target: supported simultaneous questions >= 5requests; linked blocks: faq-app

Design explanation: Five simultaneous requests match the stated peak and the module's admission bound, but a load test must establish practical capacity without weakened citation or abstention behavior.

Basis: “About 1,000 questions per day and five at once.” No response-time target was supplied.

## How the system works

The current design contains 3 components and 2 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Public website visitors → Public help-article assistant

HTTPS question → cited answer or “I don’t know”

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Authorized article editor → Public help-article assistant

Authorized CLI → module-owned catalog: publish, update, delete

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Public website visitors

Web browser · tools · region: External browsers · classification: Public

Existing visitor browsers access the public assistant over HTTPS and receive an answer with article citations or an explicit abstention. External client reference outside provisioning scope; no visitor account is proposed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Public website visitors → Public help-article assistant: HTTPS question → cited answer or “I don’t know” (integration: browser-https)

Requirement traceability: REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public help-article assistant

Azure App Service · azure · region: Australia East (proposed; unverified) · classification: Public

Proposed composed public-faq-app module on Azure App Service, owning browser UI/API, private Azure Blob Storage article catalog, separate scoped editor and read-only runtime identities, and regional model transport. Internal services remain module-owned rather than duplicate diagram deployments. Included scope: anonymous visitor questions; answers from twenty approved public UTF-8 help articles under 30 KB each, supplied as files; valid citations; explicit abstention; authorized article publication, updates and deletions. Excluded scope: private sources, arbitrary URL fetching, visitor accounts and automated business actions. Recommend bounded lexical/keyword retrieval over the catalog, selecting at most two complete articles; no embeddings, vector database or separate managed search service is proposed. Test synonyms and paraphrases before accepting retrieval quality; insufficient support must produce abstention rather than an invented answer. Treat article text as untrusted data. Validate citation membership, current revision, public URL and supporting quotes in application code; these checks alone do not establish factual entailment. Authorized CLI tooling conditionally changes the versioned catalog; reject conflicting edits, recheck revisions before returning an answer, and withhold answers when sources change or dependencies fail. No stale-source fallback. Updates and deletions must affect subsequent retrieval. User demand: approximately 1,000 questions per day and five simultaneous requests; 30,000 requests/month is a 30-day planning assumption. Contract bounds: 100 articles, 30000 UTF-8 bytes/article, 2000-byte questions, two complete retrieved articles and five admitted requests per instance. Propose one initial application instance on the smallest suitable App Service plan, selected after memory/startup and five-request load tests; no high-availability or recovery target is established. Apply server-side admission limits and safe overload responses; bounds do not cap the invoice or establish anti-abuse protection. Australia is preferred, not a confirmed strict residency boundary. Australia East remains proposed for application/catalog. Before inference, verify the selected Azure model/version, regional deployment type, quota, processing geography, abuse-monitoring retention and approval, logs and backups; no automatic global or overseas fallback. Existing editor identity and Azure destination inputs remain unverified; never place credentials in the project. Engineer handoff: reconcile emitted Terraform/resource addresses, scoped permissions, editor CLI, catalog concurrency controls, lexical retrieval, citation validation and abstention against this scope; build, scan and test the pinned emitted Linux image. Run functional, unauthorized-edit, private-ingestion denial, source-injection, paraphrase, unsupported-question, update/delete, concurrent-edit, dependency-failure, recovery, five-request load and cleanup checks; preserve artifact-bound reports and unresolved failures. Local scripted model tests do not prove answer quality, Azure IAM or deployment. Operator ownership, availability/recovery needs and abuse/spend controls remain open before launch. Current pricing evidence covers only Hot LRS base storage at USD 0.02/GB-month from Azure Retail Prices API dated 2026-11-09; compute, model tokens, operations, transfer, logs, backups and support remain unpriced. Monthly cloud costs and one-off build/validation costs remain separate and incomplete. No inspected artifact or destination-specific deployment evidence exists.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public website visitors → Public help-article assistant: HTTPS question → cited answer or “I don’t know” (integration: browser-https); Authorized article editor → Public help-article assistant: Authorized CLI → module-owned catalog: publish, update, delete

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried.; REQ-003: Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation.; REQ-004: The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback.; REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.; REQ-006: The application shall support five simultaneous questions while preserving grounding, citation and abstention checks. Capacity qualification shall use the expected approximately 1,000 questions per day; latency and availability targets remain unspecified.

Implementation status: Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authorized article editor

Authorized operator · tools · region: External operator; location unconfirmed · classification: Public

External human operator using the module's generated editor CLI to publish public UTF-8 files with reviewed citation URLs and to update or delete articles. Outside provisioning scope. The existing authorized Azure editor identity must be supplied and reviewed; no identity or permission has been verified. No public editor endpoint is proposed. This actor's connection describes the module-owned catalog management responsibility, not an independently implemented editor-to-App-Service API.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorized article editor → Public help-article assistant: Authorized CLI → module-owned catalog: publish, update, delete

Requirement traceability: REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Public help-article assistant<br/>Azure"]
  n2["Authorized article editor<br/>Tools & data"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Authorized CLI → module-owned catalog: publish, update, delete| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public website visitors | tools | Web browser | External browsers | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public help-article assistant | azure | Azure App Service | Australia East (proposed; unverified) | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article editor | tools | Authorized operator | External operator; location unconfirmed | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public website visitors** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public help-article assistant** (faq-app): azurerm_linux_web_app, azurerm_storage_account, azurerm_storage_container. Confirm service, capacity and billable dimensions. Depends on: faq-browser, faq-editor.
- **Authorized article editor** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article editor: Existing — reference/import plan needed.
- Wire faq-editor → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
