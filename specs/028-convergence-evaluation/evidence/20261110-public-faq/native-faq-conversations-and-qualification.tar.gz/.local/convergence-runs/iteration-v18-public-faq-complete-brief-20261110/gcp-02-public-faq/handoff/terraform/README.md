# Google public-only FAQ composition

Only this explicitly selected public Cloud Run browser/API receives anonymous
run.invoker access. Its catalog bucket remains private with public access
prevention and uniform IAM. The dedicated runtime has a bucket-scoped custom
object-reader role; a separate existing company editor group has get/create/delete
only on that public catalog bucket. There is no HTTP editing route. No private
source, arbitrary URL fetch, user identity or enterprise authorization is implied.

Existing project, registry and editor group are preserved. Required APIs are never
disabled on destroy. The Cloud Run platform agent, not the application, receives
reader access on the exact existing image repository. The runtime has narrow
project-level prediction and read-only cache/model-policy access; no policy writes
or user-managed key is emitted. Google-beta is used only for the documented service
identity resource. Reconcile inherited IAM and organization restrictions on public
invocation; do not disable organization policy to bypass a failure.

See applications/*/BUILD.md. Seed genuinely public articles using the authorized
editor and native generation preconditions; updates/deletes never fall back to
stale or inaccessible evidence. Versioning, noncurrent-version expiry and seven-day
soft deletion support recovery and are not an immediate erasure guarantee. Runtime
never retrieves a historical generation selected by a visitor. No question/answer
persistence or content-bearing app logs are implemented; review platform logging.

The owner policy review is scoped/expiring operator-attested evidence, not an IBM,
Google or other fabricated provider approval API. Runtime separately requires
disabled project caching and disabled model request/response logging/sharing.
The documented global cache-control read sends no question text; review that
control-plane processing and actual model geography/terms against residency needs.
Model availability/context/quotas, prices, anonymous abuse controls, budgets and
real answer/citation/abstention/latency tests remain destination checks. Concurrency,
token and instance bounds are not an invoice cap or SLA.

Use Terraform 1.17.1+; run init -backend=false, validate and test. These native schema
and mock plans do not establish actual IAM, model or deployed behavior. Build, scan
and test the exact source/image; obtain authorization before publishing, cloud
access, real account plan or deployment. Production state/operations remain gated.
