Snapshot d6384891-e306-4e39-8877-c68e59dcba9b · design r4 · generated 2026-11-09T21:56:35.410Z

# Cited public FAQ — deployment document

Generated 2026-11-09 21:56 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** 30,000 requests/month (discovery (2026-11-10))
- **Estimated run cost:** not estimated
- **Review:** 6 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. About 1,000 questions per day and five at once. Answers need valid source citations; unsupported questions must abstain; updates and deletions must affect retrieval. Recommend the simplest suitable retrieval approach and a small footprint. Show assumptions and missing current price evidence.
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** AWS Australia is preferred; make model/data-location limitations explicit.
- **Budget and timeline:** —

## 3. Architecture

**Public access**

- Public website visitor (Tools & data, existing) — Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the answer, article citations or an explicit abstention. No visitor account is proposed.

**Public FAQ application**

- Public FAQ website and assistant (AWS, sketch) — Proposed composed public-faq-app module: anonymous browser UI/API, owned private regional Amazon S3 catalog containing only approved public article content, read-only runtime identity and regional Amazon Bedrock transport. Initial input is twenty supplied UTF-8 files under 30 KB each; propose a conservative 30000-byte per-file validation limit. Authorized operator CLI publishes files and source links, updates and removes articles through conditional versioned catalog writes; visitors and runtime cannot write. Recommend deterministic keyword ranking across the small catalog, retrieving at most two complete articles per question; no embeddings, vector database, arbitrary URL fetch, private connectors, visitor accounts or automated business actions. Keyword coverage and answer quality require representative evaluation. Responses must cite current approved article IDs/source links and supporting quotes; validate source membership and quotes independently, while recognizing these checks do not prove factual entailment. Abstain for insufficient evidence, catalog/model failure or source revision changes during processing; never answer from a stale fallback. Treat article text as untrusted evidence. Updates/deletions affect subsequent retrieval; recheck supporting revisions before returning an in-flight answer. Expected load: about 1000 questions/day and five simultaneous requests; estimate 30000 questions per 30-day month as an assumption. Contract bounds remain 100 articles, 30000 bytes/article, 2000-byte questions, two retrieved articles and five admitted requests per instance. Propose explicit overload responses without invoking the model beyond admission capacity; these bounds are not a spending cap. Start with one small application deployment, subject to load tests and provider minimums; instance size and scaling are not verified. Australia is preferred; Sydney ap-southeast-2 remains proposed, not approved. Verify direct regional model availability, entitlement, quotas, data-use/retention policy and processing geography before enabling inference. No automatic overseas inference, fallback or cross-region recovery. Browser traffic may cross borders; logs, backups, support and metadata locations remain unverified. Propose body-free operational logs and single-region operation; retention, recovery objectives and operating ownership remain open. Hosting blocker: supplied AWS lifecycle review dated 2026-11-07 reports App Runner closed to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html); existing-customer eligibility is unverified. If ineligible, recommend AWS ECS Fargate with implemented public HTTPS ingress and the same FAQ/catalog/model/editor behavior. That alternative needs native generator/application integration work; the current App Runner contract and a generic container footprint do not implement it. Keep deployment blocked pending hosting resolution, tested immutable image, reviewed editor identity and artifact-bound acceptance evidence. Monthly cost evidence is unavailable: include hosting/ingress, Bedrock input/output tokens, S3 storage/version history/requests, transfer, logs, backups and applicable support. Model, tokens per question, runtime sizing, transfer and current regional rates are unknown; no monthly total is supported. One-off build cost is separate and unestimated; no effort or rate is assumed.

**Article management**

- Authorized article editor (Tools & data, existing) — Existing external authorized operator identity reference, outside provisioning scope and not verified. Supplies twenty public UTF-8 article files under 30 KB each and reviewed source links through the module's operator CLI. Publishes, updates and removes only approved public content using conditional versioned catalog writes; conflicting writes fail rather than overwrite newer edits. Separate from anonymous visitors and the read-only runtime. Reviewed destination identity and permission evidence remain required; no ARN or credentials are stored in the diagram. Proposed file limit is 30000 bytes to fit the bounded module. Editor onboarding, update/delete procedures and recovery instructions must accompany the handoff.

```mermaid
flowchart LR
  n0["Public website visitor<br/>Tools & data"]
  n1["Public FAQ website and assistant<br/>AWS"]
  n2["Authorized article editor<br/>Tools & data"]
  n0 -->|HTTPS questions; cited answers or “I don’t know”| n1
  n2 -->|Operator CLI → owned catalog: conditional publish/update/delete| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public website visitor | tools | Web browser | Visitor location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public FAQ website and assistant | aws | AWS App Runner | ap-southeast-2 | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article editor | tools | External operator identity | External operator | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public website visitor** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public FAQ website and assistant** (faq-app): aws_apprunner_service, aws_s3_bucket, aws_iam_role. Provisioned and active compute, builds, logs and transfer. Depends on: faq-browser, faq-editor.
- **Authorized article editor** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article editor: Existing — reference/import plan needed.
- Wire faq-editor → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Public website visitor | Public FAQ website and assistant | HTTPS questions; cited answers or “I don’t know” | Public |
| Authorized article editor | Public FAQ website and assistant | Operator CLI → owned catalog: conditional publish/update/delete | Public |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: The assistant shall retrieve answer evidence only from the approved public help-article catalog and shall provide no private-source connector or arbitrary URL retrieval path. (must)
- Requirement: The application should prefer Australian storage and server-side processing. Before implementation approval, document the selected model's availability, inference geography, data-use and retention policies, and locations of logs, backups and relevant service processing. Overseas inference or recovery must not be silently enabled; any exception requires an explicit user decision. Australian end-to-end residency remains unverified. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| The application should prefer Australian storage and server-side processing. Before implementation approval, document the selected model's availability, inference geography, data-use and retention policies, and locations of logs, backups and relevant service processing. Overseas inference or recovery must not be silently enabled; any exception requires an explicit user decision. Australian end-to-end residency remains unverified. | compliance | not measurable yet | Open |
| The public FAQ shall support five simultaneous question requests at an expected volume of about 1,000 questions daily. Proposed overload behavior shall reject excess work explicitly without unsupported answers or unbounded model calls; response-time acceptance remains unspecified. | performance | simultaneous supported question requests >= 5requests | Open |

**Functional**

- Every answer shows its sources (should, open)
- The assistant shall retrieve answer evidence only from the approved public help-article catalog and shall provide no private-source connector or arbitrary URL retrieval path. (must, open)
- The assistant shall cite the approved articles supporting each substantive answer and explicitly abstain when those articles provide insufficient evidence; source changes or retrieval failures shall not produce an unsupported answer. (must, open)
- Authorized editors shall be able to publish, update and remove public articles through a separate management path; public visitors and the read-only answer runtime shall not have catalog write permission. Conflicting edits shall be rejected, and answers shall be withheld when a supporting article changes or is removed during processing. (must, open)
- The first version shall provide anonymous website question answering over twenty supplied public UTF-8 help articles under 30 KB each and a separate authorized article-management path. Private content is excluded. Proposed additional exclusions are private connectors, arbitrary URL fetching, visitor accounts and automated business actions. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “The application should prefer Australian storage and server-side processing. Before implementation approval, document the selected model's availability, inference geography, data-use and retention policies, and locations of logs, backups and relevant service processing. Overseas inference or recovery must not be silently enabled; any exception requires an explicit user decision. Australian end-to-end residency remains unverified.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 1 block is sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Public website visitor, Public FAQ website and assistant, Authorized article editor.

**Estimate gaps:**

- Public website visitor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public FAQ website and assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorized article editor: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public faq application: Public FAQ website and assistant.
4. Connect existing systems: Public website visitor, Authorized article editor; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
