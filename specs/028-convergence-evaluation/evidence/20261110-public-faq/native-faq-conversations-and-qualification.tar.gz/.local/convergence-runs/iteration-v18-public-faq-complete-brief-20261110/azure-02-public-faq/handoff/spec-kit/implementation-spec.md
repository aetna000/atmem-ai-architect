# Implementation Spec Kit

Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

8 priority decisions; infrastructure: partial_implementation. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: azure

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Public website visitors (faq-browser): External browser — no infrastructure to provision; connection behavior still requires validation; tools, External browsers.
- Public help-article assistant (faq-app): Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified; azure, Australia East (proposed; unverified).
- Authorized article editor (faq-editor): Existing — reference/import plan needed; tools, External operator; location unconfirmed.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: partial_implementation
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### decision-data.country — priority 1

The data country and processing boundary is not independently confirmed.

Action: Record an explicit data.country decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d61727469636c652d6c6966656379636c65 — priority 1

REQ-003 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### requirement-proposed-61692d6661712d636f6e63757272656e742d6361706163697479 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6661712d636f6e63757272656e742d6361706163697479

### requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379

### requirement-proposed-61692d7075626c69632d6163636573732d626f756e64617279 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d6163636573732d626f756e64617279

### requirement-proposed-61692d7075626c69632d67726f756e64696e67 — priority 1

REQ-002 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67

### placement-6661712d617070 — priority 2

Public help-article assistant: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6661712d617070

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

3 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d61727469636c652d6c6966656379636c65 — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### acceptance-61692d6661712d636f6e63757272656e742d6361706163697479 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d6661712d636f6e63757272656e742d6361706163697479

### acceptance-61692d6c6f636174696f6e2d7472616e73706172656e6379 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379

### acceptance-61692d7075626c69632d6163636573732d626f756e64617279 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d6163636573732d626f756e64617279

### acceptance-61692d7075626c69632d67726f756e64696e67 — priority 2

REQ-002: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67

### acceptance-7265712d3035643866346636 — priority 2

REQ-001: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-7265712d3035643866346636

### traceability-7265712d3035643866346636 — priority 2

REQ-001 has no component links.

Action: Map the requirement to relevant components or record why it is project-wide; do not guess the mapping.

Tasks: TASK-ACCEPTANCE-7265712d3035643866346636

### existing-6661712d62726f77736572 — priority 2

Public website visitors: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-6661712d62726f77736572

### existing-6661712d656469746f72 — priority 2

Authorized article editor: existing-system contract and access are unverified.

Action: Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.

Tasks: TASK-RESOURCE-6661712d656469746f72


# Component and interface contracts

Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-browser: Public website visitors

- Responsibility: Existing visitor browsers access the public assistant over HTTPS and receive an answer with article citations or an explicit abstention. External client reference outside provisioning scope; no visitor account is proposed.
- Service: Web browser
- Provider / placement: tools / External browsers
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public help-article assistant

- Responsibility: Proposed composed public-faq-app module on Azure App Service, owning browser UI/API, private Azure Blob Storage article catalog, separate scoped editor and read-only runtime identities, and regional model transport. Internal services remain module-owned rather than duplicate diagram deployments. Included scope: anonymous visitor questions; answers from twenty approved public UTF-8 help articles under 30 KB each, supplied as files; valid citations; explicit abstention; authorized article publication, updates and deletions. Excluded scope: private sources, arbitrary URL fetching, visitor accounts and automated business actions. Recommend bounded lexical/keyword retrieval over the catalog, selecting at most two complete articles; no embeddings, vector database or separate managed search service is proposed. Test synonyms and paraphrases before accepting retrieval quality; insufficient support must produce abstention rather than an invented answer. Treat article text as untrusted data. Validate citation membership, current revision, public URL and supporting quotes in application code; these checks alone do not establish factual entailment. Authorized CLI tooling conditionally changes the versioned catalog; reject conflicting edits, recheck revisions before returning an answer, and withhold answers when sources change or dependencies fail. No stale-source fallback. Updates and deletions must affect subsequent retrieval. User demand: approximately 1,000 questions per day and five simultaneous requests; 30,000 requests/month is a 30-day planning assumption. Contract bounds: 100 articles, 30000 UTF-8 bytes/article, 2000-byte questions, two complete retrieved articles and five admitted requests per instance. Propose one initial application instance on the smallest suitable App Service plan, selected after memory/startup and five-request load tests; no high-availability or recovery target is established. Apply server-side admission limits and safe overload responses; bounds do not cap the invoice or establish anti-abuse protection. Australia is preferred, not a confirmed strict residency boundary. Australia East remains proposed for application/catalog. Before inference, verify the selected Azure model/version, regional deployment type, quota, processing geography, abuse-monitoring retention and approval, logs and backups; no automatic global or overseas fallback. Existing editor identity and Azure destination inputs remain unverified; never place credentials in the project. Engineer handoff: reconcile emitted Terraform/resource addresses, scoped permissions, editor CLI, catalog concurrency controls, lexical retrieval, citation validation and abstention against this scope; build, scan and test the pinned emitted Linux image. Run functional, unauthorized-edit, private-ingestion denial, source-injection, paraphrase, unsupported-question, update/delete, concurrent-edit, dependency-failure, recovery, five-request load and cleanup checks; preserve artifact-bound reports and unresolved failures. Local scripted model tests do not prove answer quality, Azure IAM or deployment. Operator ownership, availability/recovery needs and abuse/spend controls remain open before launch. Current pricing evidence covers only Hot LRS base storage at USD 0.02/GB-month from Azure Retail Prices API dated 2026-11-09; compute, model tokens, operations, transfer, logs, backups and support remain unpriced. Monthly cloud costs and one-off build/validation costs remain separate and incomplete. No inspected artifact or destination-specific deployment evidence exists.
- Service: Azure App Service
- Provider / placement: azure / Australia East (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-editor: Authorized article editor

- Responsibility: External human operator using the module's generated editor CLI to publish public UTF-8 files with reviewed citation URLs and to update or delete articles. Outside provisioning scope. The existing authorized Azure editor identity must be supplied and reviewed; no identity or permission has been verified. No public editor endpoint is proposed. This actor's connection describes the module-owned catalog management responsibility, not an independently implemented editor-to-App-Service API.
- Service: Authorized operator
- Provider / placement: tools / External operator; location unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-https: faq-browser → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d62726f777365722d6874747073
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d6874747073
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-catalog-management: faq-editor → faq-app

- Drawn payload/purpose: Authorized CLI → module-owned catalog: publish, update, delete
- Contract task: TASK-CONTRACT-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Integration task: TASK-INTEGRATION-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use emitted Python 3.13 applications/* source and BUILD.md. Install hash-locked runtime and test requirements in isolated provider environments and run faq_acceptance.py -v. Build, scan and test the exact Linux/amd64 image; obtain authorization before registry publication. Supply reviewed destination, image and model/policy inputs from deployment.tfvars.json.example. The runtime, port 8080, public-only retrieval, citations/abstention, source freshness, private catalog read role and separate editor grants are generated; do not ask the user to invent them. Seed the catalog only from a reviewed genuinely public UTF-8 directory using public_catalog_admin.py init. For updates/deletions inspect the current version, review and confirm the conditional write. Test unknown questions, prompt injection, concurrent edits and in-flight source changes. Source fixtures/schema/mock plans are not real cloud IAM, model quality or deployed evidence. Keep AWS versus IBM SDK dependency environments separate.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d62726f777365722d6874747073 — Define Public website visitors → Public help-article assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-browser-https: HTTPS question → cited answer or “I don’t know”. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-browser-https
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74 — Define Authorized article editor → Public help-article assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-editor-catalog-management: Authorized CLI → module-owned catalog: publish, update, delete. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-editor-catalog-management
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d62726f77736572 — Integrate existing Public website visitors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d6874747073
- Components: faq-browser
- Generated files: No implementation files generated yet
- Requirements: ai-public-access-boundary

### Implementation steps

1. Responsibility from the board: Existing visitor browsers access the public assistant over HTTPS and receive an answer with article citations or an explicit abstention. External client reference outside provisioning scope; no visitor account is proposed.
2. Verify Web browser on tools in External browsers; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-browser
- Application/configuration and tests for Public website visitors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Validate generated Public help-article assistant

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d6874747073, TASK-CONTRACT-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-grounding, ai-article-lifecycle, ai-location-transparency, ai-public-access-boundary, ai-faq-concurrent-capacity

### Implementation steps

1. Responsibility from the board: Proposed composed public-faq-app module on Azure App Service, owning browser UI/API, private Azure Blob Storage article catalog, separate scoped editor and read-only runtime identities, and regional model transport. Internal services remain module-owned rather than duplicate diagram deployments. Included scope: anonymous visitor questions; answers from twenty approved public UTF-8 help articles under 30 KB each, supplied as files; valid citations; explicit abstention; authorized article publication, updates and deletions. Excluded scope: private sources, arbitrary URL fetching, visitor accounts and automated business actions. Recommend bounded lexical/keyword retrieval over the catalog, selecting at most two complete articles; no embeddings, vector database or separate managed search service is proposed. Test synonyms and paraphrases before accepting retrieval quality; insufficient support must produce abstention rather than an invented answer. Treat article text as untrusted data. Validate citation membership, current revision, public URL and supporting quotes in application code; these checks alone do not establish factual entailment. Authorized CLI tooling conditionally changes the versioned catalog; reject conflicting edits, recheck revisions before returning an answer, and withhold answers when sources change or dependencies fail. No stale-source fallback. Updates and deletions must affect subsequent retrieval. User demand: approximately 1,000 questions per day and five simultaneous requests; 30,000 requests/month is a 30-day planning assumption. Contract bounds: 100 articles, 30000 UTF-8 bytes/article, 2000-byte questions, two complete retrieved articles and five admitted requests per instance. Propose one initial application instance on the smallest suitable App Service plan, selected after memory/startup and five-request load tests; no high-availability or recovery target is established. Apply server-side admission limits and safe overload responses; bounds do not cap the invoice or establish anti-abuse protection. Australia is preferred, not a confirmed strict residency boundary. Australia East remains proposed for application/catalog. Before inference, verify the selected Azure model/version, regional deployment type, quota, processing geography, abuse-monitoring retention and approval, logs and backups; no automatic global or overseas fallback. Existing editor identity and Azure destination inputs remain unverified; never place credentials in the project. Engineer handoff: reconcile emitted Terraform/resource addresses, scoped permissions, editor CLI, catalog concurrency controls, lexical retrieval, citation validation and abstention against this scope; build, scan and test the pinned emitted Linux image. Run functional, unauthorized-edit, private-ingestion denial, source-injection, paraphrase, unsupported-question, update/delete, concurrent-edit, dependency-failure, recovery, five-request load and cleanup checks; preserve artifact-bound reports and unresolved failures. Local scripted model tests do not prove answer quality, Azure IAM or deployment. Operator ownership, availability/recovery needs and abuse/spend controls remain open before launch. Current pricing evidence covers only Hot LRS base storage at USD 0.02/GB-month from Azure Retail Prices API dated 2026-11-09; compute, model tokens, operations, transfer, logs, backups and support remain unpriced. Monthly cloud costs and one-off build/validation costs remain separate and incomplete. No inspected artifact or destination-specific deployment evidence exists.
2. Verify Azure App Service on azure in Australia East (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried.; REQ-003: Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation.; REQ-004: The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback.; REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.; REQ-006: The application shall support five simultaneous questions while preserving grounding, citation and abstention checks. Capacity qualification shall use the expected approximately 1,000 questions per day; latency and availability targets remain unspecified.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for Public help-article assistant

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d656469746f72 — Integrate existing Authorized article editor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-editor
- Generated files: terraform/main.tf.json
- Requirements: ai-public-access-boundary

### Implementation steps

1. Responsibility from the board: External human operator using the module's generated editor CLI to publish public UTF-8 files with reviewed citation URLs and to update or delete articles. Outside provisioning scope. The existing authorized Azure editor identity must be supplied and reviewed; no identity or permission has been verified. No public editor endpoint is proposed. This actor's connection describes the module-owned catalog management responsibility, not an independently implemented editor-to-App-Service API.
2. Verify Authorized operator on tools in External operator; location unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-editor
- Application/configuration and tests for Authorized article editor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d62726f777365722d6874747073 — Wire Public website visitors to Public help-article assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d62726f777365722d6874747073, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge faq-browser-https in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-browser-https
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74 — Wire Authorized article editor to Public help-article assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-editor-catalog-management carrying Authorized CLI → module-owned catalog: publish, update, delete, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-editor-catalog-management
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073 — Verify live Public website visitors → Public help-article assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d62726f777365722d6874747073
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-browser-https with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-browser-https

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74 — Verify live Authorized article editor → Public help-article assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-editor-catalog-management with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-editor-catalog-management

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3035643866346636 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-05d8f4f6

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67 — Verify REQ-002: The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-grounding

### Implementation steps

1. Basis: “our twenty public help articles”; “says when it does not know”; “It must not answer from private sources.”; rationale: Restricting retrieval to approved public material prevents private-source disclosure; abstention reduces unsupported answers.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65 — Verify REQ-003: Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-article-lifecycle

### Implementation steps

1. Basis: “We need to update and remove articles.” Editor authorization and conditional changes are proposed engineering controls.; rationale: Proposed editor-only mutation and conflict handling prevent unauthorized changes and answers based on withdrawn content.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379 — Verify REQ-004: The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-location-transparency

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.”; rationale: An Australian application region alone does not establish where model inference, retained prompts, logs or backups are processed; checking each boundary prevents an unsupported residency claim.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d6163636573732d626f756e64617279 — Verify REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-browser, faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-access-boundary

### Implementation steps

1. Basis: “Anonymous website visitors; an authorized editor manages the articles.” Components faq-browser, faq-editor and faq-app.; rationale: Preserves the public visitor journey while separating article-writing authority from anonymous access; prevents visitors from changing the answer sources.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6661712d636f6e63757272656e742d6361706163697479 — Verify REQ-006: The application shall support five simultaneous questions while preserving grounding, citation and abstention checks. Capacity qualification shall use the expected approximately 1,000 questions per day; latency and availability targets remain unspecified.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/azure_structured.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-faq-concurrent-capacity

### Implementation steps

1. Basis: “About 1,000 questions per day and five at once.” No response-time target was supplied.; rationale: Five simultaneous requests match the stated peak and the module's admission bound, but a load test must establish practical capacity without weakened citation or abstention behavior.
2. Implement a check for supported simultaneous questions >= 5 requests; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-6661712d62726f777365722d6874747073, TASK-INTEGRATION-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3035643866346636, TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67, TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65, TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379, TASK-ACCEPTANCE-61692d7075626c69632d6163636573732d626f756e64617279, TASK-ACCEPTANCE-61692d6661712d636f6e63757272656e742d6361706163697479, TASK-INTEGRATION-LIVE-6661712d62726f777365722d6874747073, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-001 (req-05d8f4f6) → TASK-ACCEPTANCE-7265712d3035643866346636; Recorded from user discussion
- REQ-002 (ai-public-grounding) → TASK-ACCEPTANCE-61692d7075626c69632d67726f756e64696e67; Proposed; needs confirmation
- REQ-003 (ai-article-lifecycle) → TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65; Proposed; needs confirmation
- REQ-004 (ai-location-transparency) → TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379; Proposed; needs confirmation
- REQ-005 (ai-public-access-boundary) → TASK-ACCEPTANCE-61692d7075626c69632d6163636573732d626f756e64617279; Proposed; needs confirmation
- REQ-006 (ai-faq-concurrent-capacity) → TASK-ACCEPTANCE-61692d6661712d636f6e63757272656e742d6361706163697479; Proposed; needs confirmation
