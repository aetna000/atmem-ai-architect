# Implementation Spec Kit

Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

7 priority decisions; infrastructure: partial_implementation. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: gcp
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Public website visitors (faq-browser): External browser — no infrastructure to provision; connection behavior still requires validation; tools, External clients.
- Public help assistant (faq-app): Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified; gcp, australia-southeast1.
- Authorized article publisher (faq-editor): Existing — reference/import plan needed; tools, External operator.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: partial_implementation
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d61727469636c652d6c6966656379636c65 — priority 1

REQ-003 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### requirement-proposed-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365

### requirement-proposed-61692d7075626c69632d616e737765722d626f756e64617279 — priority 1

REQ-002 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d616e737765722d626f756e64617279

### requirement-proposed-61692d7075626c69632d6661712d6361706163697479 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d6661712d6361706163697479

### requirement-proposed-61692d7075626c69632d6661712d73636f7065 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d6661712d73636f7065

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

3 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d61727469636c652d6c6966656379636c65 — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### acceptance-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365

### acceptance-61692d7075626c69632d616e737765722d626f756e64617279 — priority 2

REQ-002: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d616e737765722d626f756e64617279

### acceptance-61692d7075626c69632d6661712d6361706163697479 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d6661712d6361706163697479

### acceptance-61692d7075626c69632d6661712d73636f7065 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d6661712d73636f7065

### acceptance-7265712d6131643735333632 — priority 2

REQ-001: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-7265712d6131643735333632

### traceability-7265712d6131643735333632 — priority 2

REQ-001 has no component links.

Action: Map the requirement to relevant components or record why it is project-wide; do not guess the mapping.

Tasks: TASK-ACCEPTANCE-7265712d6131643735333632

### existing-6661712d62726f77736572 — priority 2

Public website visitors: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-6661712d62726f77736572

### existing-6661712d656469746f72 — priority 2

Authorized article publisher: existing-system contract and access are unverified.

Action: Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.

Tasks: TASK-RESOURCE-6661712d656469746f72


# Component and interface contracts

Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-browser: Public website visitors

- Responsibility: Existing anonymous visitor browsers outside provisioning scope. Submit questions over HTTPS and display the returned answer with valid public-article citations or an explicit abstention. No visitor account is proposed. Expected demand is approximately 1,000 questions per day and five concurrent questions; these are planning inputs, not demonstrated capacity. Browsers are not a provisioned cloud service, while their requests, responses and network transfer can incur application charges.
- Service: Web browser
- Provider / placement: tools / External clients
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public help assistant

- Responsibility: Proposed composed public-faq-app module: anonymous browser website/API on Google Cloud Run, private regional Google Cloud Storage catalog, dedicated read-only runtime identity and regional Vertex AI model transport. Internal managed resources belong to this module; do not provision duplicates. Included scope: questions over twenty operator-supplied public UTF-8 help articles under 30 KB each, valid article citations, explicit abstention, and authorized article publication, updates and removal. Excluded scope: private content, private connectors, arbitrary URL fetching, visitor accounts and automated business actions. No public editing API is proposed.

Recommend deterministic keyword ranking over the small catalog, retrieving at most two complete articles per question. No embeddings, vector database or separate search service is needed initially. This saves components but can miss paraphrases; evaluate representative visitor questions and abstain when support is insufficient. Treat article and question text as untrusted data. Validate citation source membership and exact supporting quotes server-side; these checks alone do not prove that the answer is factually supported.

User demand: approximately 1,000 questions/day and five concurrent questions. Planning assumption: approximately 30,000 questions in a 30-day month, not a measured monthly total. The module admits five concurrent requests per instance; this is not a proven latency target or fleet-wide limit. Propose a single-region, scale-to-zero Cloud Run footprint with no warm minimum; cold-start tolerance and account-specific scaling limits require review. Preserve module bounds: maximum 100 articles of 30,000 bytes each, 2,000-byte questions and two retrieved complete articles. Validate actual files against the byte limit; reject oversized or invalid UTF-8 input explicitly.

An existing authorized editor publishes through the operator CLI using scoped native catalog permissions. The public runtime cannot publish. Conditional versioned catalog writes reject conflicting edits. Retrieval uses the current catalog and revision rechecks withhold an answer if sources change during its request; no stale-source fallback. Test update, deletion and concurrent-edit behavior, including requests already in flight.

Sydney (australia-southeast1) remains proposed for application and catalog placement, not an accepted region decision. Australia is preferred, not a confirmed strict residency rule. A compatible direct regional model, availability, quotas, processing geography, retention and abuse-logging terms remain unverified. Do not use a global endpoint or silently fall back overseas; present unavailable Australian inference for a business decision before use. Review logs, backups, service metadata and routing separately. Initial design has no cross-region failover and no agreed availability or recovery target.

Handoff work: reconcile generated resources and both existing connections with emitted source and Terraform; build, scan and test the exact pinned Python 3.13 Linux image; document destination project, identities, registry and regional model inputs. Qualify citation correctness, unsupported-question abstention, paraphrase retrieval, editor authorization, denied runtime writes, source injection, storage/model failures, revision conflicts and five-request concurrency. Verify model policy before inference. Propose metadata-only operational logs without question/answer bodies, error and saturation monitoring, and rollback instructions that preserve current catalog deletions. Client supplies the authorized editor; deployment and ongoing operational ownership remain to be assigned. Local mocks or emulation do not prove live IAM, model quality, processing location or deployment. No artifact-bound validation report is available.

Current price evidence is missing. The supplied pricing.lookup result for australia-southeast1 returned unavailable: an exact storage SKU requires configured billing-catalog access or a sourced quote; https://cloud.google.com/storage/pricing is a reference, not a retrieved regional quote. Monthly charges to price separately: Cloud Run requests/CPU/memory, model input/output tokens, Cloud Storage capacity/operations/version retention, transfer, logging, image registry and applicable build/support charges. No embedding or vector-store charges are proposed. Token usage, response duration, traffic bytes, article-change frequency and retention remain assumptions or unknowns. Monthly cloud subtotal is unknown; one-off build effort/rates are separately unknown.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-editor: Authorized article publisher

- Responsibility: Reference to the client's existing authorized Google Cloud editor identity, outside provisioning scope; exact identity remains a destination input and has not been verified. Supplies twenty public UTF-8 help-article files under 30 KB each; actual files must be checked against the module's 30,000-byte limit. Uses the module's operator CLI to publish, update and remove approved public articles through conditional catalog writes. Private content must never be published. This is an operator workflow, not a public editor API. Scoped native catalog permissions belong to the application module; its public runtime has no publishing rights. Conflicting edits must be surfaced for retry from a fresh revision. Publishing frequency and retained catalog-version volume are unknown.
- Service: Google Cloud IAM
- Provider / placement: tools / External operator
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-app: faq-browser → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d62726f777365722d617070
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-catalog: faq-editor → faq-app

- Drawn payload/purpose: Operator CLI → conditional catalog publish/update/delete
- Contract task: TASK-CONTRACT-6661712d656469746f722d636174616c6f67
- Integration task: TASK-INTEGRATION-6661712d656469746f722d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use emitted Python 3.13 applications/* source and BUILD.md. Install hash-locked runtime and test requirements in isolated provider environments and run faq_acceptance.py -v. Build, scan and test the exact Linux/amd64 image; obtain authorization before registry publication. Supply reviewed destination, image and model/policy inputs from deployment.tfvars.json.example. The runtime, port 8080, public-only retrieval, citations/abstention, source freshness, private catalog read role and separate editor grants are generated; do not ask the user to invent them. Seed the catalog only from a reviewed genuinely public UTF-8 directory using public_catalog_admin.py init. For updates/deletions inspect the current version, review and confirm the conditional write. Test unknown questions, prompt injection, concurrent edits and in-flight source changes. Source fixtures/schema/mock plans are not real cloud IAM, model quality or deployed evidence. Keep AWS versus IBM SDK dependency environments separate.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d62726f777365722d617070 — Define Public website visitors → Public help assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-browser-app: HTTPS question → cited answer or “I don’t know”. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-browser-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d656469746f722d636174616c6f67 — Define Authorized article publisher → Public help assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-editor-catalog: Operator CLI → conditional catalog publish/update/delete. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-editor-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d62726f77736572 — Integrate existing Public website visitors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d617070
- Components: faq-browser
- Generated files: No implementation files generated yet
- Requirements: ai-public-faq-capacity, ai-public-faq-scope

### Implementation steps

1. Responsibility from the board: Existing anonymous visitor browsers outside provisioning scope. Submit questions over HTTPS and display the returned answer with valid public-article citations or an explicit abstention. No visitor account is proposed. Expected demand is approximately 1,000 questions per day and five concurrent questions; these are planning inputs, not demonstrated capacity. Browsers are not a provisioned cloud service, while their requests, responses and network transfer can incur application charges.
2. Verify Web browser on tools in External clients; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed.; REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-browser
- Application/configuration and tests for Public website visitors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Validate generated Public help assistant

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d617070, TASK-CONTRACT-6661712d656469746f722d636174616c6f67
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-answer-boundary, ai-article-lifecycle, ai-australian-location-preference, ai-public-faq-capacity, ai-public-faq-scope

### Implementation steps

1. Responsibility from the board: Proposed composed public-faq-app module: anonymous browser website/API on Google Cloud Run, private regional Google Cloud Storage catalog, dedicated read-only runtime identity and regional Vertex AI model transport. Internal managed resources belong to this module; do not provision duplicates. Included scope: questions over twenty operator-supplied public UTF-8 help articles under 30 KB each, valid article citations, explicit abstention, and authorized article publication, updates and removal. Excluded scope: private content, private connectors, arbitrary URL fetching, visitor accounts and automated business actions. No public editing API is proposed.

Recommend deterministic keyword ranking over the small catalog, retrieving at most two complete articles per question. No embeddings, vector database or separate search service is needed initially. This saves components but can miss paraphrases; evaluate representative visitor questions and abstain when support is insufficient. Treat article and question text as untrusted data. Validate citation source membership and exact supporting quotes server-side; these checks alone do not prove that the answer is factually supported.

User demand: approximately 1,000 questions/day and five concurrent questions. Planning assumption: approximately 30,000 questions in a 30-day month, not a measured monthly total. The module admits five concurrent requests per instance; this is not a proven latency target or fleet-wide limit. Propose a single-region, scale-to-zero Cloud Run footprint with no warm minimum; cold-start tolerance and account-specific scaling limits require review. Preserve module bounds: maximum 100 articles of 30,000 bytes each, 2,000-byte questions and two retrieved complete articles. Validate actual files against the byte limit; reject oversized or invalid UTF-8 input explicitly.

An existing authorized editor publishes through the operator CLI using scoped native catalog permissions. The public runtime cannot publish. Conditional versioned catalog writes reject conflicting edits. Retrieval uses the current catalog and revision rechecks withhold an answer if sources change during its request; no stale-source fallback. Test update, deletion and concurrent-edit behavior, including requests already in flight.

Sydney (australia-southeast1) remains proposed for application and catalog placement, not an accepted region decision. Australia is preferred, not a confirmed strict residency rule. A compatible direct regional model, availability, quotas, processing geography, retention and abuse-logging terms remain unverified. Do not use a global endpoint or silently fall back overseas; present unavailable Australian inference for a business decision before use. Review logs, backups, service metadata and routing separately. Initial design has no cross-region failover and no agreed availability or recovery target.

Handoff work: reconcile generated resources and both existing connections with emitted source and Terraform; build, scan and test the exact pinned Python 3.13 Linux image; document destination project, identities, registry and regional model inputs. Qualify citation correctness, unsupported-question abstention, paraphrase retrieval, editor authorization, denied runtime writes, source injection, storage/model failures, revision conflicts and five-request concurrency. Verify model policy before inference. Propose metadata-only operational logs without question/answer bodies, error and saturation monitoring, and rollback instructions that preserve current catalog deletions. Client supplies the authorized editor; deployment and ongoing operational ownership remain to be assigned. Local mocks or emulation do not prove live IAM, model quality, processing location or deployment. No artifact-bound validation report is available.

Current price evidence is missing. The supplied pricing.lookup result for australia-southeast1 returned unavailable: an exact storage SKU requires configured billing-catalog access or a sourced quote; https://cloud.google.com/storage/pricing is a reference, not a retrieved regional quote. Monthly charges to price separately: Cloud Run requests/CPU/memory, model input/output tokens, Cloud Storage capacity/operations/version retention, transfer, logging, image registry and applicable build/support charges. No embedding or vector-store charges are proposed. Token usage, response duration, traffic bytes, article-change frequency and retention remain assumptions or unknowns. Monthly cloud subtotal is unknown; one-off build effort/rates are separately unknown.
2. Verify Google Cloud Run on gcp in australia-southeast1; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer.; REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.; REQ-004: Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback.; REQ-005: The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed.; REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for Public help assistant

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d656469746f72 — Integrate existing Authorized article publisher

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d656469746f722d636174616c6f67
- Components: faq-editor
- Generated files: terraform/main.tf.json
- Requirements: ai-article-lifecycle, ai-public-faq-scope

### Implementation steps

1. Responsibility from the board: Reference to the client's existing authorized Google Cloud editor identity, outside provisioning scope; exact identity remains a destination input and has not been verified. Supplies twenty public UTF-8 help-article files under 30 KB each; actual files must be checked against the module's 30,000-byte limit. Uses the module's operator CLI to publish, update and remove approved public articles through conditional catalog writes. Private content must never be published. This is an operator workflow, not a public editor API. Scoped native catalog permissions belong to the application module; its public runtime has no publishing rights. Conflicting edits must be surfaced for retry from a fresh revision. Publishing frequency and retained catalog-version volume are unknown.
2. Verify Google Cloud IAM on tools in External operator; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.; REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-editor
- Application/configuration and tests for Authorized article publisher

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d62726f777365722d617070 — Wire Public website visitors to Public help assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d62726f777365722d617070, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge faq-browser-app in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-browser-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d656469746f722d636174616c6f67 — Wire Authorized article publisher to Public help assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d656469746f722d636174616c6f67, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-editor-catalog carrying Operator CLI → conditional catalog publish/update/delete, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-editor-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070 — Verify live Public website visitors → Public help assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d62726f777365722d617070
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-browser-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-browser-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67 — Verify live Authorized article publisher → Public help assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d656469746f722d636174616c6f67
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-editor-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-editor-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d6131643735333632 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-a1d75362

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d616e737765722d626f756e64617279 — Verify REQ-002: The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-answer-boundary

### Implementation steps

1. Basis: “says when it does not know” and “It must not answer from private sources.”; rationale: Prevents private information from entering the public answer path and unsupported statements from being presented as established answers. Proposed acceptance checks must include private-source exclusion and unsupported questions.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65 — Verify REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: faq-editor, faq-app
- Generated files: terraform/main.tf.json, terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-article-lifecycle

### Implementation steps

1. Basis: “We need to update and remove articles.” The faq-editor reference proposes an authorized publishing workflow.; rationale: Keeps public answers aligned with maintained content. The proposed operator workflow separates publishing authority from public access and prevents stale concurrent edits from silently replacing newer content.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365 — Verify REQ-004: Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-australian-location-preference

### Implementation steps

1. Basis: User: “Australia is preferred; make model/data-location limitations explicit.” The faq-app module owns application hosting, article storage and model transport.; rationale: Proposed control: regional hosting alone cannot establish model processing or retention geography; explicit review prevents an undisclosed overseas fallback.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d6661712d6361706163697479 — Verify REQ-005: The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: faq-browser, faq-app
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-faq-capacity

### Implementation steps

1. Basis: “About 1,000 questions per day and five at once.” The faq-app module serves faq-browser.; rationale: Preserves the stated workload for sizing and acceptance testing without inventing a latency target. Five admitted requests per instance still requires end-to-end qualification.
2. Implement a check for Concurrent questions supported >= 5 questions; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d6661712d73636f7065 — Verify REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: faq-browser, faq-app, faq-editor
- Generated files: terraform/applications/block_6661712d617070/public_faq.py, terraform/applications/block_6661712d617070/public_catalog_store.py, terraform/applications/block_6661712d617070/public_faq_app.py, terraform/applications/block_6661712d617070/structured_http.py, terraform/applications/block_6661712d617070/structured_output.py, terraform/applications/block_6661712d617070/gcp_structured.py, terraform/applications/block_6661712d617070/policy_review.py, terraform/applications/block_6661712d617070/public_catalog_admin.py, terraform/applications/block_6661712d617070/web/index.html, terraform/applications/block_6661712d617070/web/app.css, terraform/applications/block_6661712d617070/web/app.js, terraform/applications/block_6661712d617070/faq_core_acceptance.py, terraform/applications/block_6661712d617070/faq_http_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_admin_acceptance.py, terraform/applications/block_6661712d617070/faq_catalog_store_acceptance.py, terraform/applications/block_6661712d617070/faq_acceptance.py, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/dependency-sources.json, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/test-dependency-sources.json, terraform/applications/block_6661712d617070/container-base.json, terraform/applications/block_6661712d617070/output-contract.json, terraform/applications/block_6661712d617070/faq-deployment.json, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/.dockerignore, terraform/applications/block_6661712d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/public-faq.tftest.hcl
- Requirements: ai-public-faq-scope

### Implementation steps

1. Basis: “Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content.”; rationale: Makes the initial delivery boundary explicit and prevents private-source or authentication features from being silently implied by a public FAQ module.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-6661712d62726f777365722d617070, TASK-INTEGRATION-6661712d656469746f722d636174616c6f67
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_6661712d617070/requirements.lock, terraform/applications/block_6661712d617070/test-requirements.lock, terraform/applications/block_6661712d617070/Dockerfile, terraform/applications/block_6661712d617070/BUILD.md, terraform/tests/public-faq.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d62726f77736572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f72, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d6131643735333632, TASK-ACCEPTANCE-61692d7075626c69632d616e737765722d626f756e64617279, TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65, TASK-ACCEPTANCE-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365, TASK-ACCEPTANCE-61692d7075626c69632d6661712d6361706163697479, TASK-ACCEPTANCE-61692d7075626c69632d6661712d73636f7065, TASK-INTEGRATION-LIVE-6661712d62726f777365722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d636174616c6f67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-001 (req-a1d75362) → TASK-ACCEPTANCE-7265712d6131643735333632; Recorded from user discussion
- REQ-002 (ai-public-answer-boundary) → TASK-ACCEPTANCE-61692d7075626c69632d616e737765722d626f756e64617279; Proposed; needs confirmation
- REQ-003 (ai-article-lifecycle) → TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65; Proposed; needs confirmation
- REQ-004 (ai-australian-location-preference) → TASK-ACCEPTANCE-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365; Proposed; needs confirmation
- REQ-005 (ai-public-faq-capacity) → TASK-ACCEPTANCE-61692d7075626c69632d6661712d6361706163697479; Proposed; needs confirmation
- REQ-006 (ai-public-faq-scope) → TASK-ACCEPTANCE-61692d7075626c69632d6661712d73636f7065; Proposed; needs confirmation
