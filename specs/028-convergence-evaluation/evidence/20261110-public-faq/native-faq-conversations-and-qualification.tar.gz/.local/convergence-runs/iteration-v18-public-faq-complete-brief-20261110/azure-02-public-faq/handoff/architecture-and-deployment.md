Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

# Cited public FAQ — deployment document

Generated 2026-11-09 21:59 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** 30,000 requests/month (discovery (2026-11-10))
- **Estimated run cost:** not estimated
- **Review:** 6 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Anonymous website visitors; an authorized editor manages the articles. About 1,000 questions per day and five at once. Answers need valid source citations; unsupported questions must abstain; updates and deletions must affect retrieval. Recommend the simplest suitable retrieval approach and a small footprint. Show assumptions and missing current price evidence.
- **Systems it connects to:** —
- **How good, fast and safe:** Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. Australia is preferred; make model/data-location limitations explicit.
- **Cloud preference:** Azure
- **Budget and timeline:** —

## 3. Architecture

**Public access**

- Public website visitors (Tools & data, existing) — Existing visitor browsers access the public assistant over HTTPS and receive an answer with article citations or an explicit abstention. External client reference outside provisioning scope; no visitor account is proposed.

**Public FAQ application**

- Public help-article assistant (Azure, sketch) — Proposed composed public-faq-app module on Azure App Service, owning browser UI/API, private Azure Blob Storage article catalog, separate scoped editor and read-only runtime identities, and regional model transport. Internal services remain module-owned rather than duplicate diagram deployments. Included scope: anonymous visitor questions; answers from twenty approved public UTF-8 help articles under 30 KB each, supplied as files; valid citations; explicit abstention; authorized article publication, updates and deletions. Excluded scope: private sources, arbitrary URL fetching, visitor accounts and automated business actions. Recommend bounded lexical/keyword retrieval over the catalog, selecting at most two complete articles; no embeddings, vector database or separate managed search service is proposed. Test synonyms and paraphrases before accepting retrieval quality; insufficient support must produce abstention rather than an invented answer. Treat article text as untrusted data. Validate citation membership, current revision, public URL and supporting quotes in application code; these checks alone do not establish factual entailment. Authorized CLI tooling conditionally changes the versioned catalog; reject conflicting edits, recheck revisions before returning an answer, and withhold answers when sources change or dependencies fail. No stale-source fallback. Updates and deletions must affect subsequent retrieval. User demand: approximately 1,000 questions per day and five simultaneous requests; 30,000 requests/month is a 30-day planning assumption. Contract bounds: 100 articles, 30000 UTF-8 bytes/article, 2000-byte questions, two complete retrieved articles and five admitted requests per instance. Propose one initial application instance on the smallest suitable App Service plan, selected after memory/startup and five-request load tests; no high-availability or recovery target is established. Apply server-side admission limits and safe overload responses; bounds do not cap the invoice or establish anti-abuse protection. Australia is preferred, not a confirmed strict residency boundary. Australia East remains proposed for application/catalog. Before inference, verify the selected Azure model/version, regional deployment type, quota, processing geography, abuse-monitoring retention and approval, logs and backups; no automatic global or overseas fallback. Existing editor identity and Azure destination inputs remain unverified; never place credentials in the project. Engineer handoff: reconcile emitted Terraform/resource addresses, scoped permissions, editor CLI, catalog concurrency controls, lexical retrieval, citation validation and abstention against this scope; build, scan and test the pinned emitted Linux image. Run functional, unauthorized-edit, private-ingestion denial, source-injection, paraphrase, unsupported-question, update/delete, concurrent-edit, dependency-failure, recovery, five-request load and cleanup checks; preserve artifact-bound reports and unresolved failures. Local scripted model tests do not prove answer quality, Azure IAM or deployment. Operator ownership, availability/recovery needs and abuse/spend controls remain open before launch. Current pricing evidence covers only Hot LRS base storage at USD 0.02/GB-month from Azure Retail Prices API dated 2026-11-09; compute, model tokens, operations, transfer, logs, backups and support remain unpriced. Monthly cloud costs and one-off build/validation costs remain separate and incomplete. No inspected artifact or destination-specific deployment evidence exists.

**Article management**

- Authorized article editor (Tools & data, existing) — External human operator using the module's generated editor CLI to publish public UTF-8 files with reviewed citation URLs and to update or delete articles. Outside provisioning scope. The existing authorized Azure editor identity must be supplied and reviewed; no identity or permission has been verified. No public editor endpoint is proposed. This actor's connection describes the module-owned catalog management responsibility, not an independently implemented editor-to-App-Service API.

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Public help-article assistant<br/>Azure"]
  n2["Authorized article editor<br/>Tools & data"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Authorized CLI → module-owned catalog: publish, update, delete| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public website visitors | tools | Web browser | External browsers | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public help-article assistant | azure | Azure App Service | Australia East (proposed; unverified) | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article editor | tools | Authorized operator | External operator; location unconfirmed | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public website visitors** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public help-article assistant** (faq-app): azurerm_linux_web_app, azurerm_storage_account, azurerm_storage_container. Confirm service, capacity and billable dimensions. Depends on: faq-browser, faq-editor.
- **Authorized article editor** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article editor: Existing — reference/import plan needed.
- Wire faq-editor → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Public website visitors | Public help-article assistant | HTTPS question → cited answer or “I don’t know” | Public |
| Authorized article editor | Public help-article assistant | Authorized CLI → module-owned catalog: publish, update, delete | Public |

## 5. Security controls

- **Authorized article editor** — External human operator using the module's generated editor CLI to publish public UTF-8 files with reviewed citation URLs and to update or delete articles. Outside provisioning scope. The existing authorized Azure editor identity must be supplied and reviewed; no identity or permission has been verified. No public editor endpoint is proposed. This actor's connection describes the module-owned catalog management responsibility, not an independently implemented editor-to-App-Service API.
- Requirement: The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried. (must)
- Requirement: The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback. (should)
- Requirement: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback. | compliance | not measurable yet | Open |
| The application shall support five simultaneous questions while preserving grounding, citation and abstention checks. Capacity qualification shall use the expected approximately 1,000 questions per day; latency and availability targets remain unspecified. | performance | supported simultaneous questions >= 5requests | Open |

**Functional**

- Every answer shows its sources (should, open)
- The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried. (must, open)
- Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation. (must, open)
- Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 1 block is sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Public website visitors, Public help-article assistant, Authorized article editor.

**Estimate gaps:**

- Public website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public help-article assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorized article editor: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public faq application: Public help-article assistant.
4. Connect existing systems: Public website visitors, Authorized article editor; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
