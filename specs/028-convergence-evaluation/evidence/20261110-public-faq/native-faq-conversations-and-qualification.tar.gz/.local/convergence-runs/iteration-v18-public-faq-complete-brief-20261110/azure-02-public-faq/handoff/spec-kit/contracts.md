# Component and interface contracts

Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-browser: Public website visitors

- Responsibility: Existing visitor browsers access the public assistant over HTTPS and receive an answer with article citations or an explicit abstention. External client reference outside provisioning scope; no visitor account is proposed.
- Service: Web browser
- Provider / placement: tools / External browsers
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public help-article assistant

- Responsibility: Proposed composed public-faq-app module on Azure App Service, owning browser UI/API, private Azure Blob Storage article catalog, separate scoped editor and read-only runtime identities, and regional model transport. Internal services remain module-owned rather than duplicate diagram deployments. Included scope: anonymous visitor questions; answers from twenty approved public UTF-8 help articles under 30 KB each, supplied as files; valid citations; explicit abstention; authorized article publication, updates and deletions. Excluded scope: private sources, arbitrary URL fetching, visitor accounts and automated business actions. Recommend bounded lexical/keyword retrieval over the catalog, selecting at most two complete articles; no embeddings, vector database or separate managed search service is proposed. Test synonyms and paraphrases before accepting retrieval quality; insufficient support must produce abstention rather than an invented answer. Treat article text as untrusted data. Validate citation membership, current revision, public URL and supporting quotes in application code; these checks alone do not establish factual entailment. Authorized CLI tooling conditionally changes the versioned catalog; reject conflicting edits, recheck revisions before returning an answer, and withhold answers when sources change or dependencies fail. No stale-source fallback. Updates and deletions must affect subsequent retrieval. User demand: approximately 1,000 questions per day and five simultaneous requests; 30,000 requests/month is a 30-day planning assumption. Contract bounds: 100 articles, 30000 UTF-8 bytes/article, 2000-byte questions, two complete retrieved articles and five admitted requests per instance. Propose one initial application instance on the smallest suitable App Service plan, selected after memory/startup and five-request load tests; no high-availability or recovery target is established. Apply server-side admission limits and safe overload responses; bounds do not cap the invoice or establish anti-abuse protection. Australia is preferred, not a confirmed strict residency boundary. Australia East remains proposed for application/catalog. Before inference, verify the selected Azure model/version, regional deployment type, quota, processing geography, abuse-monitoring retention and approval, logs and backups; no automatic global or overseas fallback. Existing editor identity and Azure destination inputs remain unverified; never place credentials in the project. Engineer handoff: reconcile emitted Terraform/resource addresses, scoped permissions, editor CLI, catalog concurrency controls, lexical retrieval, citation validation and abstention against this scope; build, scan and test the pinned emitted Linux image. Run functional, unauthorized-edit, private-ingestion denial, source-injection, paraphrase, unsupported-question, update/delete, concurrent-edit, dependency-failure, recovery, five-request load and cleanup checks; preserve artifact-bound reports and unresolved failures. Local scripted model tests do not prove answer quality, Azure IAM or deployment. Operator ownership, availability/recovery needs and abuse/spend controls remain open before launch. Current pricing evidence covers only Hot LRS base storage at USD 0.02/GB-month from Azure Retail Prices API dated 2026-11-09; compute, model tokens, operations, transfer, logs, backups and support remain unpriced. Monthly cloud costs and one-off build/validation costs remain separate and incomplete. No inspected artifact or destination-specific deployment evidence exists.
- Service: Azure App Service
- Provider / placement: azure / Australia East (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-editor: Authorized article editor

- Responsibility: External human operator using the module's generated editor CLI to publish public UTF-8 files with reviewed citation URLs and to update or delete articles. Outside provisioning scope. The existing authorized Azure editor identity must be supplied and reviewed; no identity or permission has been verified. No public editor endpoint is proposed. This actor's connection describes the module-owned catalog management responsibility, not an independently implemented editor-to-App-Service API.
- Service: Authorized operator
- Provider / placement: tools / External operator; location unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-https: faq-browser → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d62726f777365722d6874747073
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d6874747073
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-catalog-management: faq-editor → faq-app

- Drawn payload/purpose: Authorized CLI → module-owned catalog: publish, update, delete
- Contract task: TASK-CONTRACT-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Integration task: TASK-INTEGRATION-6661712d656469746f722d636174616c6f672d6d616e6167656d656e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
