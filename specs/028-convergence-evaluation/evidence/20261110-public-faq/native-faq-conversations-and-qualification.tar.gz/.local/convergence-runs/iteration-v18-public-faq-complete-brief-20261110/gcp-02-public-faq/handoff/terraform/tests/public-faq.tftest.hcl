mock_provider "google" {
 override_during = plan
 mock_data "google_project" { defaults = { number = "123456789012" } }
 mock_resource "google_service_account" { defaults = { email = "runtime@reviewed-project.iam.gserviceaccount.com" } }
}
mock_provider "google-beta" {
 override_during = plan
 mock_resource "google_project_service_identity" { defaults = { email = "service-123456789012@serverless-robot-prod.iam.gserviceaccount.com", member = "serviceAccount:service-123456789012@serverless-robot-prod.iam.gserviceaccount.com" } }
}

variables {
review_approved = true
project_id = "reviewed-project"
registry_location = "australia-southeast1"
registry_repository = "reviewed-images"
block_6661712d617070_name = "reviewed-public-help"
block_6661712d617070_region = "australia-southeast1"
block_6661712d617070_image_repository = "architect/public-help"
block_6661712d617070_image_digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
block_6661712d617070_model_id = "gemini-reviewed-version"
block_6661712d617070_editor_group = "help-editors@example.test"
block_6661712d617070_policy_review = {"projectId":"reviewed-project","region":"australia-southeast1","model":"gemini-reviewed-version","abuseLogging":"REVIEW_REQUIRED","approvedBy":"REVIEW_REQUIRED","evidenceSha256":"0000000000000000000000000000000000000000000000000000000000000000","expiresAt":"REPLACE_AFTER_REVIEW"}
}
run "block_6661712d617070_public_boundary" {
 command = plan
 assert {
 condition = google_storage_bucket.block_6661712d617070.public_access_prevention == "enforced" && google_storage_bucket.block_6661712d617070.uniform_bucket_level_access && !google_storage_bucket.block_6661712d617070.force_destroy
 error_message = "Only the app is public; the catalog bucket stays private and protected."
 }
 assert {
 condition = google_cloud_run_v2_service_iam_member.block_6661712d617070.member == "allUsers" && google_cloud_run_v2_service_iam_member.block_6661712d617070.role == "roles/run.invoker" && !google_cloud_run_v2_service.block_6661712d617070.iap_enabled
 error_message = "This explicit public-only application has anonymous invocation, not an invented end-user identity."
 }
 assert {
 condition = toset(google_project_iam_custom_role.block_6661712d617070_catalog.permissions) == toset(["storage.objects.get"]) && google_storage_bucket_iam_member.block_6661712d617070_editor.member == "group:${var.block_6661712d617070_editor_group}"
 error_message = "Runtime read and native editor write authority must remain separate."
 }
}
run "block_6661712d617070_mutable_image_blocked" {
 command = plan
 variables { block_6661712d617070_image_digest = "latest" }
 expect_failures = [var.block_6661712d617070_image_digest]
}
run "unapproved_blocked" {
 command = plan
 variables { review_approved = false }
 expect_failures = [terraform_data.review_gate]
}
