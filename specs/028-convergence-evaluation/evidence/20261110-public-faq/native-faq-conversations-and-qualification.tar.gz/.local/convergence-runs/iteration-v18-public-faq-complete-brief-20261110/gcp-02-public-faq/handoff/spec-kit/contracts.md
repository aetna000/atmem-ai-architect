# Component and interface contracts

Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-browser: Public website visitors

- Responsibility: Existing anonymous visitor browsers outside provisioning scope. Submit questions over HTTPS and display the returned answer with valid public-article citations or an explicit abstention. No visitor account is proposed. Expected demand is approximately 1,000 questions per day and five concurrent questions; these are planning inputs, not demonstrated capacity. Browsers are not a provisioned cloud service, while their requests, responses and network transfer can incur application charges.
- Service: Web browser
- Provider / placement: tools / External clients
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public help assistant

- Responsibility: Proposed composed public-faq-app module: anonymous browser website/API on Google Cloud Run, private regional Google Cloud Storage catalog, dedicated read-only runtime identity and regional Vertex AI model transport. Internal managed resources belong to this module; do not provision duplicates. Included scope: questions over twenty operator-supplied public UTF-8 help articles under 30 KB each, valid article citations, explicit abstention, and authorized article publication, updates and removal. Excluded scope: private content, private connectors, arbitrary URL fetching, visitor accounts and automated business actions. No public editing API is proposed.

Recommend deterministic keyword ranking over the small catalog, retrieving at most two complete articles per question. No embeddings, vector database or separate search service is needed initially. This saves components but can miss paraphrases; evaluate representative visitor questions and abstain when support is insufficient. Treat article and question text as untrusted data. Validate citation source membership and exact supporting quotes server-side; these checks alone do not prove that the answer is factually supported.

User demand: approximately 1,000 questions/day and five concurrent questions. Planning assumption: approximately 30,000 questions in a 30-day month, not a measured monthly total. The module admits five concurrent requests per instance; this is not a proven latency target or fleet-wide limit. Propose a single-region, scale-to-zero Cloud Run footprint with no warm minimum; cold-start tolerance and account-specific scaling limits require review. Preserve module bounds: maximum 100 articles of 30,000 bytes each, 2,000-byte questions and two retrieved complete articles. Validate actual files against the byte limit; reject oversized or invalid UTF-8 input explicitly.

An existing authorized editor publishes through the operator CLI using scoped native catalog permissions. The public runtime cannot publish. Conditional versioned catalog writes reject conflicting edits. Retrieval uses the current catalog and revision rechecks withhold an answer if sources change during its request; no stale-source fallback. Test update, deletion and concurrent-edit behavior, including requests already in flight.

Sydney (australia-southeast1) remains proposed for application and catalog placement, not an accepted region decision. Australia is preferred, not a confirmed strict residency rule. A compatible direct regional model, availability, quotas, processing geography, retention and abuse-logging terms remain unverified. Do not use a global endpoint or silently fall back overseas; present unavailable Australian inference for a business decision before use. Review logs, backups, service metadata and routing separately. Initial design has no cross-region failover and no agreed availability or recovery target.

Handoff work: reconcile generated resources and both existing connections with emitted source and Terraform; build, scan and test the exact pinned Python 3.13 Linux image; document destination project, identities, registry and regional model inputs. Qualify citation correctness, unsupported-question abstention, paraphrase retrieval, editor authorization, denied runtime writes, source injection, storage/model failures, revision conflicts and five-request concurrency. Verify model policy before inference. Propose metadata-only operational logs without question/answer bodies, error and saturation monitoring, and rollback instructions that preserve current catalog deletions. Client supplies the authorized editor; deployment and ongoing operational ownership remain to be assigned. Local mocks or emulation do not prove live IAM, model quality, processing location or deployment. No artifact-bound validation report is available.

Current price evidence is missing. The supplied pricing.lookup result for australia-southeast1 returned unavailable: an exact storage SKU requires configured billing-catalog access or a sourced quote; https://cloud.google.com/storage/pricing is a reference, not a retrieved regional quote. Monthly charges to price separately: Cloud Run requests/CPU/memory, model input/output tokens, Cloud Storage capacity/operations/version retention, transfer, logging, image registry and applicable build/support charges. No embedding or vector-store charges are proposed. Token usage, response duration, traffic bytes, article-change frequency and retention remain assumptions or unknowns. Monthly cloud subtotal is unknown; one-off build effort/rates are separately unknown.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-editor: Authorized article publisher

- Responsibility: Reference to the client's existing authorized Google Cloud editor identity, outside provisioning scope; exact identity remains a destination input and has not been verified. Supplies twenty public UTF-8 help-article files under 30 KB each; actual files must be checked against the module's 30,000-byte limit. Uses the module's operator CLI to publish, update and remove approved public articles through conditional catalog writes. Private content must never be published. This is an operator workflow, not a public editor API. Scoped native catalog permissions belong to the application module; its public runtime has no publishing rights. Conflicting edits must be surfaced for retry from a fresh revision. Publishing frequency and retained catalog-version volume are unknown.
- Service: Google Cloud IAM
- Provider / placement: tools / External operator
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-app: faq-browser → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d62726f777365722d617070
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-catalog: faq-editor → faq-app

- Drawn payload/purpose: Operator CLI → conditional catalog publish/update/delete
- Contract task: TASK-CONTRACT-6661712d656469746f722d636174616c6f67
- Integration task: TASK-INTEGRATION-6661712d656469746f722d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
