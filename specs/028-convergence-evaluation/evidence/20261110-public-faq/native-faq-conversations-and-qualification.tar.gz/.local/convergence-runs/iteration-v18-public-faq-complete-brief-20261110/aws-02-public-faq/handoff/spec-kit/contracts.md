# Component and interface contracts

Snapshot d6384891-e306-4e39-8877-c68e59dcba9b · design r4 · generated 2026-11-09T21:56:35.410Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-browser: Public website visitor

- Responsibility: Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the answer, article citations or an explicit abstention. No visitor account is proposed.
- Service: Web browser
- Provider / placement: tools / Visitor location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Public FAQ website and assistant

- Responsibility: Proposed composed public-faq-app module: anonymous browser UI/API, owned private regional Amazon S3 catalog containing only approved public article content, read-only runtime identity and regional Amazon Bedrock transport. Initial input is twenty supplied UTF-8 files under 30 KB each; propose a conservative 30000-byte per-file validation limit. Authorized operator CLI publishes files and source links, updates and removes articles through conditional versioned catalog writes; visitors and runtime cannot write. Recommend deterministic keyword ranking across the small catalog, retrieving at most two complete articles per question; no embeddings, vector database, arbitrary URL fetch, private connectors, visitor accounts or automated business actions. Keyword coverage and answer quality require representative evaluation. Responses must cite current approved article IDs/source links and supporting quotes; validate source membership and quotes independently, while recognizing these checks do not prove factual entailment. Abstain for insufficient evidence, catalog/model failure or source revision changes during processing; never answer from a stale fallback. Treat article text as untrusted evidence. Updates/deletions affect subsequent retrieval; recheck supporting revisions before returning an in-flight answer. Expected load: about 1000 questions/day and five simultaneous requests; estimate 30000 questions per 30-day month as an assumption. Contract bounds remain 100 articles, 30000 bytes/article, 2000-byte questions, two retrieved articles and five admitted requests per instance. Propose explicit overload responses without invoking the model beyond admission capacity; these bounds are not a spending cap. Start with one small application deployment, subject to load tests and provider minimums; instance size and scaling are not verified. Australia is preferred; Sydney ap-southeast-2 remains proposed, not approved. Verify direct regional model availability, entitlement, quotas, data-use/retention policy and processing geography before enabling inference. No automatic overseas inference, fallback or cross-region recovery. Browser traffic may cross borders; logs, backups, support and metadata locations remain unverified. Propose body-free operational logs and single-region operation; retention, recovery objectives and operating ownership remain open. Hosting blocker: supplied AWS lifecycle review dated 2026-11-07 reports App Runner closed to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html); existing-customer eligibility is unverified. If ineligible, recommend AWS ECS Fargate with implemented public HTTPS ingress and the same FAQ/catalog/model/editor behavior. That alternative needs native generator/application integration work; the current App Runner contract and a generic container footprint do not implement it. Keep deployment blocked pending hosting resolution, tested immutable image, reviewed editor identity and artifact-bound acceptance evidence. Monthly cost evidence is unavailable: include hosting/ingress, Bedrock input/output tokens, S3 storage/version history/requests, transfer, logs, backups and applicable support. Model, tokens per question, runtime sizing, transfer and current regional rates are unknown; no monthly total is supported. One-off build cost is separate and unestimated; no effort or rate is assumed.
- Service: AWS App Runner
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Verify account eligibility before retaining App Runner; it is closed to new customers. Record the hosting decision and current official availability evidence.
- Specify one deployment unit per actual application, immutable image, registry access, instance role, ingress/egress, health checks and scaling.
- Design identity sessions, secrets, custom domain/TLS, logs and rollback; test deployment health and source dependency failures.

## Component faq-editor: Authorized article editor

- Responsibility: Existing external authorized operator identity reference, outside provisioning scope and not verified. Supplies twenty public UTF-8 article files under 30 KB each and reviewed source links through the module's operator CLI. Publishes, updates and removes only approved public content using conditional versioned catalog writes; conflicting writes fail rather than overwrite newer edits. Separate from anonymous visitors and the read-only runtime. Reviewed destination identity and permission evidence remain required; no ARN or credentials are stored in the diagram. Proposed file limit is 30000 bytes to fit the bounded module. Editor onboarding, update/delete procedures and recovery instructions must accompany the handoff.
- Service: External operator identity
- Provider / placement: tools / External operator
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-app: faq-browser → faq-app

- Drawn payload/purpose: HTTPS questions; cited answers or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d62726f777365722d617070
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-catalog: faq-editor → faq-app

- Drawn payload/purpose: Operator CLI → owned catalog: conditional publish/update/delete
- Contract task: TASK-CONTRACT-6661712d656469746f722d636174616c6f67
- Integration task: TASK-INTEGRATION-6661712d656469746f722d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
