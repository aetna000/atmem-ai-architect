# Questions and assumptions to resolve

Snapshot 4d2b9fb8-5cb6-42c7-aeb2-8e06b3883a90 · design r4 · generated 2026-11-09T21:59:42.842Z

- [ai-public-grounding] Confirm REQ-002: The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried.
- [ai-article-lifecycle] Confirm REQ-003: Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation.
- [ai-location-transparency] Confirm REQ-004: The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback.
- [ai-public-access-boundary] Confirm REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.
- [ai-faq-concurrent-capacity] Confirm REQ-006: The application shall support five simultaneous questions while preserving grounding, citation and abstention checks. Capacity qualification shall use the expected approximately 1,000 questions per day; latency and availability targets remain unspecified.
- [acceptance-req-05d8f4f6] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-public-grounding] Agree a measurable acceptance check for REQ-002: The assistant shall answer using only the approved public help-article catalog and explicitly state when that catalog does not support an answer; private sources shall not be ingested or queried.
- [acceptance-ai-article-lifecycle] Agree a measurable acceptance check for REQ-003: Authorized editors shall be able to update and remove articles; conflicting edits shall be rejected, and answers shall be withheld when supporting articles change during generation.
- [acceptance-ai-location-transparency] Agree a measurable acceptance check for REQ-004: The design should prefer Australian storage and processing and document the actual locations and retention arrangements for the catalog, inference, logs and backups before inference is enabled. Any overseas processing shall be disclosed for review rather than enabled through automatic fallback.
- [acceptance-ai-public-access-boundary] Agree a measurable acceptance check for REQ-005: Visitors shall be able to ask questions without signing in. Article publication, updates and deletions shall require an authorized editor identity; anonymous visitors and the answering runtime shall not have catalog write permission.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d61727469636c652d6c6966656379636c65] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6661712d636f6e63757272656e742d6361706163697479] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d6163636573732d626f756e64617279] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d67726f756e64696e67] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
