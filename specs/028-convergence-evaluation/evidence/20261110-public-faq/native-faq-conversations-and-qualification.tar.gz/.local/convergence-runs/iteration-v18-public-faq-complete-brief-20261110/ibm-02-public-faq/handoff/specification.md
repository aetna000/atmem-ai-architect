Snapshot 49e015ab-57a2-4a4d-a118-e59e79bf86e0 · design r4 · generated 2026-11-09T22:05:33.257Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-002] The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope. (must, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Restricting retrieval to an explicitly published public catalog prevents private sources from entering public answers; abstention limits unsupported responses.

Basis: “says when it does not know” and “It must not answer from private sources.”
- [REQ-003] An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed. (must, open); target: acceptance target needed; linked blocks: faq-publisher, faq-app

Design explanation: Controlled publication and source revision checks reduce unauthorized changes and prevent removed or superseded content from supporting new answers.

Basis: “We need to update and remove articles.” The proposed faq-publisher path separates publication from public question access.
- [REQ-004] Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement. (should, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Public articles do not make visitor questions public, and local storage alone cannot establish the model's processing geography.

Basis: “Australia is preferred; make model/data-location limitations explicit.” The faq-app module stores articles and sends questions and retrieved excerpts to watsonx.
- [REQ-005] The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified. (must, open); target: simultaneous_questions_supported >= 5questions; linked blocks: faq-browser, faq-app

Design explanation: Preserves the stated simultaneous workload; an application admission bound alone does not demonstrate that the model and destination can serve it.

Basis: “About 1,000 questions per day and five at once.” Monthly planning uses a stated 30-day assumption.
- [REQ-006] Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals. (must, open); target: acceptance target needed; linked blocks: faq-browser, faq-app, faq-publisher

Design explanation: Makes the handoff boundary explicit without adding services or silently assuming private integrations and business workflows.

Basis: “Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content.”

## How the system works

The current design contains 3 components and 2 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Public visitor browser → Public FAQ website and assistant

HTTPS question → cited answer or “I don’t know”

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Authorized article publisher → Public FAQ website and assistant

Operator CLI → conditional catalog publish/update/delete

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Public visitor browser

Web browser · tools · region: Visitor location · classification: Public

Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the application's answer, article citations or abstention. Public visitors have no publishing access.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Public visitor browser → Public FAQ website and assistant: HTTPS question → cited answer or “I don’t know” (integration: browser-https)

Requirement traceability: REQ-005: The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified.; REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public FAQ website and assistant

IBM Code Engine · ibm · region: Australia preferred; destination region unconfirmed · classification: Public

Proposed composed public-faq-app module on IBM Code Engine: Python browser/API, private IBM Cloud Object Storage catalog containing only approved public article text and URLs, read-only runtime identity and regional watsonx Text Chat transport. Internal catalog, model transport and identities belong to this module; do not duplicate them as independent canvas resources. Anonymous visitors may ask questions but cannot publish. Initial corpus: twenty public UTF-8 files under 30 KB each, supplied by an authorized editor; no private content. Recommend deterministic keyword ranking over this small catalog, retrieving at most two complete articles, without embeddings or a vector database. Lexical matching may miss paraphrases; assess representative questions before adding retrieval complexity. Confirm this recommendation against emitted application code rather than assuming the implementation from the graph. Return answers with supporting quotes and valid article citations; abstain for insufficient support, invalid source references or source changes during a request. Quote validation alone does not establish factual entailment. Treat articles and questions as untrusted data, never as publishing authority or model instructions. Authorized operator CLI conditionally publishes, updates and deletes approved articles with reviewed public source URLs; stale edits conflict. Updates and deletions must affect subsequent retrieval, and source revision rechecks must withhold in-flight answers based on changed or removed articles. Catalog failure has no cached-source fallback; model failure returns an unavailable response rather than an invented answer. Supported contract bounds: at most 100 UTF-8 articles of 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Required workload: about 1000 questions/day and five simultaneous requests; approximately 30000/month assumes a 30-day planning month. Capacity and answer quality remain untested. Prefer a single application deployment with its owned catalog and model transport; propose scale-to-zero where supported and accept possible cold starts as an unresolved latency tradeoff, with no latency or availability guarantee. Private sources, arbitrary URL fetching, visitor accounts and automated actions are proposed exclusions. Australia is preferred, not a mandatory Australia-only boundary. Assess IBM Sydney (au-syd) as a candidate; Code Engine, Object Storage, watsonx model/version, plans, quotas and interoperability have not been verified. Australian storage does not establish Australian inference: questions and retrieved excerpts go to the selected model endpoint. Independently establish locations and retention for inference, abuse monitoring, application/platform logs, backups and global routing or support processing. No model, overseas fallback or cross-region recovery is selected. Obtain client agreement before proposing overseas processing; do not enable inference until destination model data-use and retention policy is reviewed. Proposed application logs exclude raw questions and article bodies; enforcement and provider-side retention need evidence. Verify scoped publisher/runtime permissions, immutable image, destination configuration, denial/failure/recovery paths and source-change behavior. Publisher maintains the source files; operational ownership, catalog recovery and rollback procedures remain to be assigned and tested. Current native price evidence, model token usage, runtime sizing and autoscaling costs are missing; no monthly estimate or one-off build estimate is established. Compiler capability is not evidence of deployed behavior or a completed handoff.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public visitor browser → Public FAQ website and assistant: HTTPS question → cited answer or “I don’t know” (integration: browser-https); Authorized article publisher → Public FAQ website and assistant: Operator CLI → conditional catalog publish/update/delete

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope.; REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.; REQ-004: Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement.; REQ-005: The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified.; REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.

Implementation status: Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authorized article publisher

Authorized publishing operator · tools · region: Operator location · classification: Internal

Reference to the client's authorized editor/operator identity, outside provisioning scope; exact native IBM identity and permissions are not supplied or verified. Supplies twenty public UTF-8 help-article files under 30 KB each and reviewed public source URLs. Uses the module's generated operator CLI to publish, conditionally update and remove articles in the owned catalog. Proposed publishing validation rejects oversized files and invalid source metadata explicitly. Requires separate scoped native IBM catalog permissions; anonymous visitors and the read-only application runtime receive no publication authority. Preserve conditional-write conflicts and source revision checks. No public editor endpoint, private-source connector or credentials are represented. Source-file retention, operational owner and tested catalog recovery remain to be documented.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorized article publisher → Public FAQ website and assistant: Operator CLI → conditional catalog publish/update/delete

Requirement traceability: REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.; REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Public visitor browser<br/>Tools & data"]
  n1["Public FAQ website and assistant<br/>IBM"]
  n2["Authorized article publisher<br/>Tools & data"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Operator CLI → conditional catalog publish/update/delete| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public visitor browser | tools | Web browser | Visitor location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public FAQ website and assistant | ibm | IBM Code Engine | Australia preferred; destination region unconfirmed | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-publisher | Authorized article publisher | tools | Authorized publishing operator | Operator location | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public visitor browser** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public FAQ website and assistant** (faq-app): ibm_code_engine_app, ibm_cos_bucket, ibm_iam_trusted_profile. Confirm service, capacity and billable dimensions. Depends on: faq-browser, faq-publisher.
- **Authorized article publisher** (faq-publisher): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article publisher: Existing — reference/import plan needed.
- Wire faq-publisher → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
