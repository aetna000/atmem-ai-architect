Snapshot d6384891-e306-4e39-8877-c68e59dcba9b · design r4 · generated 2026-11-09T21:56:35.410Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-002] The assistant shall retrieve answer evidence only from the approved public help-article catalog and shall provide no private-source connector or arbitrary URL retrieval path. (must, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Prevents private material or arbitrary external content from entering the public answer path; a private storage bucket does not make its approved public articles private sources.

Basis: “twenty public help articles” and “It must not answer from private sources.”
- [REQ-003] The assistant shall cite the approved articles supporting each substantive answer and explicitly abstain when those articles provide insufficient evidence; source changes or retrieval failures shall not produce an unsupported answer. (must, open); target: acceptance target needed; linked blocks: faq-app, faq-browser

Design explanation: Unsupported answers could mislead visitors. Citation presence alone does not establish factual support, so answer quality requires representative supported and unsupported question tests.

Basis: “cites the articles it used, and says when it does not know” and existing source requirement req-089bcf38.
- [REQ-004] Authorized editors shall be able to publish, update and remove public articles through a separate management path; public visitors and the read-only answer runtime shall not have catalog write permission. Conflicting edits shall be rejected, and answers shall be withheld when a supporting article changes or is removed during processing. (must, open); target: acceptance target needed; linked blocks: faq-editor, faq-app

Design explanation: Visitors must not change the catalog, and stale edits or concurrent removals must not silently publish obsolete information. Conditional writes and source revision rechecks are proposed controls.

Basis: “We need to update and remove articles.”
- [REQ-005] The application should prefer Australian storage and server-side processing. Before implementation approval, document the selected model's availability, inference geography, data-use and retention policies, and locations of logs, backups and relevant service processing. Overseas inference or recovery must not be silently enabled; any exception requires an explicit user decision. Australian end-to-end residency remains unverified. (should, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Proposed location controls make the Australian preference actionable without claiming regional service placement proves all processing stays in Australia.

Basis: User: “Australia is preferred; make model/data-location limitations explicit.” Applies to faq-app and its owned catalog, model transport and operational data.
- [REQ-006] The public FAQ shall support five simultaneous question requests at an expected volume of about 1,000 questions daily. Proposed overload behavior shall reject excess work explicitly without unsupported answers or unbounded model calls; response-time acceptance remains unspecified. (must, open); target: simultaneous supported question requests >= 5requests; linked blocks: faq-browser, faq-app

Design explanation: Preserves the stated simultaneous load without inventing a response-time target; admission and overload behavior need load-test evidence.

Basis: “About 1,000 questions per day and five at once.”
- [REQ-007] The first version shall provide anonymous website question answering over twenty supplied public UTF-8 help articles under 30 KB each and a separate authorized article-management path. Private content is excluded. Proposed additional exclusions are private connectors, arbitrary URL fetching, visitor accounts and automated business actions. (must, open); target: acceptance target needed; linked blocks: faq-browser, faq-app, faq-editor

Design explanation: Makes the requested first-version boundary explicit and prevents unsupported private integrations or unrelated workflows from entering the handoff.

Basis: “Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content.”

## How the system works

The current design contains 3 components and 2 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Public website visitor → Public FAQ website and assistant

HTTPS questions; cited answers or “I don’t know”

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Authorized article editor → Public FAQ website and assistant

Operator CLI → owned catalog: conditional publish/update/delete

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Public website visitor

Web browser · tools · region: Visitor location · classification: Public

Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the answer, article citations or an explicit abstention. No visitor account is proposed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Public website visitor → Public FAQ website and assistant: HTTPS questions; cited answers or “I don’t know” (integration: browser-https)

Requirement traceability: REQ-003: The assistant shall cite the approved articles supporting each substantive answer and explicitly abstain when those articles provide insufficient evidence; source changes or retrieval failures shall not produce an unsupported answer.; REQ-006: The public FAQ shall support five simultaneous question requests at an expected volume of about 1,000 questions daily. Proposed overload behavior shall reject excess work explicitly without unsupported answers or unbounded model calls; response-time acceptance remains unspecified.; REQ-007: The first version shall provide anonymous website question answering over twenty supplied public UTF-8 help articles under 30 KB each and a separate authorized article-management path. Private content is excluded. Proposed additional exclusions are private connectors, arbitrary URL fetching, visitor accounts and automated business actions.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public FAQ website and assistant

AWS App Runner · aws · region: ap-southeast-2 · classification: Public

Proposed composed public-faq-app module: anonymous browser UI/API, owned private regional Amazon S3 catalog containing only approved public article content, read-only runtime identity and regional Amazon Bedrock transport. Initial input is twenty supplied UTF-8 files under 30 KB each; propose a conservative 30000-byte per-file validation limit. Authorized operator CLI publishes files and source links, updates and removes articles through conditional versioned catalog writes; visitors and runtime cannot write. Recommend deterministic keyword ranking across the small catalog, retrieving at most two complete articles per question; no embeddings, vector database, arbitrary URL fetch, private connectors, visitor accounts or automated business actions. Keyword coverage and answer quality require representative evaluation. Responses must cite current approved article IDs/source links and supporting quotes; validate source membership and quotes independently, while recognizing these checks do not prove factual entailment. Abstain for insufficient evidence, catalog/model failure or source revision changes during processing; never answer from a stale fallback. Treat article text as untrusted evidence. Updates/deletions affect subsequent retrieval; recheck supporting revisions before returning an in-flight answer. Expected load: about 1000 questions/day and five simultaneous requests; estimate 30000 questions per 30-day month as an assumption. Contract bounds remain 100 articles, 30000 bytes/article, 2000-byte questions, two retrieved articles and five admitted requests per instance. Propose explicit overload responses without invoking the model beyond admission capacity; these bounds are not a spending cap. Start with one small application deployment, subject to load tests and provider minimums; instance size and scaling are not verified. Australia is preferred; Sydney ap-southeast-2 remains proposed, not approved. Verify direct regional model availability, entitlement, quotas, data-use/retention policy and processing geography before enabling inference. No automatic overseas inference, fallback or cross-region recovery. Browser traffic may cross borders; logs, backups, support and metadata locations remain unverified. Propose body-free operational logs and single-region operation; retention, recovery objectives and operating ownership remain open. Hosting blocker: supplied AWS lifecycle review dated 2026-11-07 reports App Runner closed to new customers (https://docs.aws.amazon.com/apprunner/latest/dg/apprunner-availability-change.html); existing-customer eligibility is unverified. If ineligible, recommend AWS ECS Fargate with implemented public HTTPS ingress and the same FAQ/catalog/model/editor behavior. That alternative needs native generator/application integration work; the current App Runner contract and a generic container footprint do not implement it. Keep deployment blocked pending hosting resolution, tested immutable image, reviewed editor identity and artifact-bound acceptance evidence. Monthly cost evidence is unavailable: include hosting/ingress, Bedrock input/output tokens, S3 storage/version history/requests, transfer, logs, backups and applicable support. Model, tokens per question, runtime sizing, transfer and current regional rates are unknown; no monthly total is supported. One-off build cost is separate and unestimated; no effort or rate is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public website visitor → Public FAQ website and assistant: HTTPS questions; cited answers or “I don’t know” (integration: browser-https); Authorized article editor → Public FAQ website and assistant: Operator CLI → owned catalog: conditional publish/update/delete

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The assistant shall retrieve answer evidence only from the approved public help-article catalog and shall provide no private-source connector or arbitrary URL retrieval path.; REQ-003: The assistant shall cite the approved articles supporting each substantive answer and explicitly abstain when those articles provide insufficient evidence; source changes or retrieval failures shall not produce an unsupported answer.; REQ-004: Authorized editors shall be able to publish, update and remove public articles through a separate management path; public visitors and the read-only answer runtime shall not have catalog write permission. Conflicting edits shall be rejected, and answers shall be withheld when a supporting article changes or is removed during processing.; REQ-005: The application should prefer Australian storage and server-side processing. Before implementation approval, document the selected model's availability, inference geography, data-use and retention policies, and locations of logs, backups and relevant service processing. Overseas inference or recovery must not be silently enabled; any exception requires an explicit user decision. Australian end-to-end residency remains unverified.; REQ-006: The public FAQ shall support five simultaneous question requests at an expected volume of about 1,000 questions daily. Proposed overload behavior shall reject excess work explicitly without unsupported answers or unbounded model calls; response-time acceptance remains unspecified.; REQ-007: The first version shall provide anonymous website question answering over twenty supplied public UTF-8 help articles under 30 KB each and a separate authorized article-management path. Private content is excluded. Proposed additional exclusions are private connectors, arbitrary URL fetching, visitor accounts and automated business actions.

Implementation status: Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Verify account eligibility before retaining App Runner; it is closed to new customers. Record the hosting decision and current official availability evidence.
- Specify one deployment unit per actual application, immutable image, registry access, instance role, ingress/egress, health checks and scaling.
- Design identity sessions, secrets, custom domain/TLS, logs and rollback; test deployment health and source dependency failures.

### Authorized article editor

External operator identity · tools · region: External operator · classification: Public

Existing external authorized operator identity reference, outside provisioning scope and not verified. Supplies twenty public UTF-8 article files under 30 KB each and reviewed source links through the module's operator CLI. Publishes, updates and removes only approved public content using conditional versioned catalog writes; conflicting writes fail rather than overwrite newer edits. Separate from anonymous visitors and the read-only runtime. Reviewed destination identity and permission evidence remain required; no ARN or credentials are stored in the diagram. Proposed file limit is 30000 bytes to fit the bounded module. Editor onboarding, update/delete procedures and recovery instructions must accompany the handoff.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorized article editor → Public FAQ website and assistant: Operator CLI → owned catalog: conditional publish/update/delete

Requirement traceability: REQ-004: Authorized editors shall be able to publish, update and remove public articles through a separate management path; public visitors and the read-only answer runtime shall not have catalog write permission. Conflicting edits shall be rejected, and answers shall be withheld when a supporting article changes or is removed during processing.; REQ-007: The first version shall provide anonymous website question answering over twenty supplied public UTF-8 help articles under 30 KB each and a separate authorized article-management path. Private content is excluded. Proposed additional exclusions are private connectors, arbitrary URL fetching, visitor accounts and automated business actions.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Public website visitor<br/>Tools & data"]
  n1["Public FAQ website and assistant<br/>AWS"]
  n2["Authorized article editor<br/>Tools & data"]
  n0 -->|HTTPS questions; cited answers or “I don’t know”| n1
  n2 -->|Operator CLI → owned catalog: conditional publish/update/delete| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public website visitor | tools | Web browser | Visitor location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public FAQ website and assistant | aws | AWS App Runner | ap-southeast-2 | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article editor | tools | External operator identity | External operator | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public website visitor** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public FAQ website and assistant** (faq-app): aws_apprunner_service, aws_s3_bucket, aws_iam_role. Provisioned and active compute, builds, logs and transfer. Depends on: faq-browser, faq-editor.
- **Authorized article editor** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article editor: Existing — reference/import plan needed.
- Wire faq-editor → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
