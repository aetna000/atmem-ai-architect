Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

# Cited public FAQ — deployment document

Generated 2026-11-09 22:02 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Google Cloud
- **Usage:** 30,000 requests/month (discovery (2026-11-10))
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 5 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. About 1,000 questions per day and five at once. Answers need valid source citations; unsupported questions must abstain; updates and deletions must affect retrieval. Recommend the simplest suitable retrieval approach and a small footprint. Show assumptions and missing current price evidence.
- **Systems it connects to:** —
- **How good, fast and safe:** Australia is preferred; make model/data-location limitations explicit.
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**Public access**

- Public website visitors (Tools & data, existing) — Existing anonymous visitor browsers outside provisioning scope. Submit questions over HTTPS and display the returned answer with valid public-article citations or an explicit abstention. No visitor account is proposed. Expected demand is approximately 1,000 questions per day and five concurrent questions; these are planning inputs, not demonstrated capacity. Browsers are not a provisioned cloud service, while their requests, responses and network transfer can incur application charges.

**Public answers and article catalog**

- Public help assistant (Google Cloud) — Proposed composed public-faq-app module: anonymous browser website/API on Google Cloud Run, private regional Google Cloud Storage catalog, dedicated read-only runtime identity and regional Vertex AI model transport. Internal managed resources belong to this module; do not provision duplicates. Included scope: questions over twenty operator-supplied public UTF-8 help articles under 30 KB each, valid article citations, explicit abstention, and authorized article publication, updates and removal. Excluded scope: private content, private connectors, arbitrary URL fetching, visitor accounts and automated business actions. No public editing API is proposed.

Recommend deterministic keyword ranking over the small catalog, retrieving at most two complete articles per question. No embeddings, vector database or separate search service is needed initially. This saves components but can miss paraphrases; evaluate representative visitor questions and abstain when support is insufficient. Treat article and question text as untrusted data. Validate citation source membership and exact supporting quotes server-side; these checks alone do not prove that the answer is factually supported.

User demand: approximately 1,000 questions/day and five concurrent questions. Planning assumption: approximately 30,000 questions in a 30-day month, not a measured monthly total. The module admits five concurrent requests per instance; this is not a proven latency target or fleet-wide limit. Propose a single-region, scale-to-zero Cloud Run footprint with no warm minimum; cold-start tolerance and account-specific scaling limits require review. Preserve module bounds: maximum 100 articles of 30,000 bytes each, 2,000-byte questions and two retrieved complete articles. Validate actual files against the byte limit; reject oversized or invalid UTF-8 input explicitly.

An existing authorized editor publishes through the operator CLI using scoped native catalog permissions. The public runtime cannot publish. Conditional versioned catalog writes reject conflicting edits. Retrieval uses the current catalog and revision rechecks withhold an answer if sources change during its request; no stale-source fallback. Test update, deletion and concurrent-edit behavior, including requests already in flight.

Sydney (australia-southeast1) remains proposed for application and catalog placement, not an accepted region decision. Australia is preferred, not a confirmed strict residency rule. A compatible direct regional model, availability, quotas, processing geography, retention and abuse-logging terms remain unverified. Do not use a global endpoint or silently fall back overseas; present unavailable Australian inference for a business decision before use. Review logs, backups, service metadata and routing separately. Initial design has no cross-region failover and no agreed availability or recovery target.

Handoff work: reconcile generated resources and both existing connections with emitted source and Terraform; build, scan and test the exact pinned Python 3.13 Linux image; document destination project, identities, registry and regional model inputs. Qualify citation correctness, unsupported-question abstention, paraphrase retrieval, editor authorization, denied runtime writes, source injection, storage/model failures, revision conflicts and five-request concurrency. Verify model policy before inference. Propose metadata-only operational logs without question/answer bodies, error and saturation monitoring, and rollback instructions that preserve current catalog deletions. Client supplies the authorized editor; deployment and ongoing operational ownership remain to be assigned. Local mocks or emulation do not prove live IAM, model quality, processing location or deployment. No artifact-bound validation report is available.

Current price evidence is missing. The supplied pricing.lookup result for australia-southeast1 returned unavailable: an exact storage SKU requires configured billing-catalog access or a sourced quote; https://cloud.google.com/storage/pricing is a reference, not a retrieved regional quote. Monthly charges to price separately: Cloud Run requests/CPU/memory, model input/output tokens, Cloud Storage capacity/operations/version retention, transfer, logging, image registry and applicable build/support charges. No embedding or vector-store charges are proposed. Token usage, response duration, traffic bytes, article-change frequency and retention remain assumptions or unknowns. Monthly cloud subtotal is unknown; one-off build effort/rates are separately unknown.

**Controlled article publishing**

- Authorized article publisher (Tools & data, existing) — Reference to the client's existing authorized Google Cloud editor identity, outside provisioning scope; exact identity remains a destination input and has not been verified. Supplies twenty public UTF-8 help-article files under 30 KB each; actual files must be checked against the module's 30,000-byte limit. Uses the module's operator CLI to publish, update and remove approved public articles through conditional catalog writes. Private content must never be published. This is an operator workflow, not a public editor API. Scoped native catalog permissions belong to the application module; its public runtime has no publishing rights. Conflicting edits must be surfaced for retry from a fresh revision. Publishing frequency and retained catalog-version volume are unknown.

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Public help assistant<br/>Google Cloud"]
  n2["Authorized article publisher<br/>Tools & data"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Operator CLI → conditional catalog publish/update/delete| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public website visitors | tools | Web browser | External clients | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public help assistant | gcp | Google Cloud Run | australia-southeast1 | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article publisher | tools | Google Cloud IAM | External operator | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public website visitors** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public help assistant** (faq-app): google_cloud_run_v2_service, google_storage_bucket, google_service_account. Confirm service, capacity and billable dimensions. Depends on: faq-browser, faq-editor.
- **Authorized article publisher** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article publisher: Existing — reference/import plan needed.
- Wire faq-editor → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Public website visitors | Public help assistant | HTTPS question → cited answer or “I don’t know” | Public |
| Authorized article publisher | Public help assistant | Operator CLI → conditional catalog publish/update/delete | Public |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer. (must)
- Requirement: Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback. | compliance | not measurable yet | Open |
| The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed. | performance | Concurrent questions supported >= 5questions | Open |

**Functional**

- Every answer shows its sources (should, open)
- The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer. (must, open)
- An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten. (must, open)
- The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Authorized article publisher | Data processed | needs data_gb | price needed | — | — |

**Usage inputs:** Data stored: — (needed).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Public website visitors, Public help assistant.

**Estimate gaps:**

- Authorized article publisher / Data processed: input needed (data_gb).
- Public website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public help assistant: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public answers and article catalog: Public help assistant.
4. Connect existing systems: Public website visitors, Authorized article publisher; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
- Authorized article publisher: needs data_gb _(estimate)_
