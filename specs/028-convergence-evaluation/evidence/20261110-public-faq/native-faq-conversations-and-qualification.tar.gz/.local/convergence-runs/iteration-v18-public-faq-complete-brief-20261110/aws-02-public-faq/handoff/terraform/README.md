# AWS public-only FAQ composition

The generated anonymous browser/API runs on App Runner. Its instance role has only
GetObject on this private bucket's catalog.json, direct regional Bedrock InvokeModel
on the selected foundation model and regional read-only retention/logging checks.
A separate editor role, assumed by an existing reviewed company role, has Get/Put
only on catalog.json. Article deletion rewrites the manifest; object DELETE and
bucket administration are absent. Existing permissions can broaden effective
access and must be reviewed. No HTTP editing route, arbitrary source fetch, user
login or private knowledge authorization is implied by this public-only module.

The new bucket has all public-access blocks, owner-enforced ownership, AES256
encryption, TLS-only policy, versioning, seven-day noncurrent expiry and protected
deletion. Recovery versions are not an immediate-erasure guarantee. Only current
articles are retrieved and the source version is rechecked before returning an
answer. Questions/answers are not persisted or written to application logs; review
platform logs separately. Public endpoints use IAM rather than private networking.

App Runner uses an existing PRIVATE ECR repository with IMMUTABLE tags and no
exclusions. The precondition verifies the chosen build tag resolves to the exact
qualified digest and automatic deployments are disabled. This uses a verified tag,
not an unsupported claim that App Runner accepts a digest-form image identifier.
Protect registry deletion/tag-policy administration and retain the source, scan and
image evidence. The separate image-pull role has repository-scoped reads plus the
required account-level ECR token operation. Service-linked role creation may be
required by App Runner; review the destination operator's permissions.

See applications/*/BUILD.md for source, tests, build and conditional editor steps.
The synchronous Converse operation requests JSON and strictly validates returned
fields, source IDs and quoted evidence. It does not claim Bedrock constrained JSON
grammar: first-time grammar compilation can exceed the HTTP deadline. Bad output
fails closed; real model citation/answer/abstention and latency checks are required.
Before inference the app requires retention mode none and text logging disabled,
and never changes those account-wide controls. Verify model/region availability,
terms, quotas and current prices. A minimum warm App Runner instance incurs cost;
instance/concurrency/token bounds are not an invoice cap or anonymous abuse control.

Use Terraform 1.17.1+, init -backend=false, validate and test. Local provider mocks
are not real IAM, ECR, model or account-plan evidence. Build/scan/test the exact image,
seed only genuinely public articles and review budgets/abuse controls before traffic.
Protect state/variables and obtain authorization before registry publication, cloud
access, real plans or deployment. Production state/backup/operations remain gated.

References:
- https://docs.aws.amazon.com/apprunner/latest/dg/security_iam_service-with-iam.html
- https://docs.aws.amazon.com/bedrock/latest/userguide/structured-output.html
