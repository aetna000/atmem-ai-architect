Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-002] The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer. (must, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Prevents private information from entering the public answer path and unsupported statements from being presented as established answers. Proposed acceptance checks must include private-source exclusion and unsupported questions.

Basis: “says when it does not know” and “It must not answer from private sources.”
- [REQ-003] An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten. (must, open); target: acceptance target needed; linked blocks: faq-editor, faq-app

Design explanation: Keeps public answers aligned with maintained content. The proposed operator workflow separates publishing authority from public access and prevents stale concurrent edits from silently replacing newer content.

Basis: “We need to update and remove articles.” The faq-editor reference proposes an authorized publishing workflow.
- [REQ-004] Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback. (should, open); target: acceptance target needed; linked blocks: faq-app

Design explanation: Proposed control: regional hosting alone cannot establish model processing or retention geography; explicit review prevents an undisclosed overseas fallback.

Basis: User: “Australia is preferred; make model/data-location limitations explicit.” The faq-app module owns application hosting, article storage and model transport.
- [REQ-005] The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed. (must, open); target: Concurrent questions supported >= 5questions; linked blocks: faq-browser, faq-app

Design explanation: Preserves the stated workload for sizing and acceptance testing without inventing a latency target. Five admitted requests per instance still requires end-to-end qualification.

Basis: “About 1,000 questions per day and five at once.” The faq-app module serves faq-browser.
- [REQ-006] The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit. (must, open); target: acceptance target needed; linked blocks: faq-browser, faq-app, faq-editor

Design explanation: Makes the initial delivery boundary explicit and prevents private-source or authentication features from being silently implied by a public FAQ module.

Basis: “Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content.”

## How the system works

The current design contains 3 components and 2 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Public website visitors → Public help assistant

HTTPS question → cited answer or “I don’t know”

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Authorized article publisher → Public help assistant

Operator CLI → conditional catalog publish/update/delete

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Public website visitors

Web browser · tools · region: External clients · classification: Public

Existing anonymous visitor browsers outside provisioning scope. Submit questions over HTTPS and display the returned answer with valid public-article citations or an explicit abstention. No visitor account is proposed. Expected demand is approximately 1,000 questions per day and five concurrent questions; these are planning inputs, not demonstrated capacity. Browsers are not a provisioned cloud service, while their requests, responses and network transfer can incur application charges.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Public website visitors → Public help assistant: HTTPS question → cited answer or “I don’t know” (integration: browser-https)

Requirement traceability: REQ-005: The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed.; REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public help assistant

Google Cloud Run · gcp · region: australia-southeast1 · classification: Public

Proposed composed public-faq-app module: anonymous browser website/API on Google Cloud Run, private regional Google Cloud Storage catalog, dedicated read-only runtime identity and regional Vertex AI model transport. Internal managed resources belong to this module; do not provision duplicates. Included scope: questions over twenty operator-supplied public UTF-8 help articles under 30 KB each, valid article citations, explicit abstention, and authorized article publication, updates and removal. Excluded scope: private content, private connectors, arbitrary URL fetching, visitor accounts and automated business actions. No public editing API is proposed.

Recommend deterministic keyword ranking over the small catalog, retrieving at most two complete articles per question. No embeddings, vector database or separate search service is needed initially. This saves components but can miss paraphrases; evaluate representative visitor questions and abstain when support is insufficient. Treat article and question text as untrusted data. Validate citation source membership and exact supporting quotes server-side; these checks alone do not prove that the answer is factually supported.

User demand: approximately 1,000 questions/day and five concurrent questions. Planning assumption: approximately 30,000 questions in a 30-day month, not a measured monthly total. The module admits five concurrent requests per instance; this is not a proven latency target or fleet-wide limit. Propose a single-region, scale-to-zero Cloud Run footprint with no warm minimum; cold-start tolerance and account-specific scaling limits require review. Preserve module bounds: maximum 100 articles of 30,000 bytes each, 2,000-byte questions and two retrieved complete articles. Validate actual files against the byte limit; reject oversized or invalid UTF-8 input explicitly.

An existing authorized editor publishes through the operator CLI using scoped native catalog permissions. The public runtime cannot publish. Conditional versioned catalog writes reject conflicting edits. Retrieval uses the current catalog and revision rechecks withhold an answer if sources change during its request; no stale-source fallback. Test update, deletion and concurrent-edit behavior, including requests already in flight.

Sydney (australia-southeast1) remains proposed for application and catalog placement, not an accepted region decision. Australia is preferred, not a confirmed strict residency rule. A compatible direct regional model, availability, quotas, processing geography, retention and abuse-logging terms remain unverified. Do not use a global endpoint or silently fall back overseas; present unavailable Australian inference for a business decision before use. Review logs, backups, service metadata and routing separately. Initial design has no cross-region failover and no agreed availability or recovery target.

Handoff work: reconcile generated resources and both existing connections with emitted source and Terraform; build, scan and test the exact pinned Python 3.13 Linux image; document destination project, identities, registry and regional model inputs. Qualify citation correctness, unsupported-question abstention, paraphrase retrieval, editor authorization, denied runtime writes, source injection, storage/model failures, revision conflicts and five-request concurrency. Verify model policy before inference. Propose metadata-only operational logs without question/answer bodies, error and saturation monitoring, and rollback instructions that preserve current catalog deletions. Client supplies the authorized editor; deployment and ongoing operational ownership remain to be assigned. Local mocks or emulation do not prove live IAM, model quality, processing location or deployment. No artifact-bound validation report is available.

Current price evidence is missing. The supplied pricing.lookup result for australia-southeast1 returned unavailable: an exact storage SKU requires configured billing-catalog access or a sourced quote; https://cloud.google.com/storage/pricing is a reference, not a retrieved regional quote. Monthly charges to price separately: Cloud Run requests/CPU/memory, model input/output tokens, Cloud Storage capacity/operations/version retention, transfer, logging, image registry and applicable build/support charges. No embedding or vector-store charges are proposed. Token usage, response duration, traffic bytes, article-change frequency and retention remain assumptions or unknowns. Monthly cloud subtotal is unknown; one-off build effort/rates are separately unknown.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public website visitors → Public help assistant: HTTPS question → cited answer or “I don’t know” (integration: browser-https); Authorized article publisher → Public help assistant: Operator CLI → conditional catalog publish/update/delete

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer.; REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.; REQ-004: Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback.; REQ-005: The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed.; REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.

Implementation status: Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authorized article publisher

Google Cloud IAM · tools · region: External operator · classification: Public

Reference to the client's existing authorized Google Cloud editor identity, outside provisioning scope; exact identity remains a destination input and has not been verified. Supplies twenty public UTF-8 help-article files under 30 KB each; actual files must be checked against the module's 30,000-byte limit. Uses the module's operator CLI to publish, update and remove approved public articles through conditional catalog writes. Private content must never be published. This is an operator workflow, not a public editor API. Scoped native catalog permissions belong to the application module; its public runtime has no publishing rights. Conflicting edits must be surfaced for retry from a fresh revision. Publishing frequency and retained catalog-version volume are unknown.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorized article publisher → Public help assistant: Operator CLI → conditional catalog publish/update/delete

Requirement traceability: REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.; REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Public help assistant<br/>Google Cloud"]
  n2["Authorized article publisher<br/>Tools & data"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Operator CLI → conditional catalog publish/update/delete| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public website visitors | tools | Web browser | External clients | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public help assistant | gcp | Google Cloud Run | australia-southeast1 | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-editor | Authorized article publisher | tools | Google Cloud IAM | External operator | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public website visitors** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public help assistant** (faq-app): google_cloud_run_v2_service, google_storage_bucket, google_service_account. Confirm service, capacity and billable dimensions. Depends on: faq-browser, faq-editor.
- **Authorized article publisher** (faq-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article publisher: Existing — reference/import plan needed.
- Wire faq-editor → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
