# Questions and assumptions to resolve

Snapshot 54d4ac50-3286-46b1-9bae-a281280e1eb9 · design r4 · generated 2026-11-09T22:02:49.040Z

- [ai-public-answer-boundary] Confirm REQ-002: The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer.
- [ai-article-lifecycle] Confirm REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.
- [ai-australian-location-preference] Confirm REQ-004: Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback.
- [ai-public-faq-capacity] Confirm REQ-005: The public assistant shall support approximately 1,000 questions per day and five concurrent questions. Qualification shall exercise five concurrent requests and document completion, failures and observed latency; no response-time guarantee is yet agreed.
- [ai-public-faq-scope] Confirm REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.
- [acceptance-req-a1d75362] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-public-answer-boundary] Agree a measurable acceptance check for REQ-002: The public assistant shall use only explicitly published public help articles as source material and shall explicitly abstain when those articles do not support an answer.
- [acceptance-ai-article-lifecycle] Agree a measurable acceptance check for REQ-003: An authorized publisher shall be able to add, update and remove public help articles; removed or superseded content shall not support subsequent answers, and conflicting edits shall be rejected rather than silently overwritten.
- [acceptance-ai-australian-location-preference] Agree a measurable acceptance check for REQ-004: Prefer Australian application hosting, article storage and model processing. Document verified locations and unresolved limitations for inference, retention, logs, backups and routing; obtain an explicit business decision before adopting overseas model processing. Do not silently use global endpoints or overseas inference fallback.
- [acceptance-ai-public-faq-scope] Agree a measurable acceptance check for REQ-006: The initial system shall serve anonymous website visitors using twenty supplied public UTF-8 help-article files under 30 KB each, with publication managed by an authorized editor. Proposed exclusions are private-source access, arbitrary URL ingestion, visitor accounts and automated business actions. Actual files shall be validated against the implementation's 30,000-byte per-article limit.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d61727469636c652d6c6966656379636c65] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6175737472616c69616e2d6c6f636174696f6e2d707265666572656e6365] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d616e737765722d626f756e64617279] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d6661712d6361706163697479] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d6661712d73636f7065] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
