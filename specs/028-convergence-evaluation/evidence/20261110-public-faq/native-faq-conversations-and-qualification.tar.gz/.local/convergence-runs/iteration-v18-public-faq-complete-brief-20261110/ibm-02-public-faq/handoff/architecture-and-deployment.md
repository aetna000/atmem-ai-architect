Snapshot 49e015ab-57a2-4a4d-a118-e59e79bf86e0 · design r4 · generated 2026-11-09T22:05:33.257Z

# Cited public FAQ — deployment document

Generated 2026-11-09 22:05 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** IBM
- **Usage:** 30,000 requests/month (discovery (2026-11-10))
- **Estimated run cost:** not estimated
- **Review:** 5 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Anonymous website visitors; an authorized editor manages the articles. Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. About 1,000 questions per day and five at once. Answers need valid source citations; unsupported questions must abstain; updates and deletions must affect retrieval. Recommend the simplest suitable retrieval approach and a small footprint. Show assumptions and missing current price evidence.
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM Australia is preferred; make model/data-location limitations explicit.
- **Budget and timeline:** —

## 3. Architecture

**Public questions**

- Public visitor browser (Tools & data, existing) — Existing visitor browser outside provisioning scope. Sends questions over HTTPS and displays the application's answer, article citations or abstention. Public visitors have no publishing access.

**Public FAQ application**

- Public FAQ website and assistant (IBM) — Proposed composed public-faq-app module on IBM Code Engine: Python browser/API, private IBM Cloud Object Storage catalog containing only approved public article text and URLs, read-only runtime identity and regional watsonx Text Chat transport. Internal catalog, model transport and identities belong to this module; do not duplicate them as independent canvas resources. Anonymous visitors may ask questions but cannot publish. Initial corpus: twenty public UTF-8 files under 30 KB each, supplied by an authorized editor; no private content. Recommend deterministic keyword ranking over this small catalog, retrieving at most two complete articles, without embeddings or a vector database. Lexical matching may miss paraphrases; assess representative questions before adding retrieval complexity. Confirm this recommendation against emitted application code rather than assuming the implementation from the graph. Return answers with supporting quotes and valid article citations; abstain for insufficient support, invalid source references or source changes during a request. Quote validation alone does not establish factual entailment. Treat articles and questions as untrusted data, never as publishing authority or model instructions. Authorized operator CLI conditionally publishes, updates and deletes approved articles with reviewed public source URLs; stale edits conflict. Updates and deletions must affect subsequent retrieval, and source revision rechecks must withhold in-flight answers based on changed or removed articles. Catalog failure has no cached-source fallback; model failure returns an unavailable response rather than an invented answer. Supported contract bounds: at most 100 UTF-8 articles of 30000 bytes each, 2000-byte questions, two complete retrieved articles and five concurrent admitted requests per instance. Required workload: about 1000 questions/day and five simultaneous requests; approximately 30000/month assumes a 30-day planning month. Capacity and answer quality remain untested. Prefer a single application deployment with its owned catalog and model transport; propose scale-to-zero where supported and accept possible cold starts as an unresolved latency tradeoff, with no latency or availability guarantee. Private sources, arbitrary URL fetching, visitor accounts and automated actions are proposed exclusions. Australia is preferred, not a mandatory Australia-only boundary. Assess IBM Sydney (au-syd) as a candidate; Code Engine, Object Storage, watsonx model/version, plans, quotas and interoperability have not been verified. Australian storage does not establish Australian inference: questions and retrieved excerpts go to the selected model endpoint. Independently establish locations and retention for inference, abuse monitoring, application/platform logs, backups and global routing or support processing. No model, overseas fallback or cross-region recovery is selected. Obtain client agreement before proposing overseas processing; do not enable inference until destination model data-use and retention policy is reviewed. Proposed application logs exclude raw questions and article bodies; enforcement and provider-side retention need evidence. Verify scoped publisher/runtime permissions, immutable image, destination configuration, denial/failure/recovery paths and source-change behavior. Publisher maintains the source files; operational ownership, catalog recovery and rollback procedures remain to be assigned and tested. Current native price evidence, model token usage, runtime sizing and autoscaling costs are missing; no monthly estimate or one-off build estimate is established. Compiler capability is not evidence of deployed behavior or a completed handoff.

**Article publishing**

- Authorized article publisher (Tools & data, existing) — Reference to the client's authorized editor/operator identity, outside provisioning scope; exact native IBM identity and permissions are not supplied or verified. Supplies twenty public UTF-8 help-article files under 30 KB each and reviewed public source URLs. Uses the module's generated operator CLI to publish, conditionally update and remove articles in the owned catalog. Proposed publishing validation rejects oversized files and invalid source metadata explicitly. Requires separate scoped native IBM catalog permissions; anonymous visitors and the read-only application runtime receive no publication authority. Preserve conditional-write conflicts and source revision checks. No public editor endpoint, private-source connector or credentials are represented. Source-file retention, operational owner and tested catalog recovery remain to be documented.

```mermaid
flowchart LR
  n0["Public visitor browser<br/>Tools & data"]
  n1["Public FAQ website and assistant<br/>IBM"]
  n2["Authorized article publisher<br/>Tools & data"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Operator CLI → conditional catalog publish/update/delete| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-browser | Public visitor browser | tools | Web browser | Visitor location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Public FAQ website and assistant | ibm | IBM Code Engine | Australia preferred; destination region unconfirmed | Proposed | Public-only cited FAQ source, browser, private catalog, separate editor/runtime roles and regional model transport generated; destination behavior unverified |
| faq-publisher | Authorized article publisher | tools | Authorized publishing operator | Operator location | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Public visitor browser** (faq-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public FAQ website and assistant** (faq-app): ibm_code_engine_app, ibm_cos_bucket, ibm_iam_trusted_profile. Confirm service, capacity and billable dimensions. Depends on: faq-browser, faq-publisher.
- **Authorized article publisher** (faq-publisher): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

- Authorized article publisher: Existing — reference/import plan needed.
- Wire faq-publisher → faq-app: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Public visitor browser | Public FAQ website and assistant | HTTPS question → cited answer or “I don’t know” | Public |
| Authorized article publisher | Public FAQ website and assistant | Operator CLI → conditional catalog publish/update/delete | Internal |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope. (must)
- Requirement: Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement. | compliance | not measurable yet | Open |
| The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified. | performance | simultaneous_questions_supported >= 5questions | Open |

**Functional**

- Every answer shows its sources (should, open)
- The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope. (must, open)
- An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed. (must, open)
- Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Public visitor browser, Public FAQ website and assistant, Authorized article publisher.

**Estimate gaps:**

- Public visitor browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public FAQ website and assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorized article publisher: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public faq application: Public FAQ website and assistant.
4. Connect existing systems: Public visitor browser, Authorized article publisher; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
