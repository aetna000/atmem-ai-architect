# Questions and assumptions to resolve

Snapshot 49e015ab-57a2-4a4d-a118-e59e79bf86e0 · design r4 · generated 2026-11-09T22:05:33.257Z

- [ai-public-grounding] Confirm REQ-002: The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope.
- [ai-controlled-publication] Confirm REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.
- [ai-location-transparency] Confirm REQ-004: Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement.
- [ai-faq-capacity] Confirm REQ-005: The public assistant must support five simultaneous questions at an expected workload of approximately 1,000 questions per day. Verify concurrent admission, model quota compatibility and graceful overload behavior against the selected destination; response-time targets remain unspecified.
- [ai-faq-scope] Confirm REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.
- [acceptance-req-0a2ef84b] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-public-grounding] Agree a measurable acceptance check for REQ-002: The public assistant must retrieve only approved public help articles and abstain when those articles do not support an answer. Private-source connections and arbitrary URL retrieval are outside the proposed scope.
- [acceptance-ai-controlled-publication] Agree a measurable acceptance check for REQ-003: An authorized publisher must be able to publish, update and remove help articles without giving public visitors write access. Proposed behavior: reject conflicting edits and withhold in-flight answers when their supporting sources change or are removed.
- [acceptance-ai-location-transparency] Agree a measurable acceptance check for REQ-004: Prefer Australian hosting and processing. Before deployment, document evidence for the locations and retention of articles, visitor questions, model processing, logs and backups; disclose unresolved boundaries and obtain agreement for any proposed overseas processing. Australia-only residency is not yet a confirmed requirement.
- [acceptance-ai-faq-scope] Agree a measurable acceptance check for REQ-006: Provide an anonymous public website assistant and authorized file-based article publication for twenty public UTF-8 articles under 30 KB each. Proposed exclusions are private-source integrations, arbitrary URL fetching, visitor accounts and automated business actions; these exclusions remain proposals.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d636f6e74726f6c6c65642d7075626c69636174696f6e] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6661712d6361706163697479] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6661712d73636f7065] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d67726f756e64696e67] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
