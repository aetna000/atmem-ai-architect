import {CONTAINER_SERVICES,containerContract} from './container-contracts.mjs';
import {existingReferenceFiles} from './existing-references.mjs';
import {generationProviders} from './generation-provider.mjs';
import {incompleteTerraform} from './incomplete-terraform.mjs';
import {CLOUD_PROVIDER_LOCKS} from './cloud-provider-locks.mjs';
const v=n=>'${var.'+n+'}',ref=(type,n,key)=>'${'+type+'.'+n+'.'+key+'}';
export function containerTerraform(project,plan,environment='staging'){
 const providers=generationProviders(project),cloud=providers[0],d=CONTAINER_SERVICES[cloud];
 if(providers.length!==1||!d)return incompleteTerraform(project,plan,environment);
 const variable={review_approved:{type:'bool',default:false},region:{type:'string',nullable:false,description:'Explicitly reviewed provider region; no default destination.'}};
 const examples={review_approved:false,region:{aws:'ap-southeast-2',azure:'australiaeast',gcp:'australia-southeast1',ibm:'au-syd'}[cloud]};
 const input=(name,description,example)=>{variable[name]={type:'string',nullable:false,description,validation:{condition:'${length(trimspace(var.'+name+')) > 0}',error_message:'Supply a reviewed nonempty value.'}};examples[name]=example;return v(name);};
 const provider={[d.provider]:{region:v('region')}};
 if(cloud==='azure')provider.azurerm={features:{},subscription_id:input('subscription_id','Reviewed Azure subscription.','11111111-1111-1111-1111-111111111111')};
 if(cloud==='gcp')provider.google={region:v('region'),project:input('project_id','Existing destination Google Cloud project.','reviewed-project')};
 if(cloud==='aws')provider.aws.allowed_account_ids=[input('account_id','Expected AWS account; provider refuses another account.','123456789012')];
 if(cloud==='azure'){delete variable.region;delete examples.region;}
 const resource={terraform_data:{review_gate:{input:{design_revision:project.revision,environment},lifecycle:{precondition:[{condition:'${var.review_approved && length(local.unfinished_work) == 0}',error_message:'Review inputs and resolve all required implementations before applying.'}]}}}},outputs={},tests=[];
 const add=(type,name,body)=>((resource[type]||={})[name]={...body,depends_on:['terraform_data.review_gate',...(body.depends_on||[])]});
 const nodes=project.nodes.filter(containerContract);
 for(const node of nodes){
  const n=plan.rows.find(r=>r.id===node.id).address;
  const name=input(n+'_name','Reviewed unique deployment name; application source is supplied separately.','architect-app-'+(nodes.indexOf(node)+1));
  variable[n+'_name'].validation={condition:'${can(regex("^[a-z][a-z0-9-]{4,28}[a-z0-9]$", var.'+n+'_name))}',error_message:'Use a unique lowercase name of 6–30 letters, digits or hyphens, starting with a letter.'};
  const image=input(n+'_image','Reviewed immutable Linux container image digest. No model-generated application code is implied.','registry.example.com/architect@sha256:'+'0'.repeat(64));
  variable[n+'_image'].validation={condition:'${can(regex("@sha256:[0-9a-f]{64}$", var.'+n+'_image))}',error_message:'Pin the reviewed application image with its SHA-256 digest.'};
  if(cloud==='gcp'){
   add('google_service_account',n,{account_id:name,display_name:'Application runtime identity'});
   add(d.type,n,{name,location:v('region'),deletion_protection:true,ingress:'INGRESS_TRAFFIC_INTERNAL_ONLY',template:{service_account:ref('google_service_account',n,'email'),scaling:{min_instance_count:0,max_instance_count:2},containers:{image,ports:{container_port:8080},resources:{limits:{cpu:'1',memory:'512Mi'}},startup_probe:{tcp_socket:{port:8080}}}}});
   outputs[n+'_uri']={value:ref(d.type,n,'uri')};
  }else if(cloud==='azure'){
   add(d.type,n,{name,resource_group_name:input('resource_group_name','Existing destination resource group.','reviewed-rg'),container_app_environment_id:input('environment_id','Existing reviewed Container Apps environment resource ID.','/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/reviewed-rg/providers/Microsoft.App/managedEnvironments/reviewed-env'),revision_mode:'Single',identity:{type:'SystemAssigned'},template:{min_replicas:0,max_replicas:2,container:{name:'application',image,cpu:0.5,memory:'1Gi',readiness_probe:{transport:'TCP',port:8080},liveness_probe:{transport:'TCP',port:8080}}},ingress:{external_enabled:false,target_port:8080,transport:'http',traffic_weight:{latest_revision:true,percentage:100}},lifecycle:{prevent_destroy:true}});
   outputs[n+'_id']={value:ref(d.type,n,'id')};
  }else if(cloud==='ibm'){
   add(d.type,n,{project_id:input('code_engine_project_id','Existing reviewed Code Engine project ID.','11111111-1111-1111-1111-111111111111'),name,image_reference:image,image_port:8080,managed_domain_mappings:'local',run_service_account:'none',scale_min_instances:0,scale_max_instances:2,scale_cpu_limit:'0.5',scale_memory_limit:'1G',lifecycle:{prevent_destroy:true}});
   outputs[n+'_id']={value:ref(d.type,n,'id')};
  }else{
   const assume=JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Principal:{Service:'ecs-tasks.amazonaws.com'},Action:'sts:AssumeRole'}]});
   add('aws_ecs_cluster',n,{name});add('aws_cloudwatch_log_group',n,{name:input(n+'_log_group','Explicit log group name.','/architect/application'),retention_in_days:30});
   add('aws_iam_role',n,{assume_role_policy:assume});add('aws_iam_role',n+'_task',{assume_role_policy:assume});
   add('aws_iam_role_policy',n,{role:ref('aws_iam_role',n,'id'),policy:JSON.stringify({Version:'2012-10-17',Statement:[{Effect:'Allow',Action:['ecr:GetAuthorizationToken'],Resource:'*'},{Effect:'Allow',Action:['ecr:BatchCheckLayerAvailability','ecr:GetDownloadUrlForLayer','ecr:BatchGetImage'],Resource:input(n+'_repository_arn','Exact ECR repository ARN for the supplied private image.','arn:aws:ecr:ap-southeast-2:123456789012:repository/architect')},{Effect:'Allow',Action:['logs:CreateLogStream','logs:PutLogEvents'],Resource:ref('aws_cloudwatch_log_group',n,'arn')+':*'}]})});
   add('aws_ecs_task_definition',n,{family:name,network_mode:'awsvpc',requires_compatibilities:['FARGATE'],cpu:'256',memory:'512',execution_role_arn:ref('aws_iam_role',n,'arn'),task_role_arn:ref('aws_iam_role',n+'_task','arn'),container_definitions:JSON.stringify([{name:'application',image,essential:true,portMappings:[{containerPort:8080,protocol:'tcp'}],logConfiguration:{logDriver:'awslogs',options:{'awslogs-group':ref('aws_cloudwatch_log_group',n,'name'),'awslogs-region':v('region'),'awslogs-stream-prefix':'application'}}}])});
   variable[n+'_subnets']={type:'list(string)',nullable:false,validation:{condition:'${length(var.'+n+'_subnets) > 0}',error_message:'Select existing private subnets with required registry/log egress.'}};examples[n+'_subnets']=['subnet-reviewed'];
   variable[n+'_security_groups']={type:'list(string)',nullable:false,validation:{condition:'${length(var.'+n+'_security_groups) > 0}',error_message:'Select reviewed security groups.'}};examples[n+'_security_groups']=['sg-reviewed'];
   add(d.type,n,{name,cluster:ref('aws_ecs_cluster',n,'id'),task_definition:ref('aws_ecs_task_definition',n,'arn'),desired_count:1,launch_type:'FARGATE',network_configuration:{subnets:v(n+'_subnets'),security_groups:v(n+'_security_groups'),assign_public_ip:false},depends_on:['aws_iam_role_policy.'+n]});outputs[n+'_id']={value:ref(d.type,n,'id')};
  }
  const imagePath={aws:`jsondecode(aws_ecs_task_definition.${n}.container_definitions)[0].image`,azure:`azurerm_container_app.${n}.template[0].container[0].image`,gcp:`google_cloud_run_v2_service.${n}.template[0].containers[0].image`,ibm:`ibm_code_engine_app.${n}.image_reference`}[cloud];
  const privateCondition={aws:`aws_ecs_service.${n}.network_configuration[0].assign_public_ip == false`,azure:`azurerm_container_app.${n}.ingress[0].external_enabled == false`,gcp:`google_cloud_run_v2_service.${n}.ingress == "INGRESS_TRAFFIC_INTERNAL_ONLY"`,ibm:`ibm_code_engine_app.${n}.managed_domain_mappings == "local"`}[cloud];
  tests.push(`run "${n}_security" {\n command = plan\n assert {\n condition = ${imagePath} == var.${n}_image\n error_message = "Use the reviewed immutable image."\n }\n assert {\n condition = ${privateCondition}\n error_message = "Unrequested public exposure is forbidden."\n }\n}\nrun "${n}_reject_mutable_image" {\n command = plan\n variables { ${n}_image = "registry.example.com/app:latest" }\n expect_failures = [var.${n}_image]\n}`);
  tests.push(`run "${n}_footprint" {\n command = plan\n assert {\n condition = ${d.type}.${n}.name == var.${n}_name\n error_message = "Container service name must use the reviewed input."\n }\n}`);
 }
 const gaps=[...plan.gapDetails.map(g=>g.id),...(environment==='production'?['production-state-and-operations-review-required']:[])];
 const config={terraform:{required_version:'>= 1.7.0, < 2.0.0',required_providers:{[d.provider]:{source:d.source,version:d.version}}},provider,variable,locals:{unfinished_work:gaps},resource,output:outputs};
 const values=Object.entries({...examples,review_approved:true}).map(([k,val])=>k+' = '+JSON.stringify(val)).join('\n');
 return {'.gitignore':'.terraform/\n*.tfstate*\n*.tfplan\n*.tfvars\n*.tfvars.json\n!deployment.tfvars.json.example\n',...existingReferenceFiles(project),...(CLOUD_PROVIDER_LOCKS[cloud]?{'.terraform.lock.hcl':CLOUD_PROVIDER_LOCKS[cloud]}:{}),'main.tf.json':JSON.stringify(config,null,2),'resource-schedule.json':JSON.stringify(plan,null,2),'deployment.tfvars.json.example':JSON.stringify(examples,null,2),'tests/container.tftest.hcl':`mock_provider "${d.provider}" {}\nvariables {\n${values}\n}\n${tests.join('\n')}\nrun "unapproved_blocked" {\n command = plan\n variables { review_approved = false }\n expect_failures = [terraform_data.review_gate]\n}\n`,'README.md':`# ${d.service} container footprint\n\nA native deployment footprint for an explicitly selected, supplied Linux application image listening on port 8080. Pin and build the real application image before use. This compiler does not implement application authentication, payments, durable memory or unspecified connections. It never packages the local loopback sidecar as a hosted application.\n\nIngress is private; public website routing and user authentication are separate contracts. Runtime identity has no application-data grants. Existing network/environment/project prerequisites must be reviewed; image-pull and platform logging configuration must be verified for the destination. Azure and IBM private-registry credentials require a separate secret integration. No credentials belong in this directory.\n\nUse Terraform 1.7+, copy deployment.tfvars.json.example to a private inputs file, supply every reviewed input and image digest, run terraform init -backend=false, terraform validate and terraform test. Mock tests inspect configuration only. An authorized account plan, real image startup checks, access tests, rollback and approval are required before deployment. Production remains blocked pending state and operational review.\n`};
}
