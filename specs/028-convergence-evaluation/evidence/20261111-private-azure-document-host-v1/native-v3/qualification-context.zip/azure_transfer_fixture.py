import hashlib,json,os,runpy,sys,types
from pathlib import Path
sys.path.insert(0,'/app')
import enterprise_azure_objects as native
from enterprise_document_job import result
metadata=json.loads(os.environ['DOCUMENT_JOB']);expected=metadata['request']
fixtures=[Path('/qualification/policy.docx'),Path('/qualification/invoice-scan.pdf')]
raw=next(p.read_bytes() for p in fixtures if hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256'])
base='/subscriptions/'+metadata['subscriptionId']+'/resourceGroups/'+metadata['resourceGroup']+'/providers/Microsoft.Storage/storageAccounts/'+metadata['storageAccount']
service=base+'/blobServices/default';container=service+'/containers/'+metadata['container']
policies={base:{'id':base,'location':metadata['region'],'kind':'StorageV2','sku':{'name':'Standard_LRS'},'properties':{
 'primaryLocation':metadata['region'],'supportsHttpsTrafficOnly':True,'minimumTlsVersion':'TLS1_2','allowSharedKeyAccess':False,
 'allowBlobPublicAccess':False,'publicNetworkAccess':'Disabled','encryption':{'services':{'blob':{'enabled':True}}}}},
 service:{'id':service,'properties':{'isVersioningEnabled':False,**{k:{'enabled':False} for k in ['deleteRetentionPolicy','containerDeleteRetentionPolicy','restorePolicy','changeFeed']}}},
 container:{'id':container,'properties':{'publicAccess':'None','hasImmutabilityPolicy':False,'hasLegalHold':False}}}
class Credential:
 def get_token(self,scope):
  assert scope in {'https://management.azure.com/.default','https://storage.azure.com/.default'}
  return types.SimpleNamespace(token='SYNTHETIC-NATIVE-TOKEN')
 def close(self):pass
class Response:
 def __init__(self,body,status=200,headers=None):self.body=body;self.status_code=status;self.headers=headers or {}
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def iter_content(self,size):
  for offset in range(0,len(self.body),size):yield self.body[offset:offset+size]
class Session:
 def close(self):pass
 def request(self,method,url,**options):
  assert self.trust_env is False and options['allow_redirects'] is False and options['stream'] is True
  assert options['headers']['Authorization']=='Bearer SYNTHETIC-NATIVE-TOKEN'
  if url.startswith('https://management.azure.com'):
   assert method=='GET' and options['params']=={'api-version':'2025-06-01'}
   return Response(json.dumps(policies[url.removeprefix('https://management.azure.com')]).encode())
  prefix='https://'+metadata['storageAccount']+'.blob.core.windows.net/'+metadata['container']+'/document-jobs/'+expected['requestId']
  if method=='GET':
   assert url==prefix+'/input' and options['headers']['If-Match']==metadata['inputETag']
   return Response(raw,headers={'ETag':metadata['inputETag'],'Content-Length':str(len(raw)),'x-ms-blob-type':'BlockBlob','x-ms-server-encrypted':'true'})
  assert method=='PUT' and url==prefix+'/result' and options['headers']['If-None-Match']=='*'
  parsed=result(raw,expected['mediaType'],expected['requestId'],options['data'])
  assert ('42.50' if expected['mediaType']=='application/pdf' else 'twenty days') in parsed['text']
  return Response(b'',201,{'ETag':'"0x8DA123ABCDEF"','x-ms-request-server-encrypted':'true'})
native.requests.Session=Session
native.AzureDocumentObjects._credential=lambda self:Credential()
sys.argv=['enterprise_azure_transfer.py',sys.argv[1]]
runpy.run_path('/app/enterprise_azure_transfer.py',run_name='__main__')
