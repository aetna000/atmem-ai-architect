Snapshot ea55299a-bad1-4d82-8951-68a1dc70e0bf · design r4 · generated 2026-11-09T20:28:31.782Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] The internal tool shall accept pasted support-ticket text and display a short summary, topic and suggested urgency for a person to review. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Defines the complete initial workflow without introducing ticket-system integrations or autonomous actions.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions. (should, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Proposed access and data-minimization boundaries reduce exposure of potentially sensitive ticket contents.

Basis: The user requests a “small internal tool”; company sign-in and no saved ticket history are engineering proposals, not confirmed policy.
- [REQ-004] Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Regional placement alone cannot establish the processing boundary; model routing, identity metadata and operational data may introduce overseas paths.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”
- [REQ-005] Accept pasted synthetic or redacted ticket text up to 20000 UTF-8 bytes and explicitly reject larger submissions without truncation. Proposed interpretation: 20 KB means 20000 bytes; automatic redaction is outside current scope. (must, open); target: Maximum accepted UTF-8 ticket size <= 20000bytes; linked blocks: ticket-triage-app

Design explanation: An explicit input limit prevents silent truncation and bounds processing; synthetic or redacted input remains the team's responsibility.

Basis: “We paste synthetic or redacted text, up to 20 KB per ticket.”
- [REQ-006] Support ten signed-in staff and approximately 200 tickets per working day, including bursts of five simultaneous requests. Validate burst handling and safe overload recovery against the selected application footprint and regional model quota before handoff acceptance. (must, open); target: Simultaneous requests supported >= 5requests; linked blocks: team-browser, ticket-triage-app

Design explanation: Captures the stated workload so the starting footprint and model quota can be tested rather than assumed adequate; no response-time target has been supplied.

Basis: “Ten staff members use it after signing in.” and “About 200 tickets per working day; bursts of five simultaneous requests.”
- [REQ-007] Reject malformed and oversized requests explicitly, deny unauthorized users before inference, and return safe errors for unavailable models or invalid model responses without fabricated suggestions or sensitive error details. Demonstrate these paths with negative and recovery tests. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Prevents malformed requests, unauthorized access or provider failures from producing misleading suggestions or exposing ticket content.

Basis: “Malformed input, denied users and model failures must be handled safely.”
- [REQ-008] Limit the application to pasted-ticket analysis and human-reviewed suggestions. Exclude sending replies, changing customer records and executing external actions; human review does not authorize those excluded capabilities. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Prevents human review from being interpreted as permission for future automated actions.

Basis: The original brief requires human review and prohibits sending replies or changing customer records; the current request says to preserve these requirements.

## How the system works

The current design contains 2 components and 1 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team browser → Ticket triage application

HTTPS: signed-in ticket submission; validated JSON suggestions or safe error

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team browser

Web browser · tools · region: Existing client location · classification: Confidential

Existing team browser, outside provisioning scope. Staff paste a support ticket and review the returned summary, topic and suggested urgency. The browser does not enforce application authorization.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team browser → Ticket triage application: HTTPS: signed-in ticket submission; validated JSON suggestions or safe error (integration: browser-https)

Requirement traceability: REQ-002: The internal tool shall accept pasted support-ticket text and display a short summary, topic and suggested urgency for a person to review.; REQ-004: Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram.; REQ-006: Support ten signed-in staff and approximately 200 tickets per working day, including bursts of five simultaneous requests. Validate burst handling and safe overload recovery against the selected application footprint and regional model quota before handoff acceptance.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket triage application

Azure App Service · azure · region: australiaeast · classification: Confidential

Proposed composed azure-structured-app module on Azure App Service. Owns browser/API runtime, App Service plan, regional Azure OpenAI account/deployment, workload identity and single-tenant Entra application registrations; do not duplicate internal resources. Scope: ten signed-in staff paste synthetic or user-redacted tickets and review a short summary, topic, suggested urgency and uncertainty. No replies, customer-record changes, action tools, automatic redaction, source-system integration or durable ticket history. Browser remains an existing client outside provisioning scope. Propose one Linux App Service Basic B1 instance initially, subject to native module support, regional checks and load testing; no high-availability claim. Workload is about 200 tickets per working day with bursts of five simultaneous requests. Propose application admission control for five active inference requests per instance, bounded model calls and explicit retryable overload responses; config.concurrency records this target and does not prove App Service or application enforcement. Verify model quota against measured token usage and five-request bursts. Keep the 1024-token output bound. Propose Australia East for application and regional model processing, conditional on compatible model/version, quota and availability checks; region is not approved. No silent global model deployment, overseas fallback or cross-region failover. Review identity metadata, telemetry, model-provider handling, support paths and all other potential processing outside Australia before deployment. Australian resource placement alone does not prove residency. Accept only non-empty text in a validated request, up to 20000 UTF-8 bytes, rejecting larger inputs without truncation. Treat ticket text as untrusted. Validate model JSON server-side for required summary/topic/urgency/uncertainty fields, types and urgency vocabulary before returning it; invalid output must never become a fabricated suggestion. Proposed API behavior: 400 malformed/empty input, 413 oversized input, 401 unauthenticated, 403 unauthorized, 429 capacity exceeded, and bounded 502/503/504 inference or dependency failures as appropriate. Use content-free error codes and request identifiers; never echo ticket content or raw provider errors. Authorize users server-side before inference through proposed existing company-group assignment, subject to Entra group and licensing suitability. JWT authorization can persist until token expiry; immediate revocation and MFA policy are not established. Keep ticket text and generated suggestions transient; exclude them from server logs, traces, telemetry, caches, temporary files and browser persistent storage. Release request content after success or failure; propose clearing displayed content when review finishes. Model-side handling must satisfy no retention: ContentLogging=false approval must already exist before inference, and provider handling requires independent verification. Engineering must build and test an immutable image using an existing suitable RBAC-mode ACR, supply reviewed destination inputs, verify logging approval and regional model compatibility, and validate generated artifacts. Acceptance evidence must cover successful four-field responses, signed-out and denied users without model calls, malformed and oversized inputs, schema-invalid model output, prompt injection, model timeout/unavailability, five simultaneous requests, overload recovery and non-retention. Representative synthetic/redacted-ticket review must assess semantic quality separately from JSON validity. Propose content-free operational metrics for request totals, latency, errors and throttling; operating ownership and recovery needs remain open. Monthly charges for the plan, model tokens, ACR, identity licensing, monitoring and transfer are unknown without sourced rates and usage assumptions; one-off build effort/rates are separately unknown. Graph intent and compiler capability are not deployment or runtime evidence.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team browser → Ticket triage application: HTTPS: signed-in ticket submission; validated JSON suggestions or safe error (integration: browser-https)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The internal tool shall accept pasted support-ticket text and display a short summary, topic and suggested urgency for a person to review.; REQ-003: Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions.; REQ-004: Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram.; REQ-005: Accept pasted synthetic or redacted ticket text up to 20000 UTF-8 bytes and explicitly reject larger submissions without truncation. Proposed interpretation: 20 KB means 20000 bytes; automatic redaction is outside current scope.; REQ-006: Support ten signed-in staff and approximately 200 tickets per working day, including bursts of five simultaneous requests. Validate burst handling and safe overload recovery against the selected application footprint and regional model quota before handoff acceptance.; REQ-007: Reject malformed and oversized requests explicitly, deny unauthorized users before inference, and return safe errors for unavailable models or invalid model responses without fabricated suggestions or sensitive error details. Demonstrate these paths with negative and recovery tests.; REQ-008: Limit the application to pasted-ticket analysis and human-reviewed suggestions. Exclude sending replies, changing customer records and executing external actions; human review does not authorize those excluded capabilities.

Implementation status: Composed Azure structured application source, browser, Entra authorization and regional model deployment generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team browser<br/>Tools & data"]
  n1["Ticket triage application<br/>Azure"]
  n0 -->|HTTPS: signed-in ticket submission; validated JSON suggestions or safe error| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team browser | tools | Web browser | Existing client location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage application | azure | Azure App Service | australiaeast | Proposed | Composed Azure structured application source, browser, Entra authorization and regional model deployment generated; destination behavior unverified |

### Resources and cost dimensions

- **Team browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage application** (ticket-triage-app): azurerm_linux_web_app, azurerm_service_plan, azurerm_cognitive_account, azurerm_cognitive_deployment, azuread_application_registration. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
