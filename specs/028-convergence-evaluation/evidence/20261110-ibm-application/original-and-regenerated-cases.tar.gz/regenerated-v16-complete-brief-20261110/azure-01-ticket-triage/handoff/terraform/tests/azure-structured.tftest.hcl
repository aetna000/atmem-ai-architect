mock_provider "azurerm" {}
mock_provider "azuread" {}
variables {
review_approved = true
subscription_id = "11111111-1111-1111-1111-111111111111"
tenant_id = "22222222-2222-2222-2222-222222222222"
resource_group_name = "reviewed-application-rg"
registry_name = "reviewedregistry"
registry_resource_group_name = "reviewed-registry-rg"
block_7469636b65742d7472696167652d617070_name = "reviewed-app"
block_7469636b65742d7472696167652d617070_location = "australiaeast"
block_7469636b65742d7472696167652d617070_repository = "architect/app"
block_7469636b65742d7472696167652d617070_image_digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
block_7469636b65742d7472696167652d617070_model_name = "REVIEW_MODEL"
block_7469636b65742d7472696167652d617070_model_version = "REVIEW_VERSION"
block_7469636b65742d7472696167652d617070_access_group_object_id = "33333333-3333-3333-3333-333333333333"
}
run "block_7469636b65742d7472696167652d617070_security" {
 command = plan
 assert {
 condition = azurerm_linux_web_app.block_7469636b65742d7472696167652d617070.https_only && !azurerm_linux_web_app.block_7469636b65742d7472696167652d617070.ftp_publish_basic_authentication_enabled && !azurerm_linux_web_app.block_7469636b65742d7472696167652d617070.webdeploy_publish_basic_authentication_enabled && !azurerm_cognitive_account.block_7469636b65742d7472696167652d617070.local_auth_enabled
 error_message = "TLS and managed identity are required; basic publishing and model keys are disabled."
 }
 assert {
 condition = azurerm_cognitive_deployment.block_7469636b65742d7472696167652d617070.sku[0].name == "Standard" && azurerm_cognitive_deployment.block_7469636b65742d7472696167652d617070.version_upgrade_option == "NoAutoUpgrade"
 error_message = "Do not silently select a global deployment or model upgrade."
 }
 assert {
 condition = azuread_service_principal.block_7469636b65742d7472696167652d617070.app_role_assignment_required && azuread_application_registration.block_7469636b65742d7472696167652d617070.requested_access_token_version == 2
 error_message = "Tenant-specific v2 access and explicit group assignment are required."
 }
}
run "block_7469636b65742d7472696167652d617070_reject_mutable_image" {
 command = plan
 variables { block_7469636b65742d7472696167652d617070_image_digest = "latest" }
 expect_failures = [var.block_7469636b65742d7472696167652d617070_image_digest]
}
run "unapproved_blocked" {
 command = plan
 variables { review_approved = false }
 expect_failures = [terraform_data.review_gate]
}
