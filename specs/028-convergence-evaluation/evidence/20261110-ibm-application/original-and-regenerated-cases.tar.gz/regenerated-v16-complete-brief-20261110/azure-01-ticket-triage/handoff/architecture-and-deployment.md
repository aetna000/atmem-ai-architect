Snapshot ea55299a-bad1-4d82-8951-68a1dc70e0bf · design r4 · generated 2026-11-09T20:28:31.782Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 20:28 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** unknown
- **Estimated run cost:** not estimated
- **Review:** 6 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** We paste synthetic or redacted text, up to 20 KB per ticket. Do not retain ticket text after processing. Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Ten staff members use it after signing in. About 200 tickets per working day; bursts of five simultaneous requests. Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price. Return summary, topic, urgency and uncertainty as a validated JSON response. Malformed input, denied users and model failures must be handled safely.
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** Azure
- **Budget and timeline:** —

## 3. Architecture

**Team access**

- Team browser (Tools & data, existing) — Existing team browser, outside provisioning scope. Staff paste a support ticket and review the returned summary, topic and suggested urgency. The browser does not enforce application authorization.

**Ticket analysis**

- Ticket triage application (Azure) — Proposed composed azure-structured-app module on Azure App Service. Owns browser/API runtime, App Service plan, regional Azure OpenAI account/deployment, workload identity and single-tenant Entra application registrations; do not duplicate internal resources. Scope: ten signed-in staff paste synthetic or user-redacted tickets and review a short summary, topic, suggested urgency and uncertainty. No replies, customer-record changes, action tools, automatic redaction, source-system integration or durable ticket history. Browser remains an existing client outside provisioning scope. Propose one Linux App Service Basic B1 instance initially, subject to native module support, regional checks and load testing; no high-availability claim. Workload is about 200 tickets per working day with bursts of five simultaneous requests. Propose application admission control for five active inference requests per instance, bounded model calls and explicit retryable overload responses; config.concurrency records this target and does not prove App Service or application enforcement. Verify model quota against measured token usage and five-request bursts. Keep the 1024-token output bound. Propose Australia East for application and regional model processing, conditional on compatible model/version, quota and availability checks; region is not approved. No silent global model deployment, overseas fallback or cross-region failover. Review identity metadata, telemetry, model-provider handling, support paths and all other potential processing outside Australia before deployment. Australian resource placement alone does not prove residency. Accept only non-empty text in a validated request, up to 20000 UTF-8 bytes, rejecting larger inputs without truncation. Treat ticket text as untrusted. Validate model JSON server-side for required summary/topic/urgency/uncertainty fields, types and urgency vocabulary before returning it; invalid output must never become a fabricated suggestion. Proposed API behavior: 400 malformed/empty input, 413 oversized input, 401 unauthenticated, 403 unauthorized, 429 capacity exceeded, and bounded 502/503/504 inference or dependency failures as appropriate. Use content-free error codes and request identifiers; never echo ticket content or raw provider errors. Authorize users server-side before inference through proposed existing company-group assignment, subject to Entra group and licensing suitability. JWT authorization can persist until token expiry; immediate revocation and MFA policy are not established. Keep ticket text and generated suggestions transient; exclude them from server logs, traces, telemetry, caches, temporary files and browser persistent storage. Release request content after success or failure; propose clearing displayed content when review finishes. Model-side handling must satisfy no retention: ContentLogging=false approval must already exist before inference, and provider handling requires independent verification. Engineering must build and test an immutable image using an existing suitable RBAC-mode ACR, supply reviewed destination inputs, verify logging approval and regional model compatibility, and validate generated artifacts. Acceptance evidence must cover successful four-field responses, signed-out and denied users without model calls, malformed and oversized inputs, schema-invalid model output, prompt injection, model timeout/unavailability, five simultaneous requests, overload recovery and non-retention. Representative synthetic/redacted-ticket review must assess semantic quality separately from JSON validity. Propose content-free operational metrics for request totals, latency, errors and throttling; operating ownership and recovery needs remain open. Monthly charges for the plan, model tokens, ACR, identity licensing, monitoring and transfer are unknown without sourced rates and usage assumptions; one-off build effort/rates are separately unknown. Graph intent and compiler capability are not deployment or runtime evidence.

```mermaid
flowchart LR
  n0["Team browser<br/>Tools & data"]
  n1["Ticket triage application<br/>Azure"]
  n0 -->|HTTPS: signed-in ticket submission; validated JSON suggestions or safe error| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team browser | tools | Web browser | Existing client location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage application | azure | Azure App Service | australiaeast | Proposed | Composed Azure structured application source, browser, Entra authorization and regional model deployment generated; destination behavior unverified |

### Resources and cost dimensions

- **Team browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage application** (ticket-triage-app): azurerm_linux_web_app, azurerm_service_plan, azurerm_cognitive_account, azurerm_cognitive_deployment, azuread_application_registration. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team browser | Ticket triage application | HTTPS: signed-in ticket submission; validated JSON suggestions or safe error | Confidential |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions. (should)
- Requirement: Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram. (must)
- Requirement: Limit the application to pasted-ticket analysis and human-reviewed suggestions. Exclude sending replies, changing customer records and executing external actions; human review does not authorize those excluded capabilities. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions. | security | not measurable yet | Open |
| Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram. | compliance | not measurable yet | Open |
| Support ten signed-in staff and approximately 200 tickets per working day, including bursts of five simultaneous requests. Validate burst handling and safe overload recovery against the selected application footprint and regional model quota before handoff acceptance. | performance | Simultaneous requests supported >= 5requests | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- The internal tool shall accept pasted support-ticket text and display a short summary, topic and suggested urgency for a person to review. (must, open)
- Accept pasted synthetic or redacted ticket text up to 20000 UTF-8 bytes and explicitly reject larger submissions without truncation. Proposed interpretation: 20 KB means 20000 bytes; automatic redaction is outside current scope. (must, open)
- Reject malformed and oversized requests explicitly, deny unauthorized users before inference, and return safe errors for unavailable models or invalid model responses without fabricated suggestions or sensitive error details. Demonstrate these paths with negative and recovery tests. (must, open)
- Limit the application to pasted-ticket analysis and human-reviewed suggestions. Exclude sending replies, changing customer records and executing external actions; human review does not authorize those excluded capabilities. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions.”, “Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team browser, Ticket triage application.

**Estimate gaps:**

- Team browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage application: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision ticket analysis: Ticket triage application.
4. Connect existing systems: Team browser; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

_None._
