# Generated Azure application

This source implements the browser, delegated Entra API authorization and bounded model operation. It is not a supplied-image placeholder. From this directory, create an isolated environment with python3.13 -m venv .venv, run .venv/bin/python -m pip install --only-binary=:all: --require-hashes -r test-requirements.lock, then .venv/bin/python azure_acceptance.py -v. Test dependencies have a separate hash-locked file and source receipts. Tests use cryptographic keys and scripted network boundaries; they do not access Azure.

Build on a clean Docker host: docker build --platform linux/amd64 --pull -t REVIEWED_REGISTRY.azurecr.io/REVIEWED_REPOSITORY:REVIEWED_BUILD .

Inspect and scan the image, run container startup and acceptance checks, then, with authorization, authenticate to the existing ACR and push it. Record the registry digest and supply it as block_7469636b65742d7472696167652d617070_image_digest. The Terraform configuration uses managed-identity pull and never builds/pushes images or executes a provisioner. Building and publishing an image is separate from running Terraform. The base image and all Python wheels are hash pinned; record exact source/image hashes. Update deliberately and rerun tests/scans.

The test-requirements.lock file adds pinned httpx/HTTP transport tooling for FastAPI TestClient; those development tools are not packaged into the image. Test fixture config lives in azure_acceptance.py; never use fixture values as deployment credentials or production configuration.
