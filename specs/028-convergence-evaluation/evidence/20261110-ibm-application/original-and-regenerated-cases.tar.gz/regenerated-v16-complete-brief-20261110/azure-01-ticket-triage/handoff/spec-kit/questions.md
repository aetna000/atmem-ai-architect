# Questions and assumptions to resolve

Snapshot ea55299a-bad1-4d82-8951-68a1dc70e0bf · design r4 · generated 2026-11-09T20:28:31.782Z

- [ai-ticket-triage] Confirm REQ-002: The internal tool shall accept pasted support-ticket text and display a short summary, topic and suggested urgency for a person to review.
- [ai-ticket-access] Confirm REQ-003: Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions.
- [ai-ticket-residency] Confirm REQ-004: Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram.
- [ai-ticket-input] Confirm REQ-005: Accept pasted synthetic or redacted ticket text up to 20000 UTF-8 bytes and explicitly reject larger submissions without truncation. Proposed interpretation: 20 KB means 20000 bytes; automatic redaction is outside current scope.
- [ai-ticket-capacity] Confirm REQ-006: Support ten signed-in staff and approximately 200 tickets per working day, including bursts of five simultaneous requests. Validate burst handling and safe overload recovery against the selected application footprint and regional model quota before handoff acceptance.
- [ai-ticket-safe-failures] Confirm REQ-007: Reject malformed and oversized requests explicitly, deny unauthorized users before inference, and return safe errors for unavailable models or invalid model responses without fabricated suggestions or sensitive error details. Demonstrate these paths with negative and recovery tests.
- [ai-ticket-scope] Confirm REQ-008: Limit the application to pasted-ticket analysis and human-reviewed suggestions. Exclude sending replies, changing customer records and executing external actions; human review does not authorize those excluded capabilities.
- [acceptance-req-bca4a7dd] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-triage] Agree a measurable acceptance check for REQ-002: The internal tool shall accept pasted support-ticket text and display a short summary, topic and suggested urgency for a person to review.
- [acceptance-ai-ticket-access] Agree a measurable acceptance check for REQ-003: Proposed: restrict application access to an authorized company group, enforce authorization on the server, and avoid durable storage or application logging of ticket text and generated suggestions.
- [acceptance-ai-ticket-residency] Agree a measurable acceptance check for REQ-004: Process ticket text and model inference in Australia using supported regional services; identify and flag any data path leaving Australia before deployment, including identity and operational metadata. Verify model availability, routing and provider data handling independently of the diagram.
- [acceptance-ai-ticket-safe-failures] Agree a measurable acceptance check for REQ-007: Reject malformed and oversized requests explicitly, deny unauthorized users before inference, and return safe errors for unavailable models or invalid model responses without fabricated suggestions or sensitive error details. Demonstrate these paths with negative and recovery tests.
- [acceptance-ai-ticket-scope] Agree a measurable acceptance check for REQ-008: Limit the application to pasted-ticket analysis and human-reviewed suggestions. Exclude sending replies, changing customer records and executing external actions; human review does not authorize those excluded capabilities.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d7469636b65742d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6361706163697479] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d696e707574] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d7265736964656e6379] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d736166652d6661696c75726573] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d73636f7065] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d747269616765] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
