# Generated Cloud Run application

In this directory, create an isolated Python 3.13 environment, install test-requirements.lock with --only-binary=:all: --require-hashes, then run gcp_acceptance.py -v. Tests use ephemeral signed JWTs and scripted transport fixtures. They do not contact Google Cloud.

Build this source with docker build --platform linux/amd64 --pull -t REVIEWED_LOCATION-docker.pkg.dev/REVIEWED_PROJECT/REVIEWED_REPOSITORY/REVIEWED_IMAGE:REVIEWED_BUILD . ; scan, run container startup/acceptance checks and retain source/image digests. Obtain authorization before authenticating to the existing Artifact Registry and pushing. Supply that exact registry digest as block_7469636b65742d7472696167652d617070_image_digest. Terraform does not run build/publish provisioners.

Provide the reviewed project/model/region and destination-owner policy evidence using block_7469636b65742d7472696167652d617070_policy_review; the supplied example is intentionally unapproved. Runtime verifies its scope/expiry, reads disabled project caching and model logging/sharing settings, and blocks before inference if any check is unknown. The owner review covers abuse-monitoring terms/exemption that this application cannot discover through a reliable API. It is an attestation, not independent proof of approval. The application never modifies those project/account-wide controls.
