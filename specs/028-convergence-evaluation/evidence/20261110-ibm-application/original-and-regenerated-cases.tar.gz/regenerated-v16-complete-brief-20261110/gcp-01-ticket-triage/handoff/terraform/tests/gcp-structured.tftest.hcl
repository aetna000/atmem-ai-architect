mock_provider "google" {
 override_during = plan
 mock_data "google_project" { defaults = { number = "123456789012" } }
 mock_resource "google_service_account" { defaults = { email = "runtime@reviewed-project.iam.gserviceaccount.com" } }
}
mock_provider "google-beta" {
 override_during = plan
 mock_resource "google_project_service_identity" { defaults = { email = "service-123456789012@gcp-sa-iap.iam.gserviceaccount.com", member = "serviceAccount:service-123456789012@gcp-sa-iap.iam.gserviceaccount.com" } }
}
variables {
review_approved = true
project_id = "reviewed-project"
registry_location = "australia-southeast1"
registry_repository = "reviewed-images"
block_7469636b65742d7472696167652d617070_name = "reviewed-ai-app"
block_7469636b65742d7472696167652d617070_region = "australia-southeast1"
block_7469636b65742d7472696167652d617070_image_repository = "architect/app"
block_7469636b65742d7472696167652d617070_image_digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"
block_7469636b65742d7472696167652d617070_model_id = "gemini-reviewed-version"
block_7469636b65742d7472696167652d617070_access_group = "architect-staff@example.test"
block_7469636b65742d7472696167652d617070_policy_review = {"projectId":"reviewed-project","region":"australia-southeast1","model":"gemini-reviewed-version","abuseLogging":"REVIEW_REQUIRED","approvedBy":"REVIEW_REQUIRED","evidenceSha256":"0000000000000000000000000000000000000000000000000000000000000000","expiresAt":"REPLACE_AFTER_REVIEW"}
}
run "block_7469636b65742d7472696167652d617070_identity" {
 command = plan
 assert {
 condition = google_cloud_run_v2_service.block_7469636b65742d7472696167652d617070.iap_enabled && !google_cloud_run_v2_service.block_7469636b65742d7472696167652d617070.invoker_iam_disabled
 error_message = "IAP and Cloud Run IAM must remain enabled."
 }
 assert {
 condition = google_cloud_run_v2_service_iam_member.block_7469636b65742d7472696167652d617070.member == google_project_service_identity.required_iap.member && google_iap_web_cloud_run_service_iam_member.block_7469636b65742d7472696167652d617070.member == "group:${var.block_7469636b65742d7472696167652d617070_access_group}"
 error_message = "Only the IAP agent invokes the service; only the reviewed group receives IAP access."
 }
 assert {
 condition = length(google_project_iam_custom_role.block_7469636b65742d7472696167652d617070.permissions) == 3 && !contains(google_project_iam_custom_role.block_7469636b65742d7472696167652d617070.permissions, "aiplatform.endpoints.setPublisherModelConfig")
 error_message = "Runtime must not modify project/account-wide model policy."
 }
}
run "block_7469636b65742d7472696167652d617070_reject_mutable_image" {
 command = plan
 variables { block_7469636b65742d7472696167652d617070_image_digest = "latest" }
 expect_failures = [var.block_7469636b65742d7472696167652d617070_image_digest]
}
run "unapproved_blocked" {
 command = plan
 variables { review_approved = false }
 expect_failures = [terraform_data.review_gate]
}
