# Component and interface contracts

Snapshot 703e2602-97f3-4675-8786-504e0f025839 · design r4 · generated 2026-11-09T20:24:41.099Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-browser: Team member’s browser

- Responsibility: Existing browser outside provisioning scope, used by ten staff members after sign-in. A team member pastes synthetic or redacted support-ticket text and reviews the returned summary, topic, suggested urgency and uncertainty. Display clear input, access and service-failure messages; do not present failed requests as successful triage. Do not persist tickets or results in browser storage. No automated replies or customer-record changes.
- Service: Web browser
- Provider / placement: tools / User location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component ticket-triage-app: Ticket triage application

- Responsibility: Proposed composed IBM Code Engine application: generated browser/API, owned IBM App ID tenant with administrator-enrolled team users, PKCE sign-in, server-side JWT/role checks, dedicated compute-linked trusted profile and regional watsonx Text Chat. Internal identity/model resources belong to this module, not separate deployments. Scope: ten signed-in staff paste synthetic or redacted tickets; about 200 tickets per working day with bursts of five simultaneous requests. Return validated JSON containing summary, topic, urgency low/medium/high/uncertain, and a plain-language uncertainty explanation, displayed for human review. No replies, customer-record changes, external tools or downstream credentials. Treat ticket text as untrusted data. Accept at most 20,000 UTF-8 bytes and validate server-side JSON structure, text type and nonempty content before inference. Reject malformed input with a content-free 400 response, oversized input with 413, missing/invalid sign-in with 401 and insufficient role with 403; denied requests must not invoke the model. Validate all four output fields and urgency enumeration server-side; reject invalid model output without returning partial triage. Proposed failures: bounded model deadline, no automatic inference retries, content-free 502/503/504 errors as appropriate, and a clear manual retry option without preserving ticket text. Overload returns 429 with retry guidance. Do not retain ticket text or generated results after processing: no durable application storage, browser persistence, ticket-bearing logs, model-response logs or content-bearing error traces; release transient request data after success or failure. Proposed starting Code Engine footprint: 0.5 vCPU and 1 GiB per instance, minimum zero and maximum two instances, five concurrent requests per instance, subject to provider constraints and five-request load testing. Scale-to-zero may cause a cold-start delay; no response-time or availability commitment is established. These footprint settings require explicit emitted Terraform/application support and are not inferred from generic configuration fields. Keep the existing 1,024-token output bound. Content-free metrics should count requests, denials, validation failures, model failures, saturation and latency without ticket/result bodies. Target Australia; Sydney (au-syd) remains an unverified candidate, not an approved destination. Verify Code Engine, App ID and selected watsonx model/plan together, including provider retention and identity, telemetry, support and registry paths; flag identified overseas paths and unresolved paths before use. No automatic overseas fallback. Team administrators own enrollment; operating ownership remains unassigned. Requires an existing Code Engine project, authorized private-registry pull-secret name and namespace, watsonx project/runtime inputs, compatible regional model/quota, scoped retention review and a built/tested/scanned immutable image. Existing company SSO, MFA and immediate token revocation are not established. Monthly cloud charges and separate one-off build costs are unknown. Generated source is not deployment evidence; acceptance, denied-access, failure, load, update and rollback checks must be bound to the exported artifact.
- Service: IBM Code Engine
- Provider / placement: ibm / Australia; Sydney (au-syd) candidate, service support unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7469636b65742d7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-to-triage: team-browser → ticket-triage-app

- Drawn payload/purpose: HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert
- Contract task: TASK-CONTRACT-62726f777365722d746f2d747269616765
- Integration task: TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
