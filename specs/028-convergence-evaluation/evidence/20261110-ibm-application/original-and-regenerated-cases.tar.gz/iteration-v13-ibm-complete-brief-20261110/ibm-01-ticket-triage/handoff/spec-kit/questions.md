# Questions and assumptions to resolve

Snapshot 703e2602-97f3-4675-8786-504e0f025839 · design r4 · generated 2026-11-09T20:24:41.099Z

- [ai-ticket-triage] Confirm REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.
- [ai-team-access] Confirm REQ-003: Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests.
- [ai-ticket-data-minimisation] Confirm REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.
- [ai-ticket-input-boundary] Confirm REQ-005: The application shall accept synthetic or redacted ticket text up to 20,000 UTF-8 bytes and reject larger submissions server-side with a clear explanation.
- [ai-ticket-australia-boundary] Confirm REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.
- [ai-ticket-capacity] Confirm REQ-007: The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed.
- [ai-ticket-safe-failures] Confirm REQ-008: The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths.
- [ai-ticket-cost-evidence] Confirm REQ-009: The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption.
- [acceptance-req-8db720e5] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-triage] Agree a measurable acceptance check for REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.
- [acceptance-ai-team-access] Agree a measurable acceptance check for REQ-003: Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests.
- [acceptance-ai-ticket-data-minimisation] Agree a measurable acceptance check for REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.
- [acceptance-ai-ticket-australia-boundary] Agree a measurable acceptance check for REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.
- [acceptance-ai-ticket-safe-failures] Agree a measurable acceptance check for REQ-008: The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths.
- [acceptance-ai-ticket-cost-evidence] Agree a measurable acceptance check for REQ-009: The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption.
- [cloud.region] Engineering verification: choose and document a suitable proposed region within the accepted country, then verify service/model support, residency, quota and account policy before deployment. Escalate only a material business trade-off.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d7465616d2d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6175737472616c69612d626f756e64617279] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6361706163697479] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d636f73742d65766964656e6365] REQ-009 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d646174612d6d696e696d69736174696f6e] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d696e7075742d626f756e64617279] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d736166652d6661696c75726573] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d747269616765] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
