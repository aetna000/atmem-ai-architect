Snapshot 703e2602-97f3-4675-8786-504e0f025839 · design r4 · generated 2026-11-09T20:24:41.099Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Provides the requested triage outcome without requiring an autonomous agent or ticket-system integration.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Proposed access boundary prevents unauthorised use of an internal tool and exposure of ticket information.

Basis: “Build a small internal tool” and the proposed ticket-triage-app sign-in boundary.
- [REQ-004] Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets. (should, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Proposed data minimisation reduces unnecessary copies of potentially sensitive ticket content; provider retention and permitted country still require review.

Basis: Pasted support-ticket workflow and the proposed stateless ticket-triage-app; retention preferences were not supplied.
- [REQ-005] The application shall accept synthetic or redacted ticket text up to 20,000 UTF-8 bytes and reject larger submissions server-side with a clear explanation. (must, open); target: Maximum accepted ticket input <= 20000UTF-8 bytes; linked blocks: ticket-triage-app

Design explanation: Bounds processing and rejects oversized tickets explicitly; the existing 20,000-byte setting interprets KB as decimal UTF-8 bytes.

Basis: “We paste synthetic or redacted text, up to 20 KB per ticket.”
- [REQ-006] Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Australian application placement alone does not establish where identity, inference, telemetry or support processing occurs.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”
- [REQ-007] The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed. (must, open); target: Simultaneous valid requests supported >= 5requests; linked blocks: team-browser, ticket-triage-app

Design explanation: Captures the supplied daily workload and burst size without inventing monthly working days or a latency commitment; load evidence is needed before claiming capacity.

Basis: “About 200 tickets per working day; bursts of five simultaneous requests.”
- [REQ-008] The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Prevents malformed or denied requests from reaching inference and prevents model failures or invalid output from appearing as trustworthy suggestions.

Basis: “Malformed input, denied users and model failures must be handled safely.”
- [REQ-009] The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Keeps the requested modest footprint and cost transparency explicit while avoiding unsupported pricing or treating a cloud subtotal as a complete delivery estimate.

Basis: “Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price.”

## How the system works

The current design contains 2 components and 1 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team member’s browser → Ticket triage application

HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team member’s browser

Web browser · tools · region: User location · classification: Confidential

Existing browser outside provisioning scope, used by ten staff members after sign-in. A team member pastes synthetic or redacted support-ticket text and reviews the returned summary, topic, suggested urgency and uncertainty. Display clear input, access and service-failure messages; do not present failed requests as successful triage. Do not persist tickets or results in browser storage. No automated replies or customer-record changes.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team member’s browser → Ticket triage application: HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert (integration: browser-https)

Requirement traceability: REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.; REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.; REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.; REQ-007: The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket triage application

IBM Code Engine · ibm · region: Australia; Sydney (au-syd) candidate, service support unverified · classification: Confidential

Proposed composed IBM Code Engine application: generated browser/API, owned IBM App ID tenant with administrator-enrolled team users, PKCE sign-in, server-side JWT/role checks, dedicated compute-linked trusted profile and regional watsonx Text Chat. Internal identity/model resources belong to this module, not separate deployments. Scope: ten signed-in staff paste synthetic or redacted tickets; about 200 tickets per working day with bursts of five simultaneous requests. Return validated JSON containing summary, topic, urgency low/medium/high/uncertain, and a plain-language uncertainty explanation, displayed for human review. No replies, customer-record changes, external tools or downstream credentials. Treat ticket text as untrusted data. Accept at most 20,000 UTF-8 bytes and validate server-side JSON structure, text type and nonempty content before inference. Reject malformed input with a content-free 400 response, oversized input with 413, missing/invalid sign-in with 401 and insufficient role with 403; denied requests must not invoke the model. Validate all four output fields and urgency enumeration server-side; reject invalid model output without returning partial triage. Proposed failures: bounded model deadline, no automatic inference retries, content-free 502/503/504 errors as appropriate, and a clear manual retry option without preserving ticket text. Overload returns 429 with retry guidance. Do not retain ticket text or generated results after processing: no durable application storage, browser persistence, ticket-bearing logs, model-response logs or content-bearing error traces; release transient request data after success or failure. Proposed starting Code Engine footprint: 0.5 vCPU and 1 GiB per instance, minimum zero and maximum two instances, five concurrent requests per instance, subject to provider constraints and five-request load testing. Scale-to-zero may cause a cold-start delay; no response-time or availability commitment is established. These footprint settings require explicit emitted Terraform/application support and are not inferred from generic configuration fields. Keep the existing 1,024-token output bound. Content-free metrics should count requests, denials, validation failures, model failures, saturation and latency without ticket/result bodies. Target Australia; Sydney (au-syd) remains an unverified candidate, not an approved destination. Verify Code Engine, App ID and selected watsonx model/plan together, including provider retention and identity, telemetry, support and registry paths; flag identified overseas paths and unresolved paths before use. No automatic overseas fallback. Team administrators own enrollment; operating ownership remains unassigned. Requires an existing Code Engine project, authorized private-registry pull-secret name and namespace, watsonx project/runtime inputs, compatible regional model/quota, scoped retention review and a built/tested/scanned immutable image. Existing company SSO, MFA and immediate token revocation are not established. Monthly cloud charges and separate one-off build costs are unknown. Generated source is not deployment evidence; acceptance, denied-access, failure, load, update and rollback checks must be bound to the exported artifact.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team member’s browser → Ticket triage application: HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert (integration: browser-https)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.; REQ-003: Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests.; REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.; REQ-005: The application shall accept synthetic or redacted ticket text up to 20,000 UTF-8 bytes and reject larger submissions server-side with a clear explanation.; REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.; REQ-007: The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed.; REQ-008: The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths.; REQ-009: The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption.

Implementation status: Composed IBM structured application source, browser, App ID authorization and keyless regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team member’s browser<br/>Tools & data"]
  n1["Ticket triage application<br/>IBM"]
  n0 -->|HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team member’s browser | tools | Web browser | User location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage application | ibm | IBM Code Engine | Australia; Sydney (au-syd) candidate, service support unverified | Proposed | Composed IBM structured application source, browser, App ID authorization and keyless regional model transport generated; destination behavior unverified |

### Resources and cost dimensions

- **Team member’s browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage application** (ticket-triage-app): ibm_code_engine_app, ibm_resource_instance, ibm_appid_application, ibm_iam_trusted_profile, ibm_iam_trusted_profile_link. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
