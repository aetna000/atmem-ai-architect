# Implementation Spec Kit

Snapshot 7d513504-8c90-4d40-ad81-b9d44611d4ce · design r4 · generated 2026-11-09T20:26:53.549Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

10 priority decisions; infrastructure: generated_implementation_unverified. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: ibm
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Team member’s browser (team-browser): External browser — no infrastructure to provision; connection behavior still requires validation; tools, User location.
- Ticket triage application (ticket-triage-app): Composed IBM structured application source, browser, App ID authorization and keyless regional model transport generated; destination behavior unverified; ibm, Australia; Sydney (au-syd) candidate, service support unverified.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 7d513504-8c90-4d40-ad81-b9d44611d4ce · design r4 · generated 2026-11-09T20:26:53.549Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: generated_implementation_unverified
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d7465616d2d616363657373 — priority 1

REQ-003 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7465616d2d616363657373

### requirement-proposed-61692d7469636b65742d6175737472616c69612d626f756e64617279 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69612d626f756e64617279

### requirement-proposed-61692d7469636b65742d6361706163697479 — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d6361706163697479

### requirement-proposed-61692d7469636b65742d636f73742d65766964656e6365 — priority 1

REQ-009 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d636f73742d65766964656e6365

### requirement-proposed-61692d7469636b65742d646174612d6d696e696d69736174696f6e — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d646174612d6d696e696d69736174696f6e

### requirement-proposed-61692d7469636b65742d696e7075742d626f756e64617279 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d696e7075742d626f756e64617279

### requirement-proposed-61692d7469636b65742d736166652d6661696c75726573 — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d736166652d6661696c75726573

### requirement-proposed-61692d7469636b65742d747269616765 — priority 1

REQ-002 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d747269616765

### cost-coverage — priority 2

2 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d7465616d2d616363657373 — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7465616d2d616363657373

### acceptance-61692d7469636b65742d6175737472616c69612d626f756e64617279 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69612d626f756e64617279

### acceptance-61692d7469636b65742d6361706163697479 — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d6361706163697479

### acceptance-61692d7469636b65742d636f73742d65766964656e6365 — priority 2

REQ-009: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d636f73742d65766964656e6365

### acceptance-61692d7469636b65742d646174612d6d696e696d69736174696f6e — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d646174612d6d696e696d69736174696f6e

### acceptance-61692d7469636b65742d696e7075742d626f756e64617279 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d696e7075742d626f756e64617279

### acceptance-61692d7469636b65742d736166652d6661696c75726573 — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d736166652d6661696c75726573

### acceptance-61692d7469636b65742d747269616765 — priority 2

REQ-002: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7469636b65742d747269616765

### acceptance-7265712d3864623732306535 — priority 2

REQ-001: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-7265712d3864623732306535

### traceability-7265712d3864623732306535 — priority 2

REQ-001 has no component links.

Action: Map the requirement to relevant components or record why it is project-wide; do not guess the mapping.

Tasks: TASK-ACCEPTANCE-7265712d3864623732306535

### existing-7465616d2d62726f77736572 — priority 2

Team member’s browser: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-7465616d2d62726f77736572


# Component and interface contracts

Snapshot 7d513504-8c90-4d40-ad81-b9d44611d4ce · design r4 · generated 2026-11-09T20:26:53.549Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-browser: Team member’s browser

- Responsibility: Existing browser outside provisioning scope, used by ten staff members after sign-in. A team member pastes synthetic or redacted support-ticket text and reviews the returned summary, topic, suggested urgency and uncertainty. Display clear input, access and service-failure messages; do not present failed requests as successful triage. Do not persist tickets or results in browser storage. No automated replies or customer-record changes.
- Service: Web browser
- Provider / placement: tools / User location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component ticket-triage-app: Ticket triage application

- Responsibility: Proposed composed IBM Code Engine application: generated browser/API, owned IBM App ID tenant with administrator-enrolled team users, PKCE sign-in, server-side JWT/role checks, dedicated compute-linked trusted profile and regional watsonx Text Chat. Internal identity/model resources belong to this module, not separate deployments. Scope: ten signed-in staff paste synthetic or redacted tickets; about 200 tickets per working day with bursts of five simultaneous requests. Return validated JSON containing summary, topic, urgency low/medium/high/uncertain, and a plain-language uncertainty explanation, displayed for human review. No replies, customer-record changes, external tools or downstream credentials. Treat ticket text as untrusted data. Accept at most 20,000 UTF-8 bytes and validate server-side JSON structure, text type and nonempty content before inference. Reject malformed input with a content-free 400 response, oversized input with 413, missing/invalid sign-in with 401 and insufficient role with 403; denied requests must not invoke the model. Validate all four output fields and urgency enumeration server-side; reject invalid model output without returning partial triage. Proposed failures: bounded model deadline, no automatic inference retries, content-free 502/503/504 errors as appropriate, and a clear manual retry option without preserving ticket text. Overload returns 429 with retry guidance. Do not retain ticket text or generated results after processing: no durable application storage, browser persistence, ticket-bearing logs, model-response logs or content-bearing error traces; release transient request data after success or failure. Proposed starting Code Engine footprint: 0.5 vCPU and 1 GiB per instance, minimum zero and maximum two instances, five concurrent requests per instance, subject to provider constraints and five-request load testing. Scale-to-zero may cause a cold-start delay; no response-time or availability commitment is established. These footprint settings require explicit emitted Terraform/application support and are not inferred from generic configuration fields. Keep the existing 1,024-token output bound. Content-free metrics should count requests, denials, validation failures, model failures, saturation and latency without ticket/result bodies. Target Australia; Sydney (au-syd) remains an unverified candidate, not an approved destination. Verify Code Engine, App ID and selected watsonx model/plan together, including provider retention and identity, telemetry, support and registry paths; flag identified overseas paths and unresolved paths before use. No automatic overseas fallback. Team administrators own enrollment; operating ownership remains unassigned. Requires an existing Code Engine project, authorized private-registry pull-secret name and namespace, watsonx project/runtime inputs, compatible regional model/quota, scoped retention review and a built/tested/scanned immutable image. Existing company SSO, MFA and immediate token revocation are not established. Monthly cloud charges and separate one-off build costs are unknown. Generated source is not deployment evidence; acceptance, denied-access, failure, load, update and rollback checks must be bound to the exported artifact.
- Service: IBM Code Engine
- Provider / placement: ibm / Australia; Sydney (au-syd) candidate, service support unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7469636b65742d7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-to-triage: team-browser → ticket-triage-app

- Drawn payload/purpose: HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert
- Contract task: TASK-CONTRACT-62726f777365722d746f2d747269616765
- Integration task: TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 7d513504-8c90-4d40-ad81-b9d44611d4ce · design r4 · generated 2026-11-09T20:26:53.549Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/tests/ibm-structured.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use emitted Python 3.13 applications/* source and BUILD.md. Install hash-locked test-requirements.lock and run ibm_acceptance.py. Build, scan and test the pinned Linux/amd64 image; obtain authorization before publishing to the existing IBM Container Registry. Supply its digest, existing Code Engine project/pull-secret name, watsonx project/runtime/model inputs and scoped operator review. Enroll approved users in the new owned App ID tenant and add exact subjects; it starts with no authorized users. Add the generated trusted profile as a collaborator on the existing watsonx project and verify access. The runtime, port, PKCE/scoped JWT checks and compute-token transport are implemented. These tests do not establish live IBM identity, project membership, inference quality or deployment.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/tests/ibm-structured.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-62726f777365722d746f2d747269616765 — Define Team member’s browser → Ticket triage application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection browser-to-triage: HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge browser-to-triage
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-7465616d2d62726f77736572 — Integrate existing Team member’s browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d746f2d747269616765
- Components: team-browser
- Generated files: No implementation files generated yet
- Requirements: ai-ticket-triage, ai-ticket-data-minimisation, ai-ticket-australia-boundary, ai-ticket-capacity

### Implementation steps

1. Responsibility from the board: Existing browser outside provisioning scope, used by ten staff members after sign-in. A team member pastes synthetic or redacted support-ticket text and reviews the returned summary, topic, suggested urgency and uncertainty. Display clear input, access and service-failure messages; do not present failed requests as successful triage. Do not persist tickets or results in browser storage. No automated replies or customer-record changes.
2. Verify Web browser on tools in User location; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.; REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.; REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.; REQ-007: The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component team-browser
- Application/configuration and tests for Team member’s browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7469636b65742d7472696167652d617070 — Validate generated Ticket triage application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-triage, ai-team-access, ai-ticket-data-minimisation, ai-ticket-input-boundary, ai-ticket-australia-boundary, ai-ticket-capacity, ai-ticket-safe-failures, ai-ticket-cost-evidence

### Implementation steps

1. Responsibility from the board: Proposed composed IBM Code Engine application: generated browser/API, owned IBM App ID tenant with administrator-enrolled team users, PKCE sign-in, server-side JWT/role checks, dedicated compute-linked trusted profile and regional watsonx Text Chat. Internal identity/model resources belong to this module, not separate deployments. Scope: ten signed-in staff paste synthetic or redacted tickets; about 200 tickets per working day with bursts of five simultaneous requests. Return validated JSON containing summary, topic, urgency low/medium/high/uncertain, and a plain-language uncertainty explanation, displayed for human review. No replies, customer-record changes, external tools or downstream credentials. Treat ticket text as untrusted data. Accept at most 20,000 UTF-8 bytes and validate server-side JSON structure, text type and nonempty content before inference. Reject malformed input with a content-free 400 response, oversized input with 413, missing/invalid sign-in with 401 and insufficient role with 403; denied requests must not invoke the model. Validate all four output fields and urgency enumeration server-side; reject invalid model output without returning partial triage. Proposed failures: bounded model deadline, no automatic inference retries, content-free 502/503/504 errors as appropriate, and a clear manual retry option without preserving ticket text. Overload returns 429 with retry guidance. Do not retain ticket text or generated results after processing: no durable application storage, browser persistence, ticket-bearing logs, model-response logs or content-bearing error traces; release transient request data after success or failure. Proposed starting Code Engine footprint: 0.5 vCPU and 1 GiB per instance, minimum zero and maximum two instances, five concurrent requests per instance, subject to provider constraints and five-request load testing. Scale-to-zero may cause a cold-start delay; no response-time or availability commitment is established. These footprint settings require explicit emitted Terraform/application support and are not inferred from generic configuration fields. Keep the existing 1,024-token output bound. Content-free metrics should count requests, denials, validation failures, model failures, saturation and latency without ticket/result bodies. Target Australia; Sydney (au-syd) remains an unverified candidate, not an approved destination. Verify Code Engine, App ID and selected watsonx model/plan together, including provider retention and identity, telemetry, support and registry paths; flag identified overseas paths and unresolved paths before use. No automatic overseas fallback. Team administrators own enrollment; operating ownership remains unassigned. Requires an existing Code Engine project, authorized private-registry pull-secret name and namespace, watsonx project/runtime inputs, compatible regional model/quota, scoped retention review and a built/tested/scanned immutable image. Existing company SSO, MFA and immediate token revocation are not established. Monthly cloud charges and separate one-off build costs are unknown. Generated source is not deployment evidence; acceptance, denied-access, failure, load, update and rollback checks must be bound to the exported artifact.
2. Verify IBM Code Engine on ibm in Australia; Sydney (au-syd) candidate, service support unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.; REQ-003: Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests.; REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.; REQ-005: The application shall accept synthetic or redacted ticket text up to 20,000 UTF-8 bytes and reject larger submissions server-side with a clear explanation.; REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.; REQ-007: The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed.; REQ-008: The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths.; REQ-009: The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component ticket-triage-app
- Application/configuration and tests for Ticket triage application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-62726f777365722d746f2d747269616765 — Wire Team member’s browser to Ticket triage application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f777365722d746f2d747269616765, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge browser-to-triage in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation browser-to-triage
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765 — Verify live Team member’s browser → Ticket triage application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge browser-to-triage with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence browser-to-triage

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3864623732306535 — Verify REQ-001: A person approves sensitive actions before they happen

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-8db720e5

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d747269616765 — Verify REQ-002: The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-triage

### Implementation steps

1. Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”; rationale: Provides the requested triage outcome without requiring an autonomous agent or ticket-system integration.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7465616d2d616363657373 — Verify REQ-003: Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-team-access

### Implementation steps

1. Basis: “Build a small internal tool” and the proposed ticket-triage-app sign-in boundary.; rationale: Proposed access boundary prevents unauthorised use of an internal tool and exposure of ticket information.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d646174612d6d696e696d69736174696f6e — Verify REQ-004: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-data-minimisation

### Implementation steps

1. Basis: Pasted support-ticket workflow and the proposed stateless ticket-triage-app; retention preferences were not supplied.; rationale: Proposed data minimisation reduces unnecessary copies of potentially sensitive ticket content; provider retention and permitted country still require review.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d696e7075742d626f756e64617279 — Verify REQ-005: The application shall accept synthetic or redacted ticket text up to 20,000 UTF-8 bytes and reject larger submissions server-side with a clear explanation.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-input-boundary

### Implementation steps

1. Basis: “We paste synthetic or redacted text, up to 20 KB per ticket.”; rationale: Bounds processing and rejects oversized tickets explicitly; the existing 20,000-byte setting interprets KB as decimal UTF-8 bytes.
2. Implement a check for Maximum accepted ticket input <= 20000 UTF-8 bytes; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69612d626f756e64617279 — Verify REQ-006: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-australia-boundary

### Implementation steps

1. Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”; rationale: Australian application placement alone does not establish where identity, inference, telemetry or support processing occurs.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d6361706163697479 — Verify REQ-007: The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-capacity

### Implementation steps

1. Basis: “About 200 tickets per working day; bursts of five simultaneous requests.”; rationale: Captures the supplied daily workload and burst size without inventing monthly working days or a latency commitment; load evidence is needed before claiming capacity.
2. Implement a check for Simultaneous valid requests supported >= 5 requests; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d736166652d6661696c75726573 — Verify REQ-008: The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-safe-failures

### Implementation steps

1. Basis: “Malformed input, denied users and model failures must be handled safely.”; rationale: Prevents malformed or denied requests from reaching inference and prevents model failures or invalid output from appearing as trustworthy suggestions.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d636f73742d65766964656e6365 — Verify REQ-009: The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/ibm_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/ibm_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_http.py, terraform/applications/block_7469636b65742d7472696167652d617070/http_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/export_contract_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/policy_review.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/output-contract.json, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/ibm-structured.tftest.hcl
- Requirements: ai-ticket-cost-evidence

### Implementation steps

1. Basis: “Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price.”; rationale: Keeps the requested modest footprint and cost transparency explicit while avoiding unsupported pricing or treating a cloud subtotal as a complete delivery estimate.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-009

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/tests/ibm-structured.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3864623732306535, TASK-ACCEPTANCE-61692d7469636b65742d747269616765, TASK-ACCEPTANCE-61692d7465616d2d616363657373, TASK-ACCEPTANCE-61692d7469636b65742d646174612d6d696e696d69736174696f6e, TASK-ACCEPTANCE-61692d7469636b65742d696e7075742d626f756e64617279, TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69612d626f756e64617279, TASK-ACCEPTANCE-61692d7469636b65742d6361706163697479, TASK-ACCEPTANCE-61692d7469636b65742d736166652d6661696c75726573, TASK-ACCEPTANCE-61692d7469636b65742d636f73742d65766964656e6365, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 7d513504-8c90-4d40-ad81-b9d44611d4ce · design r4 · generated 2026-11-09T20:26:53.549Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-001 (req-8db720e5) → TASK-ACCEPTANCE-7265712d3864623732306535; Recorded from user discussion
- REQ-002 (ai-ticket-triage) → TASK-ACCEPTANCE-61692d7469636b65742d747269616765; Proposed; needs confirmation
- REQ-003 (ai-team-access) → TASK-ACCEPTANCE-61692d7465616d2d616363657373; Proposed; needs confirmation
- REQ-004 (ai-ticket-data-minimisation) → TASK-ACCEPTANCE-61692d7469636b65742d646174612d6d696e696d69736174696f6e; Proposed; needs confirmation
- REQ-005 (ai-ticket-input-boundary) → TASK-ACCEPTANCE-61692d7469636b65742d696e7075742d626f756e64617279; Proposed; needs confirmation
- REQ-006 (ai-ticket-australia-boundary) → TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69612d626f756e64617279; Proposed; needs confirmation
- REQ-007 (ai-ticket-capacity) → TASK-ACCEPTANCE-61692d7469636b65742d6361706163697479; Proposed; needs confirmation
- REQ-008 (ai-ticket-safe-failures) → TASK-ACCEPTANCE-61692d7469636b65742d736166652d6661696c75726573; Proposed; needs confirmation
- REQ-009 (ai-ticket-cost-evidence) → TASK-ACCEPTANCE-61692d7469636b65742d636f73742d65766964656e6365; Proposed; needs confirmation
