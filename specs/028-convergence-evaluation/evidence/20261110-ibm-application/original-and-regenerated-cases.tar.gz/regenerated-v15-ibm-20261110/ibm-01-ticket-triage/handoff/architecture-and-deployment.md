Snapshot 7d513504-8c90-4d40-ad81-b9d44611d4ce · design r4 · generated 2026-11-09T20:26:53.549Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 20:26 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** IBM
- **Usage:** unknown
- **Estimated run cost:** not estimated
- **Review:** 4 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** We paste synthetic or redacted text, up to 20 KB per ticket. Do not retain ticket text after processing. Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Ten staff members use it after signing in. About 200 tickets per working day; bursts of five simultaneous requests. Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price. Return summary, topic, urgency and uncertainty as a validated JSON response. Malformed input, denied users and model failures must be handled safely.
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM
- **Budget and timeline:** —

## 3. Architecture

**Team access**

- Team member’s browser (Tools & data, existing) — Existing browser outside provisioning scope, used by ten staff members after sign-in. A team member pastes synthetic or redacted support-ticket text and reviews the returned summary, topic, suggested urgency and uncertainty. Display clear input, access and service-failure messages; do not present failed requests as successful triage. Do not persist tickets or results in browser storage. No automated replies or customer-record changes.

**Human-reviewed triage**

- Ticket triage application (IBM) — Proposed composed IBM Code Engine application: generated browser/API, owned IBM App ID tenant with administrator-enrolled team users, PKCE sign-in, server-side JWT/role checks, dedicated compute-linked trusted profile and regional watsonx Text Chat. Internal identity/model resources belong to this module, not separate deployments. Scope: ten signed-in staff paste synthetic or redacted tickets; about 200 tickets per working day with bursts of five simultaneous requests. Return validated JSON containing summary, topic, urgency low/medium/high/uncertain, and a plain-language uncertainty explanation, displayed for human review. No replies, customer-record changes, external tools or downstream credentials. Treat ticket text as untrusted data. Accept at most 20,000 UTF-8 bytes and validate server-side JSON structure, text type and nonempty content before inference. Reject malformed input with a content-free 400 response, oversized input with 413, missing/invalid sign-in with 401 and insufficient role with 403; denied requests must not invoke the model. Validate all four output fields and urgency enumeration server-side; reject invalid model output without returning partial triage. Proposed failures: bounded model deadline, no automatic inference retries, content-free 502/503/504 errors as appropriate, and a clear manual retry option without preserving ticket text. Overload returns 429 with retry guidance. Do not retain ticket text or generated results after processing: no durable application storage, browser persistence, ticket-bearing logs, model-response logs or content-bearing error traces; release transient request data after success or failure. Proposed starting Code Engine footprint: 0.5 vCPU and 1 GiB per instance, minimum zero and maximum two instances, five concurrent requests per instance, subject to provider constraints and five-request load testing. Scale-to-zero may cause a cold-start delay; no response-time or availability commitment is established. These footprint settings require explicit emitted Terraform/application support and are not inferred from generic configuration fields. Keep the existing 1,024-token output bound. Content-free metrics should count requests, denials, validation failures, model failures, saturation and latency without ticket/result bodies. Target Australia; Sydney (au-syd) remains an unverified candidate, not an approved destination. Verify Code Engine, App ID and selected watsonx model/plan together, including provider retention and identity, telemetry, support and registry paths; flag identified overseas paths and unresolved paths before use. No automatic overseas fallback. Team administrators own enrollment; operating ownership remains unassigned. Requires an existing Code Engine project, authorized private-registry pull-secret name and namespace, watsonx project/runtime inputs, compatible regional model/quota, scoped retention review and a built/tested/scanned immutable image. Existing company SSO, MFA and immediate token revocation are not established. Monthly cloud charges and separate one-off build costs are unknown. Generated source is not deployment evidence; acceptance, denied-access, failure, load, update and rollback checks must be bound to the exported artifact.

```mermaid
flowchart LR
  n0["Team member’s browser<br/>Tools & data"]
  n1["Ticket triage application<br/>IBM"]
  n0 -->|HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team member’s browser | tools | Web browser | User location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage application | ibm | IBM Code Engine | Australia; Sydney (au-syd) candidate, service support unverified | Proposed | Composed IBM structured application source, browser, App ID authorization and keyless regional model transport generated; destination behavior unverified |

### Resources and cost dimensions

- **Team member’s browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage application** (ticket-triage-app): ibm_code_engine_app, ibm_resource_instance, ibm_appid_application, ibm_iam_trusted_profile, ibm_iam_trusted_profile_link. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team member’s browser | Ticket triage application | HTTPS + sign-in: submit ticket; return validated summary, topic, urgency, uncert | Confidential |

## 5. Security controls

- **Team member’s browser** — Existing browser outside provisioning scope, used by ten staff members after sign-in. A team member pastes synthetic or redacted support-ticket text and reviews the returned summary, topic, suggested urgency and uncertainty. Display clear input, access and service-failure messages; do not present failed requests as successful triage. Do not persist tickets or results in browser storage. No automated replies or customer-record changes.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests. (must)
- Requirement: Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets. (should)
- Requirement: Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests. | security | not measurable yet | Open |
| Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets. | security | not measurable yet | Open |
| Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas. | compliance | not measurable yet | Open |
| The application shall support ten enrolled staff, approximately 200 tickets per working day and bursts of five simultaneous valid requests. Acceptance testing shall exercise the five-request burst and record completed requests, safe errors, latency and resource use; no response-time target is yet agreed. | performance | Simultaneous valid requests supported >= 5requests | Open |
| The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption. | cost | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- The application shall accept pasted support-ticket text and return a short summary, topic and suggested urgency, visibly presented as suggestions for human review. (must, open)
- The application shall accept synthetic or redacted ticket text up to 20,000 UTF-8 bytes and reject larger submissions server-side with a clear explanation. (must, open)
- The server shall reject malformed and oversized input, enforce authentication and role authorization before inference, validate model output against the response contract and return clear content-free errors on failure without fabricated or partial triage. Proposed controls include bounded inference time, no automatic inference retries and safe overload rejection; positive, denial and failure tests must verify these paths. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Maintainability**

- [minor] 4 quality requirements have no measurable target. Add a metric and target to: “Proposed: only explicitly enrolled team members may submit tickets or receive triage results; the server shall reject unauthenticated or unauthorised requests.”, “Proposed: do not persist ticket text or generated results in application storage, browser storage or operational logs; review model-provider retention and processing location before use with real tickets.”, “Target Australian regional processing where the selected IBM services support it. Before use, document service/model availability and all identified processing, retention or access paths outside Australia, explicitly flagging unresolved paths; do not silently fall back overseas.”, “The delivery record shall distinguish monthly cloud/AI running costs from one-off implementation costs, cite sources and regional/model assumptions for each priced item, and explicitly identify unknown compute, inference, identity, registry, transfer and telemetry charges. The proposed small starting footprint shall be checked against the burst workload before adoption.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team member’s browser, Ticket triage application.

**Estimate gaps:**

- Team member’s browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage application: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision human-reviewed triage: Ticket triage application.
4. Connect existing systems: Team member’s browser; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

_None._
