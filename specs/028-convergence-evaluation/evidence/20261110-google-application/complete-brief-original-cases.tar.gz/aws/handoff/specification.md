Snapshot 693d6ad8-d645-4312-8e91-ec6283ea1de6 · design r4 · generated 2026-11-09T19:36:11.801Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion. (must, open); target: acceptance target needed; linked blocks: triage-web, triage-api, triage-processor

Design explanation: Defines the complete requested result while keeping suggestions subject to human judgment; representative tickets will be needed to assess accuracy.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model. (must, open); target: acceptance target needed; linked blocks: staff-sign-in, triage-api, triage-processor

Design explanation: Proposed authenticated staff access prevents an internal tool from becoming an anonymous inference endpoint.

Basis: “Build a small internal tool” and “our team”; Cognito and API authorization are proposed design choices.
- [REQ-004] Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials. (should, open); target: acceptance target needed; linked blocks: triage-web, triage-api, triage-processor, regional-model

Design explanation: Proposed data minimization limits exposure of potentially sensitive support content; provider processing and residency still require review.

Basis: Pasted support tickets pass through triage-web, triage-processor and regional-model; storage is not requested.
- [REQ-005] Accept manually pasted synthetic or redacted tickets up to 20 KB, proposed as 20,000 UTF-8 bytes; enforce the limit server-side and reject larger inputs explicitly without truncation. (must, open); target: Maximum accepted ticket UTF-8 size == 20000bytes; linked blocks: triage-web, triage-api, triage-processor

Design explanation: Align the browser and server limits so valid tickets are accepted and oversized text is rejected without silently losing information. Decimal KB is an explicit engineering interpretation.

Basis: “We paste synthetic or redacted text, up to 20 KB per ticket.”
- [REQ-006] Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback. (must, open); target: acceptance target needed; linked blocks: triage-web, staff-sign-in, triage-api, triage-processor, regional-model

Design explanation: Regional placement must account for model processing and global delivery paths; Australian users alone do not establish Australian processing.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”
- [REQ-007] Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified. (must, open); target: Simultaneous valid ticket requests supported >= 5requests; linked blocks: staff-sign-in, triage-api, triage-processor, regional-model

Design explanation: Five-request bursts exceed the previous concurrency-one proposal; quotas and end-to-end behavior must support the stated demand.

Basis: “Ten staff members use it after signing in. About 200 tickets per working day; bursts of five simultaneous requests.”
- [REQ-008] Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts. (must, open); target: acceptance target needed; linked blocks: triage-web, staff-sign-in, triage-api, triage-processor

Design explanation: Invalid requests and provider failures must not leak ticket text, trigger unauthorized inference or appear as completed suggestions.

Basis: “Malformed input, denied users and model failures must be handled safely.”
- [REQ-009] Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate. (must, open); target: acceptance target needed; linked blocks: triage-web, staff-sign-in, triage-api, triage-processor, regional-model

Design explanation: A partial storage quote cannot establish total running cost; unsupported estimates would mislead the handoff.

Basis: “Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price.”

## How the system works

The current design contains 6 components and 6 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team member → Ticket triage web app

HTTPS: paste ticket and review suggestions

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Ticket triage web app → Staff sign-in

Staff sign-in: authorization code with PKCE

Integration contract: oauth-pkce.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Staff sign-in → Authenticated triage API

JWT authorizer: validate access token and scope

Integration contract: jwt-authorizer.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Ticket triage web app → Authenticated triage API

Browser → regional API directly: ticket and suggestions; no caching

Integration contract: web-rag-api.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Authenticated triage API → Generate triage suggestions

Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors

Integration contract: http-api-lambda.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Generate triage suggestions → Regional AI model

Bedrock Converse: bounded structured generation

Integration contract: bedrock-converse.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team member

Web browser · tools · region: User location · classification: Confidential

Existing staff browser outside provisioning scope. Ten staff members sign in, paste individual synthetic or redacted tickets and review the returned summary, topic, urgency and uncertainty. Expected use is about 200 tickets per working day, with bursts of five simultaneous requests across the team. No automatic replies or customer-record updates.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team member → Ticket triage web app: HTTPS: paste ticket and review suggestions (integration: browser-https)

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket triage web app

Amazon CloudFront · aws · region: Global edge service; residency review pending · classification: Confidential

Browser interface for synthetic or redacted ticket entry and human review by ten signed-in staff. Owns private static assets, S3 hosting and CloudFront access control. Send ticket requests directly to the regional API; CloudFront serves static assets only. Display summary, topic, urgency and uncertainty together only after successful validation; render generated text as text, never executable markup. Show safe, distinguishable input, access, capacity and processing errors; never display partial suggestions as success. No automatic submission retries. Do not persist tickets or suggestions in browser storage, analytics or service-worker caches; clear ticket input after success or failure. No automatic replies or record changes. FLAG: CloudFront is global; static assets, network metadata and delivery logs may be handled outside Australia. Geographic restrictions do not establish Australian residency. Verify actual routing and logging before claiming compliance.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team member → Ticket triage web app: HTTPS: paste ticket and review suggestions (integration: browser-https)

Outputs: Ticket triage web app → Staff sign-in: Staff sign-in: authorization code with PKCE (integration: oauth-pkce); Ticket triage web app → Authenticated triage API: Browser → regional API directly: ticket and suggestions; no caching (integration: web-rag-api)

Requirement traceability: REQ-002: For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion.; REQ-004: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.; REQ-005: Accept manually pasted synthetic or redacted tickets up to 20 KB, proposed as 20,000 UTF-8 bytes; enforce the limit server-side and reject larger inputs explicitly without truncation.; REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.; REQ-008: Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts.; REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.

Implementation status: Private web hosting and Cognito authorization-code/PKCE sign-in generated

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Staff sign-in

Amazon Cognito · aws · region: ap-southeast-2 · classification: Confidential

Proposed admin-created staff accounts with required software-token MFA and authorization-code sign-in with PKCE. No public self-registration. Issues access tokens for the triage API. Existing company identity federation is not assumed; onboarding and account removal need an operating owner before delivery.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket triage web app → Staff sign-in: Staff sign-in: authorization code with PKCE (integration: oauth-pkce)

Outputs: Staff sign-in → Authenticated triage API: JWT authorizer: validate access token and scope (integration: jwt-authorizer)

Requirement traceability: REQ-003: Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model.; REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.; REQ-007: Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified.; REQ-008: Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts.; REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.

Implementation status: Private web hosting and Cognito authorization-code/PKCE sign-in generated

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authenticated triage API

Amazon API Gateway · aws · region: ap-southeast-2 · classification: Confidential

Proposed Sydney regional HTTP API receiving ticket requests directly from the browser, without routing ticket payloads through CloudFront. Validate Cognito access-token issuer, intended API client/audience semantics and required scope before invoking Lambda; deny missing, expired or invalid credentials without model invocation. Restrict browser origins to the web app. Accept a bounded JSON ticket request; coordinate the HTTP body envelope limit with the 20,000-byte text limit. Return validated summary, topic, urgency and uncertainty together. Proposed error contract: 400 malformed/empty input, 413 oversized text, 401/403 access denial, 429 capacity limit and safe 5xx processing failures, without ticket content or incomplete suggestions. Align API, browser and model deadlines so errors arrive before integration timeout. Exclude ticket bodies, suggestions and tokens from logs and tracing; use Cache-Control: no-store on success and error responses. No anonymous inference route. Regional support, endpoint routing and overseas service-metadata handling require verification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff sign-in → Authenticated triage API: JWT authorizer: validate access token and scope (integration: jwt-authorizer); Ticket triage web app → Authenticated triage API: Browser → regional API directly: ticket and suggestions; no caching (integration: web-rag-api)

Outputs: Authenticated triage API → Generate triage suggestions: Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors (integration: http-api-lambda)

Requirement traceability: REQ-002: For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion.; REQ-003: Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model.; REQ-004: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.; REQ-005: Accept manually pasted synthetic or redacted tickets up to 20 KB, proposed as 20,000 UTF-8 bytes; enforce the limit server-side and reject larger inputs explicitly without truncation.; REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.; REQ-007: Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified.; REQ-008: Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts.; REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Generate triage suggestions

AWS Lambda · aws · region: ap-southeast-2 · classification: Confidential

Processes one synthetic or redacted ticket and returns validated JSON with summary, topic, urgency and uncertainty for human review. Accept up to 20,000 UTF-8 bytes, interpreting KB as decimal; reject malformed, empty or oversized input explicitly without truncation. Treat ticket content as untrusted data. Validate required fields, types, allowed urgency values and bounded string lengths server-side; reject missing, extra or invalid fields rather than returning a partial suggestion. Proposed starting footprint: 256 MiB, 30-second function timeout, reserved concurrency five, 512 output tokens, at most two SDK attempts within a bounded overall deadline and 30-day content-free operational logs; no provisioned concurrency. Verify account concurrency, Bedrock quotas and five-request burst behavior. Model failure, timeout, throttling or invalid output returns a safe error without ticket content or partial suggestions; do not retain payloads for retries. Ticket text is transient only: no application storage, payload logs or tracing bodies. Release request references after success or failure; immediate memory zeroization is not guaranteed. No ticketing credentials, outbound-action tools or customer-record permissions. Owns execution role, scoped log group, version and alias. Sydney placement is proposed; regional model compatibility and provider retention remain unverified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Authenticated triage API → Generate triage suggestions: Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors (integration: http-api-lambda)

Outputs: Generate triage suggestions → Regional AI model: Bedrock Converse: bounded structured generation (integration: bedrock-converse)

Requirement traceability: REQ-002: For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion.; REQ-003: Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model.; REQ-004: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.; REQ-005: Accept manually pasted synthetic or redacted tickets up to 20 KB, proposed as 20,000 UTF-8 bytes; enforce the limit server-side and reject larger inputs explicitly without truncation.; REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.; REQ-007: Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified.; REQ-008: Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts.; REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.

Implementation status: Schema-checked structured generation handler, scoped model permission and caller binding generated

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Regional AI model

Amazon Bedrock · aws · region: ap-southeast-2 · classification: Confidential

Reference to a direct regional Amazon Bedrock foundation model, not a model provisioned by this project. Sydney is proposed; model ID remains unselected. Verify a suitable model's Sydney availability, Converse support, account access, quotas and provider retention behavior before selection. No cross-region inference profiles or overseas fallback. Keep model invocation content logging disabled and verify that destination configuration satisfies ticket non-retention. Neither residency nor non-retention is established by this diagram.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Generate triage suggestions → Regional AI model: Bedrock Converse: bounded structured generation (integration: bedrock-converse)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.; REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.; REQ-007: Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified.; REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.

Implementation status: Existing regional foundation model — required model ID input generated

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Ticket triage web app<br/>AWS"]
  n2["Staff sign-in<br/>AWS"]
  n3["Authenticated triage API<br/>AWS"]
  n4["Generate triage suggestions<br/>AWS"]
  n5["Regional AI model<br/>AWS"]
  n0 -->|HTTPS: paste ticket and review suggestions| n1
  n1 -->|Staff sign-in: authorization code with PKCE| n2
  n2 -->|JWT authorizer: validate access token and scope| n3
  n1 -->|Browser → regional API directly: ticket and suggestions; no caching| n3
  n3 -->|Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors| n4
  n4 -->|Bedrock Converse: bounded structured generation| n5
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Team member | tools | Web browser | User location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-web | Ticket triage web app | aws | Amazon CloudFront | Global edge service; residency review pending | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| staff-sign-in | Staff sign-in | aws | Amazon Cognito | ap-southeast-2 | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| triage-api | Authenticated triage API | aws | Amazon API Gateway | ap-southeast-2 | Proposed | Implementation needed |
| triage-processor | Generate triage suggestions | aws | AWS Lambda | ap-southeast-2 | Proposed | Schema-checked structured generation handler, scoped model permission and caller binding generated |
| regional-model | Regional AI model | aws | Amazon Bedrock | ap-southeast-2 | Existing | Existing regional foundation model — required model ID input generated |

### Resources and cost dimensions

- **Team member** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage web app** (triage-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: staff-browser.
- **Staff sign-in** (staff-sign-in): aws_cognito_user_pool. Active users and authentication features. Depends on: triage-web.
- **Authenticated triage API** (triage-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: staff-sign-in, triage-web.
- **Generate triage suggestions** (triage-processor): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: triage-api.
- **Regional AI model** (regional-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: triage-processor.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
