import json
import importlib.util
import os
import sys
from pathlib import Path
import unittest
from unittest.mock import MagicMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"build/block_7472696167652d70726f636573736f72"))
spec=importlib.util.spec_from_file_location("http_operation",Path(__file__).resolve().parents[1]/"build/block_7472696167652d70726f636573736f72/block_7472696167652d70726f636573736f72.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class AuthorizationTests(unittest.TestCase):
    def setUp(self):
        os.environ.update(EXPECTED_API_ID="api",COGNITO_ISSUER="issuer",COGNITO_CLIENT_ID="client",COGNITO_USER_POOL_ID="pool",MAX_INPUT_BYTES="20000",MODEL_ARN="synthetic",MAX_OUTPUT_TOKENS="512")
        module._identity=MagicMock();module._client=MagicMock();module._retention=MagicMock();module._retention.get_account_data_retention.return_value={"mode":"none"};module._retention.get_model_invocation_logging_configuration.return_value={}
        module._identity.admin_get_user.return_value={"Enabled":True,"UserStatus":"CONFIRMED","UserAttributes":[{"Name":"sub","Value":"subject"}]}
        self.event={"version":"2.0","requestContext":{"apiId":"api","routeKey":"POST /api/ask","authorizer":{"jwt":{"claims":{"iss":"issuer","client_id":"client","token_use":"access","scope":"atmem/ask","sub":"subject","username":"user"}}}},"isBase64Encoded":False,"body":json.dumps({"text":"input"})}
    def test_valid_response_and_revocation(self):
        text="{\"summary\":\"x\",\"topic\":\"x\",\"urgency\":\"low\",\"uncertainty\":\"x\"}"
        module._client.converse.return_value={"output":{"message":{"content":[{"text":text}]}},"stopReason":"end_turn"}
        self.assertEqual(module.handler(self.event,None)["statusCode"],200)
        user=module._identity.admin_get_user.return_value
        module._identity.admin_get_user.side_effect=[user,{**user,"Enabled":False}]
        self.assertEqual(module.handler(self.event,None)["statusCode"],403)
    def test_denies_unsigned_or_disabled_requests_without_model_call(self):
        self.assertEqual(module.handler({},None)["statusCode"],403)
        module._identity.admin_get_user.return_value["Enabled"]=False
        self.assertEqual(module.handler(self.event,None)["statusCode"],403)
        module._client.converse.assert_not_called()
    def test_identity_outage_fails_closed(self):
        module._identity.admin_get_user.side_effect=RuntimeError("private provider detail")
        self.assertEqual(module.handler(self.event,None)["statusCode"],503)
        module._client.converse.assert_not_called()
