# Verify model data handling

The structured operation requires regional Bedrock account retention mode none and disabled text invocation logging. It reads these controls before sending input and fails closed when verification is unavailable. It never changes account policy.

After authorization for read-only account access, install the hash-locked runtime requirements in an isolated operator environment, then run:

`python3 verify-model-policy.py --account REVIEWED_12_DIGIT_ACCOUNT --region REVIEWED_REGION --confirm-read`

Keep the returned observation with the account/region and timestamp in protected deployment evidence. A passing read is not a model-quality or deployment test. Check that the selected model is available with this policy. Changing an account-wide setting can affect other workloads; obtain separate approval and review existing systems. Use a suitable isolated account/region when a shared account cannot satisfy this contract. Never relax the policy or replace the client's no-retention requirement just to make inference work.

The operator needs sts:GetCallerIdentity, bedrock:GetAccountDataRetention and bedrock:GetModelInvocationLoggingConfiguration. These are reads; credentials remain outside the package.
