# Terraform 1.7+; mock AWS only. No real credentials or resources.
mock_provider "aws" {}
variables {
  aws_region = "ap-southeast-2"
  aws_account_id = "123456789012"
  review_approved = true
  block_726567696f6e616c2d6d6f64656c_model_id = "amazon.nova-micro-v1:0"
}
run "generated_storage_plan" {
  command = plan
}
run "unapproved_plan_rejected" {
  command = plan
  variables { review_approved = false }
  expect_failures = [terraform_data.review_gate]
}

run "block_7472696167652d617069_jwt_boundary" {
 command = plan
 assert {
  condition = aws_apigatewayv2_route.block_7472696167652d776562.authorization_type == "JWT" && contains(aws_apigatewayv2_route.block_7472696167652d776562.authorization_scopes,"atmem/ask")
  error_message = "Structured operation must require verified scoped JWT access."
 }
 assert {
  condition = aws_cognito_user_pool.block_73746166662d7369676e2d696e.mfa_configuration == "ON" && aws_cognito_user_pool.block_73746166662d7369676e2d696e.admin_create_user_config[0].allow_admin_create_user_only
  error_message = "Sign-in requires MFA and controlled user creation."
 }
 assert {
  condition = aws_s3_bucket_public_access_block.block_7472696167652d776562.block_public_policy && aws_s3_bucket_public_access_block.block_7472696167652d776562.restrict_public_buckets
  error_message = "Web assets must not expose a public S3 bucket."
 }
 assert {
  condition = aws_lambda_permission.block_7472696167652d776562.principal == "apigateway.amazonaws.com" && aws_lambda_permission.block_7472696167652d776562.source_account == var.aws_account_id
  error_message = "Only the account-bound API invocation contract may be generated."
 }
}