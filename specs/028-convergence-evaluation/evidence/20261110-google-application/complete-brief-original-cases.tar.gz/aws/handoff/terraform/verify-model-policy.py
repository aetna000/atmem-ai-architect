"""Read-only model policy check. Account access needs separate authorization."""
import argparse
import json
import re

def inspect_policy(session,expected_account):
    from botocore.config import Config
    config=Config(connect_timeout=2,read_timeout=5,retries={"total_max_attempts":1})
    identity=session.client("sts",config=config).get_caller_identity()
    if identity.get("Account")!=expected_account:return {"status":"blocked","reason":"Unexpected AWS account; no model policy was read."}
    client=session.client("bedrock",config=config)
    mode=client.get_account_data_retention().get("mode")
    logging=client.get_model_invocation_logging_configuration().get("loggingConfig",{})
    verified=mode=="none" and isinstance(logging,dict) and logging.get("textDataDeliveryEnabled",False) is False
    return {"status":"passed" if verified else "blocked","retentionMode":mode,"textLoggingDisabled":isinstance(logging,dict) and logging.get("textDataDeliveryEnabled",False) is False,"boundary":"Read-only policy observation; not model-quality, authentication or deployment evidence."}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--account",required=True);parser.add_argument("--region",required=True);parser.add_argument("--confirm-read",action="store_true")
    args=parser.parse_args()
    if not args.confirm_read:parser.error("Obtain authorization for account access before supplying --confirm-read")
    if not re.fullmatch(r"[0-9]{12}",args.account) or not re.fullmatch(r"[a-z]{2}-[a-z]+-[1-9]",args.region):parser.error("Supply the exact commercial AWS account and region")
    try:
        import boto3
        result=inspect_policy(boto3.Session(region_name=args.region),args.account)
    except Exception:result={"status":"unavailable","reason":"Policy read failed. Check the hash-locked SDK installation, authorized credential chain and read permissions; no policy was changed."}
    print(json.dumps(result));return 0 if result["status"]=="passed" else 2

if __name__=="__main__":raise SystemExit(main())
