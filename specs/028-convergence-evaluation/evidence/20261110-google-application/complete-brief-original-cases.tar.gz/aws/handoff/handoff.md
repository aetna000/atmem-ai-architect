# Delivery handoff

Snapshot 693d6ad8-d645-4312-8e91-ec6283ea1de6 · design r4 · generated 2026-11-09T19:36:11.801Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Regional AI model / Endpoint hours: price needed.
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated triage API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Generate triage suggestions: no cost lines; add charges or an explicit zero-cost line with a reason.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
