Snapshot 693d6ad8-d645-4312-8e91-ec6283ea1de6 · design r4 · generated 2026-11-09T19:36:11.801Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 19:36 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Ten staff members use it after signing in. About 200 tickets per working day; bursts of five simultaneous requests. Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price. Return summary, topic, urgency and uncertainty as a validated JSON response. Malformed input, denied users and model failures must be handled safely.
- **Systems it connects to:** —
- **How good, fast and safe:** We paste synthetic or redacted text, up to 20 KB per ticket. Do not retain ticket text after processing. Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Cloud preference:** AWS
- **Budget and timeline:** —

## 3. Architecture

**Staff experience**

- Team member (Tools & data, existing) — Existing staff browser outside provisioning scope. Ten staff members sign in, paste individual synthetic or redacted tickets and review the returned summary, topic, urgency and uncertainty. Expected use is about 200 tickets per working day, with bursts of five simultaneous requests across the team. No automatic replies or customer-record updates.
- Ticket triage web app (AWS, sketch) — Browser interface for synthetic or redacted ticket entry and human review by ten signed-in staff. Owns private static assets, S3 hosting and CloudFront access control. Send ticket requests directly to the regional API; CloudFront serves static assets only. Display summary, topic, urgency and uncertainty together only after successful validation; render generated text as text, never executable markup. Show safe, distinguishable input, access, capacity and processing errors; never display partial suggestions as success. No automatic submission retries. Do not persist tickets or suggestions in browser storage, analytics or service-worker caches; clear ticket input after success or failure. No automatic replies or record changes. FLAG: CloudFront is global; static assets, network metadata and delivery logs may be handled outside Australia. Geographic restrictions do not establish Australian residency. Verify actual routing and logging before claiming compliance.

**Staff access**

- Staff sign-in (AWS, sketch) — Proposed admin-created staff accounts with required software-token MFA and authorization-code sign-in with PKCE. No public self-registration. Issues access tokens for the triage API. Existing company identity federation is not assumed; onboarding and account removal need an operating owner before delivery.

**Ticket analysis**

- Authenticated triage API (AWS, sketch) — Proposed Sydney regional HTTP API receiving ticket requests directly from the browser, without routing ticket payloads through CloudFront. Validate Cognito access-token issuer, intended API client/audience semantics and required scope before invoking Lambda; deny missing, expired or invalid credentials without model invocation. Restrict browser origins to the web app. Accept a bounded JSON ticket request; coordinate the HTTP body envelope limit with the 20,000-byte text limit. Return validated summary, topic, urgency and uncertainty together. Proposed error contract: 400 malformed/empty input, 413 oversized text, 401/403 access denial, 429 capacity limit and safe 5xx processing failures, without ticket content or incomplete suggestions. Align API, browser and model deadlines so errors arrive before integration timeout. Exclude ticket bodies, suggestions and tokens from logs and tracing; use Cache-Control: no-store on success and error responses. No anonymous inference route. Regional support, endpoint routing and overseas service-metadata handling require verification.
- Generate triage suggestions (AWS) — Processes one synthetic or redacted ticket and returns validated JSON with summary, topic, urgency and uncertainty for human review. Accept up to 20,000 UTF-8 bytes, interpreting KB as decimal; reject malformed, empty or oversized input explicitly without truncation. Treat ticket content as untrusted data. Validate required fields, types, allowed urgency values and bounded string lengths server-side; reject missing, extra or invalid fields rather than returning a partial suggestion. Proposed starting footprint: 256 MiB, 30-second function timeout, reserved concurrency five, 512 output tokens, at most two SDK attempts within a bounded overall deadline and 30-day content-free operational logs; no provisioned concurrency. Verify account concurrency, Bedrock quotas and five-request burst behavior. Model failure, timeout, throttling or invalid output returns a safe error without ticket content or partial suggestions; do not retain payloads for retries. Ticket text is transient only: no application storage, payload logs or tracing bodies. Release request references after success or failure; immediate memory zeroization is not guaranteed. No ticketing credentials, outbound-action tools or customer-record permissions. Owns execution role, scoped log group, version and alias. Sydney placement is proposed; regional model compatibility and provider retention remain unverified.
- Regional AI model (AWS, existing) — Reference to a direct regional Amazon Bedrock foundation model, not a model provisioned by this project. Sydney is proposed; model ID remains unselected. Verify a suitable model's Sydney availability, Converse support, account access, quotas and provider retention behavior before selection. No cross-region inference profiles or overseas fallback. Keep model invocation content logging disabled and verify that destination configuration satisfies ticket non-retention. Neither residency nor non-retention is established by this diagram.

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Ticket triage web app<br/>AWS"]
  n2["Staff sign-in<br/>AWS"]
  n3["Authenticated triage API<br/>AWS"]
  n4["Generate triage suggestions<br/>AWS"]
  n5["Regional AI model<br/>AWS"]
  n0 -->|HTTPS: paste ticket and review suggestions| n1
  n1 -->|Staff sign-in: authorization code with PKCE| n2
  n2 -->|JWT authorizer: validate access token and scope| n3
  n1 -->|Browser → regional API directly: ticket and suggestions; no caching| n3
  n3 -->|Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors| n4
  n4 -->|Bedrock Converse: bounded structured generation| n5
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Team member | tools | Web browser | User location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-web | Ticket triage web app | aws | Amazon CloudFront | Global edge service; residency review pending | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| staff-sign-in | Staff sign-in | aws | Amazon Cognito | ap-southeast-2 | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| triage-api | Authenticated triage API | aws | Amazon API Gateway | ap-southeast-2 | Proposed | Implementation needed |
| triage-processor | Generate triage suggestions | aws | AWS Lambda | ap-southeast-2 | Proposed | Schema-checked structured generation handler, scoped model permission and caller binding generated |
| regional-model | Regional AI model | aws | Amazon Bedrock | ap-southeast-2 | Existing | Existing regional foundation model — required model ID input generated |

### Resources and cost dimensions

- **Team member** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage web app** (triage-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: staff-browser.
- **Staff sign-in** (staff-sign-in): aws_cognito_user_pool. Active users and authentication features. Depends on: triage-web.
- **Authenticated triage API** (triage-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: staff-sign-in, triage-web.
- **Generate triage suggestions** (triage-processor): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: triage-api.
- **Regional AI model** (regional-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: triage-processor.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team member | Ticket triage web app | HTTPS: paste ticket and review suggestions | Confidential |
| Ticket triage web app | Staff sign-in | Staff sign-in: authorization code with PKCE | Confidential |
| Staff sign-in | Authenticated triage API | JWT authorizer: validate access token and scope | Confidential |
| Ticket triage web app | Authenticated triage API | Browser → regional API directly: ticket and suggestions; no caching | Confidential |
| Authenticated triage API | Generate triage suggestions | Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors | Confidential |
| Generate triage suggestions | Regional AI model | Bedrock Converse: bounded structured generation | Confidential |

## 5. Security controls

- **Team member** — Existing staff browser outside provisioning scope. Ten staff members sign in, paste individual synthetic or redacted tickets and review the returned summary, topic, urgency and uncertainty. Expected use is about 200 tickets per working day, with bursts of five simultaneous requests across the team. No automatic replies or customer-record updates.
- **Staff sign-in** — Proposed admin-created staff accounts with required software-token MFA and authorization-code sign-in with PKCE. No public self-registration. Issues access tokens for the triage API. Existing company identity federation is not assumed; onboarding and account removal need an operating owner before delivery.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model. (must)
- Requirement: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials. (should)
- Requirement: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model. | security | not measurable yet | Open |
| Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials. | security | not measurable yet | Open |
| Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback. | compliance | not measurable yet | Open |
| Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified. | scalability | Simultaneous valid ticket requests supported >= 5requests | Open |
| Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate. | cost | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion. (must, open)
- Accept manually pasted synthetic or redacted tickets up to 20 KB, proposed as 20,000 UTF-8 bytes; enforce the limit server-side and reject larger inputs explicitly without truncation. (must, open)
- Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 4 quality requirements have no measurable target. Add a metric and target to: “Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model.”, “Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.”, “Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.”, “Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 3 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Regional AI model | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team member, Ticket triage web app, Authenticated triage API, Generate triage suggestions.

**Estimate gaps:**

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Regional AI model / Endpoint hours: price needed.
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated triage API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Generate triage suggestions: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff experience: Ticket triage web app.
4. Provision staff access: Staff sign-in.
5. Provision ticket analysis: Authenticated triage API, Generate triage suggestions.
6. Connect existing systems: Team member, Regional AI model; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Staff sign-in: needs requests_per_month _(estimate)_
- Regional AI model: needs a unit price with a source _(estimate)_
