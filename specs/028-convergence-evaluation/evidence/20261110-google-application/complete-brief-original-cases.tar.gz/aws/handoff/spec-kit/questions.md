# Questions and assumptions to resolve

Snapshot 693d6ad8-d645-4312-8e91-ec6283ea1de6 · design r4 · generated 2026-11-09T19:36:11.801Z

- [ai-ticket-triage] Confirm REQ-002: For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion.
- [ai-staff-access] Confirm REQ-003: Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model.
- [ai-ticket-minimization] Confirm REQ-004: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.
- [ai-ticket-input-boundary] Confirm REQ-005: Accept manually pasted synthetic or redacted tickets up to 20 KB, proposed as 20,000 UTF-8 bytes; enforce the limit server-side and reject larger inputs explicitly without truncation.
- [ai-australian-processing] Confirm REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.
- [ai-triage-capacity] Confirm REQ-007: Support ten signed-in staff and approximately 200 tickets per working day, including five simultaneous valid requests; verify the complete application under that burst and return explicit safe capacity errors when limits are exceeded. Response-time acceptance remains unspecified.
- [ai-triage-safe-failures] Confirm REQ-008: Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts.
- [ai-triage-cost-evidence] Confirm REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.
- [acceptance-req-b181d9f5] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-triage] Agree a measurable acceptance check for REQ-002: For a manually pasted support ticket, return a short summary, topic and suggested urgency together for human review; report processing failures without displaying an invalid result as a completed suggestion.
- [acceptance-ai-staff-access] Agree a measurable acceptance check for REQ-003: Proposed: only explicitly onboarded staff may submit tickets for analysis; the API must reject missing or invalid authorization before invoking the model.
- [acceptance-ai-ticket-minimization] Agree a measurable acceptance check for REQ-004: Proposed: do not persist ticket text or generated suggestions in application storage, browser persistence or logs; record operational metadata without ticket content or credentials.
- [acceptance-ai-australian-processing] Agree a measurable acceptance check for REQ-006: Use an Australian region for regional services where supported. Identify and flag any ticket, identity, metadata or logging path that could leave Australia; verify model residency and retention before delivery, with no silent cross-region inference or overseas fallback.
- [acceptance-ai-triage-safe-failures] Agree a measurable acceptance check for REQ-008: Reject malformed input and unauthorized requests before model invocation; handle model errors, timeouts, throttling and invalid output with safe errors containing no ticket content or partial suggestions. Verify success and negative paths against the exact emitted artifacts.
- [acceptance-ai-triage-cost-evidence] Agree a measurable acceptance check for REQ-009: Document the proposed starting footprint and recurring cloud cost drivers with source, date, region, currency and usage assumptions for each priced item; explicitly mark unpriced items and keep one-off build costs separate. Do not present a partial subtotal as the full estimate.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d6175737472616c69616e2d70726f63657373696e67] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d73746166662d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d696e7075742d626f756e64617279] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6d696e696d697a6174696f6e] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d747269616765] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d6361706163697479] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d636f73742d65766964656e6365] REQ-009 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d736166652d6661696c75726573] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
