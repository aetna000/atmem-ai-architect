# Component and interface contracts

Snapshot 693d6ad8-d645-4312-8e91-ec6283ea1de6 · design r4 · generated 2026-11-09T19:36:11.801Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component staff-browser: Team member

- Responsibility: Existing staff browser outside provisioning scope. Ten staff members sign in, paste individual synthetic or redacted tickets and review the returned summary, topic, urgency and uncertainty. Expected use is about 200 tickets per working day, with bursts of five simultaneous requests across the team. No automatic replies or customer-record updates.
- Service: Web browser
- Provider / placement: tools / User location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-73746166662d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component triage-web: Ticket triage web app

- Responsibility: Browser interface for synthetic or redacted ticket entry and human review by ten signed-in staff. Owns private static assets, S3 hosting and CloudFront access control. Send ticket requests directly to the regional API; CloudFront serves static assets only. Display summary, topic, urgency and uncertainty together only after successful validation; render generated text as text, never executable markup. Show safe, distinguishable input, access, capacity and processing errors; never display partial suggestions as success. No automatic submission retries. Do not persist tickets or suggestions in browser storage, analytics or service-worker caches; clear ticket input after success or failure. No automatic replies or record changes. FLAG: CloudFront is global; static assets, network metadata and delivery logs may be handled outside Australia. Geographic restrictions do not establish Australian residency. Verify actual routing and logging before claiming compliance.
- Service: Amazon CloudFront
- Provider / placement: aws / Global edge service; residency review pending
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component staff-sign-in: Staff sign-in

- Responsibility: Proposed admin-created staff accounts with required software-token MFA and authorization-code sign-in with PKCE. No public self-registration. Issues access tokens for the triage API. Existing company identity federation is not assumed; onboarding and account removal need an operating owner before delivery.
- Service: Amazon Cognito
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d7369676e2d696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-api: Authenticated triage API

- Responsibility: Proposed Sydney regional HTTP API receiving ticket requests directly from the browser, without routing ticket payloads through CloudFront. Validate Cognito access-token issuer, intended API client/audience semantics and required scope before invoking Lambda; deny missing, expired or invalid credentials without model invocation. Restrict browser origins to the web app. Accept a bounded JSON ticket request; coordinate the HTTP body envelope limit with the 20,000-byte text limit. Return validated summary, topic, urgency and uncertainty together. Proposed error contract: 400 malformed/empty input, 413 oversized text, 401/403 access denial, 429 capacity limit and safe 5xx processing failures, without ticket content or incomplete suggestions. Align API, browser and model deadlines so errors arrive before integration timeout. Exclude ticket bodies, suggestions and tokens from logs and tracing; use Cache-Control: no-store on success and error responses. No anonymous inference route. Regional support, endpoint routing and overseas service-metadata handling require verification.
- Service: Amazon API Gateway
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-processor: Generate triage suggestions

- Responsibility: Processes one synthetic or redacted ticket and returns validated JSON with summary, topic, urgency and uncertainty for human review. Accept up to 20,000 UTF-8 bytes, interpreting KB as decimal; reject malformed, empty or oversized input explicitly without truncation. Treat ticket content as untrusted data. Validate required fields, types, allowed urgency values and bounded string lengths server-side; reject missing, extra or invalid fields rather than returning a partial suggestion. Proposed starting footprint: 256 MiB, 30-second function timeout, reserved concurrency five, 512 output tokens, at most two SDK attempts within a bounded overall deadline and 30-day content-free operational logs; no provisioned concurrency. Verify account concurrency, Bedrock quotas and five-request burst behavior. Model failure, timeout, throttling or invalid output returns a safe error without ticket content or partial suggestions; do not retain payloads for retries. Ticket text is transient only: no application storage, payload logs or tracing bodies. Release request references after success or failure; immediate memory zeroization is not guaranteed. No ticketing credentials, outbound-action tools or customer-record permissions. Owns execution role, scoped log group, version and alias. Sydney placement is proposed; regional model compatibility and provider retention remain unverified.
- Service: AWS Lambda
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d70726f636573736f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component regional-model: Regional AI model

- Responsibility: Reference to a direct regional Amazon Bedrock foundation model, not a model provisioned by this project. Sydney is proposed; model ID remains unselected. Verify a suitable model's Sydney availability, Converse support, account access, quotas and provider retention behavior before selection. No cross-region inference profiles or overseas fallback. Keep model invocation content logging disabled and verify that destination configuration satisfies ticket non-retention. Neither residency nor non-retention is established by this diagram.
- Service: Amazon Bedrock
- Provider / placement: aws / ap-southeast-2
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-726567696f6e616c2d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### browser-web: staff-browser → triage-web

- Drawn payload/purpose: HTTPS: paste ticket and review suggestions
- Contract task: TASK-CONTRACT-62726f777365722d776562
- Integration task: TASK-INTEGRATION-62726f777365722d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-sign-in: triage-web → staff-sign-in

- Drawn payload/purpose: Staff sign-in: authorization code with PKCE
- Contract task: TASK-CONTRACT-7765622d7369676e2d696e
- Integration task: TASK-INTEGRATION-7765622d7369676e2d696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sign-in-api: staff-sign-in → triage-api

- Drawn payload/purpose: JWT authorizer: validate access token and scope
- Contract task: TASK-CONTRACT-7369676e2d696e2d617069
- Integration task: TASK-INTEGRATION-7369676e2d696e2d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-api: triage-web → triage-api

- Drawn payload/purpose: Browser → regional API directly: ticket and suggestions; no caching
- Contract task: TASK-CONTRACT-7765622d617069
- Integration task: TASK-INTEGRATION-7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-processor: triage-api → triage-processor

- Drawn payload/purpose: Authorized ticket → validated summary, topic, urgency, uncertainty; safe errors
- Contract task: TASK-CONTRACT-6170692d70726f636573736f72
- Integration task: TASK-INTEGRATION-6170692d70726f636573736f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### processor-model: triage-processor → regional-model

- Drawn payload/purpose: Bedrock Converse: bounded structured generation
- Contract task: TASK-CONTRACT-70726f636573736f722d6d6f64656c
- Integration task: TASK-INTEGRATION-70726f636573736f722d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
