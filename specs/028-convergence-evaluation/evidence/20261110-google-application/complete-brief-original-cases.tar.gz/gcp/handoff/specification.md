Snapshot 33d5abe4-99d8-41dc-a608-ca98a7a83370 · design r4 · generated 2026-11-09T19:42:58.427Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] The application shall accept a pasted support ticket and display a short summary, topic and suggested urgency for human review; invalid or failed generation shall produce an explicit error rather than a fabricated suggestion. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Defines the complete first-version outcome without introducing ticket-system integrations or automated actions.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Proposed access and data-handling boundaries reduce exposure of potentially sensitive support-ticket content.

Basis: The user describes a “small internal tool”; ticket-triage-app proposes company-group authentication and transient processing.
- [REQ-004] Accept pasted synthetic or redacted tickets up to 20,000 UTF-8 bytes, interpreting 20 KB as decimal; reject larger requests explicitly without truncating them. (must, open); target: Maximum accepted ticket text size <= 20000UTF-8 bytes; linked blocks: ticket-triage-app

Design explanation: An explicit server-side byte limit prevents silent truncation and keeps the application within its supported input contract.

Basis: User: “We paste synthetic or redacted text, up to 20 KB per ticket.” Existing ticket-triage-app limit is 20,000 bytes; decimal KB interpretation is proposed.
- [REQ-005] Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app, team-browser

Design explanation: Australian placement alone does not establish the location of inference or ancillary processing; undisclosed overseas paths would undermine the requested boundary.

Basis: User: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”
- [REQ-006] The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Preserves the review-only boundary and prevents application expansion into unauthorized customer actions.

Basis: Original project brief requires human review and prohibits replies or customer-record changes; the current request says to preserve these requirements.
- [REQ-007] Support ten signed-in staff processing approximately 200 tickets per working day and bursts of five simultaneous requests; demonstrate bounded resource use and explicit overload behavior through load tests. Response-time and availability targets remain unspecified. (must, open); target: Concurrent requests supported >= 5requests; linked blocks: ticket-triage-app

Design explanation: Records the actual operating load without inventing working days per month or a response-time guarantee.

Basis: “Ten staff members use it after signing in. About 200 tickets per working day; bursts of five simultaneous requests.”
- [REQ-008] Reject malformed or oversized input and unauthorized users before inference; validate successful output against the four-field JSON contract and return safe explicit errors on timeout, provider failure or invalid output, without fabricated suggestions or ticket content in errors. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Prevents invalid requests, denied access and generation failures from producing misleading suggestions or exposing ticket content.

Basis: “Malformed input, denied users and model failures must be handled safely.”
- [REQ-009] Document proposed runtime limits and itemize recurring cloud/AI cost drivers with sources or explicit unknowns; keep one-off build costs separate and do not treat daily ticket volume as monthly usage without a stated working-day assumption. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Makes operating costs reviewable without presenting unavailable prices or unquoted development effort as an estimate.

Basis: “Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price.”

## How the system works

The current design contains 2 components and 1 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team browser → Ticket triage app

Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team browser

Web browser · tools · region: To be selected · classification: Confidential

Existing browser used by ten staff, outside provisioning scope. Staff sign in, paste synthetic or redacted support-ticket text and review summary, topic, suggested urgency and uncertainty. Display suggestions only after a valid server response; show safe errors without stale or fabricated suggestions. No replies, customer-record changes or ticket-system integration. Proposed browser behavior: no persistent ticket/result storage, clear text and suggestions when review ends, prevent duplicate submissions and return no-store responses. Company sign-in compatibility and end-of-review behavior require implementation and testing.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team browser → Ticket triage app: Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re (integration: browser-https)

Requirement traceability: REQ-002: The application shall accept a pasted support ticket and display a short summary, topic and suggested urgency for human review; invalid or failed generation shall produce an explicit error rather than a fabricated suggestion.; REQ-005: Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints.; REQ-006: The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version.; REQ-008: Reject malformed or oversized input and unauthorized users before inference; validate successful output against the four-field JSON contract and return safe explicit errors on timeout, provider failure or invalid output, without fabricated suggestions or ticket content in errors.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket triage app

Google Cloud Run · gcp · region: australia-southeast1 · classification: Confidential

Proposed composed Google Cloud Run application module owning browser/API runtime, organization Identity-Aware Proxy access, dedicated keyless runtime identity, scoped model/policy-reader permissions and regional Vertex AI Gemini transport. Internal module resources are not separate deployment blocks. Requires an organization-owned project, an existing authorized company group, an existing Artifact Registry repository and a built/tested immutable application image. Current company sign-in and group compatibility remain unresolved.

Included scope: ten signed-in staff paste one synthetic or redacted ticket and receive summary, topic, suggested urgency and uncertainty as validated JSON for human review. Excluded: outbound replies, customer-record mutations, ticket-system integration, automated actions, durable ticket history, retrieval and training. Treat ticket instructions as untrusted data. Accept at most 20,000 UTF-8 bytes of text, interpreting 20 KB as decimal; reject oversized text without truncation and bound the complete HTTP request. Proposed output limit remains 512 tokens; truncated or invalid output must fail safely.

Enforce authentication and authorized-group access on the server before inference. Validate signed IAP assertions and audience; do not trust arbitrary forwarded identity headers. Restrict direct runtime access so it cannot bypass IAP. Unknown or denied identities receive no inference or ticket data. Existing identity/group configuration must be reviewed; token expiry/skew limits revocation freshness, and MFA or continuous revocation is not proven.

Proposed API contract: POST /triage with JSON {text: string}; reject malformed JSON, invalid UTF-8, wrong types, empty text and unexpected fields. Successful responses contain exactly four correctly typed fields with urgency restricted to the proposed enumeration. Use safe 400/413 input errors, 401/403 access errors, 429 overload and bounded 502/503/504 generation failures as appropriate. Return no partial or fabricated suggestions, provider internals or ticket content in errors. Bound model attempts to two for transient failures within the request deadline; do not retry invalid input or denied access. Browser must handle non-success responses without presenting prior suggestions as current.

Proposed starting footprint: request-based Cloud Run, 1 vCPU, 512 MiB, minimum zero instances, maximum two instances and per-instance request concurrency five. These are engineering proposals to reconcile with emitted configuration and load-test; cold starts are possible and no latency or availability guarantee is established. Plan for about 200 tickets per working day and bursts of five simultaneous requests. Bound model concurrency and overload behavior; check regional quotas. Do not assume five concurrent requests proves acceptable latency or memory use.

Process text transiently only: no durable ticket/result storage, content logging, tracing, caching or content-bearing errors. No browser persistent storage; propose clearing text and suggestions when review ends. Use no-store response headers. Content-free operational metrics cover request counts, denied access, validation failures, model failures, latency and overload. Review telemetry identifiers and retention separately. Require disabled project caching and model logging/sharing plus documented destination-owner abuse-logging review; application settings alone cannot prove provider non-retention.

Propose Sydney australia-southeast1 for runtime and compatible direct regional Gemini processing; region/model selection remains unaccepted and unverified. Do not silently fall back to global or overseas endpoints. Review inference, identity, build/artifact, telemetry and support paths and disclose any processing outside Australia before deployment. No specific model/version, quota or entitlement is verified.

Cost record: monthly cloud/AI total UNKNOWN. Include Cloud Run CPU/memory/request duration and requests, Gemini input/output tokens, IAP/identity prerequisites where chargeable, image storage/builds, telemetry, network transfer and applicable support. Browser has no newly provisioned cloud resource; existing devices, connectivity and identity licences are outside the incremental hosting subtotal. Ticket-content storage is excluded. Monthly request volume is 200 multiplied by actual working days; days/month, typical token counts, generation duration, selected model/SKUs, rates, currency and tax remain unknown. A maximum byte size is not typical token usage. The supplied pricing.lookup returned no exact regional storage price and supplies no applicable compute/inference rates; it cannot support a subtotal for this workload. One-off build/verification cost is separately UNKNOWN: no effort, rate or quote is supplied.

Engineering handoff tasks: implement the browser and POST /triage contract, authorization, strict request/response validation, bounded Gemini transport, no-content observability and cleanup; reconcile emitted infrastructure with proposed sizing and identities; build and test the immutable image. Acceptance evidence must cover allowed/denied users, forged/expired/wrong-audience assertions, direct-access bypass, malformed/oversized requests, injection attempts, missing/extra/wrong-type output fields, unknown urgency, model timeout/failure, overload and five concurrent requests. Inspect browser storage, logs, traces, caches and errors for retained content. Evaluate suggestion quality on reviewed synthetic tickets separately from schema checks. Handoff must identify artifact/file locations, destination inputs, operator ownership, rollout/rollback and incident procedures. No artifact-bound tests, account-specific plan, deployment or runtime evidence is supplied.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team browser → Ticket triage app: Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re (integration: browser-https)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The application shall accept a pasted support ticket and display a short summary, topic and suggested urgency for human review; invalid or failed generation shall produce an explicit error rather than a fabricated suggestion.; REQ-003: Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open.; REQ-004: Accept pasted synthetic or redacted tickets up to 20,000 UTF-8 bytes, interpreting 20 KB as decimal; reject larger requests explicitly without truncating them.; REQ-005: Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints.; REQ-006: The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version.; REQ-007: Support ten signed-in staff processing approximately 200 tickets per working day and bursts of five simultaneous requests; demonstrate bounded resource use and explicit overload behavior through load tests. Response-time and availability targets remain unspecified.; REQ-008: Reject malformed or oversized input and unauthorized users before inference; validate successful output against the four-field JSON contract and return safe explicit errors on timeout, provider failure or invalid output, without fabricated suggestions or ticket content in errors.; REQ-009: Document proposed runtime limits and itemize recurring cloud/AI cost drivers with sources or explicit unknowns; keep one-off build costs separate and do not treat daily ticket volume as monthly usage without a stated working-day assumption.

Implementation status: Composed Google structured application source, browser, IAP identity and regional model transport generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team browser<br/>Tools & data"]
  n1["Ticket triage app<br/>Google Cloud"]
  n0 -->|Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team browser | tools | Web browser | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage app | gcp | Google Cloud Run | australia-southeast1 | Proposed | Composed Google structured application source, browser, IAP identity and regional model transport generated; destination behavior unverified |

### Resources and cost dimensions

- **Team browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage app** (ticket-triage-app): google_cloud_run_v2_service, google_service_account, google_project_iam_custom_role, google_iap_web_cloud_run_service_iam_member. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
