Snapshot 33d5abe4-99d8-41dc-a608-ca98a7a83370 · design r4 · generated 2026-11-09T19:42:58.427Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 19:42 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Google Cloud
- **Usage:** unknown
- **Estimated run cost:** not estimated
- **Review:** 5 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** We paste synthetic or redacted text, up to 20 KB per ticket. Do not retain ticket text after processing. Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Who uses it, and how much:** Here are the remaining project facts before we finalize the handoff. Preserve these requirements and update the system as needed. Ten staff members use it after signing in. About 200 tickets per working day; bursts of five simultaneous requests. Propose a modest starting footprint and show sourced costs or explicit unknowns. Do not invent a price. Return summary, topic, urgency and uncertainty as a validated JSON response. Malformed input, denied users and model failures must be handled safely.
- **Systems it connects to:** Ten staff members use it after signing in.
- **How good, fast and safe:** —
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**Staff review**

- Team browser (Tools & data, existing) — Existing browser used by ten staff, outside provisioning scope. Staff sign in, paste synthetic or redacted support-ticket text and review summary, topic, suggested urgency and uncertainty. Display suggestions only after a valid server response; show safe errors without stale or fabricated suggestions. No replies, customer-record changes or ticket-system integration. Proposed browser behavior: no persistent ticket/result storage, clear text and suggestions when review ends, prevent duplicate submissions and return no-store responses. Company sign-in compatibility and end-of-review behavior require implementation and testing.

**Ticket suggestions**

- Ticket triage app (Google Cloud) — Proposed composed Google Cloud Run application module owning browser/API runtime, organization Identity-Aware Proxy access, dedicated keyless runtime identity, scoped model/policy-reader permissions and regional Vertex AI Gemini transport. Internal module resources are not separate deployment blocks. Requires an organization-owned project, an existing authorized company group, an existing Artifact Registry repository and a built/tested immutable application image. Current company sign-in and group compatibility remain unresolved.

Included scope: ten signed-in staff paste one synthetic or redacted ticket and receive summary, topic, suggested urgency and uncertainty as validated JSON for human review. Excluded: outbound replies, customer-record mutations, ticket-system integration, automated actions, durable ticket history, retrieval and training. Treat ticket instructions as untrusted data. Accept at most 20,000 UTF-8 bytes of text, interpreting 20 KB as decimal; reject oversized text without truncation and bound the complete HTTP request. Proposed output limit remains 512 tokens; truncated or invalid output must fail safely.

Enforce authentication and authorized-group access on the server before inference. Validate signed IAP assertions and audience; do not trust arbitrary forwarded identity headers. Restrict direct runtime access so it cannot bypass IAP. Unknown or denied identities receive no inference or ticket data. Existing identity/group configuration must be reviewed; token expiry/skew limits revocation freshness, and MFA or continuous revocation is not proven.

Proposed API contract: POST /triage with JSON {text: string}; reject malformed JSON, invalid UTF-8, wrong types, empty text and unexpected fields. Successful responses contain exactly four correctly typed fields with urgency restricted to the proposed enumeration. Use safe 400/413 input errors, 401/403 access errors, 429 overload and bounded 502/503/504 generation failures as appropriate. Return no partial or fabricated suggestions, provider internals or ticket content in errors. Bound model attempts to two for transient failures within the request deadline; do not retry invalid input or denied access. Browser must handle non-success responses without presenting prior suggestions as current.

Proposed starting footprint: request-based Cloud Run, 1 vCPU, 512 MiB, minimum zero instances, maximum two instances and per-instance request concurrency five. These are engineering proposals to reconcile with emitted configuration and load-test; cold starts are possible and no latency or availability guarantee is established. Plan for about 200 tickets per working day and bursts of five simultaneous requests. Bound model concurrency and overload behavior; check regional quotas. Do not assume five concurrent requests proves acceptable latency or memory use.

Process text transiently only: no durable ticket/result storage, content logging, tracing, caching or content-bearing errors. No browser persistent storage; propose clearing text and suggestions when review ends. Use no-store response headers. Content-free operational metrics cover request counts, denied access, validation failures, model failures, latency and overload. Review telemetry identifiers and retention separately. Require disabled project caching and model logging/sharing plus documented destination-owner abuse-logging review; application settings alone cannot prove provider non-retention.

Propose Sydney australia-southeast1 for runtime and compatible direct regional Gemini processing; region/model selection remains unaccepted and unverified. Do not silently fall back to global or overseas endpoints. Review inference, identity, build/artifact, telemetry and support paths and disclose any processing outside Australia before deployment. No specific model/version, quota or entitlement is verified.

Cost record: monthly cloud/AI total UNKNOWN. Include Cloud Run CPU/memory/request duration and requests, Gemini input/output tokens, IAP/identity prerequisites where chargeable, image storage/builds, telemetry, network transfer and applicable support. Browser has no newly provisioned cloud resource; existing devices, connectivity and identity licences are outside the incremental hosting subtotal. Ticket-content storage is excluded. Monthly request volume is 200 multiplied by actual working days; days/month, typical token counts, generation duration, selected model/SKUs, rates, currency and tax remain unknown. A maximum byte size is not typical token usage. The supplied pricing.lookup returned no exact regional storage price and supplies no applicable compute/inference rates; it cannot support a subtotal for this workload. One-off build/verification cost is separately UNKNOWN: no effort, rate or quote is supplied.

Engineering handoff tasks: implement the browser and POST /triage contract, authorization, strict request/response validation, bounded Gemini transport, no-content observability and cleanup; reconcile emitted infrastructure with proposed sizing and identities; build and test the immutable image. Acceptance evidence must cover allowed/denied users, forged/expired/wrong-audience assertions, direct-access bypass, malformed/oversized requests, injection attempts, missing/extra/wrong-type output fields, unknown urgency, model timeout/failure, overload and five concurrent requests. Inspect browser storage, logs, traces, caches and errors for retained content. Evaluate suggestion quality on reviewed synthetic tickets separately from schema checks. Handoff must identify artifact/file locations, destination inputs, operator ownership, rollout/rollback and incident procedures. No artifact-bound tests, account-specific plan, deployment or runtime evidence is supplied.

```mermaid
flowchart LR
  n0["Team browser<br/>Tools & data"]
  n1["Ticket triage app<br/>Google Cloud"]
  n0 -->|Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team browser | tools | Web browser | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage app | gcp | Google Cloud Run | australia-southeast1 | Proposed | Composed Google structured application source, browser, IAP identity and regional model transport generated; destination behavior unverified |

### Resources and cost dimensions

- **Team browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage app** (ticket-triage-app): google_cloud_run_v2_service, google_service_account, google_project_iam_custom_role, google_iap_web_cloud_run_service_iam_member. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team browser | Ticket triage app | Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re | Confidential |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open. (must)
- Requirement: Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints. (must)
- Requirement: The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open. | security | not measurable yet | Open |
| Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints. | compliance | not measurable yet | Open |
| Support ten signed-in staff processing approximately 200 tickets per working day and bursts of five simultaneous requests; demonstrate bounded resource use and explicit overload behavior through load tests. Response-time and availability targets remain unspecified. | scalability | Concurrent requests supported >= 5requests | Open |
| Document proposed runtime limits and itemize recurring cloud/AI cost drivers with sources or explicit unknowns; keep one-off build costs separate and do not treat daily ticket volume as monthly usage without a stated working-day assumption. | cost | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- The application shall accept a pasted support ticket and display a short summary, topic and suggested urgency for human review; invalid or failed generation shall produce an explicit error rather than a fabricated suggestion. (must, open)
- Accept pasted synthetic or redacted tickets up to 20,000 UTF-8 bytes, interpreting 20 KB as decimal; reject larger requests explicitly without truncating them. (must, open)
- The system shall provide suggestions from manually pasted tickets for human review only, without sending replies, modifying customer records or invoking external business actions; ticket-system integrations and durable ticket history are outside this version. (must, open)
- Reject malformed or oversized input and unauthorized users before inference; validate successful output against the four-field JSON contract and return safe explicit errors on timeout, provider failure or invalid output, without fabricated suggestions or ticket content in errors. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Maintainability**

- [minor] 3 quality requirements have no measurable target. Add a metric and target to: “Proposed: restrict application use to an authorized company group, reject unauthorized requests on the server, and process tickets without durable content storage or ticket-content logging; residency remains open.”, “Use an Australian region where the selected runtime and model support it. Document processing locations and flag any ticket data or associated information that could leave Australia before deployment; do not silently use overseas or global inference endpoints.”, “Document proposed runtime limits and itemize recurring cloud/AI cost drivers with sources or explicit unknowns; keep one-off build costs separate and do not treat daily ticket volume as monthly usage without a stated working-day assumption.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team browser, Ticket triage app.

**Estimate gaps:**

- Team browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage app: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision ticket suggestions: Ticket triage app.
4. Connect existing systems: Team browser; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

_None._
