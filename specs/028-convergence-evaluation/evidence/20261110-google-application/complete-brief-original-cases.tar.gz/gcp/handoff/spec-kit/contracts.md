# Component and interface contracts

Snapshot 33d5abe4-99d8-41dc-a608-ca98a7a83370 · design r4 · generated 2026-11-09T19:42:58.427Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-browser: Team browser

- Responsibility: Existing browser used by ten staff, outside provisioning scope. Staff sign in, paste synthetic or redacted support-ticket text and review summary, topic, suggested urgency and uncertainty. Display suggestions only after a valid server response; show safe errors without stale or fabricated suggestions. No replies, customer-record changes or ticket-system integration. Proposed browser behavior: no persistent ticket/result storage, clear text and suggestions when review ends, prevent duplicate submissions and return no-store responses. Company sign-in compatibility and end-of-review behavior require implementation and testing.
- Service: Web browser
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component ticket-triage-app: Ticket triage app

- Responsibility: Proposed composed Google Cloud Run application module owning browser/API runtime, organization Identity-Aware Proxy access, dedicated keyless runtime identity, scoped model/policy-reader permissions and regional Vertex AI Gemini transport. Internal module resources are not separate deployment blocks. Requires an organization-owned project, an existing authorized company group, an existing Artifact Registry repository and a built/tested immutable application image. Current company sign-in and group compatibility remain unresolved.

Included scope: ten signed-in staff paste one synthetic or redacted ticket and receive summary, topic, suggested urgency and uncertainty as validated JSON for human review. Excluded: outbound replies, customer-record mutations, ticket-system integration, automated actions, durable ticket history, retrieval and training. Treat ticket instructions as untrusted data. Accept at most 20,000 UTF-8 bytes of text, interpreting 20 KB as decimal; reject oversized text without truncation and bound the complete HTTP request. Proposed output limit remains 512 tokens; truncated or invalid output must fail safely.

Enforce authentication and authorized-group access on the server before inference. Validate signed IAP assertions and audience; do not trust arbitrary forwarded identity headers. Restrict direct runtime access so it cannot bypass IAP. Unknown or denied identities receive no inference or ticket data. Existing identity/group configuration must be reviewed; token expiry/skew limits revocation freshness, and MFA or continuous revocation is not proven.

Proposed API contract: POST /triage with JSON {text: string}; reject malformed JSON, invalid UTF-8, wrong types, empty text and unexpected fields. Successful responses contain exactly four correctly typed fields with urgency restricted to the proposed enumeration. Use safe 400/413 input errors, 401/403 access errors, 429 overload and bounded 502/503/504 generation failures as appropriate. Return no partial or fabricated suggestions, provider internals or ticket content in errors. Bound model attempts to two for transient failures within the request deadline; do not retry invalid input or denied access. Browser must handle non-success responses without presenting prior suggestions as current.

Proposed starting footprint: request-based Cloud Run, 1 vCPU, 512 MiB, minimum zero instances, maximum two instances and per-instance request concurrency five. These are engineering proposals to reconcile with emitted configuration and load-test; cold starts are possible and no latency or availability guarantee is established. Plan for about 200 tickets per working day and bursts of five simultaneous requests. Bound model concurrency and overload behavior; check regional quotas. Do not assume five concurrent requests proves acceptable latency or memory use.

Process text transiently only: no durable ticket/result storage, content logging, tracing, caching or content-bearing errors. No browser persistent storage; propose clearing text and suggestions when review ends. Use no-store response headers. Content-free operational metrics cover request counts, denied access, validation failures, model failures, latency and overload. Review telemetry identifiers and retention separately. Require disabled project caching and model logging/sharing plus documented destination-owner abuse-logging review; application settings alone cannot prove provider non-retention.

Propose Sydney australia-southeast1 for runtime and compatible direct regional Gemini processing; region/model selection remains unaccepted and unverified. Do not silently fall back to global or overseas endpoints. Review inference, identity, build/artifact, telemetry and support paths and disclose any processing outside Australia before deployment. No specific model/version, quota or entitlement is verified.

Cost record: monthly cloud/AI total UNKNOWN. Include Cloud Run CPU/memory/request duration and requests, Gemini input/output tokens, IAP/identity prerequisites where chargeable, image storage/builds, telemetry, network transfer and applicable support. Browser has no newly provisioned cloud resource; existing devices, connectivity and identity licences are outside the incremental hosting subtotal. Ticket-content storage is excluded. Monthly request volume is 200 multiplied by actual working days; days/month, typical token counts, generation duration, selected model/SKUs, rates, currency and tax remain unknown. A maximum byte size is not typical token usage. The supplied pricing.lookup returned no exact regional storage price and supplies no applicable compute/inference rates; it cannot support a subtotal for this workload. One-off build/verification cost is separately UNKNOWN: no effort, rate or quote is supplied.

Engineering handoff tasks: implement the browser and POST /triage contract, authorization, strict request/response validation, bounded Gemini transport, no-content observability and cleanup; reconcile emitted infrastructure with proposed sizing and identities; build and test the immutable image. Acceptance evidence must cover allowed/denied users, forged/expired/wrong-audience assertions, direct-access bypass, malformed/oversized requests, injection attempts, missing/extra/wrong-type output fields, unknown urgency, model timeout/failure, overload and five concurrent requests. Inspect browser storage, logs, traces, caches and errors for retained content. Evaluate suggestion quality on reviewed synthetic tickets separately from schema checks. Handoff must identify artifact/file locations, destination inputs, operator ownership, rollout/rollback and incident procedures. No artifact-bound tests, account-specific plan, deployment or runtime evidence is supplied.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7469636b65742d7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-triage-https: team-browser → ticket-triage-app

- Drawn payload/purpose: Authorized HTTPS: bounded ticket JSON in; validated suggestions or safe error re
- Contract task: TASK-CONTRACT-62726f777365722d7472696167652d6874747073
- Integration task: TASK-INTEGRATION-62726f777365722d7472696167652d6874747073
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
