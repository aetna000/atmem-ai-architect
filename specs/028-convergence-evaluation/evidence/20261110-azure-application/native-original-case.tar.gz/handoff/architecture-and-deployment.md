Snapshot c26c30a0-f32d-4c2c-9fa4-dcdf3914c70d · design r3 · generated 2026-11-09T19:05:56.565Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 19:05 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** unknown
- **Estimated run cost:** not estimated
- **Review:** 5 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Cloud preference:** Azure
- **Budget and timeline:** —

## 3. Architecture

**Team access**

- Team member’s browser (Tools & data, existing) — Existing browser outside provisioning scope. A team member signs in, pastes a support ticket and reviews the returned summary, topic and suggested urgency. Any subsequent action happens outside this tool.

**Human-reviewed ticket suggestions**

- Ticket triage application (Azure) — Proposed azure-structured-app deployment module hosted on Azure App Service: browser UI and Python API, App Service plan, single-tenant Entra application registrations, workload identity and regional Azure OpenAI account/deployment are owned within this module. Propose Australia East (australiaeast) for application hosting and regional inference, subject to confirming service/model/version availability and quota; specific-region approval remains open. No global model deployment or overseas inference fallback is proposed. Flag and review any potential processing outside Australia, including identity metadata, diagnostics, model safety processing and support access; their locations and contractual boundaries remain unverified. Authorizes team access through an existing company Entra group, subject to confirming tenant/group availability and licensing. Accepts pasted text and returns schema-checked suggestions for human review; no ticketing credentials, outbound replies or customer-record writes. Proposed: no durable ticket storage and no ticket bodies in operational logs. Treat ticket text as untrusted input; show a safe error rather than fabricated output on model failure. Proposes a single-region first version without cross-region failover; availability needs review. Requires approved ContentLogging=false before inference, existing compatible ACR and a built immutable image digest. Immediate identity revocation and company MFA policy need separate review. No destination configuration, model quality, residency compliance or deployment has been verified.

```mermaid
flowchart LR
  n0["Team member’s browser<br/>Tools & data"]
  n1["Ticket triage application<br/>Azure"]
  n0 -->|Signed-in HTTPS: paste ticket; return suggestions for review| n1
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team member’s browser | tools | Web browser | User location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage application | azure | Azure App Service | australiaeast | Proposed | Composed Azure structured application source, browser, Entra authorization and regional model deployment generated; destination behavior unverified |

### Resources and cost dimensions

- **Team member’s browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage application** (ticket-triage-app): azurerm_linux_web_app, azurerm_service_plan, azurerm_cognitive_account, azurerm_cognitive_deployment, azuread_application_registration. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team member’s browser | Ticket triage application | Signed-in HTTPS: paste ticket; return suggestions for review | Confidential |

## 5. Security controls

- **Team member’s browser** — Existing browser outside provisioning scope. A team member signs in, pastes a support ticket and reviews the returned summary, topic and suggested urgency. Any subsequent action happens outside this tool.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing. (must)
- Requirement: Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing. | security | not measurable yet | Open |
| Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover. | compliance | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing.”, “Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team member’s browser, Ticket triage application.

**Estimate gaps:**

- Team member’s browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage application: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision human-reviewed ticket suggestions: Ticket triage application.
4. Connect existing systems: Team member’s browser; test failure behaviour.
5. Run the acceptance checks (success measures and requirements) in staging; record results.
6. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
