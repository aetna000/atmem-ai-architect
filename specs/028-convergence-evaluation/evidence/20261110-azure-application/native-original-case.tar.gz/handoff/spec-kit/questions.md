# Questions and assumptions to resolve

Snapshot c26c30a0-f32d-4c2c-9fa4-dcdf3914c70d · design r3 · generated 2026-11-09T19:05:56.565Z

- [ai-ticket-suggestions] Confirm REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.
- [ai-ticket-access-privacy] Confirm REQ-003: Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing.
- [ai-ticket-australian-placement] Confirm REQ-004: Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover.
- [acceptance-req-c67c46a5] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-suggestions] Agree a measurable acceptance check for REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.
- [acceptance-ai-ticket-access-privacy] Agree a measurable acceptance check for REQ-003: Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing.
- [acceptance-ai-ticket-australian-placement] Agree a measurable acceptance check for REQ-004: Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d7469636b65742d6163636573732d70726976616379] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d6175737472616c69616e2d706c6163656d656e74] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d73756767657374696f6e73] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
