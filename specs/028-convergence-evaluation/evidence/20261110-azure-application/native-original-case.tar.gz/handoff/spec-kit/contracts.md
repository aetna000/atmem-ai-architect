# Component and interface contracts

Snapshot c26c30a0-f32d-4c2c-9fa4-dcdf3914c70d · design r3 · generated 2026-11-09T19:05:56.565Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-browser: Team member’s browser

- Responsibility: Existing browser outside provisioning scope. A team member signs in, pastes a support ticket and reviews the returned summary, topic and suggested urgency. Any subsequent action happens outside this tool.
- Service: Web browser
- Provider / placement: tools / User location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component ticket-triage-app: Ticket triage application

- Responsibility: Proposed azure-structured-app deployment module hosted on Azure App Service: browser UI and Python API, App Service plan, single-tenant Entra application registrations, workload identity and regional Azure OpenAI account/deployment are owned within this module. Propose Australia East (australiaeast) for application hosting and regional inference, subject to confirming service/model/version availability and quota; specific-region approval remains open. No global model deployment or overseas inference fallback is proposed. Flag and review any potential processing outside Australia, including identity metadata, diagnostics, model safety processing and support access; their locations and contractual boundaries remain unverified. Authorizes team access through an existing company Entra group, subject to confirming tenant/group availability and licensing. Accepts pasted text and returns schema-checked suggestions for human review; no ticketing credentials, outbound replies or customer-record writes. Proposed: no durable ticket storage and no ticket bodies in operational logs. Treat ticket text as untrusted input; show a safe error rather than fabricated output on model failure. Proposes a single-region first version without cross-region failover; availability needs review. Requires approved ContentLogging=false before inference, existing compatible ACR and a built immutable image digest. Immediate identity revocation and company MFA policy need separate review. No destination configuration, model quality, residency compliance or deployment has been verified.
- Service: Azure App Service
- Provider / placement: azure / australiaeast
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7469636b65742d7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-to-triage: team-browser → ticket-triage-app

- Drawn payload/purpose: Signed-in HTTPS: paste ticket; return suggestions for review
- Contract task: TASK-CONTRACT-62726f777365722d746f2d747269616765
- Integration task: TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
