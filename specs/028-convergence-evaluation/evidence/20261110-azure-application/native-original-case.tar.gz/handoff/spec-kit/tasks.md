# Detailed implementation tasks

Snapshot c26c30a0-f32d-4c2c-9fa4-dcdf3914c70d · design r3 · generated 2026-11-09T19:05:56.565Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use the emitted Python 3.13 applications/* source and BUILD.md. In each application directory, create an isolated Python 3.13 environment, install the hash-locked test-requirements.lock with binary wheels and run azure_acceptance.py. Build the pinned Linux/amd64 Docker image, scan and test it, then obtain authorization before publishing to the reviewed existing ACR. Supply that exact digest to Terraform. Runtime, port 8080, Entra scope/roles and model transport are already implemented; do not ask the user to invent them. Local scripted tests do not establish Azure sign-in, group revocation, policy approval, model quality or deployment.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-62726f777365722d746f2d747269616765 — Define Team member’s browser → Ticket triage application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection browser-to-triage: Signed-in HTTPS: paste ticket; return suggestions for review. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge browser-to-triage
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-7465616d2d62726f77736572 — Integrate existing Team member’s browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d746f2d747269616765
- Components: team-browser
- Generated files: No implementation files generated yet
- Requirements: ai-ticket-suggestions

### Implementation steps

1. Responsibility from the board: Existing browser outside provisioning scope. A team member signs in, pastes a support ticket and reviews the returned summary, topic and suggested urgency. Any subsequent action happens outside this tool.
2. Verify Web browser on tools in User location; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component team-browser
- Application/configuration and tests for Team member’s browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7469636b65742d7472696167652d617070 — Validate generated Ticket triage application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl
- Requirements: ai-ticket-suggestions, ai-ticket-access-privacy, ai-ticket-australian-placement

### Implementation steps

1. Responsibility from the board: Proposed azure-structured-app deployment module hosted on Azure App Service: browser UI and Python API, App Service plan, single-tenant Entra application registrations, workload identity and regional Azure OpenAI account/deployment are owned within this module. Propose Australia East (australiaeast) for application hosting and regional inference, subject to confirming service/model/version availability and quota; specific-region approval remains open. No global model deployment or overseas inference fallback is proposed. Flag and review any potential processing outside Australia, including identity metadata, diagnostics, model safety processing and support access; their locations and contractual boundaries remain unverified. Authorizes team access through an existing company Entra group, subject to confirming tenant/group availability and licensing. Accepts pasted text and returns schema-checked suggestions for human review; no ticketing credentials, outbound replies or customer-record writes. Proposed: no durable ticket storage and no ticket bodies in operational logs. Treat ticket text as untrusted input; show a safe error rather than fabricated output on model failure. Proposes a single-region first version without cross-region failover; availability needs review. Requires approved ContentLogging=false before inference, existing compatible ACR and a built immutable image digest. Immediate identity revocation and company MFA policy need separate review. No destination configuration, model quality, residency compliance or deployment has been verified.
2. Verify Azure App Service on azure in australiaeast; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.; REQ-003: Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing.; REQ-004: Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component ticket-triage-app
- Application/configuration and tests for Ticket triage application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-62726f777365722d746f2d747269616765 — Wire Team member’s browser to Ticket triage application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f777365722d746f2d747269616765, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge browser-to-triage in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation browser-to-triage
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765 — Verify live Team member’s browser → Ticket triage application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge browser-to-triage with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence browser-to-triage

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d6336376334366135 — Verify REQ-001: A person approves sensitive actions before they happen

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-c67c46a5

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d73756767657374696f6e73 — Verify REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: team-browser, ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl
- Requirements: ai-ticket-suggestions

### Implementation steps

1. Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”; rationale: Defines the complete first-version outcome while keeping uncertain AI suggestions subject to human judgment.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d6163636573732d70726976616379 — Verify REQ-003: Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl
- Requirements: ai-ticket-access-privacy

### Implementation steps

1. Basis: The user requests a “small internal tool”; ticket-triage-app proposes team authorization and transient processing.; rationale: Proposed access and retention boundaries reduce exposure of potentially sensitive support-ticket content.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69616e2d706c6163656d656e74 — Verify REQ-004: Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: ticket-triage-app
- Generated files: terraform/applications/block_7469636b65742d7472696167652d617070/azure_structured.py, terraform/applications/block_7469636b65742d7472696167652d617070/azure_acceptance.py, terraform/applications/block_7469636b65742d7472696167652d617070/structured_output.py, terraform/applications/block_7469636b65742d7472696167652d617070/web/index.html, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.css, terraform/applications/block_7469636b65742d7472696167652d617070/web/app.js, terraform/applications/block_7469636b65742d7472696167652d617070/requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-requirements.lock, terraform/applications/block_7469636b65742d7472696167652d617070/test-dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/dependency-sources.json, terraform/applications/block_7469636b65742d7472696167652d617070/container-base.json, terraform/applications/block_7469636b65742d7472696167652d617070/Dockerfile, terraform/applications/block_7469636b65742d7472696167652d617070/.dockerignore, terraform/applications/block_7469636b65742d7472696167652d617070/BUILD.md, terraform/main.tf.json, terraform/deployment.tfvars.json.example, terraform/tests/azure-structured.tftest.hcl
- Requirements: ai-ticket-australian-placement

### Implementation steps

1. Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”; rationale: Regional hosting alone does not establish that inference, identity, diagnostics or support processing stays within Australia; identifying exceptions prevents an unsupported residency claim.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-62726f777365722d746f2d747269616765
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-7465616d2d62726f77736572, TASK-RESOURCE-7469636b65742d7472696167652d617070, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d6336376334366135, TASK-ACCEPTANCE-61692d7469636b65742d73756767657374696f6e73, TASK-ACCEPTANCE-61692d7469636b65742d6163636573732d70726976616379, TASK-ACCEPTANCE-61692d7469636b65742d6175737472616c69616e2d706c6163656d656e74, TASK-INTEGRATION-LIVE-62726f777365722d746f2d747269616765
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
