Snapshot c26c30a0-f32d-4c2c-9fa4-dcdf3914c70d · design r3 · generated 2026-11-09T19:05:56.565Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result. (must, open); target: acceptance target needed; linked blocks: team-browser, ticket-triage-app

Design explanation: Defines the complete first-version outcome while keeping uncertain AI suggestions subject to human judgment.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Proposed access and retention boundaries reduce exposure of potentially sensitive support-ticket content.

Basis: The user requests a “small internal tool”; ticket-triage-app proposes team authorization and transient processing.
- [REQ-004] Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover. (must, open); target: acceptance target needed; linked blocks: ticket-triage-app

Design explanation: Regional hosting alone does not establish that inference, identity, diagnostics or support processing stays within Australia; identifying exceptions prevents an unsupported residency claim.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”

## How the system works

The current design contains 2 components and 1 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team member’s browser → Ticket triage application

Signed-in HTTPS: paste ticket; return suggestions for review

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team member’s browser

Web browser · tools · region: User location · classification: Confidential

Existing browser outside provisioning scope. A team member signs in, pastes a support ticket and reviews the returned summary, topic and suggested urgency. Any subsequent action happens outside this tool.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team member’s browser → Ticket triage application: Signed-in HTTPS: paste ticket; return suggestions for review (integration: browser-https)

Requirement traceability: REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket triage application

Azure App Service · azure · region: australiaeast · classification: Confidential

Proposed azure-structured-app deployment module hosted on Azure App Service: browser UI and Python API, App Service plan, single-tenant Entra application registrations, workload identity and regional Azure OpenAI account/deployment are owned within this module. Propose Australia East (australiaeast) for application hosting and regional inference, subject to confirming service/model/version availability and quota; specific-region approval remains open. No global model deployment or overseas inference fallback is proposed. Flag and review any potential processing outside Australia, including identity metadata, diagnostics, model safety processing and support access; their locations and contractual boundaries remain unverified. Authorizes team access through an existing company Entra group, subject to confirming tenant/group availability and licensing. Accepts pasted text and returns schema-checked suggestions for human review; no ticketing credentials, outbound replies or customer-record writes. Proposed: no durable ticket storage and no ticket bodies in operational logs. Treat ticket text as untrusted input; show a safe error rather than fabricated output on model failure. Proposes a single-region first version without cross-region failover; availability needs review. Requires approved ContentLogging=false before inference, existing compatible ACR and a built immutable image digest. Immediate identity revocation and company MFA policy need separate review. No destination configuration, model quality, residency compliance or deployment has been verified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team member’s browser → Ticket triage application: Signed-in HTTPS: paste ticket; return suggestions for review (integration: browser-https)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: Accept pasted support-ticket text and return a short summary, topic and suggested urgency clearly presented as suggestions for human review; handle invalid output or inference failure without presenting a fabricated result.; REQ-003: Proposed: restrict use to the authorized internal team, process tickets without durable application storage, and exclude ticket bodies from operational logs; confirm country restrictions before selecting regional processing.; REQ-004: Use an Australian Azure region for application hosting and ticket inference where the selected services support it. Identify and flag any data processing, storage or access that could occur outside Australia before deployment; do not silently enable overseas inference or failover.

Implementation status: Composed Azure structured application source, browser, Entra authorization and regional model deployment generated; destination behavior unverified

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team member’s browser<br/>Tools & data"]
  n1["Ticket triage application<br/>Azure"]
  n0 -->|Signed-in HTTPS: paste ticket; return suggestions for review| n1
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team member’s browser | tools | Web browser | User location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| ticket-triage-app | Ticket triage application | azure | Azure App Service | australiaeast | Proposed | Composed Azure structured application source, browser, Entra authorization and regional model deployment generated; destination behavior unverified |

### Resources and cost dimensions

- **Team member’s browser** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage application** (ticket-triage-app): azurerm_linux_web_app, azurerm_service_plan, azurerm_cognitive_account, azurerm_cognitive_deployment, azuread_application_registration. Confirm service, capacity and billable dimensions. Depends on: team-browser.

### Engineering work remaining

S3 foundation only. Validate the plan, account, region, cost and security before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
