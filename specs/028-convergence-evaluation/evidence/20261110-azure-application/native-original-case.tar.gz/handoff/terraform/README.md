# Azure structured AI application

Each explicitly selected azure-structured-app block is a composed application module: Linux App Service, browser, API, user-assigned runtime identity, regional Azure OpenAI account/deployment, two Entra app registrations, an API scope/role, and an assignment of an existing company group. It does not create users/groups, import existing applications or implement arbitrary other blocks. See resource-schedule.json for unresolved scope. Public TLS endpoints use identity enforcement; private networking is not implemented by this module.

The emitted Python 3.13 application verifies signed RS256 Entra v2 access tokens for the exact tenant, API audience, browser client, delegated scope and assigned WorkspaceUser role. ID tokens, app-only tokens and forwarded identity headers grant no API access. Keys are fetched from the fixed tenant endpoint with bounded retrieval and rotation caching. Bearer tokens authorize until expiry: group removal, disabling a user and logout do not immediately revoke an already issued token. Tenant Conditional Access/MFA and any continuous-revocation requirement require destination policy/engineering and real tests. Entra P1/P2 is needed for group assignments. Provisioning Entra registrations/role assignments needs separately reviewed administrator/Graph permissions; the runtime receives none of those permissions.

Runtime identity receives model inference access and account-scoped Reader for policy checks, plus AcrPull on the exact existing registry. These are not subscription-wide Owner grants. Registry mode must support AcrPull; an ABAC-enabled registry needs a different reviewed assignment. No static credential, model key or client secret is emitted. Protect Terraform state: providers may retain sensitive service attributes even when no output exposes a key.

Input/results are not persisted by the app. Before inference, a read-only ARM check requires the exact model account and ContentLogging=false capability. This capability requires approved modified abuse monitoring; the app cannot self-approve it. Missing approval, policy outage or unknown state blocks inference with a clear setup error, without sending the user input to the model. It never modifies account-wide policy. Review provider processing, monitoring, residency and account terms separately; Standard regional model deployment alone does not prove whole-system residency. Model/account availability, compatible model/version, quotas, prices and this policy approval need authorized destination checks. No availability or privacy approval is invented.

Build/test the emitted applications first using each applications/*/BUILD.md. Build and push to an existing reviewed ACR, retain exact source/image digests, then supply deployment inputs. No Terraform provisioners or bootstrap cloud actions run automatically. Register Microsoft.Web, Microsoft.CognitiveServices and Microsoft.ManagedIdentity separately under authorized subscription control; automatic registration is disabled. Both providers are pinned to the expected tenant/subscription and use the operator credential chain.

Use terraform init -backend=false, terraform validate and terraform test for provider schemas and mock configuration checks. Review actual destination inputs and an authorized plan separately. Production is blocked until state, backup and operations are reviewed. App Service B1 and a single process are an initial bounded deployment, not a high-availability SLA. Per-process concurrency/output limits and model quota bound traffic; they are not an invoice cap. No request bodies, tokens or model text are logged by the application; review platform-level logging separately.

The model returns flat schema-checked fields with a human-review marker. No tool/action is executed. Output validation does not prove factual or classification accuracy. Run representative model-quality tests, real sign-in/role/expiry tests, image startup/scan, policy checks and an authorized account plan before deployment. This export itself proves no deployment.

References:
- https://learn.microsoft.com/en-us/entra/identity-platform/claims-validation
- https://learn.microsoft.com/en-us/entra/identity-platform/howto-add-app-roles-in-apps
- https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/abuse-monitoring
- https://learn.microsoft.com/en-us/rest/api/aifoundry/azureopenai/chat
- https://registry.terraform.io/providers/hashicorp/azurerm/4.81.0/docs/resources/linux_web_app
- https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs
