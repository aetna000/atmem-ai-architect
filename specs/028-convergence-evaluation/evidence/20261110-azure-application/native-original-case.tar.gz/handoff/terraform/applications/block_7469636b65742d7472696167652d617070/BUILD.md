# Generated Azure application

This source implements the browser, delegated Entra API authorization and bounded model operation. It is not a supplied-image placeholder. Run the emitted local acceptance tests in Python 3.13 after installing requirements.lock and the separate documented test dependencies. Tests use cryptographic keys and scripted network boundaries; they do not access Azure.

Build on a clean Docker host: docker build --platform linux/amd64 --pull -t REVIEWED_REGISTRY.azurecr.io/REVIEWED_REPOSITORY:REVIEWED_BUILD .

Inspect and scan the image, run container startup and acceptance checks, then, with authorization, authenticate to the existing ACR and push it. Record the registry digest and supply it as block_7469636b65742d7472696167652d617070_image_digest. The Terraform configuration uses managed-identity pull and never builds/pushes images or executes a provisioner. Building and publishing an image is separate from running Terraform. The base image and all Python wheels are hash pinned; record exact source/image hashes. Update deliberately and rerun tests/scans.

Local test dependency: httpx (for FastAPI TestClient) is a development tool, not packaged into the image. Test fixture config lives in azure_acceptance.py; never use fixture values as deployment credentials or production configuration.
