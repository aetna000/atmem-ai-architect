# Start here — Metered multi-tenant AI workspace

Snapshot d5a97916-b39c-4d59-9f5a-93913292b8cf · design r1 · generated 2026-11-09T18:11:47.274Z

Give this ZIP to a coding agent with this instruction:

> Read AGENTS.md and spec-kit/plan.md. Review the specification, design and implementation tasks. Explain the first actionable task and ask about the highest-impact missing decision. Then implement approved scope, maintaining task progress and test evidence. Do not treat this handoff as permission to deploy.

## Reading order

1. AGENTS.md
2. specification.md or specification.pdf
3. diagram.svg or diagram.pdf, then resource-schedule.json
4. spec-kit/readiness.md, plan.md, contracts.md and questions.md
5. spec-kit/tasks.md or tasks.json
6. terraform/ and estimate.json

project.atmem-ai-architect.json is the editable source snapshot. PDFs/images are review formats. The receiving agent needs the destination repository, runtime decisions and appropriate access; unknowns are listed rather than invented.
