# Questions and assumptions to resolve

Snapshot f96b7e50-67a0-45cd-bc1b-6fc66d13decc · design r3 · generated 2026-11-09T17:11:37.834Z

- [ai-ticket-triage] Confirm REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.
- [ai-staff-access] Confirm REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.
- [ai-ticket-data-boundary] Confirm REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.
- [acceptance-req-33fb06f9] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-triage] Agree a measurable acceptance check for REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.
- [acceptance-ai-staff-access] Agree a measurable acceptance check for REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.
- [acceptance-ai-ticket-data-boundary] Agree a measurable acceptance check for REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d73746166662d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d646174612d626f756e64617279] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d747269616765] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
