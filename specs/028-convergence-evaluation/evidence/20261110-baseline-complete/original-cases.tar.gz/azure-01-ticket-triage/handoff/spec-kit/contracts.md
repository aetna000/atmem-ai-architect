# Component and interface contracts

Snapshot f96b7e50-67a0-45cd-bc1b-6fc66d13decc · design r3 · generated 2026-11-09T17:11:37.834Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-reviewer: Team member

- Responsibility: Existing person in Australia using a browser outside provisioning scope. Pastes a ticket, reads the proposed summary, topic and urgency, and makes the final judgment. The tool cannot send replies or change customer records.
- Service: Web browser
- Provider / placement: tools / Australia — existing users
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d7265766965776572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component triage-app: Ticket triage web app

- Responsibility: Proposed Azure App Service deployment serving both the browser interface and server API; owns its hosting plan configuration. Propose Australia East, subject to availability verification; regional placement is not yet accepted. Server verifies staff identity and authorization, bounds ticket input, and treats ticket content as untrusted data. Calls the model through managed identity and validates structured output containing summary, topic, suggested urgency and a short reason. Displays suggestions for human review; invalid output or model failure produces a clear retry message rather than an invented result. No reply-sending tools, customer-system credentials or write integrations. Proposed session-only handling with no application persistence or ticket content in logs. Browser caching, server diagnostics and outbound dependencies require review for accidental retention or overseas transfers. Propose no overseas fallback; a regional outage temporarily prevents analysis, while staff retain their existing manual process. Team owns code, deployment and operations; named operating owner remains unresolved. Custom application and infrastructure implementation required.
- Service: Azure App Service
- Provider / placement: azure / australiaeast
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component staff-sign-in: Staff sign-in

- Responsibility: Proposed Microsoft Entra ID application registration and staff access assignment. Tenant ownership and existing sign-in arrangement are not yet known; this does not assume an existing Entra deployment. Entra identity processing cannot be assumed to remain within the app's Azure region: tenant data location, authentication processing and related logs require separate review, with any overseas handling explicitly flagged. Do not send ticket text or suggestions through identity claims or sign-in URLs. App Service authentication and server authorization must restrict use to assigned staff. Registration, token validation and denied-access tests require implementation.
- Service: Microsoft Entra ID
- Provider / placement: azure / Tenant/global service — residency review required
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d7369676e2d696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-model: Ticket analysis model

- Responsibility: Proposed Azure OpenAI resource with a model deployment for structured ticket analysis. Receives ticket text and returns a short summary, topic, suggested urgency and reason; no tools or customer-system access. Propose Australia East and a regional deployment type that keeps inference in Australia; model support, deployment-type availability, quotas and capacity are unverified. Do not silently substitute Global or Data Zone deployment types or an overseas endpoint. Review prompt/output retention, abuse monitoring, support access and processing locations separately from the resource location; flag any overseas handling before use. Propose bounded output, request deadlines and limited retries, with no overseas inference fallback. Availability and model quality are unverified; acceptance requires representative tickets, including ambiguous and malicious content. Custom provisioning and API integration required.
- Service: Azure OpenAI
- Provider / placement: azure / australiaeast
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-monitoring: Operational monitoring

- Responsibility: Proposed Azure Monitor Application Insights instance for request counts, duration, failures and model usage. Propose Australia East, subject to availability and telemetry-processing review. Excludes ticket bodies, prompts, suggestions and authentication tokens; telemetry filtering must be implemented and tested, including automatic exception and dependency capture. Retention, access permissions, any workspace dependency and alert ownership require implementation review. Any required workspace must also have explicitly reviewed Australian placement; overseas exports or processing must be flagged before activation. This is not a stored ticket history. Monitoring infrastructure and integrations remain engineering work.
- Service: Azure Monitor Application Insights
- Provider / placement: azure / australiaeast
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d6d6f6e69746f72696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### reviewer-to-app: team-reviewer → triage-app

- Drawn payload/purpose: HTTPS: paste ticket; receive suggestions for review
- Contract task: TASK-CONTRACT-72657669657765722d746f2d617070
- Integration task: TASK-INTEGRATION-72657669657765722d746f2d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-to-sign-in: triage-app → staff-sign-in

- Drawn payload/purpose: OpenID Connect sign-in; validate staff access; identity residency review require
- Contract task: TASK-CONTRACT-6170702d746f2d7369676e2d696e
- Integration task: TASK-INTEGRATION-6170702d746f2d7369676e2d696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-to-model: triage-app → triage-model

- Drawn payload/purpose: HTTPS with managed identity: ticket → suggestion; Australian regional inference 
- Contract task: TASK-CONTRACT-6170702d746f2d6d6f64656c
- Integration task: TASK-INTEGRATION-6170702d746f2d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-to-monitoring: triage-app → triage-monitoring

- Drawn payload/purpose: Telemetry: timing, usage and errors; exclude ticket text; Australian destination
- Contract task: TASK-CONTRACT-6170702d746f2d6d6f6e69746f72696e67
- Integration task: TASK-INTEGRATION-6170702d746f2d6d6f6e69746f72696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
