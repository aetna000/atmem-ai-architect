# Detailed implementation tasks

Snapshot f96b7e50-67a0-45cd-bc1b-6fc66d13decc · design r3 · generated 2026-11-09T17:11:37.834Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-72657669657765722d746f2d617070 — Define Team member → Ticket triage web app

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: team-reviewer, triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection reviewer-to-app: HTTPS: paste ticket; receive suggestions for review. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge reviewer-to-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d746f2d7369676e2d696e — Define Ticket triage web app → Staff sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: triage-app, staff-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-to-sign-in: OpenID Connect sign-in; validate staff access; identity residency review require. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-to-sign-in
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d746f2d6d6f64656c — Define Ticket triage web app → Ticket analysis model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-to-model: HTTPS with managed identity: ticket → suggestion; Australian regional inference . Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-to-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d746f2d6d6f6e69746f72696e67 — Define Ticket triage web app → Operational monitoring

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: triage-app, triage-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-to-monitoring: Telemetry: timing, usage and errors; exclude ticket text; Australian destination. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-to-monitoring
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-7465616d2d7265766965776572 — Integrate existing Team member

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72657669657765722d746f2d617070
- Components: team-reviewer
- Generated files: No implementation files generated yet
- Requirements: ai-ticket-triage

### Implementation steps

1. Responsibility from the board: Existing person in Australia using a browser outside provisioning scope. Pastes a ticket, reads the proposed summary, topic and urgency, and makes the final judgment. The tool cannot send replies or change customer records.
2. Verify Web browser on tools in Australia — existing users; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component team-reviewer
- Application/configuration and tests for Team member

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7472696167652d617070 — Implement Ticket triage web app

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72657669657765722d746f2d617070, TASK-CONTRACT-6170702d746f2d7369676e2d696e, TASK-CONTRACT-6170702d746f2d6d6f64656c, TASK-CONTRACT-6170702d746f2d6d6f6e69746f72696e67
- Components: triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-triage, ai-staff-access, ai-ticket-data-boundary

### Implementation steps

1. Responsibility from the board: Proposed Azure App Service deployment serving both the browser interface and server API; owns its hosting plan configuration. Propose Australia East, subject to availability verification; regional placement is not yet accepted. Server verifies staff identity and authorization, bounds ticket input, and treats ticket content as untrusted data. Calls the model through managed identity and validates structured output containing summary, topic, suggested urgency and a short reason. Displays suggestions for human review; invalid output or model failure produces a clear retry message rather than an invented result. No reply-sending tools, customer-system credentials or write integrations. Proposed session-only handling with no application persistence or ticket content in logs. Browser caching, server diagnostics and outbound dependencies require review for accidental retention or overseas transfers. Propose no overseas fallback; a regional outage temporarily prevents analysis, while staff retain their existing manual process. Team owns code, deployment and operations; named operating owner remains unresolved. Custom application and infrastructure implementation required.
2. Verify Azure App Service on azure in australiaeast; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure App Service; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.; REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.; REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component triage-app
- Application/configuration and tests for Ticket triage web app

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73746166662d7369676e2d696e — Implement Staff sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d746f2d7369676e2d696e
- Components: staff-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-staff-access

### Implementation steps

1. Responsibility from the board: Proposed Microsoft Entra ID application registration and staff access assignment. Tenant ownership and existing sign-in arrangement are not yet known; this does not assume an existing Entra deployment. Entra identity processing cannot be assumed to remain within the app's Azure region: tenant data location, authentication processing and related logs require separate review, with any overseas handling explicitly flagged. Do not send ticket text or suggestions through identity claims or sign-in URLs. App Service authentication and server authorization must restrict use to assigned staff. Registration, token validation and denied-access tests require implementation.
2. Verify Microsoft Entra ID on azure in Tenant/global service — residency review required; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Microsoft Entra ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-sign-in
- Application/configuration and tests for Staff sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7472696167652d6d6f64656c — Implement Ticket analysis model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d746f2d6d6f64656c
- Components: triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-triage, ai-ticket-data-boundary

### Implementation steps

1. Responsibility from the board: Proposed Azure OpenAI resource with a model deployment for structured ticket analysis. Receives ticket text and returns a short summary, topic, suggested urgency and reason; no tools or customer-system access. Propose Australia East and a regional deployment type that keeps inference in Australia; model support, deployment-type availability, quotas and capacity are unverified. Do not silently substitute Global or Data Zone deployment types or an overseas endpoint. Review prompt/output retention, abuse monitoring, support access and processing locations separately from the resource location; flag any overseas handling before use. Propose bounded output, request deadlines and limited retries, with no overseas inference fallback. Availability and model quality are unverified; acceptance requires representative tickets, including ambiguous and malicious content. Custom provisioning and API integration required.
2. Verify Azure OpenAI on azure in australiaeast; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure OpenAI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.; REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component triage-model
- Application/configuration and tests for Ticket analysis model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7472696167652d6d6f6e69746f72696e67 — Implement Operational monitoring

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d746f2d6d6f6e69746f72696e67
- Components: triage-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-data-boundary

### Implementation steps

1. Responsibility from the board: Proposed Azure Monitor Application Insights instance for request counts, duration, failures and model usage. Propose Australia East, subject to availability and telemetry-processing review. Excludes ticket bodies, prompts, suggestions and authentication tokens; telemetry filtering must be implemented and tested, including automatic exception and dependency capture. Retention, access permissions, any workspace dependency and alert ownership require implementation review. Any required workspace must also have explicitly reviewed Australian placement; overseas exports or processing must be flagged before activation. This is not a stored ticket history. Monitoring infrastructure and integrations remain engineering work.
2. Verify Azure Monitor Application Insights on azure in australiaeast; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Monitor Application Insights; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component triage-monitoring
- Application/configuration and tests for Operational monitoring

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-72657669657765722d746f2d617070 — Wire Team member to Ticket triage web app

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72657669657765722d746f2d617070, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070
- Components: team-reviewer, triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge reviewer-to-app carrying HTTPS: paste ticket; receive suggestions for review, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation reviewer-to-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d746f2d7369676e2d696e — Wire Ticket triage web app to Staff sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d746f2d7369676e2d696e, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-73746166662d7369676e2d696e
- Components: triage-app, staff-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-to-sign-in carrying OpenID Connect sign-in; validate staff access; identity residency review require, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-to-sign-in
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d746f2d6d6f64656c — Wire Ticket triage web app to Ticket analysis model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d746f2d6d6f64656c, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c
- Components: triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-to-model carrying HTTPS with managed identity: ticket → suggestion; Australian regional inference , using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-to-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d746f2d6d6f6e69746f72696e67 — Wire Ticket triage web app to Operational monitoring

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d746f2d6d6f6e69746f72696e67, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f6e69746f72696e67
- Components: triage-app, triage-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-to-monitoring carrying Telemetry: timing, usage and errors; exclude ticket text; Australian destination, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-to-monitoring
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-72657669657765722d746f2d617070 — Verify live Team member → Ticket triage web app

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72657669657765722d746f2d617070
- Components: team-reviewer, triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge reviewer-to-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence reviewer-to-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d746f2d7369676e2d696e — Verify live Ticket triage web app → Staff sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d746f2d7369676e2d696e
- Components: triage-app, staff-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-to-sign-in with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-to-sign-in

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d746f2d6d6f64656c — Verify live Ticket triage web app → Ticket analysis model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d746f2d6d6f64656c
- Components: triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-to-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-to-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d746f2d6d6f6e69746f72696e67 — Verify live Ticket triage web app → Operational monitoring

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d746f2d6d6f6e69746f72696e67
- Components: triage-app, triage-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-to-monitoring with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-to-monitoring

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3333666230366639 — Verify REQ-001: A person approves sensitive actions before they happen

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-33fb06f9

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d747269616765 — Verify REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-INTEGRATION-LIVE-72657669657765722d746f2d617070, TASK-INTEGRATION-LIVE-6170702d746f2d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f6e69746f72696e67
- Components: team-reviewer, triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-triage

### Implementation steps

1. Basis: “pastes a support ticket and gets a short summary, topic and suggested urgency”; rationale: Preserves the requested outcome without adding autonomous actions; malformed or uncertain suggestions must not appear authoritative.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d73746166662d616363657373 — Verify REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-73746166662d7369676e2d696e, TASK-INTEGRATION-LIVE-72657669657765722d746f2d617070, TASK-INTEGRATION-LIVE-6170702d746f2d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f6e69746f72696e67
- Components: triage-app, staff-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-staff-access

### Implementation steps

1. Basis: User describes a “small internal tool” for “our team”; staff-sign-in is a proposed implementation.; rationale: Proposed access boundary prevents an internal tool from accepting anonymous or unassigned users.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d646174612d626f756e64617279 — Verify REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7472696167652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-72657669657765722d746f2d617070, TASK-INTEGRATION-LIVE-6170702d746f2d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f6e69746f72696e67
- Components: triage-app, triage-model, triage-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-data-boundary

### Implementation steps

1. Basis: Pasted support tickets flow through triage-app and triage-model; no history or storage outcome was requested.; rationale: Proposed minimization limits unnecessary exposure of support-ticket information; provider retention and country restrictions remain open.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-73746166662d7369676e2d696e, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7472696167652d6d6f6e69746f72696e67, TASK-INTEGRATION-72657669657765722d746f2d617070, TASK-INTEGRATION-6170702d746f2d7369676e2d696e, TASK-INTEGRATION-6170702d746f2d6d6f64656c, TASK-INTEGRATION-6170702d746f2d6d6f6e69746f72696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-73746166662d7369676e2d696e, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7472696167652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-72657669657765722d746f2d617070, TASK-INTEGRATION-LIVE-6170702d746f2d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f6e69746f72696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3333666230366639, TASK-ACCEPTANCE-61692d7469636b65742d747269616765, TASK-ACCEPTANCE-61692d73746166662d616363657373, TASK-ACCEPTANCE-61692d7469636b65742d646174612d626f756e64617279, TASK-INTEGRATION-LIVE-72657669657765722d746f2d617070, TASK-INTEGRATION-LIVE-6170702d746f2d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d746f2d6d6f6e69746f72696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
