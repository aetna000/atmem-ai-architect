Snapshot f96b7e50-67a0-45cd-bc1b-6fc66d13decc · design r3 · generated 2026-11-09T17:11:37.834Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 17:11 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** Azure
- **Budget and timeline:** —

## 3. Architecture

**Staff access**

- Team member (Tools & data, existing) — Existing person in Australia using a browser outside provisioning scope. Pastes a ticket, reads the proposed summary, topic and urgency, and makes the final judgment. The tool cannot send replies or change customer records.
- Staff sign-in (Azure, sketch) — Proposed Microsoft Entra ID application registration and staff access assignment. Tenant ownership and existing sign-in arrangement are not yet known; this does not assume an existing Entra deployment. Entra identity processing cannot be assumed to remain within the app's Azure region: tenant data location, authentication processing and related logs require separate review, with any overseas handling explicitly flagged. Do not send ticket text or suggestions through identity claims or sign-in URLs. App Service authentication and server authorization must restrict use to assigned staff. Registration, token validation and denied-access tests require implementation.

**Ticket triage**

- Ticket triage web app (Azure, sketch) — Proposed Azure App Service deployment serving both the browser interface and server API; owns its hosting plan configuration. Propose Australia East, subject to availability verification; regional placement is not yet accepted. Server verifies staff identity and authorization, bounds ticket input, and treats ticket content as untrusted data. Calls the model through managed identity and validates structured output containing summary, topic, suggested urgency and a short reason. Displays suggestions for human review; invalid output or model failure produces a clear retry message rather than an invented result. No reply-sending tools, customer-system credentials or write integrations. Proposed session-only handling with no application persistence or ticket content in logs. Browser caching, server diagnostics and outbound dependencies require review for accidental retention or overseas transfers. Propose no overseas fallback; a regional outage temporarily prevents analysis, while staff retain their existing manual process. Team owns code, deployment and operations; named operating owner remains unresolved. Custom application and infrastructure implementation required.
- Ticket analysis model (Azure, sketch) — Proposed Azure OpenAI resource with a model deployment for structured ticket analysis. Receives ticket text and returns a short summary, topic, suggested urgency and reason; no tools or customer-system access. Propose Australia East and a regional deployment type that keeps inference in Australia; model support, deployment-type availability, quotas and capacity are unverified. Do not silently substitute Global or Data Zone deployment types or an overseas endpoint. Review prompt/output retention, abuse monitoring, support access and processing locations separately from the resource location; flag any overseas handling before use. Propose bounded output, request deadlines and limited retries, with no overseas inference fallback. Availability and model quality are unverified; acceptance requires representative tickets, including ambiguous and malicious content. Custom provisioning and API integration required.

**Operations**

- Operational monitoring (Azure, sketch) — Proposed Azure Monitor Application Insights instance for request counts, duration, failures and model usage. Propose Australia East, subject to availability and telemetry-processing review. Excludes ticket bodies, prompts, suggestions and authentication tokens; telemetry filtering must be implemented and tested, including automatic exception and dependency capture. Retention, access permissions, any workspace dependency and alert ownership require implementation review. Any required workspace must also have explicitly reviewed Australian placement; overseas exports or processing must be flagged before activation. This is not a stored ticket history. Monitoring infrastructure and integrations remain engineering work.

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Ticket triage web app<br/>Azure"]
  n2["Staff sign-in<br/>Azure"]
  n3["Ticket analysis model<br/>Azure"]
  n4["Operational monitoring<br/>Azure"]
  n0 -->|HTTPS: paste ticket; receive suggestions for review| n1
  n1 -->|OpenID Connect sign-in; validate staff access; identity residency review require| n2
  n1 -->|HTTPS with managed identity: ticket → suggestion; Australian regional inference | n3
  n1 -->|Telemetry: timing, usage and errors; exclude ticket text; Australian destination| n4
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-reviewer | Team member | tools | Web browser | Australia — existing users | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-app | Ticket triage web app | azure | Azure App Service | australiaeast | Proposed | Implementation needed |
| staff-sign-in | Staff sign-in | azure | Microsoft Entra ID | Tenant/global service — residency review required | Proposed | Implementation needed |
| triage-model | Ticket analysis model | azure | Azure OpenAI | australiaeast | Proposed | Implementation needed |
| triage-monitoring | Operational monitoring | azure | Azure Monitor Application Insights | australiaeast | Proposed | Implementation needed |

### Resources and cost dimensions

- **Team member** (team-reviewer): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage web app** (triage-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-reviewer.
- **Staff sign-in** (staff-sign-in): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Ticket analysis model** (triage-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Operational monitoring** (triage-monitoring): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.

### Engineering work remaining

- Ticket triage web app: Implementation needed.
- Staff sign-in: Implementation needed.
- Ticket analysis model: Implementation needed.
- Operational monitoring: Implementation needed.
- Wire team-reviewer → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → staff-sign-in: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-monitoring: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team member | Ticket triage web app | HTTPS: paste ticket; receive suggestions for review | Confidential |
| Ticket triage web app | Staff sign-in | OpenID Connect sign-in; validate staff access; identity residency review require | Confidential |
| Ticket triage web app | Ticket analysis model | HTTPS with managed identity: ticket → suggestion; Australian regional inference  | Confidential |
| Ticket triage web app | Operational monitoring | Telemetry: timing, usage and errors; exclude ticket text; Australian destination | Confidential |

## 5. Security controls

- **Team member** — Existing person in Australia using a browser outside provisioning scope. Pastes a ticket, reads the proposed summary, topic and urgency, and makes the final judgment. The tool cannot send replies or change customer records.
- **Staff sign-in** — Proposed Microsoft Entra ID application registration and staff access assignment. Tenant ownership and existing sign-in arrangement are not yet known; this does not assume an existing Entra deployment. Entra identity processing cannot be assumed to remain within the app's Azure region: tenant data location, authentication processing and related logs require separate review, with any overseas handling explicitly flagged. Do not send ticket text or suggestions through identity claims or sign-in URLs. App Service authentication and server authorization must restrict use to assigned staff. Registration, token validation and denied-access tests require implementation.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server. (must)
- Requirement: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch. (should)
- Open finding SEC-002: Sensitive data is involved but where it must be stored is not stated.

## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server. | security | not measurable yet | Open |
| Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch. | security | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Security & controls**

- [major] Sensitive data is involved but where it must be stored is not stated. Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks. _(AtMem AI Architect rule SEC-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.”, “Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 4 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Ticket analysis model | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team member, Ticket triage web app, Operational monitoring.

**Estimate gaps:**

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Ticket analysis model / Endpoint hours: price needed.
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff access: Staff sign-in.
4. Provision ticket triage: Ticket triage web app, Ticket analysis model.
5. Provision operations: Operational monitoring.
6. Connect existing systems: Team member; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- Staff sign-in: needs requests_per_month _(estimate)_
- Ticket analysis model: needs a unit price with a source _(estimate)_
