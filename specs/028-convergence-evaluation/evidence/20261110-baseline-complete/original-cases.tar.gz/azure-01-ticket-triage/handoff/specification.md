Snapshot f96b7e50-67a0-45cd-bc1b-6fc66d13decc · design r3 · generated 2026-11-09T17:11:37.834Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced. (must, open); target: acceptance target needed; linked blocks: team-reviewer, triage-app, triage-model

Design explanation: Preserves the requested outcome without adding autonomous actions; malformed or uncertain suggestions must not appear authoritative.

Basis: “pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server. (must, open); target: acceptance target needed; linked blocks: triage-app, staff-sign-in

Design explanation: Proposed access boundary prevents an internal tool from accepting anonymous or unassigned users.

Basis: User describes a “small internal tool” for “our team”; staff-sign-in is a proposed implementation.
- [REQ-004] Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch. (should, open); target: acceptance target needed; linked blocks: triage-app, triage-model, triage-monitoring

Design explanation: Proposed minimization limits unnecessary exposure of support-ticket information; provider retention and country restrictions remain open.

Basis: Pasted support tickets flow through triage-app and triage-model; no history or storage outcome was requested.

## How the system works

The current design contains 5 components and 4 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team member → Ticket triage web app

HTTPS: paste ticket; receive suggestions for review

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Ticket triage web app → Staff sign-in

OpenID Connect sign-in; validate staff access; identity residency review require

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Ticket triage web app → Ticket analysis model

HTTPS with managed identity: ticket → suggestion; Australian regional inference 

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Ticket triage web app → Operational monitoring

Telemetry: timing, usage and errors; exclude ticket text; Australian destination

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team member

Web browser · tools · region: Australia — existing users · classification: Confidential

Existing person in Australia using a browser outside provisioning scope. Pastes a ticket, reads the proposed summary, topic and urgency, and makes the final judgment. The tool cannot send replies or change customer records.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team member → Ticket triage web app: HTTPS: paste ticket; receive suggestions for review

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket triage web app

Azure App Service · azure · region: australiaeast · classification: Confidential

Proposed Azure App Service deployment serving both the browser interface and server API; owns its hosting plan configuration. Propose Australia East, subject to availability verification; regional placement is not yet accepted. Server verifies staff identity and authorization, bounds ticket input, and treats ticket content as untrusted data. Calls the model through managed identity and validates structured output containing summary, topic, suggested urgency and a short reason. Displays suggestions for human review; invalid output or model failure produces a clear retry message rather than an invented result. No reply-sending tools, customer-system credentials or write integrations. Proposed session-only handling with no application persistence or ticket content in logs. Browser caching, server diagnostics and outbound dependencies require review for accidental retention or overseas transfers. Propose no overseas fallback; a regional outage temporarily prevents analysis, while staff retain their existing manual process. Team owns code, deployment and operations; named operating owner remains unresolved. Custom application and infrastructure implementation required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team member → Ticket triage web app: HTTPS: paste ticket; receive suggestions for review

Outputs: Ticket triage web app → Staff sign-in: OpenID Connect sign-in; validate staff access; identity residency review require; Ticket triage web app → Ticket analysis model: HTTPS with managed identity: ticket → suggestion; Australian regional inference ; Ticket triage web app → Operational monitoring: Telemetry: timing, usage and errors; exclude ticket text; Australian destination

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.; REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.; REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Staff sign-in

Microsoft Entra ID · azure · region: Tenant/global service — residency review required · classification: Internal

Proposed Microsoft Entra ID application registration and staff access assignment. Tenant ownership and existing sign-in arrangement are not yet known; this does not assume an existing Entra deployment. Entra identity processing cannot be assumed to remain within the app's Azure region: tenant data location, authentication processing and related logs require separate review, with any overseas handling explicitly flagged. Do not send ticket text or suggestions through identity claims or sign-in URLs. App Service authentication and server authorization must restrict use to assigned staff. Registration, token validation and denied-access tests require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket triage web app → Staff sign-in: OpenID Connect sign-in; validate staff access; identity residency review require

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Proposed: permit ticket submission and suggestion access only to authenticated, assigned staff, with authorization enforced by the server.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Ticket analysis model

Azure OpenAI · azure · region: australiaeast · classification: Confidential

Proposed Azure OpenAI resource with a model deployment for structured ticket analysis. Receives ticket text and returns a short summary, topic, suggested urgency and reason; no tools or customer-system access. Propose Australia East and a regional deployment type that keeps inference in Australia; model support, deployment-type availability, quotas and capacity are unverified. Do not silently substitute Global or Data Zone deployment types or an overseas endpoint. Review prompt/output retention, abuse monitoring, support access and processing locations separately from the resource location; flag any overseas handling before use. Propose bounded output, request deadlines and limited retries, with no overseas inference fallback. Availability and model quality are unverified; acceptance requires representative tickets, including ambiguous and malicious content. Custom provisioning and API integration required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket triage web app → Ticket analysis model: HTTPS with managed identity: ticket → suggestion; Australian regional inference 

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency for human review; show a clear failure or uncertainty indication when a usable suggestion cannot be produced.; REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Operational monitoring

Azure Monitor Application Insights · azure · region: australiaeast · classification: Internal

Proposed Azure Monitor Application Insights instance for request counts, duration, failures and model usage. Propose Australia East, subject to availability and telemetry-processing review. Excludes ticket bodies, prompts, suggestions and authentication tokens; telemetry filtering must be implemented and tested, including automatic exception and dependency capture. Retention, access permissions, any workspace dependency and alert ownership require implementation review. Any required workspace must also have explicitly reviewed Australian placement; overseas exports or processing must be flagged before activation. This is not a stored ticket history. Monitoring infrastructure and integrations remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket triage web app → Operational monitoring: Telemetry: timing, usage and errors; exclude ticket text; Australian destination

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Proposed: avoid application persistence of ticket text and suggestions, exclude their content from telemetry, and review model-service retention and processing locations against the agreed country boundary before launch.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Ticket triage web app<br/>Azure"]
  n2["Staff sign-in<br/>Azure"]
  n3["Ticket analysis model<br/>Azure"]
  n4["Operational monitoring<br/>Azure"]
  n0 -->|HTTPS: paste ticket; receive suggestions for review| n1
  n1 -->|OpenID Connect sign-in; validate staff access; identity residency review require| n2
  n1 -->|HTTPS with managed identity: ticket → suggestion; Australian regional inference | n3
  n1 -->|Telemetry: timing, usage and errors; exclude ticket text; Australian destination| n4
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-reviewer | Team member | tools | Web browser | Australia — existing users | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-app | Ticket triage web app | azure | Azure App Service | australiaeast | Proposed | Implementation needed |
| staff-sign-in | Staff sign-in | azure | Microsoft Entra ID | Tenant/global service — residency review required | Proposed | Implementation needed |
| triage-model | Ticket analysis model | azure | Azure OpenAI | australiaeast | Proposed | Implementation needed |
| triage-monitoring | Operational monitoring | azure | Azure Monitor Application Insights | australiaeast | Proposed | Implementation needed |

### Resources and cost dimensions

- **Team member** (team-reviewer): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket triage web app** (triage-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-reviewer.
- **Staff sign-in** (staff-sign-in): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Ticket analysis model** (triage-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Operational monitoring** (triage-monitoring): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.

### Engineering work remaining

- Ticket triage web app: Implementation needed.
- Staff sign-in: Implementation needed.
- Ticket analysis model: Implementation needed.
- Operational monitoring: Implementation needed.
- Wire team-reviewer → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → staff-sign-in: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-monitoring: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
