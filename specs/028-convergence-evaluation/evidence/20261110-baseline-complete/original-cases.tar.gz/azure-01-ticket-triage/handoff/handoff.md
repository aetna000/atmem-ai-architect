# Delivery handoff

Snapshot f96b7e50-67a0-45cd-bc1b-6fc66d13decc · design r3 · generated 2026-11-09T17:11:37.834Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Ticket analysis model / Endpoint hours: price needed.
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage web app: Implementation needed.
- Staff sign-in: Implementation needed.
- Ticket analysis model: Implementation needed.
- Operational monitoring: Implementation needed.
- Wire team-reviewer → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → staff-sign-in: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-monitoring: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
