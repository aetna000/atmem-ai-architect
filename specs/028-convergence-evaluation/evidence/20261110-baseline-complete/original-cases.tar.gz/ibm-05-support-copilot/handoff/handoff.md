# Delivery handoff

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Existing CRM / Storage: input needed (data_gb).
- Approved support knowledge / Storage: input needed (data_gb).
- Grounded draft generation / Endpoint hours: price needed.
- Approval and action ledger / Storage: input needed (data_gb).
- Scoped integration credentials / Checked requests: input needed (requests_per_month).
- Support staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Drafting and approval application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved action executor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational visibility: no cost lines; add charges or an explicit zero-cost line with a reason.
- Staff sign-in: Implementation needed.
- Drafting and approval application: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and action ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped integration credentials: Implementation needed.
- Operational visibility: Implementation needed.
- Wire support-staff → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → staff-identity: implement data flow, access policy and acceptance test.
- Wire copilot-app → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → service-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → service-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire action-executor → operational-logs: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
