# Infrastructure implementation required

Requested providers: ibm. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Staff sign-in: Implementation needed.
- Drafting and approval application: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and action ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped integration credentials: Implementation needed.
- Operational visibility: Implementation needed.
- Wire support-staff → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → staff-identity: implement data flow, access policy and acceptance test.
- Wire copilot-app → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → service-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → service-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire action-executor → operational-logs: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
