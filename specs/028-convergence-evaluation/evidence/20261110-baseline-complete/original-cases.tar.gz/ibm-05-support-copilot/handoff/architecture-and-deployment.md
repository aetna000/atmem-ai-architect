Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

# Human-approved support copilot — deployment document

Generated 2026-11-09 18:10 UTC from design revision r2 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

- **Cloud:** IBM
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system. Fifty support agents and five supervisors. Account-changing actions require supervisor approval.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM
- **Budget and timeline:** —

## 3. Architecture

**Staff review**

- Support staff (Tools & data, existing, sketch) — Existing staff using a browser outside provisioning scope. Review cited drafts and exact proposed actions, edit or reject them, and explicitly approve individual operations. Staff permissions must be checked by the server.
- Staff sign-in (IBM, sketch) — Proposed IBM Cloud App ID authentication for the staff application. Company identity federation, MFA and account lifecycle need qualification. The application separately enforces case access and approval permissions; authentication alone does not authorize actions.

**Draft and approve**

- Drafting and approval application (IBM, sketch) — Proposed IBM Cloud Code Engine application owns the staff web interface and server API. Reads authorized CRM cases and approved knowledge, requests grounded drafts and returns citations and action recommendations. Treats source content as untrusted. Enforces staff authorization, anti-forgery protection and approval bound to exact payload, case version and knowledge version; edits invalidate approval. Atomically records approval and execution intent. Has read-only CRM credentials and cannot send replies or change accounts. Application code, hosting ingress and integrations remain engineering work; no supplied-image contract is selected.
- Grounded draft generation (IBM, sketch) — Proposed IBM watsonx.ai inference generates draft replies and structured action recommendations from minimized case data and approved excerpts. No action tools or CRM credentials. Model choice, structured-output handling, grounding evaluation, quotas, data handling and regional availability require qualification. Missing evidence produces a review warning rather than an unsupported answer.

**Existing business systems**

- Existing CRM (Tools & data, existing, sketch) — Client-owned existing CRM; vendor and API capabilities are unknown. Provides cases and receives only approved replies or allowlisted account changes. Must qualify read/write permissions, case-version checks, operation IDs, idempotency and outcome lookup before enabling writes. No modification or provisioning of the CRM is implied.
- Approved support knowledge (Tools & data, existing, sketch) — Existing approved support knowledge; repository and retrieval interface remain unknown. Application retrieves only content the staff member may access, retaining source identifiers and revisions for citations. Source changes and unavailable or insufficient evidence must be surfaced before approval. Connector and permission-preserving retrieval require implementation.

**Approved execution**

- Approval and action ledger (IBM, sketch) — Proposed managed PostgreSQL stores versioned drafts, exact action payload hashes, approver identity, approval state, transactional outbox, unique operation IDs and execution results. Atomic claims and uniqueness constraints prevent concurrent duplicate dispatch. Approved payload changes require new approval. Retain ambiguous outcomes for reconciliation; worker leases alone cannot prevent duplicate CRM effects. Backup, recovery and retention settings remain proposals to define.
- Approved action executor (IBM, sketch) — Separate private IBM Cloud Code Engine worker deployment owns narrowly scoped CRM write credentials. Claims approved outbox operations, validates payload hash, approver authority, allowlist and current case preconditions, then sends the approved reply or account action. No public execution endpoint and no model-selected arbitrary tools. Uses stable destination idempotency keys where supported; after uncertain outcomes, reconciles by operation ID or blocks for staff investigation instead of blindly retrying. CRM capability qualification is required before writes are enabled. Failed and stale operations return to staff review. Implementation and fault-injection tests remain engineering work.

**Operations**

- Scoped integration credentials (IBM, sketch) — Proposed IBM Cloud Secrets Manager stores integration secrets. Separate application and executor service identities receive only the secrets needed for their responsibilities. CRM write secrets are available only to the executor. Credential issuance, rotation and runtime access need implementation and verification; no credentials belong in the diagram.
- Operational visibility (IBM, sketch) — Proposed IBM Cloud Logs receives redacted application and executor events correlated by case and operation ID. Monitor failed drafting, denied approval, stalled execution and ambiguous CRM outcomes. Approval evidence remains in the durable ledger. Avoid raw case text and secrets in logs. Alert routing, retention, access and operational ownership require implementation and agreement.

```mermaid
flowchart LR
  n0["Support staff<br/>Tools & data"]
  n1["Staff sign-in<br/>IBM"]
  n2["Drafting and approval application<br/>IBM"]
  n3["Existing CRM<br/>Tools & data"]
  n4["Approved support knowledge<br/>Tools & data"]
  n5["Grounded draft generation<br/>IBM"]
  n6["Approval and action ledger<br/>IBM"]
  n7["Approved action executor<br/>IBM"]
  n8["Scoped integration credentials<br/>IBM"]
  n9["Operational visibility<br/>IBM"]
  n0 -->|HTTPS: review drafts, approve exact operations, receive status| n2
  n2 -->|OIDC sign-in and server token validation; implementation required| n1
  n2 -->|Read authorized case and revision through CRM API; unresolved| n3
  n2 -->|Permission-filtered approved excerpts and source revisions; unresolved| n4
  n2 -->|HTTPS inference: approved context → draft and recommendations| n5
  n2 -->|TLS SQL: drafts, approval transaction, outbox and status reads| n6
  n7 -->|TLS SQL: claim approved operations; record outcomes and reconciliation| n6
  n7 -->|Approved CRM writes with stable operation ID; reconcile uncertain outcome| n3
  n2 -->|Service identity: retrieve scoped read and application credentials| n8
  n7 -->|Executor identity: retrieve narrowly scoped CRM write credentials| n8
  n2 -->|Redacted request, authorization and drafting events| n9
  n7 -->|Redacted execution, retry and recovery events| n9
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| support-staff | Support staff | tools | Approval workflow | Existing location; unresolved | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| staff-identity | Staff sign-in | ibm | IBM Cloud App ID | To be selected after country decision | Proposed | Implementation needed |
| copilot-app | Drafting and approval application | ibm | IBM Cloud Code Engine | To be selected after country decision | Proposed | Implementation needed |
| existing-crm | Existing CRM | tools | Storage or existing data connector | Existing placement; unresolved | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| approved-knowledge | Approved support knowledge | tools | Storage or existing data connector | Existing placement; unresolved | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| draft-model | Grounded draft generation | ibm | IBM watsonx.ai | To be selected after country decision | Proposed | Implementation needed |
| approval-ledger | Approval and action ledger | ibm | IBM Cloud Databases for PostgreSQL | To be selected after country decision | Proposed | Implementation needed |
| action-executor | Approved action executor | ibm | IBM Cloud Code Engine | To be selected after country decision | Proposed | Implementation needed |
| service-secrets | Scoped integration credentials | ibm | IBM Cloud Secrets Manager | To be selected after country decision | Proposed | Implementation needed |
| operational-logs | Operational visibility | ibm | IBM Cloud Logs | To be selected after country decision | Proposed | Implementation needed |

### Resources and cost dimensions

- **Support staff** (support-staff): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Staff sign-in** (staff-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Drafting and approval application** (copilot-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: support-staff.
- **Existing CRM** (existing-crm): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved support knowledge** (approved-knowledge): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Grounded draft generation** (draft-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Approval and action ledger** (approval-ledger): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved action executor** (action-executor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Scoped integration credentials** (service-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Operational visibility** (operational-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.

### Engineering work remaining

- Staff sign-in: Implementation needed.
- Drafting and approval application: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and action ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped integration credentials: Implementation needed.
- Operational visibility: Implementation needed.
- Wire support-staff → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → staff-identity: implement data flow, access policy and acceptance test.
- Wire copilot-app → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → service-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → service-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire action-executor → operational-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Support staff | Drafting and approval application | HTTPS: review drafts, approve exact operations, receive status | Confidential |
| Drafting and approval application | Staff sign-in | OIDC sign-in and server token validation; implementation required | Confidential |
| Drafting and approval application | Existing CRM | Read authorized case and revision through CRM API; unresolved | Confidential |
| Drafting and approval application | Approved support knowledge | Permission-filtered approved excerpts and source revisions; unresolved | Confidential |
| Drafting and approval application | Grounded draft generation | HTTPS inference: approved context → draft and recommendations | Confidential |
| Drafting and approval application | Approval and action ledger | TLS SQL: drafts, approval transaction, outbox and status reads | Confidential |
| Approved action executor | Approval and action ledger | TLS SQL: claim approved operations; record outcomes and reconciliation | Confidential |
| Approved action executor | Existing CRM | Approved CRM writes with stable operation ID; reconcile uncertain outcome | Confidential |
| Drafting and approval application | Scoped integration credentials | Service identity: retrieve scoped read and application credentials | Confidential |
| Approved action executor | Scoped integration credentials | Executor identity: retrieve narrowly scoped CRM write credentials | Confidential |
| Drafting and approval application | Operational visibility | Redacted request, authorization and drafting events | Confidential |
| Approved action executor | Operational visibility | Redacted execution, retry and recovery events | Confidential |

## 5. Security controls

- **Support staff** — Existing staff using a browser outside provisioning scope. Review cited drafts and exact proposed actions, edit or reject them, and explicitly approve individual operations. Staff permissions must be checked by the server.
- **Staff sign-in** — Proposed IBM Cloud App ID authentication for the staff application. Company identity federation, MFA and account lifecycle need qualification. The application separately enforces case access and approval permissions; authentication alone does not authorize actions.
- **Scoped integration credentials** — Proposed IBM Cloud Secrets Manager stores integration secrets. Separate application and executor service identities receive only the secrets needed for their responsibilities. CRM write secrets are available only to the executor. Credential issuance, rotation and runtime access need implementation and verification; no credentials belong in the diagram.
- Requirement: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied. (must)
- Requirement: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority. (must)
- Open finding SEC-002: Sensitive data is involved but where it must be stored is not stated.

## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated. | reliability | not measurable yet | Open |

**Functional**

- Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied. (must, open)
- The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Security & controls**

- [major] Sensitive data is involved but where it must be stored is not stated. Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks. _(AtMem AI Architect rule SEC-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 10 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Existing CRM | Storage | needs data_gb | price needed | — | — |
| Approved support knowledge | Storage | needs data_gb | price needed | — | — |
| Grounded draft generation | Endpoint hours | 730 hours | price needed | — | — |
| Approval and action ledger | Storage | needs data_gb | price needed | — | — |
| Scoped integration credentials | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Support staff, Drafting and approval application, Approved action executor, Operational visibility.

**Estimate gaps:**

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Existing CRM / Storage: input needed (data_gb).
- Approved support knowledge / Storage: input needed (data_gb).
- Grounded draft generation / Endpoint hours: price needed.
- Approval and action ledger / Storage: input needed (data_gb).
- Scoped integration credentials / Checked requests: input needed (requests_per_month).
- Support staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Drafting and approval application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved action executor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational visibility: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff review: Staff sign-in.
4. Provision approved execution: Approved action executor, Approval and action ledger.
5. Provision draft and approve: Drafting and approval application, Grounded draft generation.
6. Provision operations: Scoped integration credentials, Operational visibility.
7. Connect existing systems: Support staff, Existing CRM, Approved support knowledge; test failure behaviour.
8. Run the acceptance checks (success measures and requirements) in staging; record results.
9. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Staff sign-in: needs requests_per_month _(estimate)_
- Existing CRM: needs data_gb _(estimate)_
- Approved support knowledge: needs data_gb _(estimate)_
- Grounded draft generation: needs a unit price with a source _(estimate)_
- Approval and action ledger: needs data_gb _(estimate)_
- Scoped integration credentials: needs requests_per_month _(estimate)_
