Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

# Human-approved support copilot — solution specification

## Problem and intended outcome

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied. (must, open); target: acceptance target needed; linked blocks: copilot-app, staff-identity, approval-ledger, action-executor

Design explanation: Prevents unapproved communications or account changes, including when a draft changes after review.

Basis: User: “Nothing is sent or changed until a staff member explicitly approves it.” Proposed copilot-app, approval-ledger and action-executor boundaries.
- [REQ-004] Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated. (must, open); target: acceptance target needed; linked blocks: approval-ledger, action-executor, existing-crm

Design explanation: A CRM write may succeed before a timeout or worker crash; retrying without destination reconciliation can repeat the business effect.

Basis: User: “Retries must not perform an action twice.” Proposed approval-ledger and action-executor.
- [REQ-005] The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority. (must, open); target: acceptance target needed; linked blocks: copilot-app, existing-crm, approved-knowledge, draft-model

Design explanation: Staff need traceable evidence to review a draft, and case or knowledge content must not bypass access restrictions or authorize actions.

Basis: User: “reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions.” Citations and insufficient-evidence warnings are proposed review controls.

## How the system works

The current design contains 10 components and 12 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Support staff → Drafting and approval application

HTTPS: review drafts, approve exact operations, receive status

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Drafting and approval application → Staff sign-in

OIDC sign-in and server token validation; implementation required

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Drafting and approval application → Existing CRM

Read authorized case and revision through CRM API; unresolved

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Drafting and approval application → Approved support knowledge

Permission-filtered approved excerpts and source revisions; unresolved

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Drafting and approval application → Grounded draft generation

HTTPS inference: approved context → draft and recommendations

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Drafting and approval application → Approval and action ledger

TLS SQL: drafts, approval transaction, outbox and status reads

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Approved action executor → Approval and action ledger

TLS SQL: claim approved operations; record outcomes and reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Approved action executor → Existing CRM

Approved CRM writes with stable operation ID; reconcile uncertain outcome

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Drafting and approval application → Scoped integration credentials

Service identity: retrieve scoped read and application credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Approved action executor → Scoped integration credentials

Executor identity: retrieve narrowly scoped CRM write credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Drafting and approval application → Operational visibility

Redacted request, authorization and drafting events

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Approved action executor → Operational visibility

Redacted execution, retry and recovery events

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Support staff

Approval workflow · tools · region: Existing location; unresolved · classification: Confidential

Existing staff using a browser outside provisioning scope. Review cited drafts and exact proposed actions, edit or reject them, and explicitly approve individual operations. Staff permissions must be checked by the server.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Support staff → Drafting and approval application: HTTPS: review drafts, approve exact operations, receive status

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Staff sign-in

IBM Cloud App ID · ibm · region: To be selected after country decision · classification: Confidential

Proposed IBM Cloud App ID authentication for the staff application. Company identity federation, MFA and account lifecycle need qualification. The application separately enforces case access and approval permissions; authentication alone does not authorize actions.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Drafting and approval application → Staff sign-in: OIDC sign-in and server token validation; implementation required

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Drafting and approval application

IBM Cloud Code Engine · ibm · region: To be selected after country decision · classification: Confidential

Proposed IBM Cloud Code Engine application owns the staff web interface and server API. Reads authorized CRM cases and approved knowledge, requests grounded drafts and returns citations and action recommendations. Treats source content as untrusted. Enforces staff authorization, anti-forgery protection and approval bound to exact payload, case version and knowledge version; edits invalidate approval. Atomically records approval and execution intent. Has read-only CRM credentials and cannot send replies or change accounts. Application code, hosting ingress and integrations remain engineering work; no supplied-image contract is selected.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Support staff → Drafting and approval application: HTTPS: review drafts, approve exact operations, receive status

Outputs: Drafting and approval application → Staff sign-in: OIDC sign-in and server token validation; implementation required; Drafting and approval application → Existing CRM: Read authorized case and revision through CRM API; unresolved; Drafting and approval application → Approved support knowledge: Permission-filtered approved excerpts and source revisions; unresolved; Drafting and approval application → Grounded draft generation: HTTPS inference: approved context → draft and recommendations; Drafting and approval application → Approval and action ledger: TLS SQL: drafts, approval transaction, outbox and status reads; Drafting and approval application → Scoped integration credentials: Service identity: retrieve scoped read and application credentials; Drafting and approval application → Operational visibility: Redacted request, authorization and drafting events

Requirement traceability: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.; REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing CRM

Storage or existing data connector · tools · region: Existing placement; unresolved · classification: Confidential

Client-owned existing CRM; vendor and API capabilities are unknown. Provides cases and receives only approved replies or allowlisted account changes. Must qualify read/write permissions, case-version checks, operation IDs, idempotency and outcome lookup before enabling writes. No modification or provisioning of the CRM is implied.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Drafting and approval application → Existing CRM: Read authorized case and revision through CRM API; unresolved; Approved action executor → Existing CRM: Approved CRM writes with stable operation ID; reconcile uncertain outcome

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.; REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Approved support knowledge

Storage or existing data connector · tools · region: Existing placement; unresolved · classification: Confidential

Existing approved support knowledge; repository and retrieval interface remain unknown. Application retrieves only content the staff member may access, retaining source identifiers and revisions for citations. Source changes and unavailable or insufficient evidence must be surfaced before approval. Connector and permission-preserving retrieval require implementation.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Drafting and approval application → Approved support knowledge: Permission-filtered approved excerpts and source revisions; unresolved

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Grounded draft generation

IBM watsonx.ai · ibm · region: To be selected after country decision · classification: Confidential

Proposed IBM watsonx.ai inference generates draft replies and structured action recommendations from minimized case data and approved excerpts. No action tools or CRM credentials. Model choice, structured-output handling, grounding evaluation, quotas, data handling and regional availability require qualification. Missing evidence produces a review warning rather than an unsupported answer.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Drafting and approval application → Grounded draft generation: HTTPS inference: approved context → draft and recommendations

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Approval and action ledger

IBM Cloud Databases for PostgreSQL · ibm · region: To be selected after country decision · classification: Confidential

Proposed managed PostgreSQL stores versioned drafts, exact action payload hashes, approver identity, approval state, transactional outbox, unique operation IDs and execution results. Atomic claims and uniqueness constraints prevent concurrent duplicate dispatch. Approved payload changes require new approval. Retain ambiguous outcomes for reconciliation; worker leases alone cannot prevent duplicate CRM effects. Backup, recovery and retention settings remain proposals to define.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Drafting and approval application → Approval and action ledger: TLS SQL: drafts, approval transaction, outbox and status reads; Approved action executor → Approval and action ledger: TLS SQL: claim approved operations; record outcomes and reconciliation

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.; REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Approved action executor

IBM Cloud Code Engine · ibm · region: To be selected after country decision · classification: Confidential

Separate private IBM Cloud Code Engine worker deployment owns narrowly scoped CRM write credentials. Claims approved outbox operations, validates payload hash, approver authority, allowlist and current case preconditions, then sends the approved reply or account action. No public execution endpoint and no model-selected arbitrary tools. Uses stable destination idempotency keys where supported; after uncertain outcomes, reconciles by operation ID or blocks for staff investigation instead of blindly retrying. CRM capability qualification is required before writes are enabled. Failed and stale operations return to staff review. Implementation and fault-injection tests remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Approved action executor → Approval and action ledger: TLS SQL: claim approved operations; record outcomes and reconciliation; Approved action executor → Existing CRM: Approved CRM writes with stable operation ID; reconcile uncertain outcome; Approved action executor → Scoped integration credentials: Executor identity: retrieve narrowly scoped CRM write credentials; Approved action executor → Operational visibility: Redacted execution, retry and recovery events

Requirement traceability: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.; REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Scoped integration credentials

IBM Cloud Secrets Manager · ibm · region: To be selected after country decision · classification: Confidential

Proposed IBM Cloud Secrets Manager stores integration secrets. Separate application and executor service identities receive only the secrets needed for their responsibilities. CRM write secrets are available only to the executor. Credential issuance, rotation and runtime access need implementation and verification; no credentials belong in the diagram.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Drafting and approval application → Scoped integration credentials: Service identity: retrieve scoped read and application credentials; Approved action executor → Scoped integration credentials: Executor identity: retrieve narrowly scoped CRM write credentials

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Operational visibility

IBM Cloud Logs · ibm · region: To be selected after country decision · classification: Confidential

Proposed IBM Cloud Logs receives redacted application and executor events correlated by case and operation ID. Monitor failed drafting, denied approval, stalled execution and ambiguous CRM outcomes. Approval evidence remains in the durable ledger. Avoid raw case text and secrets in logs. Alert routing, retention, access and operational ownership require implementation and agreement.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Drafting and approval application → Operational visibility: Redacted request, authorization and drafting events; Approved action executor → Operational visibility: Redacted execution, retry and recovery events

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Support staff<br/>Tools & data"]
  n1["Staff sign-in<br/>IBM"]
  n2["Drafting and approval application<br/>IBM"]
  n3["Existing CRM<br/>Tools & data"]
  n4["Approved support knowledge<br/>Tools & data"]
  n5["Grounded draft generation<br/>IBM"]
  n6["Approval and action ledger<br/>IBM"]
  n7["Approved action executor<br/>IBM"]
  n8["Scoped integration credentials<br/>IBM"]
  n9["Operational visibility<br/>IBM"]
  n0 -->|HTTPS: review drafts, approve exact operations, receive status| n2
  n2 -->|OIDC sign-in and server token validation; implementation required| n1
  n2 -->|Read authorized case and revision through CRM API; unresolved| n3
  n2 -->|Permission-filtered approved excerpts and source revisions; unresolved| n4
  n2 -->|HTTPS inference: approved context → draft and recommendations| n5
  n2 -->|TLS SQL: drafts, approval transaction, outbox and status reads| n6
  n7 -->|TLS SQL: claim approved operations; record outcomes and reconciliation| n6
  n7 -->|Approved CRM writes with stable operation ID; reconcile uncertain outcome| n3
  n2 -->|Service identity: retrieve scoped read and application credentials| n8
  n7 -->|Executor identity: retrieve narrowly scoped CRM write credentials| n8
  n2 -->|Redacted request, authorization and drafting events| n9
  n7 -->|Redacted execution, retry and recovery events| n9
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| support-staff | Support staff | tools | Approval workflow | Existing location; unresolved | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| staff-identity | Staff sign-in | ibm | IBM Cloud App ID | To be selected after country decision | Proposed | Implementation needed |
| copilot-app | Drafting and approval application | ibm | IBM Cloud Code Engine | To be selected after country decision | Proposed | Implementation needed |
| existing-crm | Existing CRM | tools | Storage or existing data connector | Existing placement; unresolved | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| approved-knowledge | Approved support knowledge | tools | Storage or existing data connector | Existing placement; unresolved | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| draft-model | Grounded draft generation | ibm | IBM watsonx.ai | To be selected after country decision | Proposed | Implementation needed |
| approval-ledger | Approval and action ledger | ibm | IBM Cloud Databases for PostgreSQL | To be selected after country decision | Proposed | Implementation needed |
| action-executor | Approved action executor | ibm | IBM Cloud Code Engine | To be selected after country decision | Proposed | Implementation needed |
| service-secrets | Scoped integration credentials | ibm | IBM Cloud Secrets Manager | To be selected after country decision | Proposed | Implementation needed |
| operational-logs | Operational visibility | ibm | IBM Cloud Logs | To be selected after country decision | Proposed | Implementation needed |

### Resources and cost dimensions

- **Support staff** (support-staff): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Staff sign-in** (staff-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Drafting and approval application** (copilot-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: support-staff.
- **Existing CRM** (existing-crm): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved support knowledge** (approved-knowledge): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Grounded draft generation** (draft-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Approval and action ledger** (approval-ledger): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved action executor** (action-executor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Scoped integration credentials** (service-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Operational visibility** (operational-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.

### Engineering work remaining

- Staff sign-in: Implementation needed.
- Drafting and approval application: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and action ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped integration credentials: Implementation needed.
- Operational visibility: Implementation needed.
- Wire support-staff → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → staff-identity: implement data flow, access policy and acceptance test.
- Wire copilot-app → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → service-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → service-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire action-executor → operational-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
