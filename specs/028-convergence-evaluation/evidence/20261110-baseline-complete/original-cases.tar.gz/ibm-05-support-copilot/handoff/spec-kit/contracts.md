# Component and interface contracts

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component support-staff: Support staff

- Responsibility: Existing staff using a browser outside provisioning scope. Review cited drafts and exact proposed actions, edit or reject them, and explicitly approve individual operations. Staff permissions must be checked by the server.
- Service: Approval workflow
- Provider / placement: tools / Existing location; unresolved
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-737570706f72742d7374616666
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component staff-identity: Staff sign-in

- Responsibility: Proposed IBM Cloud App ID authentication for the staff application. Company identity federation, MFA and account lifecycle need qualification. The application separately enforces case access and approval permissions; authentication alone does not authorize actions.
- Service: IBM Cloud App ID
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component copilot-app: Drafting and approval application

- Responsibility: Proposed IBM Cloud Code Engine application owns the staff web interface and server API. Reads authorized CRM cases and approved knowledge, requests grounded drafts and returns citations and action recommendations. Treats source content as untrusted. Enforces staff authorization, anti-forgery protection and approval bound to exact payload, case version and knowledge version; edits invalidate approval. Atomically records approval and execution intent. Has read-only CRM credentials and cannot send replies or change accounts. Application code, hosting ingress and integrations remain engineering work; no supplied-image contract is selected.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f70696c6f742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component existing-crm: Existing CRM

- Responsibility: Client-owned existing CRM; vendor and API capabilities are unknown. Provides cases and receives only approved replies or allowlisted account changes. Must qualify read/write permissions, case-version checks, operation IDs, idempotency and outcome lookup before enabling writes. No modification or provisioning of the CRM is implied.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing placement; unresolved
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6578697374696e672d63726d
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component approved-knowledge: Approved support knowledge

- Responsibility: Existing approved support knowledge; repository and retrieval interface remain unknown. Application retrieves only content the staff member may access, retaining source identifiers and revisions for citations. Source changes and unavailable or insufficient evidence must be surfaced before approval. Connector and permission-preserving retrieval require implementation.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing placement; unresolved
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component draft-model: Grounded draft generation

- Responsibility: Proposed IBM watsonx.ai inference generates draft replies and structured action recommendations from minimized case data and approved excerpts. No action tools or CRM credentials. Model choice, structured-output handling, grounding evaluation, quotas, data handling and regional availability require qualification. Missing evidence produces a review warning rather than an unsupported answer.
- Service: IBM watsonx.ai
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-64726166742d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component approval-ledger: Approval and action ledger

- Responsibility: Proposed managed PostgreSQL stores versioned drafts, exact action payload hashes, approver identity, approval state, transactional outbox, unique operation IDs and execution results. Atomic claims and uniqueness constraints prevent concurrent duplicate dispatch. Approved payload changes require new approval. Retain ambiguous outcomes for reconciliation; worker leases alone cannot prevent duplicate CRM effects. Backup, recovery and retention settings remain proposals to define.
- Service: IBM Cloud Databases for PostgreSQL
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617070726f76616c2d6c6564676572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component action-executor: Approved action executor

- Responsibility: Separate private IBM Cloud Code Engine worker deployment owns narrowly scoped CRM write credentials. Claims approved outbox operations, validates payload hash, approver authority, allowlist and current case preconditions, then sends the approved reply or account action. No public execution endpoint and no model-selected arbitrary tools. Uses stable destination idempotency keys where supported; after uncertain outcomes, reconciles by operation ID or blocks for staff investigation instead of blindly retrying. CRM capability qualification is required before writes are enabled. Failed and stale operations return to staff review. Implementation and fault-injection tests remain engineering work.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-616374696f6e2d6578656375746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component service-secrets: Scoped integration credentials

- Responsibility: Proposed IBM Cloud Secrets Manager stores integration secrets. Separate application and executor service identities receive only the secrets needed for their responsibilities. CRM write secrets are available only to the executor. Credential issuance, rotation and runtime access need implementation and verification; no credentials belong in the diagram.
- Service: IBM Cloud Secrets Manager
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736572766963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component operational-logs: Operational visibility

- Responsibility: Proposed IBM Cloud Logs receives redacted application and executor events correlated by case and operation ID. Monitor failed drafting, denied approval, stalled execution and ambiguous CRM outcomes. Approval evidence remains in the durable ledger. Avoid raw case text and secrets in logs. Alert routing, retention, access and operational ownership require implementation and agreement.
- Service: IBM Cloud Logs
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### staff-app: support-staff → copilot-app

- Drawn payload/purpose: HTTPS: review drafts, approve exact operations, receive status
- Contract task: TASK-CONTRACT-73746166662d617070
- Integration task: TASK-INTEGRATION-73746166662d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: copilot-app → staff-identity

- Drawn payload/purpose: OIDC sign-in and server token validation; implementation required
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-crm-read: copilot-app → existing-crm

- Drawn payload/purpose: Read authorized case and revision through CRM API; unresolved
- Contract task: TASK-CONTRACT-6170702d63726d2d72656164
- Integration task: TASK-INTEGRATION-6170702d63726d2d72656164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-knowledge-read: copilot-app → approved-knowledge

- Drawn payload/purpose: Permission-filtered approved excerpts and source revisions; unresolved
- Contract task: TASK-CONTRACT-6170702d6b6e6f776c656467652d72656164
- Integration task: TASK-INTEGRATION-6170702d6b6e6f776c656467652d72656164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-model: copilot-app → draft-model

- Drawn payload/purpose: HTTPS inference: approved context → draft and recommendations
- Contract task: TASK-CONTRACT-6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-ledger: copilot-app → approval-ledger

- Drawn payload/purpose: TLS SQL: drafts, approval transaction, outbox and status reads
- Contract task: TASK-CONTRACT-6170702d6c6564676572
- Integration task: TASK-INTEGRATION-6170702d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-ledger: action-executor → approval-ledger

- Drawn payload/purpose: TLS SQL: claim approved operations; record outcomes and reconciliation
- Contract task: TASK-CONTRACT-6578656375746f722d6c6564676572
- Integration task: TASK-INTEGRATION-6578656375746f722d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-crm: action-executor → existing-crm

- Drawn payload/purpose: Approved CRM writes with stable operation ID; reconcile uncertain outcome
- Contract task: TASK-CONTRACT-6578656375746f722d63726d
- Integration task: TASK-INTEGRATION-6578656375746f722d63726d
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: copilot-app → service-secrets

- Drawn payload/purpose: Service identity: retrieve scoped read and application credentials
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-secrets: action-executor → service-secrets

- Drawn payload/purpose: Executor identity: retrieve narrowly scoped CRM write credentials
- Contract task: TASK-CONTRACT-6578656375746f722d73656372657473
- Integration task: TASK-INTEGRATION-6578656375746f722d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-logs: copilot-app → operational-logs

- Drawn payload/purpose: Redacted request, authorization and drafting events
- Contract task: TASK-CONTRACT-6170702d6c6f6773
- Integration task: TASK-INTEGRATION-6170702d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-logs: action-executor → operational-logs

- Drawn payload/purpose: Redacted execution, retry and recovery events
- Contract task: TASK-CONTRACT-6578656375746f722d6c6f6773
- Integration task: TASK-INTEGRATION-6578656375746f722d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
