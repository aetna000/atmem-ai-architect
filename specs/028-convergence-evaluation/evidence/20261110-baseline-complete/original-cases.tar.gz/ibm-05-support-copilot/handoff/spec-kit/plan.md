# Implementation Spec Kit

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

6 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

## Confirmed design decisions

- platform.cloud: ibm

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Support staff (support-staff): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing location; unresolved.
- Staff sign-in (staff-identity): Implementation needed; ibm, To be selected after country decision.
- Drafting and approval application (copilot-app): Implementation needed; ibm, To be selected after country decision.
- Existing CRM (existing-crm): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing placement; unresolved.
- Approved support knowledge (approved-knowledge): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing placement; unresolved.
- Grounded draft generation (draft-model): Implementation needed; ibm, To be selected after country decision.
- Approval and action ledger (approval-ledger): Implementation needed; ibm, To be selected after country decision.
- Approved action executor (action-executor): Implementation needed; ibm, To be selected after country decision.
- Scoped integration credentials (service-secrets): Implementation needed; ibm, To be selected after country decision.
- Operational visibility (operational-logs): Implementation needed; ibm, To be selected after country decision.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
