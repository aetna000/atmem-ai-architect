# Questions and assumptions to resolve

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

- [ai-explicit-approval] Confirm REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.
- [ai-no-duplicate-actions] Confirm REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.
- [ai-grounded-case-drafts] Confirm REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.
- [acceptance-ai-explicit-approval] Agree a measurable acceptance check for REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.
- [acceptance-ai-no-duplicate-actions] Agree a measurable acceptance check for REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.
- [acceptance-ai-grounded-case-drafts] Agree a measurable acceptance check for REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d6578706c696369742d617070726f76616c] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d636173652d647261667473] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6e6f2d6475706c69636174652d616374696f6e73] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
