# Implementation Spec Kit

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

6 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

## Confirmed design decisions

- platform.cloud: ibm

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Support staff (support-staff): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing location; unresolved.
- Staff sign-in (staff-identity): Implementation needed; ibm, To be selected after country decision.
- Drafting and approval application (copilot-app): Implementation needed; ibm, To be selected after country decision.
- Existing CRM (existing-crm): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing placement; unresolved.
- Approved support knowledge (approved-knowledge): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing placement; unresolved.
- Grounded draft generation (draft-model): Implementation needed; ibm, To be selected after country decision.
- Approval and action ledger (approval-ledger): Implementation needed; ibm, To be selected after country decision.
- Approved action executor (action-executor): Implementation needed; ibm, To be selected after country decision.
- Scoped integration credentials (service-secrets): Implementation needed; ibm, To be selected after country decision.
- Operational visibility (operational-logs): Implementation needed; ibm, To be selected after country decision.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### decision-data.country — priority 1

The data country and processing boundary is not independently confirmed.

Action: Record an explicit data.country decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d6578706c696369742d617070726f76616c — priority 1

REQ-003 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c

### requirement-proposed-61692d67726f756e6465642d636173652d647261667473 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d67726f756e6465642d636173652d647261667473

### requirement-proposed-61692d6e6f2d6475706c69636174652d616374696f6e73 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73

### placement-616374696f6e2d6578656375746f72 — priority 2

Approved action executor: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-616374696f6e2d6578656375746f72

### placement-617070726f76616c2d6c6564676572 — priority 2

Approval and action ledger: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-617070726f76616c2d6c6564676572

### placement-636f70696c6f742d617070 — priority 2

Drafting and approval application: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-636f70696c6f742d617070

### placement-64726166742d6d6f64656c — priority 2

Grounded draft generation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-64726166742d6d6f64656c

### placement-6f7065726174696f6e616c2d6c6f6773 — priority 2

Operational visibility: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773

### placement-736572766963652d73656372657473 — priority 2

Scoped integration credentials: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-736572766963652d73656372657473

### placement-73746166662d6964656e74697479 — priority 2

Staff sign-in: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-73746166662d6964656e74697479

### review-5345432d3030323a616374696f6e2d6578656375746f722c617070726f76616c2d6c65646765722c617070726f7665642d6b6e6f776c656467652c636f70696c6f742d6170702c64726166742d6d6f64656c2c6578697374696e672d63726d2c6f7065726174696f6e616c2d6c6f67732c736572766963652d736563726574732c73746166662d6964656e746974792c737570706f72742d7374616666 — priority 2

Sensitive data is involved but where it must be stored is not stated.

Action: Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks.

Tasks: TASK-SECURITY-DESIGN, TASK-SECURITY

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

10 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d6578706c696369742d617070726f76616c — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c

### acceptance-61692d67726f756e6465642d636173652d647261667473 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d67726f756e6465642d636173652d647261667473

### acceptance-61692d6e6f2d6475706c69636174652d616374696f6e73 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73

### implementation-616374696f6e2d6578656375746f72 — priority 2

Approved action executor: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-616374696f6e2d6578656375746f72

### implementation-617070726f76616c2d6c6564676572 — priority 2

Approval and action ledger: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-617070726f76616c2d6c6564676572

### implementation-636f70696c6f742d617070 — priority 2

Drafting and approval application: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-636f70696c6f742d617070

### implementation-64726166742d6d6f64656c — priority 2

Grounded draft generation: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-64726166742d6d6f64656c

### implementation-6f7065726174696f6e616c2d6c6f6773 — priority 2

Operational visibility: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773

### implementation-736572766963652d73656372657473 — priority 2

Scoped integration credentials: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-736572766963652d73656372657473

### implementation-73746166662d6964656e74697479 — priority 2

Staff sign-in: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-73746166662d6964656e74697479

### existing-617070726f7665642d6b6e6f776c65646765 — priority 2

Approved support knowledge: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765

### existing-6578697374696e672d63726d — priority 2

Existing CRM: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-6578697374696e672d63726d

### existing-737570706f72742d7374616666 — priority 2

Support staff: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-737570706f72742d7374616666


# Component and interface contracts

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component support-staff: Support staff

- Responsibility: Existing staff using a browser outside provisioning scope. Review cited drafts and exact proposed actions, edit or reject them, and explicitly approve individual operations. Staff permissions must be checked by the server.
- Service: Approval workflow
- Provider / placement: tools / Existing location; unresolved
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-737570706f72742d7374616666
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component staff-identity: Staff sign-in

- Responsibility: Proposed IBM Cloud App ID authentication for the staff application. Company identity federation, MFA and account lifecycle need qualification. The application separately enforces case access and approval permissions; authentication alone does not authorize actions.
- Service: IBM Cloud App ID
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component copilot-app: Drafting and approval application

- Responsibility: Proposed IBM Cloud Code Engine application owns the staff web interface and server API. Reads authorized CRM cases and approved knowledge, requests grounded drafts and returns citations and action recommendations. Treats source content as untrusted. Enforces staff authorization, anti-forgery protection and approval bound to exact payload, case version and knowledge version; edits invalidate approval. Atomically records approval and execution intent. Has read-only CRM credentials and cannot send replies or change accounts. Application code, hosting ingress and integrations remain engineering work; no supplied-image contract is selected.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f70696c6f742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component existing-crm: Existing CRM

- Responsibility: Client-owned existing CRM; vendor and API capabilities are unknown. Provides cases and receives only approved replies or allowlisted account changes. Must qualify read/write permissions, case-version checks, operation IDs, idempotency and outcome lookup before enabling writes. No modification or provisioning of the CRM is implied.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing placement; unresolved
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6578697374696e672d63726d
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component approved-knowledge: Approved support knowledge

- Responsibility: Existing approved support knowledge; repository and retrieval interface remain unknown. Application retrieves only content the staff member may access, retaining source identifiers and revisions for citations. Source changes and unavailable or insufficient evidence must be surfaced before approval. Connector and permission-preserving retrieval require implementation.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing placement; unresolved
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component draft-model: Grounded draft generation

- Responsibility: Proposed IBM watsonx.ai inference generates draft replies and structured action recommendations from minimized case data and approved excerpts. No action tools or CRM credentials. Model choice, structured-output handling, grounding evaluation, quotas, data handling and regional availability require qualification. Missing evidence produces a review warning rather than an unsupported answer.
- Service: IBM watsonx.ai
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-64726166742d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component approval-ledger: Approval and action ledger

- Responsibility: Proposed managed PostgreSQL stores versioned drafts, exact action payload hashes, approver identity, approval state, transactional outbox, unique operation IDs and execution results. Atomic claims and uniqueness constraints prevent concurrent duplicate dispatch. Approved payload changes require new approval. Retain ambiguous outcomes for reconciliation; worker leases alone cannot prevent duplicate CRM effects. Backup, recovery and retention settings remain proposals to define.
- Service: IBM Cloud Databases for PostgreSQL
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617070726f76616c2d6c6564676572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component action-executor: Approved action executor

- Responsibility: Separate private IBM Cloud Code Engine worker deployment owns narrowly scoped CRM write credentials. Claims approved outbox operations, validates payload hash, approver authority, allowlist and current case preconditions, then sends the approved reply or account action. No public execution endpoint and no model-selected arbitrary tools. Uses stable destination idempotency keys where supported; after uncertain outcomes, reconciles by operation ID or blocks for staff investigation instead of blindly retrying. CRM capability qualification is required before writes are enabled. Failed and stale operations return to staff review. Implementation and fault-injection tests remain engineering work.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-616374696f6e2d6578656375746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component service-secrets: Scoped integration credentials

- Responsibility: Proposed IBM Cloud Secrets Manager stores integration secrets. Separate application and executor service identities receive only the secrets needed for their responsibilities. CRM write secrets are available only to the executor. Credential issuance, rotation and runtime access need implementation and verification; no credentials belong in the diagram.
- Service: IBM Cloud Secrets Manager
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736572766963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component operational-logs: Operational visibility

- Responsibility: Proposed IBM Cloud Logs receives redacted application and executor events correlated by case and operation ID. Monitor failed drafting, denied approval, stalled execution and ambiguous CRM outcomes. Approval evidence remains in the durable ledger. Avoid raw case text and secrets in logs. Alert routing, retention, access and operational ownership require implementation and agreement.
- Service: IBM Cloud Logs
- Provider / placement: ibm / To be selected after country decision
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### staff-app: support-staff → copilot-app

- Drawn payload/purpose: HTTPS: review drafts, approve exact operations, receive status
- Contract task: TASK-CONTRACT-73746166662d617070
- Integration task: TASK-INTEGRATION-73746166662d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: copilot-app → staff-identity

- Drawn payload/purpose: OIDC sign-in and server token validation; implementation required
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-crm-read: copilot-app → existing-crm

- Drawn payload/purpose: Read authorized case and revision through CRM API; unresolved
- Contract task: TASK-CONTRACT-6170702d63726d2d72656164
- Integration task: TASK-INTEGRATION-6170702d63726d2d72656164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-knowledge-read: copilot-app → approved-knowledge

- Drawn payload/purpose: Permission-filtered approved excerpts and source revisions; unresolved
- Contract task: TASK-CONTRACT-6170702d6b6e6f776c656467652d72656164
- Integration task: TASK-INTEGRATION-6170702d6b6e6f776c656467652d72656164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-model: copilot-app → draft-model

- Drawn payload/purpose: HTTPS inference: approved context → draft and recommendations
- Contract task: TASK-CONTRACT-6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-ledger: copilot-app → approval-ledger

- Drawn payload/purpose: TLS SQL: drafts, approval transaction, outbox and status reads
- Contract task: TASK-CONTRACT-6170702d6c6564676572
- Integration task: TASK-INTEGRATION-6170702d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-ledger: action-executor → approval-ledger

- Drawn payload/purpose: TLS SQL: claim approved operations; record outcomes and reconciliation
- Contract task: TASK-CONTRACT-6578656375746f722d6c6564676572
- Integration task: TASK-INTEGRATION-6578656375746f722d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-crm: action-executor → existing-crm

- Drawn payload/purpose: Approved CRM writes with stable operation ID; reconcile uncertain outcome
- Contract task: TASK-CONTRACT-6578656375746f722d63726d
- Integration task: TASK-INTEGRATION-6578656375746f722d63726d
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: copilot-app → service-secrets

- Drawn payload/purpose: Service identity: retrieve scoped read and application credentials
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-secrets: action-executor → service-secrets

- Drawn payload/purpose: Executor identity: retrieve narrowly scoped CRM write credentials
- Contract task: TASK-CONTRACT-6578656375746f722d73656372657473
- Integration task: TASK-INTEGRATION-6578656375746f722d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-logs: copilot-app → operational-logs

- Drawn payload/purpose: Redacted request, authorization and drafting events
- Contract task: TASK-CONTRACT-6170702d6c6f6773
- Integration task: TASK-INTEGRATION-6170702d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-logs: action-executor → operational-logs

- Drawn payload/purpose: Redacted execution, retry and recovery events
- Contract task: TASK-CONTRACT-6578656375746f722d6c6f6773
- Integration task: TASK-INTEGRATION-6578656375746f722d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-73746166662d617070 — Define Support staff → Drafting and approval application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: support-staff, copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection staff-app: HTTPS: review drafts, approve exact operations, receive status. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge staff-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6964656e74697479 — Define Drafting and approval application → Staff sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, staff-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-identity: OIDC sign-in and server token validation; implementation required. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-identity
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d63726d2d72656164 — Define Drafting and approval application → Existing CRM

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-crm-read: Read authorized case and revision through CRM API; unresolved. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-crm-read
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6b6e6f776c656467652d72656164 — Define Drafting and approval application → Approved support knowledge

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, approved-knowledge
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-knowledge-read: Permission-filtered approved excerpts and source revisions; unresolved. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-knowledge-read
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6d6f64656c — Define Drafting and approval application → Grounded draft generation

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-model: HTTPS inference: approved context → draft and recommendations. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6c6564676572 — Define Drafting and approval application → Approval and action ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-ledger: TLS SQL: drafts, approval transaction, outbox and status reads. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-ledger
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d6c6564676572 — Define Approved action executor → Approval and action ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-ledger: TLS SQL: claim approved operations; record outcomes and reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-ledger
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d63726d — Define Approved action executor → Existing CRM

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-crm: Approved CRM writes with stable operation ID; reconcile uncertain outcome. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-crm
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d73656372657473 — Define Drafting and approval application → Scoped integration credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-secrets: Service identity: retrieve scoped read and application credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d73656372657473 — Define Approved action executor → Scoped integration credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-secrets: Executor identity: retrieve narrowly scoped CRM write credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6c6f6773 — Define Drafting and approval application → Operational visibility

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-logs: Redacted request, authorization and drafting events. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-logs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d6c6f6773 — Define Approved action executor → Operational visibility

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-logs: Redacted execution, retry and recovery events. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-logs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-737570706f72742d7374616666 — Integrate existing Support staff

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d617070
- Components: support-staff
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing staff using a browser outside provisioning scope. Review cited drafts and exact proposed actions, edit or reject them, and explicitly approve individual operations. Staff permissions must be checked by the server.
2. Verify Approval workflow on tools in Existing location; unresolved; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component support-staff
- Application/configuration and tests for Support staff

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73746166662d6964656e74697479 — Implement Staff sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6964656e74697479
- Components: staff-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud App ID authentication for the staff application. Company identity federation, MFA and account lifecycle need qualification. The application separately enforces case access and approval permissions; authentication alone does not authorize actions.
2. Verify IBM Cloud App ID on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud App ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-identity
- Application/configuration and tests for Staff sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f70696c6f742d617070 — Implement Drafting and approval application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d617070, TASK-CONTRACT-6170702d6964656e74697479, TASK-CONTRACT-6170702d63726d2d72656164, TASK-CONTRACT-6170702d6b6e6f776c656467652d72656164, TASK-CONTRACT-6170702d6d6f64656c, TASK-CONTRACT-6170702d6c6564676572, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-6170702d6c6f6773
- Components: copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval, ai-grounded-case-drafts

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Code Engine application owns the staff web interface and server API. Reads authorized CRM cases and approved knowledge, requests grounded drafts and returns citations and action recommendations. Treats source content as untrusted. Enforces staff authorization, anti-forgery protection and approval bound to exact payload, case version and knowledge version; edits invalidate approval. Atomically records approval and execution intent. Has read-only CRM credentials and cannot send replies or change accounts. Application code, hosting ingress and integrations remain engineering work; no supplied-image contract is selected.
2. Verify IBM Cloud Code Engine on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.; REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component copilot-app
- Application/configuration and tests for Drafting and approval application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6578697374696e672d63726d — Integrate existing Existing CRM

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d63726d2d72656164, TASK-CONTRACT-6578656375746f722d63726d
- Components: existing-crm
- Generated files: No implementation files generated yet
- Requirements: ai-no-duplicate-actions, ai-grounded-case-drafts

### Implementation steps

1. Responsibility from the board: Client-owned existing CRM; vendor and API capabilities are unknown. Provides cases and receives only approved replies or allowlisted account changes. Must qualify read/write permissions, case-version checks, operation IDs, idempotency and outcome lookup before enabling writes. No modification or provisioning of the CRM is implied.
2. Verify Storage or existing data connector on tools in Existing placement; unresolved; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.; REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component existing-crm
- Application/configuration and tests for Existing CRM

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765 — Integrate existing Approved support knowledge

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6b6e6f776c656467652d72656164
- Components: approved-knowledge
- Generated files: No implementation files generated yet
- Requirements: ai-grounded-case-drafts

### Implementation steps

1. Responsibility from the board: Existing approved support knowledge; repository and retrieval interface remain unknown. Application retrieves only content the staff member may access, retaining source identifiers and revisions for citations. Source changes and unavailable or insufficient evidence must be surfaced before approval. Connector and permission-preserving retrieval require implementation.
2. Verify Storage or existing data connector on tools in Existing placement; unresolved; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component approved-knowledge
- Application/configuration and tests for Approved support knowledge

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-64726166742d6d6f64656c — Implement Grounded draft generation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6d6f64656c
- Components: draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-case-drafts

### Implementation steps

1. Responsibility from the board: Proposed IBM watsonx.ai inference generates draft replies and structured action recommendations from minimized case data and approved excerpts. No action tools or CRM credentials. Model choice, structured-output handling, grounding evaluation, quotas, data handling and regional availability require qualification. Missing evidence produces a review warning rather than an unsupported answer.
2. Verify IBM watsonx.ai on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM watsonx.ai; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component draft-model
- Application/configuration and tests for Grounded draft generation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617070726f76616c2d6c6564676572 — Implement Approval and action ledger

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6c6564676572, TASK-CONTRACT-6578656375746f722d6c6564676572
- Components: approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval, ai-no-duplicate-actions

### Implementation steps

1. Responsibility from the board: Proposed managed PostgreSQL stores versioned drafts, exact action payload hashes, approver identity, approval state, transactional outbox, unique operation IDs and execution results. Atomic claims and uniqueness constraints prevent concurrent duplicate dispatch. Approved payload changes require new approval. Retain ambiguous outcomes for reconciliation; worker leases alone cannot prevent duplicate CRM effects. Backup, recovery and retention settings remain proposals to define.
2. Verify IBM Cloud Databases for PostgreSQL on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Databases for PostgreSQL; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.; REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component approval-ledger
- Application/configuration and tests for Approval and action ledger

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-616374696f6e2d6578656375746f72 — Implement Approved action executor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6578656375746f722d6c6564676572, TASK-CONTRACT-6578656375746f722d63726d, TASK-CONTRACT-6578656375746f722d73656372657473, TASK-CONTRACT-6578656375746f722d6c6f6773
- Components: action-executor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval, ai-no-duplicate-actions

### Implementation steps

1. Responsibility from the board: Separate private IBM Cloud Code Engine worker deployment owns narrowly scoped CRM write credentials. Claims approved outbox operations, validates payload hash, approver authority, allowlist and current case preconditions, then sends the approved reply or account action. No public execution endpoint and no model-selected arbitrary tools. Uses stable destination idempotency keys where supported; after uncertain outcomes, reconciles by operation ID or blocks for staff investigation instead of blindly retrying. CRM capability qualification is required before writes are enabled. Failed and stale operations return to staff review. Implementation and fault-injection tests remain engineering work.
2. Verify IBM Cloud Code Engine on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.; REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component action-executor
- Application/configuration and tests for Approved action executor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-736572766963652d73656372657473 — Implement Scoped integration credentials

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-6578656375746f722d73656372657473
- Components: service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Secrets Manager stores integration secrets. Separate application and executor service identities receive only the secrets needed for their responsibilities. CRM write secrets are available only to the executor. Credential issuance, rotation and runtime access need implementation and verification; no credentials belong in the diagram.
2. Verify IBM Cloud Secrets Manager on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Secrets Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component service-secrets
- Application/configuration and tests for Scoped integration credentials

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773 — Implement Operational visibility

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6c6f6773, TASK-CONTRACT-6578656375746f722d6c6f6773
- Components: operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Logs receives redacted application and executor events correlated by case and operation ID. Monitor failed drafting, denied approval, stalled execution and ambiguous CRM outcomes. Approval evidence remains in the durable ledger. Avoid raw case text and secrets in logs. Alert routing, retention, access and operational ownership require implementation and agreement.
2. Verify IBM Cloud Logs on ibm in To be selected after country decision; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Logs; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component operational-logs
- Application/configuration and tests for Operational visibility

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-73746166662d617070 — Wire Support staff to Drafting and approval application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73746166662d617070, TASK-RESOURCE-737570706f72742d7374616666, TASK-RESOURCE-636f70696c6f742d617070
- Components: support-staff, copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge staff-app carrying HTTPS: review drafts, approve exact operations, receive status, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation staff-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6964656e74697479 — Wire Drafting and approval application to Staff sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6964656e74697479, TASK-RESOURCE-73746166662d6964656e74697479, TASK-RESOURCE-636f70696c6f742d617070
- Components: copilot-app, staff-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-identity carrying OIDC sign-in and server token validation; implementation required, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-identity
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d63726d2d72656164 — Wire Drafting and approval application to Existing CRM

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d63726d2d72656164, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-6578697374696e672d63726d
- Components: copilot-app, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-crm-read carrying Read authorized case and revision through CRM API; unresolved, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-crm-read
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6b6e6f776c656467652d72656164 — Wire Drafting and approval application to Approved support knowledge

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6b6e6f776c656467652d72656164, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Components: copilot-app, approved-knowledge
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-knowledge-read carrying Permission-filtered approved excerpts and source revisions; unresolved, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-knowledge-read
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6d6f64656c — Wire Drafting and approval application to Grounded draft generation

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6d6f64656c, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-64726166742d6d6f64656c
- Components: copilot-app, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-model carrying HTTPS inference: approved context → draft and recommendations, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6c6564676572 — Wire Drafting and approval application to Approval and action ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6c6564676572, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-617070726f76616c2d6c6564676572
- Components: copilot-app, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-ledger carrying TLS SQL: drafts, approval transaction, outbox and status reads, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-ledger
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d6c6564676572 — Wire Approved action executor to Approval and action ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d6c6564676572, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-ledger carrying TLS SQL: claim approved operations; record outcomes and reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-ledger
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d63726d — Wire Approved action executor to Existing CRM

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d63726d, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-616374696f6e2d6578656375746f72
- Components: action-executor, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-crm carrying Approved CRM writes with stable operation ID; reconcile uncertain outcome, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-crm
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d73656372657473 — Wire Drafting and approval application to Scoped integration credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d73656372657473, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-736572766963652d73656372657473
- Components: copilot-app, service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-secrets carrying Service identity: retrieve scoped read and application credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d73656372657473 — Wire Approved action executor to Scoped integration credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d73656372657473, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-736572766963652d73656372657473
- Components: action-executor, service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-secrets carrying Executor identity: retrieve narrowly scoped CRM write credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6c6f6773 — Wire Drafting and approval application to Operational visibility

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6c6f6773, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Components: copilot-app, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-logs carrying Redacted request, authorization and drafting events, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-logs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d6c6f6773 — Wire Approved action executor to Operational visibility

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d6c6f6773, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Components: action-executor, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-logs carrying Redacted execution, retry and recovery events, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-logs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-73746166662d617070 — Verify live Support staff → Drafting and approval application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73746166662d617070
- Components: support-staff, copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge staff-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence staff-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6964656e74697479 — Verify live Drafting and approval application → Staff sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6964656e74697479
- Components: copilot-app, staff-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-identity with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-identity

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d63726d2d72656164 — Verify live Drafting and approval application → Existing CRM

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d63726d2d72656164
- Components: copilot-app, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-crm-read with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-crm-read

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6b6e6f776c656467652d72656164 — Verify live Drafting and approval application → Approved support knowledge

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6b6e6f776c656467652d72656164
- Components: copilot-app, approved-knowledge
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-knowledge-read with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-knowledge-read

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6d6f64656c — Verify live Drafting and approval application → Grounded draft generation

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6d6f64656c
- Components: copilot-app, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6c6564676572 — Verify live Drafting and approval application → Approval and action ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6c6564676572
- Components: copilot-app, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-ledger with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-ledger

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572 — Verify live Approved action executor → Approval and action ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d6c6564676572
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-ledger with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-ledger

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d63726d — Verify live Approved action executor → Existing CRM

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d63726d
- Components: action-executor, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-crm with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-crm

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d73656372657473 — Verify live Drafting and approval application → Scoped integration credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d73656372657473
- Components: copilot-app, service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473 — Verify live Approved action executor → Scoped integration credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d73656372657473
- Components: action-executor, service-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6c6f6773 — Verify live Drafting and approval application → Operational visibility

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6c6f6773
- Components: copilot-app, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-logs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-logs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d6c6f6773 — Verify live Approved action executor → Operational visibility

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d6c6f6773
- Components: action-executor, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-logs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-logs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c — Verify REQ-003: Every outbound reply and account change must require server-validated approval by an authorized staff member of the exact operation payload and version. Editing an approved operation invalidates its approval. The model and drafting application must not hold CRM write credentials; unapproved or non-allowlisted operations must be denied.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-73746166662d6964656e74697479, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-INTEGRATION-LIVE-73746166662d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d63726d2d72656164, TASK-INTEGRATION-LIVE-6170702d6b6e6f776c656467652d72656164, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-6578656375746f722d6c6f6773
- Components: copilot-app, staff-identity, approval-ledger, action-executor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval

### Implementation steps

1. Basis: User: “Nothing is sent or changed until a staff member explicitly approves it.” Proposed copilot-app, approval-ledger and action-executor boundaries.; rationale: Prevents unapproved communications or account changes, including when a draft changes after review.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73 — Verify REQ-004: Retries, concurrent workers and recovery after a crash must not repeat an approved operation's external effect. Persist a stable operation ID and use qualified destination idempotency or authoritative outcome reconciliation. An uncertain result must block automatic resubmission until resolved. Acceptance tests must cover a successful CRM write followed by a lost response and worker restart; writes remain disabled until a safe destination contract is demonstrated.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-INTEGRATION-LIVE-6170702d63726d2d72656164, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d6c6f6773
- Components: approval-ledger, action-executor, existing-crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-no-duplicate-actions

### Implementation steps

1. Basis: User: “Retries must not perform an action twice.” Proposed approval-ledger and action-executor.; rationale: A CRM write may succeed before a timeout or worker crash; retrying without destination reconciliation can repeat the business effect.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d636173652d647261667473 — Verify REQ-005: The copilot must read only authorized case information and approved support knowledge, produce a reviewable response draft and separate action recommendations, and retain supporting source identifiers and revisions. Proposed control: show citations and clearly flag insufficient or conflicting evidence before approval. Treat retrieved content as untrusted data and never as execution authority.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-64726166742d6d6f64656c, TASK-INTEGRATION-LIVE-73746166662d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d63726d2d72656164, TASK-INTEGRATION-LIVE-6170702d6b6e6f776c656467652d72656164, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773
- Components: copilot-app, existing-crm, approved-knowledge, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-case-drafts

### Implementation steps

1. Basis: User: “reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions.” Citations and insufficient-evidence warnings are proposed review controls.; rationale: Staff need traceable evidence to review a draft, and case or knowledge content must not bypass access restrictions or authorize actions.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-737570706f72742d7374616666, TASK-RESOURCE-73746166662d6964656e74697479, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-736572766963652d73656372657473, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773, TASK-INTEGRATION-73746166662d617070, TASK-INTEGRATION-6170702d6964656e74697479, TASK-INTEGRATION-6170702d63726d2d72656164, TASK-INTEGRATION-6170702d6b6e6f776c656467652d72656164, TASK-INTEGRATION-6170702d6d6f64656c, TASK-INTEGRATION-6170702d6c6564676572, TASK-INTEGRATION-6578656375746f722d6c6564676572, TASK-INTEGRATION-6578656375746f722d63726d, TASK-INTEGRATION-6170702d73656372657473, TASK-INTEGRATION-6578656375746f722d73656372657473, TASK-INTEGRATION-6170702d6c6f6773, TASK-INTEGRATION-6578656375746f722d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-737570706f72742d7374616666, TASK-RESOURCE-73746166662d6964656e74697479, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-736572766963652d73656372657473, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773, TASK-INTEGRATION-LIVE-73746166662d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d63726d2d72656164, TASK-INTEGRATION-LIVE-6170702d6b6e6f776c656467652d72656164, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-6578656375746f722d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c, TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73, TASK-ACCEPTANCE-61692d67726f756e6465642d636173652d647261667473, TASK-INTEGRATION-LIVE-73746166662d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d63726d2d72656164, TASK-INTEGRATION-LIVE-6170702d6b6e6f776c656467652d72656164, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-6578656375746f722d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot a7071c3d-630f-4834-bf9a-697925e38a90 · design r2 · generated 2026-11-09T18:10:11.932Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-003 (ai-explicit-approval) → TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c; Proposed; needs confirmation
- REQ-004 (ai-no-duplicate-actions) → TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73; Proposed; needs confirmation
- REQ-005 (ai-grounded-case-drafts) → TASK-ACCEPTANCE-61692d67726f756e6465642d636173652d647261667473; Proposed; needs confirmation
