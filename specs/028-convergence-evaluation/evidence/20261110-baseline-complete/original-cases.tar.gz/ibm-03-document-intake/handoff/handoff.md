# Delivery handoff

Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Application sign-in / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: price needed.
- Invoice ledger and durable work queue / Storage: price needed.
- Structured invoice extraction / Endpoint hours: price needed.
- Service credentials / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Extraction and approved-delivery worker: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Processing and recovery visibility: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: Implementation needed.
- Application sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice ledger and durable work queue: Implementation needed.
- Extraction and approved-delivery worker: Implementation needed.
- Structured invoice extraction: Implementation needed.
- Service credentials: Implementation needed.
- Processing and recovery visibility: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-users: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-model: implement data flow, access policy and acceptance test.
- Wire invoice-worker → accounting-api: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-logs: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-logs: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
