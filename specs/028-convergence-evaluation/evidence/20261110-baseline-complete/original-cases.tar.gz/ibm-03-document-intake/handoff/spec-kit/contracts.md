# Component and interface contracts

Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component invoice-users: Uploaders and reviewers

- Responsibility: Existing people using a browser, outside provisioning scope. Uploaders submit PDFs; authorised reviewers inspect source documents, correct extracted fields and approve a specific result revision. Whether these are separate groups remains open. Browser downloads expose personal data to authorised users; managed-service residency does not establish the location of their devices.
- Service: Approval workflow
- Provider / placement: tools / Existing client locations — not established
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component invoice-app: Invoice upload and review application

- Responsibility: Proposed Code Engine application serving the browser interface and authenticated API. Enforces upload/reviewer permissions server-side and accepts PDF invoices up to 10 MB; proposed interpretation is 10,000,000 bytes, enforced while streaming. Validates document type and registers durable intake work for approximately 500 invoices/day without assuming a peak arrival rate. Returns status, source previews and review queue. Approval binds the corrected result revision and atomically creates an accounting outbox record; later edits invalidate approval. Handles personal data without logging document content. Proposed private service access where supported, with authenticated HTTPS browser ingress. Australian hosting, application code, hosting configuration and integrations require implementation and qualification.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-identity: Application sign-in

- Responsibility: Proposed IBM Cloud App ID instance for application sign-in. Australian availability, identity-data processing, company federation and lifecycle ownership remain unverified. No PDF or extracted invoice fields are sent to the identity service. The application validates sessions and independently authorises uploader/reviewer actions; sign-in alone does not grant approval rights.
- Service: IBM Cloud App ID
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-files: Private invoice PDFs

- Responsibility: Proposed private IBM Cloud Object Storage bucket for immutable invoice PDFs up to 10 MB, potentially containing personal data. Application identity writes documents; worker identity reads exact objects; reviewers obtain authorised access through the application. Ledger holds exact object references and content hashes. Retain originals for 90 days, proposed from intake, then delete all relevant object versions and clean incomplete uploads. Storage, replication and recovery copies must stay in Australia. Public access is prohibited. Encryption, lifecycle enforcement, deletion evidence and Australian service configuration remain implementation and verification work; immutability must not prevent scheduled expiry.
- Service: IBM Cloud Object Storage
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d66696c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-ledger: Invoice ledger and durable work queue

- Responsibility: Proposed managed PostgreSQL deployment holding intake keys, account-scoped unique document hashes, source references, extraction revisions, review records, approval audit and accounting outbox. Transactions, unique constraints, leased claims and fenced completion prevent concurrent retries creating duplicate intake or applying stale results. Expired leases recover work; exhausted tasks remain visible for replay. Different scans of one business invoice require additional duplicate detection. Retain originals' references and extraction audit history for 90 days, proposed from intake, with coordinated expiry of derived personal data. Backup expiry and restore procedures must enforce the retention boundary and remain in Australia. Long-lived deduplication evidence and delivery reconciliation after expiry require an explicit minimal-data policy; do not silently retain invoice content indefinitely. Australian availability, recovery targets and operational configuration remain unverified.
- Service: IBM Cloud Databases for PostgreSQL
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6c6564676572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-worker: Extraction and approved-delivery worker

- Responsibility: Proposed separate Code Engine job deployment with scheduled invocation draining durable work for approximately 500 invoices/day. Claims leased tasks, reads exact PDFs and performs sandboxed text extraction or OCR for scans inside Australia. Bounds PDF pages, decompression, runtime and temporary storage independently of the 10 MB upload limit; cleans temporary files after processing. Treats document instructions as untrusted. Validates supplier, date, decimal total and currency; uncertain or invalid fields enter review without fabrication. Bounded retries and terminal records support recovery. Delivers only approved immutable revisions with a stable accounting idempotency key and receipt; ambiguous outcomes enter reconciliation unless destination retry safety is established. Also performs leased retention cleanup with expiry checks preventing processing of deleted records. Australian compute, OCR, scheduling and all integrations require implementation and qualification.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d776f726b6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-model: Structured invoice extraction

- Responsibility: Proposed watsonx.ai inference receiving extracted invoice text, potentially containing personal data, and returning candidate supplier, invoice date, total and currency with supporting text references. No model ID, entitlement or Australian endpoint is verified. Australian processing, provider retention and data-use terms, structured outputs, quotas and representative-invoice accuracy must be qualified before invoice data is sent. No cross-border inference fallback is permitted. OCR belongs to the worker and is not assumed to be native model functionality. If a suitable Australian endpoint is unavailable, retain the extraction requirement and resolve an IBM-hosted in-country implementation before delivery.
- Service: IBM watsonx.ai
- Provider / placement: ibm / Australia — model availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component accounting-api: Existing accounting API

- Responsibility: Client's existing accounting API, outside provisioning scope. Receives only reviewer-approved invoice revisions. Its processing location, subprocessors and retention are not established; the Australian extracted-data boundary must be resolved before transmitting real invoice data. Authentication, payload mapping, idempotency-key support, receipt lookup and failure semantics remain unresolved contracts. The architecture neither modifies this system nor proves safe retries or Australian residency.
- Service: Existing accounting API
- Provider / placement: tools / Existing location — Australian residency unverified
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6163636f756e74696e672d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component invoice-secrets: Service credentials

- Responsibility: Proposed Secrets Manager instance for required database and external API credentials. Application and worker identities receive separate least-privilege access; use IAM authentication where supported. Secret values never enter the diagram or logs, and invoice content is not stored here. Australian availability, integration and credential rotation require qualification and implementation.
- Service: IBM Cloud Secrets Manager
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-logs: Processing and recovery visibility

- Responsibility: Proposed IBM Cloud Logs instance for redacted correlation IDs, processing failures and delivery outcomes. Exclude invoice content, extracted fields, credentials and raw model payloads, including exception traces. Alert on repeated failures, stalled work, reconciliation and overdue retention cleanup; recipients and operating ownership remain open. Business extraction and approval audit stays in PostgreSQL for the specified 90 days, separate from operational logs. Australian collection, storage, alert routing, retention and service availability require qualification and implementation.
- Service: IBM Cloud Logs
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### users-app: invoice-users → invoice-app

- Drawn payload/purpose: Authenticated HTTPS: PDF upload up to 10 MB, review and approval
- Contract task: TASK-CONTRACT-75736572732d617070
- Integration task: TASK-INTEGRATION-75736572732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-users: invoice-app → invoice-users

- Drawn payload/purpose: Authorised HTTPS: review queue, source preview and status
- Contract task: TASK-CONTRACT-6170702d7573657273
- Integration task: TASK-INTEGRATION-6170702d7573657273
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: invoice-app → invoice-identity

- Drawn payload/purpose: Proposed OIDC sign-in and server session validation
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-files: invoice-app → invoice-files

- Drawn payload/purpose: Authenticated object API: private PDF writes and authorised reads in Australia
- Contract task: TASK-CONTRACT-6170702d66696c6573
- Integration task: TASK-INTEGRATION-6170702d66696c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-ledger: invoice-app → invoice-ledger

- Drawn payload/purpose: TLS SQL: intake, expiry timestamps, review and atomic approval/outbox
- Contract task: TASK-CONTRACT-6170702d6c6564676572
- Integration task: TASK-INTEGRATION-6170702d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-ledger: invoice-worker → invoice-ledger

- Drawn payload/purpose: TLS SQL: lease work, results, delivery reconciliation and retention cleanup
- Contract task: TASK-CONTRACT-776f726b65722d6c6564676572
- Integration task: TASK-INTEGRATION-776f726b65722d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-files: invoice-worker → invoice-files

- Drawn payload/purpose: Scoped object API: exact PDF reads and coordinated 90-day expiry deletion
- Contract task: TASK-CONTRACT-776f726b65722d66696c6573
- Integration task: TASK-INTEGRATION-776f726b65722d66696c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-model: invoice-worker → invoice-model

- Drawn payload/purpose: Authenticated inference: invoice text; Australian processing must be qualified
- Contract task: TASK-CONTRACT-776f726b65722d6d6f64656c
- Integration task: TASK-INTEGRATION-776f726b65722d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-accounting: invoice-worker → accounting-api

- Drawn payload/purpose: HTTPS: approved revision, delivery key and receipt; destination residency unreso
- Contract task: TASK-CONTRACT-776f726b65722d6163636f756e74696e67
- Integration task: TASK-INTEGRATION-776f726b65722d6163636f756e74696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: invoice-app → invoice-secrets

- Drawn payload/purpose: IAM-authenticated retrieval of scoped application secrets
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-secrets: invoice-worker → invoice-secrets

- Drawn payload/purpose: IAM-authenticated retrieval of scoped worker secrets
- Contract task: TASK-CONTRACT-776f726b65722d73656372657473
- Integration task: TASK-INTEGRATION-776f726b65722d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-logs: invoice-app → invoice-logs

- Drawn payload/purpose: Redacted application and access-failure logs; exclude invoice content
- Contract task: TASK-CONTRACT-6170702d6c6f6773
- Integration task: TASK-INTEGRATION-6170702d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-logs: invoice-worker → invoice-logs

- Drawn payload/purpose: Redacted processing, delivery and retention-cleanup alerts
- Contract task: TASK-CONTRACT-776f726b65722d6c6f6773
- Integration task: TASK-INTEGRATION-776f726b65722d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
