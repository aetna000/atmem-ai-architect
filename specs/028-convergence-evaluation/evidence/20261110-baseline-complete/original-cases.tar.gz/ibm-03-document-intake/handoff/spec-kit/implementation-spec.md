# Implementation Spec Kit

Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

8 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: ibm
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Uploaders and reviewers (invoice-users): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing client locations — not established.
- Invoice upload and review application (invoice-app): Implementation needed; ibm, Australia — regional availability unverified.
- Application sign-in (invoice-identity): Implementation needed; ibm, Australia — regional availability unverified.
- Private invoice PDFs (invoice-files): Implementation needed; ibm, Australia — regional availability unverified.
- Invoice ledger and durable work queue (invoice-ledger): Implementation needed; ibm, Australia — regional availability unverified.
- Extraction and approved-delivery worker (invoice-worker): Implementation needed; ibm, Australia — regional availability unverified.
- Structured invoice extraction (invoice-model): Implementation needed; ibm, Australia — model availability unverified.
- Existing accounting API (accounting-api): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — Australian residency unverified.
- Service credentials (invoice-secrets): Implementation needed; ibm, Australia — regional availability unverified.
- Processing and recovery visibility (invoice-logs): Implementation needed; ibm, Australia — regional availability unverified.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d696e766f6963652d617070726f76616c — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c

### requirement-proposed-61692d696e766f6963652d65787472616374696f6e — priority 1

REQ-003 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e

### requirement-proposed-61692d696e766f6963652d6964656d706f74656e6379 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379

### requirement-proposed-61692d696e766f6963652d696e74616b652d6361706163697479 — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d696e74616b652d6361706163697479

### requirement-proposed-61692d696e766f6963652d7265736964656e6379 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379

### requirement-proposed-61692d696e766f6963652d726574656e74696f6e — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

10 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d696e766f6963652d617070726f76616c — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c

### acceptance-61692d696e766f6963652d65787472616374696f6e — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e

### acceptance-61692d696e766f6963652d6964656d706f74656e6379 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379

### acceptance-61692d696e766f6963652d696e74616b652d6361706163697479 — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d696e74616b652d6361706163697479

### acceptance-61692d696e766f6963652d7265736964656e6379 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379

### acceptance-61692d696e766f6963652d726574656e74696f6e — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e

### implementation-696e766f6963652d617070 — priority 2

Invoice upload and review application: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d617070

### implementation-696e766f6963652d66696c6573 — priority 2

Private invoice PDFs: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d66696c6573

### implementation-696e766f6963652d6964656e74697479 — priority 2

Application sign-in: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d6964656e74697479

### implementation-696e766f6963652d6c6564676572 — priority 2

Invoice ledger and durable work queue: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d6c6564676572

### implementation-696e766f6963652d6c6f6773 — priority 2

Processing and recovery visibility: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d6c6f6773

### implementation-696e766f6963652d6d6f64656c — priority 2

Structured invoice extraction: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d6d6f64656c

### implementation-696e766f6963652d73656372657473 — priority 2

Service credentials: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d73656372657473

### implementation-696e766f6963652d776f726b6572 — priority 2

Extraction and approved-delivery worker: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d776f726b6572

### existing-6163636f756e74696e672d617069 — priority 2

Existing accounting API: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-6163636f756e74696e672d617069

### existing-696e766f6963652d7573657273 — priority 2

Uploaders and reviewers: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-696e766f6963652d7573657273


# Component and interface contracts

Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component invoice-users: Uploaders and reviewers

- Responsibility: Existing people using a browser, outside provisioning scope. Uploaders submit PDFs; authorised reviewers inspect source documents, correct extracted fields and approve a specific result revision. Whether these are separate groups remains open. Browser downloads expose personal data to authorised users; managed-service residency does not establish the location of their devices.
- Service: Approval workflow
- Provider / placement: tools / Existing client locations — not established
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component invoice-app: Invoice upload and review application

- Responsibility: Proposed Code Engine application serving the browser interface and authenticated API. Enforces upload/reviewer permissions server-side and accepts PDF invoices up to 10 MB; proposed interpretation is 10,000,000 bytes, enforced while streaming. Validates document type and registers durable intake work for approximately 500 invoices/day without assuming a peak arrival rate. Returns status, source previews and review queue. Approval binds the corrected result revision and atomically creates an accounting outbox record; later edits invalidate approval. Handles personal data without logging document content. Proposed private service access where supported, with authenticated HTTPS browser ingress. Australian hosting, application code, hosting configuration and integrations require implementation and qualification.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-identity: Application sign-in

- Responsibility: Proposed IBM Cloud App ID instance for application sign-in. Australian availability, identity-data processing, company federation and lifecycle ownership remain unverified. No PDF or extracted invoice fields are sent to the identity service. The application validates sessions and independently authorises uploader/reviewer actions; sign-in alone does not grant approval rights.
- Service: IBM Cloud App ID
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-files: Private invoice PDFs

- Responsibility: Proposed private IBM Cloud Object Storage bucket for immutable invoice PDFs up to 10 MB, potentially containing personal data. Application identity writes documents; worker identity reads exact objects; reviewers obtain authorised access through the application. Ledger holds exact object references and content hashes. Retain originals for 90 days, proposed from intake, then delete all relevant object versions and clean incomplete uploads. Storage, replication and recovery copies must stay in Australia. Public access is prohibited. Encryption, lifecycle enforcement, deletion evidence and Australian service configuration remain implementation and verification work; immutability must not prevent scheduled expiry.
- Service: IBM Cloud Object Storage
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d66696c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-ledger: Invoice ledger and durable work queue

- Responsibility: Proposed managed PostgreSQL deployment holding intake keys, account-scoped unique document hashes, source references, extraction revisions, review records, approval audit and accounting outbox. Transactions, unique constraints, leased claims and fenced completion prevent concurrent retries creating duplicate intake or applying stale results. Expired leases recover work; exhausted tasks remain visible for replay. Different scans of one business invoice require additional duplicate detection. Retain originals' references and extraction audit history for 90 days, proposed from intake, with coordinated expiry of derived personal data. Backup expiry and restore procedures must enforce the retention boundary and remain in Australia. Long-lived deduplication evidence and delivery reconciliation after expiry require an explicit minimal-data policy; do not silently retain invoice content indefinitely. Australian availability, recovery targets and operational configuration remain unverified.
- Service: IBM Cloud Databases for PostgreSQL
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6c6564676572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-worker: Extraction and approved-delivery worker

- Responsibility: Proposed separate Code Engine job deployment with scheduled invocation draining durable work for approximately 500 invoices/day. Claims leased tasks, reads exact PDFs and performs sandboxed text extraction or OCR for scans inside Australia. Bounds PDF pages, decompression, runtime and temporary storage independently of the 10 MB upload limit; cleans temporary files after processing. Treats document instructions as untrusted. Validates supplier, date, decimal total and currency; uncertain or invalid fields enter review without fabrication. Bounded retries and terminal records support recovery. Delivers only approved immutable revisions with a stable accounting idempotency key and receipt; ambiguous outcomes enter reconciliation unless destination retry safety is established. Also performs leased retention cleanup with expiry checks preventing processing of deleted records. Australian compute, OCR, scheduling and all integrations require implementation and qualification.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d776f726b6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-model: Structured invoice extraction

- Responsibility: Proposed watsonx.ai inference receiving extracted invoice text, potentially containing personal data, and returning candidate supplier, invoice date, total and currency with supporting text references. No model ID, entitlement or Australian endpoint is verified. Australian processing, provider retention and data-use terms, structured outputs, quotas and representative-invoice accuracy must be qualified before invoice data is sent. No cross-border inference fallback is permitted. OCR belongs to the worker and is not assumed to be native model functionality. If a suitable Australian endpoint is unavailable, retain the extraction requirement and resolve an IBM-hosted in-country implementation before delivery.
- Service: IBM watsonx.ai
- Provider / placement: ibm / Australia — model availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component accounting-api: Existing accounting API

- Responsibility: Client's existing accounting API, outside provisioning scope. Receives only reviewer-approved invoice revisions. Its processing location, subprocessors and retention are not established; the Australian extracted-data boundary must be resolved before transmitting real invoice data. Authentication, payload mapping, idempotency-key support, receipt lookup and failure semantics remain unresolved contracts. The architecture neither modifies this system nor proves safe retries or Australian residency.
- Service: Existing accounting API
- Provider / placement: tools / Existing location — Australian residency unverified
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6163636f756e74696e672d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component invoice-secrets: Service credentials

- Responsibility: Proposed Secrets Manager instance for required database and external API credentials. Application and worker identities receive separate least-privilege access; use IAM authentication where supported. Secret values never enter the diagram or logs, and invoice content is not stored here. Australian availability, integration and credential rotation require qualification and implementation.
- Service: IBM Cloud Secrets Manager
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-logs: Processing and recovery visibility

- Responsibility: Proposed IBM Cloud Logs instance for redacted correlation IDs, processing failures and delivery outcomes. Exclude invoice content, extracted fields, credentials and raw model payloads, including exception traces. Alert on repeated failures, stalled work, reconciliation and overdue retention cleanup; recipients and operating ownership remain open. Business extraction and approval audit stays in PostgreSQL for the specified 90 days, separate from operational logs. Australian collection, storage, alert routing, retention and service availability require qualification and implementation.
- Service: IBM Cloud Logs
- Provider / placement: ibm / Australia — regional availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### users-app: invoice-users → invoice-app

- Drawn payload/purpose: Authenticated HTTPS: PDF upload up to 10 MB, review and approval
- Contract task: TASK-CONTRACT-75736572732d617070
- Integration task: TASK-INTEGRATION-75736572732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-users: invoice-app → invoice-users

- Drawn payload/purpose: Authorised HTTPS: review queue, source preview and status
- Contract task: TASK-CONTRACT-6170702d7573657273
- Integration task: TASK-INTEGRATION-6170702d7573657273
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: invoice-app → invoice-identity

- Drawn payload/purpose: Proposed OIDC sign-in and server session validation
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-files: invoice-app → invoice-files

- Drawn payload/purpose: Authenticated object API: private PDF writes and authorised reads in Australia
- Contract task: TASK-CONTRACT-6170702d66696c6573
- Integration task: TASK-INTEGRATION-6170702d66696c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-ledger: invoice-app → invoice-ledger

- Drawn payload/purpose: TLS SQL: intake, expiry timestamps, review and atomic approval/outbox
- Contract task: TASK-CONTRACT-6170702d6c6564676572
- Integration task: TASK-INTEGRATION-6170702d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-ledger: invoice-worker → invoice-ledger

- Drawn payload/purpose: TLS SQL: lease work, results, delivery reconciliation and retention cleanup
- Contract task: TASK-CONTRACT-776f726b65722d6c6564676572
- Integration task: TASK-INTEGRATION-776f726b65722d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-files: invoice-worker → invoice-files

- Drawn payload/purpose: Scoped object API: exact PDF reads and coordinated 90-day expiry deletion
- Contract task: TASK-CONTRACT-776f726b65722d66696c6573
- Integration task: TASK-INTEGRATION-776f726b65722d66696c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-model: invoice-worker → invoice-model

- Drawn payload/purpose: Authenticated inference: invoice text; Australian processing must be qualified
- Contract task: TASK-CONTRACT-776f726b65722d6d6f64656c
- Integration task: TASK-INTEGRATION-776f726b65722d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-accounting: invoice-worker → accounting-api

- Drawn payload/purpose: HTTPS: approved revision, delivery key and receipt; destination residency unreso
- Contract task: TASK-CONTRACT-776f726b65722d6163636f756e74696e67
- Integration task: TASK-INTEGRATION-776f726b65722d6163636f756e74696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: invoice-app → invoice-secrets

- Drawn payload/purpose: IAM-authenticated retrieval of scoped application secrets
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-secrets: invoice-worker → invoice-secrets

- Drawn payload/purpose: IAM-authenticated retrieval of scoped worker secrets
- Contract task: TASK-CONTRACT-776f726b65722d73656372657473
- Integration task: TASK-INTEGRATION-776f726b65722d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-logs: invoice-app → invoice-logs

- Drawn payload/purpose: Redacted application and access-failure logs; exclude invoice content
- Contract task: TASK-CONTRACT-6170702d6c6f6773
- Integration task: TASK-INTEGRATION-6170702d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-logs: invoice-worker → invoice-logs

- Drawn payload/purpose: Redacted processing, delivery and retention-cleanup alerts
- Contract task: TASK-CONTRACT-776f726b65722d6c6f6773
- Integration task: TASK-INTEGRATION-776f726b65722d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-75736572732d617070 — Define Uploaders and reviewers → Invoice upload and review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-app: Authenticated HTTPS: PDF upload up to 10 MB, review and approval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d7573657273 — Define Invoice upload and review application → Uploaders and reviewers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-users
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-users: Authorised HTTPS: review queue, source preview and status. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-users
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6964656e74697479 — Define Invoice upload and review application → Application sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-identity: Proposed OIDC sign-in and server session validation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-identity
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d66696c6573 — Define Invoice upload and review application → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-files: Authenticated object API: private PDF writes and authorised reads in Australia. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-files
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6c6564676572 — Define Invoice upload and review application → Invoice ledger and durable work queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-ledger: TLS SQL: intake, expiry timestamps, review and atomic approval/outbox. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-ledger
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d6c6564676572 — Define Extraction and approved-delivery worker → Invoice ledger and durable work queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-ledger: TLS SQL: lease work, results, delivery reconciliation and retention cleanup. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-ledger
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d66696c6573 — Define Extraction and approved-delivery worker → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-files: Scoped object API: exact PDF reads and coordinated 90-day expiry deletion. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-files
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d6d6f64656c — Define Extraction and approved-delivery worker → Structured invoice extraction

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-model: Authenticated inference: invoice text; Australian processing must be qualified. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d6163636f756e74696e67 — Define Extraction and approved-delivery worker → Existing accounting API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-accounting: HTTPS: approved revision, delivery key and receipt; destination residency unreso. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-accounting
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d73656372657473 — Define Invoice upload and review application → Service credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-secrets: IAM-authenticated retrieval of scoped application secrets. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d73656372657473 — Define Extraction and approved-delivery worker → Service credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-secrets: IAM-authenticated retrieval of scoped worker secrets. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6c6f6773 — Define Invoice upload and review application → Processing and recovery visibility

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-logs: Redacted application and access-failure logs; exclude invoice content. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-logs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d6c6f6773 — Define Extraction and approved-delivery worker → Processing and recovery visibility

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-logs: Redacted processing, delivery and retention-cleanup alerts. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-logs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-696e766f6963652d7573657273 — Integrate existing Uploaders and reviewers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d617070, TASK-CONTRACT-6170702d7573657273
- Components: invoice-users
- Generated files: No implementation files generated yet
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Existing people using a browser, outside provisioning scope. Uploaders submit PDFs; authorised reviewers inspect source documents, correct extracted fields and approve a specific result revision. Whether these are separate groups remains open. Browser downloads expose personal data to authorised users; managed-service residency does not establish the location of their devices.
2. Verify Approval workflow on tools in Existing client locations — not established; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-users
- Application/configuration and tests for Uploaders and reviewers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d617070 — Implement Invoice upload and review application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d617070, TASK-CONTRACT-6170702d7573657273, TASK-CONTRACT-6170702d6964656e74697479, TASK-CONTRACT-6170702d66696c6573, TASK-CONTRACT-6170702d6c6564676572, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-6170702d6c6f6773
- Components: invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency, ai-invoice-intake-capacity

### Implementation steps

1. Responsibility from the board: Proposed Code Engine application serving the browser interface and authenticated API. Enforces upload/reviewer permissions server-side and accepts PDF invoices up to 10 MB; proposed interpretation is 10,000,000 bytes, enforced while streaming. Validates document type and registers durable intake work for approximately 500 invoices/day without assuming a peak arrival rate. Returns status, source previews and review queue. Approval binds the corrected result revision and atomically creates an accounting outbox record; later edits invalidate approval. Handles personal data without logging document content. Proposed private service access where supported, with authenticated HTTPS browser ingress. Australian hosting, application code, hosting configuration and integrations require implementation and qualification.
2. Verify IBM Cloud Code Engine on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-app
- Application/configuration and tests for Invoice upload and review application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6964656e74697479 — Implement Application sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6964656e74697479
- Components: invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud App ID instance for application sign-in. Australian availability, identity-data processing, company federation and lifecycle ownership remain unverified. No PDF or extracted invoice fields are sent to the identity service. The application validates sessions and independently authorises uploader/reviewer actions; sign-in alone does not grant approval rights.
2. Verify IBM Cloud App ID on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud App ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-identity
- Application/configuration and tests for Application sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d66696c6573 — Implement Private invoice PDFs

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d66696c6573, TASK-CONTRACT-776f726b65722d66696c6573
- Components: invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-residency, ai-invoice-retention

### Implementation steps

1. Responsibility from the board: Proposed private IBM Cloud Object Storage bucket for immutable invoice PDFs up to 10 MB, potentially containing personal data. Application identity writes documents; worker identity reads exact objects; reviewers obtain authorised access through the application. Ledger holds exact object references and content hashes. Retain originals for 90 days, proposed from intake, then delete all relevant object versions and clean incomplete uploads. Storage, replication and recovery copies must stay in Australia. Public access is prohibited. Encryption, lifecycle enforcement, deletion evidence and Australian service configuration remain implementation and verification work; immutability must not prevent scheduled expiry.
2. Verify IBM Cloud Object Storage on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Object Storage; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-files
- Application/configuration and tests for Private invoice PDFs

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6c6564676572 — Implement Invoice ledger and durable work queue

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6c6564676572, TASK-CONTRACT-776f726b65722d6c6564676572
- Components: invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency, ai-invoice-retention, ai-invoice-intake-capacity

### Implementation steps

1. Responsibility from the board: Proposed managed PostgreSQL deployment holding intake keys, account-scoped unique document hashes, source references, extraction revisions, review records, approval audit and accounting outbox. Transactions, unique constraints, leased claims and fenced completion prevent concurrent retries creating duplicate intake or applying stale results. Expired leases recover work; exhausted tasks remain visible for replay. Different scans of one business invoice require additional duplicate detection. Retain originals' references and extraction audit history for 90 days, proposed from intake, with coordinated expiry of derived personal data. Backup expiry and restore procedures must enforce the retention boundary and remain in Australia. Long-lived deduplication evidence and delivery reconciliation after expiry require an explicit minimal-data policy; do not silently retain invoice content indefinitely. Australian availability, recovery targets and operational configuration remain unverified.
2. Verify IBM Cloud Databases for PostgreSQL on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Databases for PostgreSQL; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.; REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-ledger
- Application/configuration and tests for Invoice ledger and durable work queue

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d776f726b6572 — Implement Extraction and approved-delivery worker

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d6c6564676572, TASK-CONTRACT-776f726b65722d66696c6573, TASK-CONTRACT-776f726b65722d6d6f64656c, TASK-CONTRACT-776f726b65722d6163636f756e74696e67, TASK-CONTRACT-776f726b65722d73656372657473, TASK-CONTRACT-776f726b65722d6c6f6773
- Components: invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency, ai-invoice-retention, ai-invoice-intake-capacity

### Implementation steps

1. Responsibility from the board: Proposed separate Code Engine job deployment with scheduled invocation draining durable work for approximately 500 invoices/day. Claims leased tasks, reads exact PDFs and performs sandboxed text extraction or OCR for scans inside Australia. Bounds PDF pages, decompression, runtime and temporary storage independently of the 10 MB upload limit; cleans temporary files after processing. Treats document instructions as untrusted. Validates supplier, date, decimal total and currency; uncertain or invalid fields enter review without fabrication. Bounded retries and terminal records support recovery. Delivers only approved immutable revisions with a stable accounting idempotency key and receipt; ambiguous outcomes enter reconciliation unless destination retry safety is established. Also performs leased retention cleanup with expiry checks preventing processing of deleted records. Australian compute, OCR, scheduling and all integrations require implementation and qualification.
2. Verify IBM Cloud Code Engine on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.; REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-worker
- Application/configuration and tests for Extraction and approved-delivery worker

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6d6f64656c — Implement Structured invoice extraction

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d6d6f64656c
- Components: invoice-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-residency

### Implementation steps

1. Responsibility from the board: Proposed watsonx.ai inference receiving extracted invoice text, potentially containing personal data, and returning candidate supplier, invoice date, total and currency with supporting text references. No model ID, entitlement or Australian endpoint is verified. Australian processing, provider retention and data-use terms, structured outputs, quotas and representative-invoice accuracy must be qualified before invoice data is sent. No cross-border inference fallback is permitted. OCR belongs to the worker and is not assumed to be native model functionality. If a suitable Australian endpoint is unavailable, retain the extraction requirement and resolve an IBM-hosted in-country implementation before delivery.
2. Verify IBM watsonx.ai on ibm in Australia — model availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM watsonx.ai; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-model
- Application/configuration and tests for Structured invoice extraction

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6163636f756e74696e672d617069 — Integrate existing Existing accounting API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d6163636f756e74696e67
- Components: accounting-api
- Generated files: No implementation files generated yet
- Requirements: ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency

### Implementation steps

1. Responsibility from the board: Client's existing accounting API, outside provisioning scope. Receives only reviewer-approved invoice revisions. Its processing location, subprocessors and retention are not established; the Australian extracted-data boundary must be resolved before transmitting real invoice data. Authentication, payload mapping, idempotency-key support, receipt lookup and failure semantics remain unresolved contracts. The architecture neither modifies this system nor proves safe retries or Australian residency.
2. Verify Existing accounting API on tools in Existing location — Australian residency unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component accounting-api
- Application/configuration and tests for Existing accounting API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d73656372657473 — Implement Service credentials

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-776f726b65722d73656372657473
- Components: invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Secrets Manager instance for required database and external API credentials. Application and worker identities receive separate least-privilege access; use IAM authentication where supported. Secret values never enter the diagram or logs, and invoice content is not stored here. Australian availability, integration and credential rotation require qualification and implementation.
2. Verify IBM Cloud Secrets Manager on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Secrets Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-secrets
- Application/configuration and tests for Service credentials

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6c6f6773 — Implement Processing and recovery visibility

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6c6f6773, TASK-CONTRACT-776f726b65722d6c6f6773
- Components: invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-residency

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Logs instance for redacted correlation IDs, processing failures and delivery outcomes. Exclude invoice content, extracted fields, credentials and raw model payloads, including exception traces. Alert on repeated failures, stalled work, reconciliation and overdue retention cleanup; recipients and operating ownership remain open. Business extraction and approval audit stays in PostgreSQL for the specified 90 days, separate from operational logs. Australian collection, storage, alert routing, retention and service availability require qualification and implementation.
2. Verify IBM Cloud Logs on ibm in Australia — regional availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Logs; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-logs
- Application/configuration and tests for Processing and recovery visibility

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-75736572732d617070 — Wire Uploaders and reviewers to Invoice upload and review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d617070, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-app carrying Authenticated HTTPS: PDF upload up to 10 MB, review and approval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d7573657273 — Wire Invoice upload and review application to Uploaders and reviewers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d7573657273, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070
- Components: invoice-app, invoice-users
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-users carrying Authorised HTTPS: review queue, source preview and status, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-users
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6964656e74697479 — Wire Invoice upload and review application to Application sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6964656e74697479, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-identity carrying Proposed OIDC sign-in and server session validation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-identity
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d66696c6573 — Wire Invoice upload and review application to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d66696c6573, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573
- Components: invoice-app, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-files carrying Authenticated object API: private PDF writes and authorised reads in Australia, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-files
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6c6564676572 — Wire Invoice upload and review application to Invoice ledger and durable work queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6c6564676572, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6c6564676572
- Components: invoice-app, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-ledger carrying TLS SQL: intake, expiry timestamps, review and atomic approval/outbox, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-ledger
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d6c6564676572 — Wire Extraction and approved-delivery worker to Invoice ledger and durable work queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d6c6564676572, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572
- Components: invoice-worker, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-ledger carrying TLS SQL: lease work, results, delivery reconciliation and retention cleanup, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-ledger
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d66696c6573 — Wire Extraction and approved-delivery worker to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d66696c6573, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d776f726b6572
- Components: invoice-worker, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-files carrying Scoped object API: exact PDF reads and coordinated 90-day expiry deletion, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-files
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d6d6f64656c — Wire Extraction and approved-delivery worker to Structured invoice extraction

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d6d6f64656c, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6d6f64656c
- Components: invoice-worker, invoice-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-model carrying Authenticated inference: invoice text; Australian processing must be qualified, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d6163636f756e74696e67 — Wire Extraction and approved-delivery worker to Existing accounting API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-6163636f756e74696e672d617069
- Components: invoice-worker, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-accounting carrying HTTPS: approved revision, delivery key and receipt; destination residency unreso, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-accounting
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d73656372657473 — Wire Invoice upload and review application to Service credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d73656372657473, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d73656372657473
- Components: invoice-app, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-secrets carrying IAM-authenticated retrieval of scoped application secrets, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d73656372657473 — Wire Extraction and approved-delivery worker to Service credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d73656372657473, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d73656372657473
- Components: invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-secrets carrying IAM-authenticated retrieval of scoped worker secrets, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6c6f6773 — Wire Invoice upload and review application to Processing and recovery visibility

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6c6f6773, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6c6f6773
- Components: invoice-app, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-logs carrying Redacted application and access-failure logs; exclude invoice content, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-logs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d6c6f6773 — Wire Extraction and approved-delivery worker to Processing and recovery visibility

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d6c6f6773, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6c6f6773
- Components: invoice-worker, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-logs carrying Redacted processing, delivery and retention-cleanup alerts, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-logs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-75736572732d617070 — Verify live Uploaders and reviewers → Invoice upload and review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d617070
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d7573657273 — Verify live Invoice upload and review application → Uploaders and reviewers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d7573657273
- Components: invoice-app, invoice-users
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-users with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-users

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6964656e74697479 — Verify live Invoice upload and review application → Application sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6964656e74697479
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-identity with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-identity

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d66696c6573 — Verify live Invoice upload and review application → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d66696c6573
- Components: invoice-app, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-files with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-files

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6c6564676572 — Verify live Invoice upload and review application → Invoice ledger and durable work queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6c6564676572
- Components: invoice-app, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-ledger with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-ledger

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572 — Verify live Extraction and approved-delivery worker → Invoice ledger and durable work queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d6c6564676572
- Components: invoice-worker, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-ledger with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-ledger

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d66696c6573 — Verify live Extraction and approved-delivery worker → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d66696c6573
- Components: invoice-worker, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-files with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-files

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c — Verify live Extraction and approved-delivery worker → Structured invoice extraction

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d6d6f64656c
- Components: invoice-worker, invoice-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67 — Verify live Extraction and approved-delivery worker → Existing accounting API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d6163636f756e74696e67
- Components: invoice-worker, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-accounting with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-accounting

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d73656372657473 — Verify live Invoice upload and review application → Service credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d73656372657473
- Components: invoice-app, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d73656372657473 — Verify live Extraction and approved-delivery worker → Service credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d73656372657473
- Components: invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6c6f6773 — Verify live Invoice upload and review application → Processing and recovery visibility

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6c6f6773
- Components: invoice-app, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-logs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-logs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773 — Verify live Extraction and approved-delivery worker → Processing and recovery visibility

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d6c6f6773
- Components: invoice-worker, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-logs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-logs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e — Verify REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6d6f64656c, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: invoice-app, invoice-files, invoice-worker, invoice-model, invoice-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.”; rationale: Keeps extraction useful to reviewers while preventing uncertain model output from silently becoming accounting data; scanned-PDF support is a proposed scope assumption.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379 — Verify REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: invoice-app, invoice-ledger, invoice-worker, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-idempotency

### Implementation steps

1. Basis: “Delivery can repeat; retries must not create duplicate invoices.”; rationale: Repeated submissions, worker crashes and ambiguous accounting responses can otherwise create duplicate invoices. Destination idempotency or authoritative reconciliation is a necessary unresolved dependency.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c — Verify REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: invoice-users, invoice-app, invoice-identity, invoice-ledger, invoice-worker, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Basis: “A reviewer approves a result before it is sent to our existing accounting API.”; rationale: Prevents unreviewed extraction or post-approval edits from reaching accounting and makes each delivery attributable to its reviewer.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379 — Verify REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6d6f64656c, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-RESOURCE-696e766f6963652d6c6f6773, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: invoice-app, invoice-files, invoice-ledger, invoice-worker, invoice-model, accounting-api, invoice-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-residency

### Implementation steps

1. Basis: “they may contain personal data” and “Keep documents and extracted data in Australia; flag unverified service availability.”; rationale: Personal invoice data could otherwise leave Australia through inference, replication, backups or the accounting integration; naming an Australian region does not establish compliance.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e — Verify REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: invoice-files, invoice-ledger, invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-retention

### Implementation steps

1. Basis: “Keep originals and extraction audit history for 90 days.” The proposed intake-based start and cleanup mechanics are engineering assumptions.; rationale: Coordinated expiry prevents personal data surviving in source versions, derived records, temporary files or restored backups after normal records are deleted.
2. Implement a check for Original and extraction audit retention == 90 days; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d696e74616b652d6361706163697479 — Verify REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: invoice-app, invoice-ledger, invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-intake-capacity

### Implementation steps

1. Basis: “PDF invoices up to 10 MB, around 500 per day” and the existing durable work queue and extraction worker.; rationale: Durable buffering accommodates variable arrival rates; a small compressed PDF can still exhaust processing resources without independent extraction limits.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6d6f64656c, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-RESOURCE-696e766f6963652d6c6f6773, TASK-INTEGRATION-75736572732d617070, TASK-INTEGRATION-6170702d7573657273, TASK-INTEGRATION-6170702d6964656e74697479, TASK-INTEGRATION-6170702d66696c6573, TASK-INTEGRATION-6170702d6c6564676572, TASK-INTEGRATION-776f726b65722d6c6564676572, TASK-INTEGRATION-776f726b65722d66696c6573, TASK-INTEGRATION-776f726b65722d6d6f64656c, TASK-INTEGRATION-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-6170702d73656372657473, TASK-INTEGRATION-776f726b65722d73656372657473, TASK-INTEGRATION-6170702d6c6f6773, TASK-INTEGRATION-776f726b65722d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6c6564676572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6d6f64656c, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-RESOURCE-696e766f6963652d6c6f6773, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e, TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379, TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c, TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379, TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e, TASK-ACCEPTANCE-61692d696e766f6963652d696e74616b652d6361706163697479, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d7573657273, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6170702d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d6c6564676572, TASK-INTEGRATION-LIVE-776f726b65722d66696c6573, TASK-INTEGRATION-LIVE-776f726b65722d6d6f64656c, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473, TASK-INTEGRATION-LIVE-6170702d6c6f6773, TASK-INTEGRATION-LIVE-776f726b65722d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-003 (ai-invoice-extraction) → TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e; Proposed; needs confirmation
- REQ-004 (ai-invoice-idempotency) → TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379; Proposed; needs confirmation
- REQ-005 (ai-invoice-approval) → TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c; Proposed; needs confirmation
- REQ-006 (ai-invoice-residency) → TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379; Proposed; needs confirmation
- REQ-007 (ai-invoice-retention) → TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e; Proposed; needs confirmation
- REQ-008 (ai-invoice-intake-capacity) → TASK-ACCEPTANCE-61692d696e766f6963652d696e74616b652d6361706163697479; Proposed; needs confirmation
