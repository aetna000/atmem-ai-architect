Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

# Asynchronous document intake — solution specification

## Problem and intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-files, invoice-worker, invoice-model, invoice-ledger

Design explanation: Keeps extraction useful to reviewers while preventing uncertain model output from silently becoming accounting data; scanned-PDF support is a proposed scope assumption.

Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.”
- [REQ-004] Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-ledger, invoice-worker, accounting-api

Design explanation: Repeated submissions, worker crashes and ambiguous accounting responses can otherwise create duplicate invoices. Destination idempotency or authoritative reconciliation is a necessary unresolved dependency.

Basis: “Delivery can repeat; retries must not create duplicate invoices.”
- [REQ-005] Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval. (must, open); target: acceptance target needed; linked blocks: invoice-users, invoice-app, invoice-identity, invoice-ledger, invoice-worker, accounting-api

Design explanation: Prevents unreviewed extraction or post-approval edits from reaching accounting and makes each delivery attributable to its reviewer.

Basis: “A reviewer approves a result before it is sent to our existing accounting API.”
- [REQ-006] Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-files, invoice-ledger, invoice-worker, invoice-model, accounting-api, invoice-logs

Design explanation: Personal invoice data could otherwise leave Australia through inference, replication, backups or the accounting integration; naming an Australian region does not establish compliance.

Basis: “they may contain personal data” and “Keep documents and extracted data in Australia; flag unverified service availability.”
- [REQ-007] Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention. (must, open); target: Original and extraction audit retention == 90days; linked blocks: invoice-files, invoice-ledger, invoice-worker

Design explanation: Coordinated expiry prevents personal data surviving in source versions, derived records, temporary files or restored backups after normal records are deleted.

Basis: “Keep originals and extraction audit history for 90 days.” The proposed intake-based start and cleanup mechanics are engineering assumptions.
- [REQ-008] Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-ledger, invoice-worker

Design explanation: Durable buffering accommodates variable arrival rates; a small compressed PDF can still exhaust processing resources without independent extraction limits.

Basis: “PDF invoices up to 10 MB, around 500 per day” and the existing durable work queue and extraction worker.

## How the system works

The current design contains 10 components and 13 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Uploaders and reviewers → Invoice upload and review application

Authenticated HTTPS: PDF upload up to 10 MB, review and approval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Invoice upload and review application → Uploaders and reviewers

Authorised HTTPS: review queue, source preview and status

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Invoice upload and review application → Application sign-in

Proposed OIDC sign-in and server session validation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Invoice upload and review application → Private invoice PDFs

Authenticated object API: private PDF writes and authorised reads in Australia

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Invoice upload and review application → Invoice ledger and durable work queue

TLS SQL: intake, expiry timestamps, review and atomic approval/outbox

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Extraction and approved-delivery worker → Invoice ledger and durable work queue

TLS SQL: lease work, results, delivery reconciliation and retention cleanup

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Extraction and approved-delivery worker → Private invoice PDFs

Scoped object API: exact PDF reads and coordinated 90-day expiry deletion

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Extraction and approved-delivery worker → Structured invoice extraction

Authenticated inference: invoice text; Australian processing must be qualified

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Extraction and approved-delivery worker → Existing accounting API

HTTPS: approved revision, delivery key and receipt; destination residency unreso

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Invoice upload and review application → Service credentials

IAM-authenticated retrieval of scoped application secrets

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Extraction and approved-delivery worker → Service credentials

IAM-authenticated retrieval of scoped worker secrets

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Invoice upload and review application → Processing and recovery visibility

Redacted application and access-failure logs; exclude invoice content

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Extraction and approved-delivery worker → Processing and recovery visibility

Redacted processing, delivery and retention-cleanup alerts

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Uploaders and reviewers

Approval workflow · tools · region: Existing client locations — not established · classification: Confidential

Existing people using a browser, outside provisioning scope. Uploaders submit PDFs; authorised reviewers inspect source documents, correct extracted fields and approve a specific result revision. Whether these are separate groups remains open. Browser downloads expose personal data to authorised users; managed-service residency does not establish the location of their devices.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Invoice upload and review application → Uploaders and reviewers: Authorised HTTPS: review queue, source preview and status

Outputs: Uploaders and reviewers → Invoice upload and review application: Authenticated HTTPS: PDF upload up to 10 MB, review and approval

Requirement traceability: REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Invoice upload and review application

IBM Cloud Code Engine · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed Code Engine application serving the browser interface and authenticated API. Enforces upload/reviewer permissions server-side and accepts PDF invoices up to 10 MB; proposed interpretation is 10,000,000 bytes, enforced while streaming. Validates document type and registers durable intake work for approximately 500 invoices/day without assuming a peak arrival rate. Returns status, source previews and review queue. Approval binds the corrected result revision and atomically creates an accounting outbox record; later edits invalidate approval. Handles personal data without logging document content. Proposed private service access where supported, with authenticated HTTPS browser ingress. Australian hosting, application code, hosting configuration and integrations require implementation and qualification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Uploaders and reviewers → Invoice upload and review application: Authenticated HTTPS: PDF upload up to 10 MB, review and approval

Outputs: Invoice upload and review application → Uploaders and reviewers: Authorised HTTPS: review queue, source preview and status; Invoice upload and review application → Application sign-in: Proposed OIDC sign-in and server session validation; Invoice upload and review application → Private invoice PDFs: Authenticated object API: private PDF writes and authorised reads in Australia; Invoice upload and review application → Invoice ledger and durable work queue: TLS SQL: intake, expiry timestamps, review and atomic approval/outbox; Invoice upload and review application → Service credentials: IAM-authenticated retrieval of scoped application secrets; Invoice upload and review application → Processing and recovery visibility: Redacted application and access-failure logs; exclude invoice content

Requirement traceability: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Application sign-in

IBM Cloud App ID · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed IBM Cloud App ID instance for application sign-in. Australian availability, identity-data processing, company federation and lifecycle ownership remain unverified. No PDF or extracted invoice fields are sent to the identity service. The application validates sessions and independently authorises uploader/reviewer actions; sign-in alone does not grant approval rights.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Application sign-in: Proposed OIDC sign-in and server session validation

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Private invoice PDFs

IBM Cloud Object Storage · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed private IBM Cloud Object Storage bucket for immutable invoice PDFs up to 10 MB, potentially containing personal data. Application identity writes documents; worker identity reads exact objects; reviewers obtain authorised access through the application. Ledger holds exact object references and content hashes. Retain originals for 90 days, proposed from intake, then delete all relevant object versions and clean incomplete uploads. Storage, replication and recovery copies must stay in Australia. Public access is prohibited. Encryption, lifecycle enforcement, deletion evidence and Australian service configuration remain implementation and verification work; immutability must not prevent scheduled expiry.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Private invoice PDFs: Authenticated object API: private PDF writes and authorised reads in Australia; Extraction and approved-delivery worker → Private invoice PDFs: Scoped object API: exact PDF reads and coordinated 90-day expiry deletion

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Invoice ledger and durable work queue

IBM Cloud Databases for PostgreSQL · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed managed PostgreSQL deployment holding intake keys, account-scoped unique document hashes, source references, extraction revisions, review records, approval audit and accounting outbox. Transactions, unique constraints, leased claims and fenced completion prevent concurrent retries creating duplicate intake or applying stale results. Expired leases recover work; exhausted tasks remain visible for replay. Different scans of one business invoice require additional duplicate detection. Retain originals' references and extraction audit history for 90 days, proposed from intake, with coordinated expiry of derived personal data. Backup expiry and restore procedures must enforce the retention boundary and remain in Australia. Long-lived deduplication evidence and delivery reconciliation after expiry require an explicit minimal-data policy; do not silently retain invoice content indefinitely. Australian availability, recovery targets and operational configuration remain unverified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Invoice ledger and durable work queue: TLS SQL: intake, expiry timestamps, review and atomic approval/outbox; Extraction and approved-delivery worker → Invoice ledger and durable work queue: TLS SQL: lease work, results, delivery reconciliation and retention cleanup

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.; REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Extraction and approved-delivery worker

IBM Cloud Code Engine · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed separate Code Engine job deployment with scheduled invocation draining durable work for approximately 500 invoices/day. Claims leased tasks, reads exact PDFs and performs sandboxed text extraction or OCR for scans inside Australia. Bounds PDF pages, decompression, runtime and temporary storage independently of the 10 MB upload limit; cleans temporary files after processing. Treats document instructions as untrusted. Validates supplier, date, decimal total and currency; uncertain or invalid fields enter review without fabrication. Bounded retries and terminal records support recovery. Delivers only approved immutable revisions with a stable accounting idempotency key and receipt; ambiguous outcomes enter reconciliation unless destination retry safety is established. Also performs leased retention cleanup with expiry checks preventing processing of deleted records. Australian compute, OCR, scheduling and all integrations require implementation and qualification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Extraction and approved-delivery worker → Invoice ledger and durable work queue: TLS SQL: lease work, results, delivery reconciliation and retention cleanup; Extraction and approved-delivery worker → Private invoice PDFs: Scoped object API: exact PDF reads and coordinated 90-day expiry deletion; Extraction and approved-delivery worker → Structured invoice extraction: Authenticated inference: invoice text; Australian processing must be qualified; Extraction and approved-delivery worker → Existing accounting API: HTTPS: approved revision, delivery key and receipt; destination residency unreso; Extraction and approved-delivery worker → Service credentials: IAM-authenticated retrieval of scoped worker secrets; Extraction and approved-delivery worker → Processing and recovery visibility: Redacted processing, delivery and retention-cleanup alerts

Requirement traceability: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.; REQ-007: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention.; REQ-008: Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Structured invoice extraction

IBM watsonx.ai · ibm · region: Australia — model availability unverified · classification: Confidential

Proposed watsonx.ai inference receiving extracted invoice text, potentially containing personal data, and returning candidate supplier, invoice date, total and currency with supporting text references. No model ID, entitlement or Australian endpoint is verified. Australian processing, provider retention and data-use terms, structured outputs, quotas and representative-invoice accuracy must be qualified before invoice data is sent. No cross-border inference fallback is permitted. OCR belongs to the worker and is not assumed to be native model functionality. If a suitable Australian endpoint is unavailable, retain the extraction requirement and resolve an IBM-hosted in-country implementation before delivery.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and approved-delivery worker → Structured invoice extraction: Authenticated inference: invoice text; Australian processing must be qualified

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing accounting API

Existing accounting API · tools · region: Existing location — Australian residency unverified · classification: Confidential

Client's existing accounting API, outside provisioning scope. Receives only reviewer-approved invoice revisions. Its processing location, subprocessors and retention are not established; the Australian extracted-data boundary must be resolved before transmitting real invoice data. Authentication, payload mapping, idempotency-key support, receipt lookup and failure semantics remain unresolved contracts. The architecture neither modifies this system nor proves safe retries or Australian residency.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Extraction and approved-delivery worker → Existing accounting API: HTTPS: approved revision, delivery key and receipt; destination residency unreso

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.; REQ-005: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval.; REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Service credentials

IBM Cloud Secrets Manager · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed Secrets Manager instance for required database and external API credentials. Application and worker identities receive separate least-privilege access; use IAM authentication where supported. Secret values never enter the diagram or logs, and invoice content is not stored here. Australian availability, integration and credential rotation require qualification and implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Service credentials: IAM-authenticated retrieval of scoped application secrets; Extraction and approved-delivery worker → Service credentials: IAM-authenticated retrieval of scoped worker secrets

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Processing and recovery visibility

IBM Cloud Logs · ibm · region: Australia — regional availability unverified · classification: Confidential

Proposed IBM Cloud Logs instance for redacted correlation IDs, processing failures and delivery outcomes. Exclude invoice content, extracted fields, credentials and raw model payloads, including exception traces. Alert on repeated failures, stalled work, reconciliation and overdue retention cleanup; recipients and operating ownership remain open. Business extraction and approval audit stays in PostgreSQL for the specified 90 days, separate from operational logs. Australian collection, storage, alert routing, retention and service availability require qualification and implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Processing and recovery visibility: Redacted application and access-failure logs; exclude invoice content; Extraction and approved-delivery worker → Processing and recovery visibility: Redacted processing, delivery and retention-cleanup alerts

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice upload and review application<br/>IBM"]
  n2["Application sign-in<br/>IBM"]
  n3["Private invoice PDFs<br/>IBM"]
  n4["Invoice ledger and durable work queue<br/>IBM"]
  n5["Extraction and approved-delivery worker<br/>IBM"]
  n6["Structured invoice extraction<br/>IBM"]
  n7["Existing accounting API<br/>Tools & data"]
  n8["Service credentials<br/>IBM"]
  n9["Processing and recovery visibility<br/>IBM"]
  n0 -->|Authenticated HTTPS: PDF upload up to 10 MB, review and approval| n1
  n1 -->|Authorised HTTPS: review queue, source preview and status| n0
  n1 -->|Proposed OIDC sign-in and server session validation| n2
  n1 -->|Authenticated object API: private PDF writes and authorised reads in Australia| n3
  n1 -->|TLS SQL: intake, expiry timestamps, review and atomic approval/outbox| n4
  n5 -->|TLS SQL: lease work, results, delivery reconciliation and retention cleanup| n4
  n5 -->|Scoped object API: exact PDF reads and coordinated 90-day expiry deletion| n3
  n5 -->|Authenticated inference: invoice text; Australian processing must be qualified| n6
  n5 -->|HTTPS: approved revision, delivery key and receipt; destination residency unreso| n7
  n1 -->|IAM-authenticated retrieval of scoped application secrets| n8
  n5 -->|IAM-authenticated retrieval of scoped worker secrets| n8
  n1 -->|Redacted application and access-failure logs; exclude invoice content| n9
  n5 -->|Redacted processing, delivery and retention-cleanup alerts| n9
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Approval workflow | Existing client locations — not established | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-app | Invoice upload and review application | ibm | IBM Cloud Code Engine | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-identity | Application sign-in | ibm | IBM Cloud App ID | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-files | Private invoice PDFs | ibm | IBM Cloud Object Storage | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-ledger | Invoice ledger and durable work queue | ibm | IBM Cloud Databases for PostgreSQL | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-worker | Extraction and approved-delivery worker | ibm | IBM Cloud Code Engine | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-model | Structured invoice extraction | ibm | IBM watsonx.ai | Australia — model availability unverified | Proposed | Implementation needed |
| accounting-api | Existing accounting API | tools | Existing accounting API | Existing location — Australian residency unverified | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| invoice-secrets | Service credentials | ibm | IBM Cloud Secrets Manager | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-logs | Processing and recovery visibility | ibm | IBM Cloud Logs | Australia — regional availability unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Invoice upload and review application** (invoice-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users.
- **Application sign-in** (invoice-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Private invoice PDFs** (invoice-files): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Invoice ledger and durable work queue** (invoice-ledger): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Extraction and approved-delivery worker** (invoice-worker): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Structured invoice extraction** (invoice-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Existing accounting API** (accounting-api): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Service credentials** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Processing and recovery visibility** (invoice-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.

### Engineering work remaining

- Invoice upload and review application: Implementation needed.
- Application sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice ledger and durable work queue: Implementation needed.
- Extraction and approved-delivery worker: Implementation needed.
- Structured invoice extraction: Implementation needed.
- Service credentials: Implementation needed.
- Processing and recovery visibility: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-users: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-model: implement data flow, access policy and acceptance test.
- Wire invoice-worker → accounting-api: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-logs: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Keep documents and extracted data in Australia; flag unverified service availability.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
