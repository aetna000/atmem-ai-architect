# Infrastructure implementation required

Requested providers: ibm. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Invoice upload and review application: Implementation needed.
- Application sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice ledger and durable work queue: Implementation needed.
- Extraction and approved-delivery worker: Implementation needed.
- Structured invoice extraction: Implementation needed.
- Service credentials: Implementation needed.
- Processing and recovery visibility: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-users: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-model: implement data flow, access policy and acceptance test.
- Wire invoice-worker → accounting-api: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-logs: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-logs: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
