Snapshot 849b64cc-86a6-4f62-8ed7-7ba5ef00a71c · design r3 · generated 2026-11-09T18:01:52.453Z

# Asynchronous document intake — deployment document

Generated 2026-11-09 18:01 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** IBM
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** PDF invoices up to 10 MB, around 500 per day; they may contain personal data. Keep originals and extraction audit history for 90 days. Keep documents and extracted data in Australia; flag unverified service availability.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM
- **Budget and timeline:** —

## 3. Architecture

**Invoice intake and review**

- Uploaders and reviewers (Tools & data, existing, sketch) — Existing people using a browser, outside provisioning scope. Uploaders submit PDFs; authorised reviewers inspect source documents, correct extracted fields and approve a specific result revision. Whether these are separate groups remains open. Browser downloads expose personal data to authorised users; managed-service residency does not establish the location of their devices.
- Invoice upload and review application (IBM, sketch) — Proposed Code Engine application serving the browser interface and authenticated API. Enforces upload/reviewer permissions server-side and accepts PDF invoices up to 10 MB; proposed interpretation is 10,000,000 bytes, enforced while streaming. Validates document type and registers durable intake work for approximately 500 invoices/day without assuming a peak arrival rate. Returns status, source previews and review queue. Approval binds the corrected result revision and atomically creates an accounting outbox record; later edits invalidate approval. Handles personal data without logging document content. Proposed private service access where supported, with authenticated HTTPS browser ingress. Australian hosting, application code, hosting configuration and integrations require implementation and qualification.
- Application sign-in (IBM, sketch) — Proposed IBM Cloud App ID instance for application sign-in. Australian availability, identity-data processing, company federation and lifecycle ownership remain unverified. No PDF or extracted invoice fields are sent to the identity service. The application validates sessions and independently authorises uploader/reviewer actions; sign-in alone does not grant approval rights.

**Durable invoice state**

- Private invoice PDFs (IBM, sketch) — Proposed private IBM Cloud Object Storage bucket for immutable invoice PDFs up to 10 MB, potentially containing personal data. Application identity writes documents; worker identity reads exact objects; reviewers obtain authorised access through the application. Ledger holds exact object references and content hashes. Retain originals for 90 days, proposed from intake, then delete all relevant object versions and clean incomplete uploads. Storage, replication and recovery copies must stay in Australia. Public access is prohibited. Encryption, lifecycle enforcement, deletion evidence and Australian service configuration remain implementation and verification work; immutability must not prevent scheduled expiry.
- Invoice ledger and durable work queue (IBM, sketch) — Proposed managed PostgreSQL deployment holding intake keys, account-scoped unique document hashes, source references, extraction revisions, review records, approval audit and accounting outbox. Transactions, unique constraints, leased claims and fenced completion prevent concurrent retries creating duplicate intake or applying stale results. Expired leases recover work; exhausted tasks remain visible for replay. Different scans of one business invoice require additional duplicate detection. Retain originals' references and extraction audit history for 90 days, proposed from intake, with coordinated expiry of derived personal data. Backup expiry and restore procedures must enforce the retention boundary and remain in Australia. Long-lived deduplication evidence and delivery reconciliation after expiry require an explicit minimal-data policy; do not silently retain invoice content indefinitely. Australian availability, recovery targets and operational configuration remain unverified.

**Extraction and delivery**

- Extraction and approved-delivery worker (IBM, sketch) — Proposed separate Code Engine job deployment with scheduled invocation draining durable work for approximately 500 invoices/day. Claims leased tasks, reads exact PDFs and performs sandboxed text extraction or OCR for scans inside Australia. Bounds PDF pages, decompression, runtime and temporary storage independently of the 10 MB upload limit; cleans temporary files after processing. Treats document instructions as untrusted. Validates supplier, date, decimal total and currency; uncertain or invalid fields enter review without fabrication. Bounded retries and terminal records support recovery. Delivers only approved immutable revisions with a stable accounting idempotency key and receipt; ambiguous outcomes enter reconciliation unless destination retry safety is established. Also performs leased retention cleanup with expiry checks preventing processing of deleted records. Australian compute, OCR, scheduling and all integrations require implementation and qualification.
- Structured invoice extraction (IBM, sketch) — Proposed watsonx.ai inference receiving extracted invoice text, potentially containing personal data, and returning candidate supplier, invoice date, total and currency with supporting text references. No model ID, entitlement or Australian endpoint is verified. Australian processing, provider retention and data-use terms, structured outputs, quotas and representative-invoice accuracy must be qualified before invoice data is sent. No cross-border inference fallback is permitted. OCR belongs to the worker and is not assumed to be native model functionality. If a suitable Australian endpoint is unavailable, retain the extraction requirement and resolve an IBM-hosted in-country implementation before delivery.
- Existing accounting API (Tools & data, existing, sketch) — Client's existing accounting API, outside provisioning scope. Receives only reviewer-approved invoice revisions. Its processing location, subprocessors and retention are not established; the Australian extracted-data boundary must be resolved before transmitting real invoice data. Authentication, payload mapping, idempotency-key support, receipt lookup and failure semantics remain unresolved contracts. The architecture neither modifies this system nor proves safe retries or Australian residency.

**Operations**

- Service credentials (IBM, sketch) — Proposed Secrets Manager instance for required database and external API credentials. Application and worker identities receive separate least-privilege access; use IAM authentication where supported. Secret values never enter the diagram or logs, and invoice content is not stored here. Australian availability, integration and credential rotation require qualification and implementation.
- Processing and recovery visibility (IBM, sketch) — Proposed IBM Cloud Logs instance for redacted correlation IDs, processing failures and delivery outcomes. Exclude invoice content, extracted fields, credentials and raw model payloads, including exception traces. Alert on repeated failures, stalled work, reconciliation and overdue retention cleanup; recipients and operating ownership remain open. Business extraction and approval audit stays in PostgreSQL for the specified 90 days, separate from operational logs. Australian collection, storage, alert routing, retention and service availability require qualification and implementation.

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice upload and review application<br/>IBM"]
  n2["Application sign-in<br/>IBM"]
  n3["Private invoice PDFs<br/>IBM"]
  n4["Invoice ledger and durable work queue<br/>IBM"]
  n5["Extraction and approved-delivery worker<br/>IBM"]
  n6["Structured invoice extraction<br/>IBM"]
  n7["Existing accounting API<br/>Tools & data"]
  n8["Service credentials<br/>IBM"]
  n9["Processing and recovery visibility<br/>IBM"]
  n0 -->|Authenticated HTTPS: PDF upload up to 10 MB, review and approval| n1
  n1 -->|Authorised HTTPS: review queue, source preview and status| n0
  n1 -->|Proposed OIDC sign-in and server session validation| n2
  n1 -->|Authenticated object API: private PDF writes and authorised reads in Australia| n3
  n1 -->|TLS SQL: intake, expiry timestamps, review and atomic approval/outbox| n4
  n5 -->|TLS SQL: lease work, results, delivery reconciliation and retention cleanup| n4
  n5 -->|Scoped object API: exact PDF reads and coordinated 90-day expiry deletion| n3
  n5 -->|Authenticated inference: invoice text; Australian processing must be qualified| n6
  n5 -->|HTTPS: approved revision, delivery key and receipt; destination residency unreso| n7
  n1 -->|IAM-authenticated retrieval of scoped application secrets| n8
  n5 -->|IAM-authenticated retrieval of scoped worker secrets| n8
  n1 -->|Redacted application and access-failure logs; exclude invoice content| n9
  n5 -->|Redacted processing, delivery and retention-cleanup alerts| n9
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Approval workflow | Existing client locations — not established | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-app | Invoice upload and review application | ibm | IBM Cloud Code Engine | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-identity | Application sign-in | ibm | IBM Cloud App ID | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-files | Private invoice PDFs | ibm | IBM Cloud Object Storage | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-ledger | Invoice ledger and durable work queue | ibm | IBM Cloud Databases for PostgreSQL | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-worker | Extraction and approved-delivery worker | ibm | IBM Cloud Code Engine | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-model | Structured invoice extraction | ibm | IBM watsonx.ai | Australia — model availability unverified | Proposed | Implementation needed |
| accounting-api | Existing accounting API | tools | Existing accounting API | Existing location — Australian residency unverified | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| invoice-secrets | Service credentials | ibm | IBM Cloud Secrets Manager | Australia — regional availability unverified | Proposed | Implementation needed |
| invoice-logs | Processing and recovery visibility | ibm | IBM Cloud Logs | Australia — regional availability unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Invoice upload and review application** (invoice-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users.
- **Application sign-in** (invoice-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Private invoice PDFs** (invoice-files): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Invoice ledger and durable work queue** (invoice-ledger): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Extraction and approved-delivery worker** (invoice-worker): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Structured invoice extraction** (invoice-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Existing accounting API** (accounting-api): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Service credentials** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Processing and recovery visibility** (invoice-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.

### Engineering work remaining

- Invoice upload and review application: Implementation needed.
- Application sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice ledger and durable work queue: Implementation needed.
- Extraction and approved-delivery worker: Implementation needed.
- Structured invoice extraction: Implementation needed.
- Service credentials: Implementation needed.
- Processing and recovery visibility: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-users: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-ledger: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-model: implement data flow, access policy and acceptance test.
- Wire invoice-worker → accounting-api: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-logs: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Uploaders and reviewers | Invoice upload and review application | Authenticated HTTPS: PDF upload up to 10 MB, review and approval | Confidential |
| Invoice upload and review application | Uploaders and reviewers | Authorised HTTPS: review queue, source preview and status | Confidential |
| Invoice upload and review application | Application sign-in | Proposed OIDC sign-in and server session validation | Confidential |
| Invoice upload and review application | Private invoice PDFs | Authenticated object API: private PDF writes and authorised reads in Australia | Confidential |
| Invoice upload and review application | Invoice ledger and durable work queue | TLS SQL: intake, expiry timestamps, review and atomic approval/outbox | Confidential |
| Extraction and approved-delivery worker | Invoice ledger and durable work queue | TLS SQL: lease work, results, delivery reconciliation and retention cleanup | Confidential |
| Extraction and approved-delivery worker | Private invoice PDFs | Scoped object API: exact PDF reads and coordinated 90-day expiry deletion | Confidential |
| Extraction and approved-delivery worker | Structured invoice extraction | Authenticated inference: invoice text; Australian processing must be qualified | Confidential |
| Extraction and approved-delivery worker | Existing accounting API | HTTPS: approved revision, delivery key and receipt; destination residency unreso | Confidential |
| Invoice upload and review application | Service credentials | IAM-authenticated retrieval of scoped application secrets | Confidential |
| Extraction and approved-delivery worker | Service credentials | IAM-authenticated retrieval of scoped worker secrets | Confidential |
| Invoice upload and review application | Processing and recovery visibility | Redacted application and access-failure logs; exclude invoice content | Confidential |
| Extraction and approved-delivery worker | Processing and recovery visibility | Redacted processing, delivery and retention-cleanup alerts | Confidential |

## 5. Security controls

- **Uploaders and reviewers** — Existing people using a browser, outside provisioning scope. Uploaders submit PDFs; authorised reviewers inspect source documents, correct extracted fields and approve a specific result revision. Whether these are separate groups remains open. Browser downloads expose personal data to authorised users; managed-service residency does not establish the location of their devices.
- **Application sign-in** — Proposed IBM Cloud App ID instance for application sign-in. Australian availability, identity-data processing, company federation and lifecycle ownership remain unverified. No PDF or extracted invoice fields are sent to the identity service. The application validates sessions and independently authorises uploader/reviewer actions; sign-in alone does not grant approval rights.
- **Service credentials** — Proposed Secrets Manager instance for required database and external API credentials. Application and worker identities receive separate least-privilege access; use IAM authentication where supported. Secret values never enter the diagram or logs, and invoice content is not stored here. Australian availability, integration and credential rotation require qualification and implementation.
- Requirement: Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval. (must)
- Requirement: Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback. (must)
- Requirement: Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety. | reliability | not measurable yet | Open |
| Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback. | compliance | not measurable yet | Open |
| Retain invoice originals and extraction audit history for 90 days, proposed from intake. Implement coordinated expiry of source versions and related personal-data records, temporary-file cleanup and backup/restore deletion controls. Define minimal deduplication and reconciliation evidence separately so retention cleanup does not silently weaken duplicate prevention. | compliance | Original and extraction audit retention == 90days | Open |
| Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity. | scalability | not measurable yet | Open |

**Functional**

- For each accepted PDF, retain the source and present supplier, invoice date, total and currency for review, clearly identifying missing, invalid or uncertain fields. Proposed scope includes text and scanned PDFs; unreadable documents must produce a visible reviewable failure. (must, open)
- Only an authorised reviewer may approve an invoice revision. Accounting delivery must use that exact approved revision, with reviewer identity, approval time and delivery outcome recorded durably; corrections after approval require renewed approval. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 3 quality requirements have no measurable target. Add a metric and target to: “Repeated delivery of the same intake and processing retries must resolve to one durable invoice record and at most one accounting invoice. Use transactional uniqueness, recoverable work claims and a stable delivery key; hold ambiguous accounting outcomes for reconciliation until the destination contract proves retry safety.”, “Keep invoice documents and extracted data, including temporary processing, inference, replicas and recovery copies, in Australia. Qualify each service's regional availability and data handling before sending real invoices. Resolve the existing accounting API's location against this boundary; do not silently permit cross-border fallback.”, “Accept PDF invoices up to 10 MB and support approximately 500 daily intakes through durable asynchronous processing. Enforce size and document validation server-side and bound PDF/OCR resource consumption. Peak arrival rate and completion-time acceptance targets remain unspecified; daily volume alone does not prove processing capacity.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 10 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Application sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Private invoice PDFs | Storage | 0.01 GB-month | price needed | — | — |
| Invoice ledger and durable work queue | Storage | 0.01 GB-month | price needed | — | — |
| Structured invoice extraction | Endpoint hours | 730 hours | price needed | — | — |
| Service credentials | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: 0.01 (discovery (2026-11-10)); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Uploaders and reviewers, Invoice upload and review application, Extraction and approved-delivery worker, Existing accounting API, Processing and recovery visibility.

**Estimate gaps:**

- Application sign-in / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: price needed.
- Invoice ledger and durable work queue / Storage: price needed.
- Structured invoice extraction / Endpoint hours: price needed.
- Service credentials / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Extraction and approved-delivery worker: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Processing and recovery visibility: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision invoice intake and review: Invoice upload and review application, Application sign-in.
4. Provision durable invoice state: Private invoice PDFs, Invoice ledger and durable work queue.
5. Provision extraction and delivery: Extraction and approved-delivery worker, Structured invoice extraction.
6. Provision operations: Service credentials, Processing and recovery visibility.
7. Connect existing systems: Uploaders and reviewers, Existing accounting API; test failure behaviour.
8. Run the acceptance checks (success measures and requirements) in staging; record results.
9. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Keep documents and extracted data in Australia; flag unverified service availability.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- Application sign-in: needs requests_per_month _(estimate)_
- Private invoice PDFs: needs a unit price with a source _(estimate)_
- Invoice ledger and durable work queue: needs a unit price with a source _(estimate)_
- Structured invoice extraction: needs a unit price with a source _(estimate)_
- Service credentials: needs requests_per_month _(estimate)_
