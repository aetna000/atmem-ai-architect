Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

# Asynchronous document intake — solution specification

## Problem and intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval. (must, open); target: acceptance target needed; linked blocks: invoice-documents, invoice-workflow, invoice-extraction, invoice-state, invoice-web

Design explanation: Gives reviewers a usable invoice record while exposing uncertain extraction instead of silently accepting incorrect financial data.

Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.” Confidence flags and source comparison are proposed safeguards.
- [REQ-004] Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions. (must, open); target: acceptance target needed; linked blocks: invoice-identity, invoice-application, invoice-state, invoice-delivery, invoice-accounting

Design explanation: Prevents unreviewed or subsequently altered financial values from crossing into accounting and makes each approval attributable.

Basis: “A reviewer approves a result before it is sent to our existing accounting API.” Revision-bound approval and audit history are proposed enforcement details.
- [REQ-005] Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved. (must, open); target: acceptance target needed; linked blocks: invoice-intake-worker, invoice-workflow, invoice-state, invoice-delivery, invoice-accounting

Design explanation: At-least-once events and lost accounting responses can repeat processing or create duplicate financial entries; local deduplication alone cannot prevent remote duplicates.

Basis: “Delivery can repeat; retries must not create duplicate invoices.” Accounting-side idempotency or reconciliation is not yet established.
- [REQ-006] Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions. (must, open); target: acceptance target needed; linked blocks: invoice-accounting, invoice-delivery, invoice-secrets

Design explanation: Preserves ownership of the existing accounting system and prevents integration credentials from reaching browsers or logs; endpoint and credentials alone do not prove API compatibility.

Basis: “The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.” Supported by invoice-accounting, invoice-delivery and invoice-secrets.

## How the system works

The current design contains 15 components and 21 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Uploaders and reviewers → Invoice upload and review application

HTTPS upload and review; approval available only to reviewers

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Invoice upload and review application → User sign-in

OAuth authorization code with PKCE; custom integration

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: User sign-in → Authenticated invoice API

JWT issuer and signing keys; custom authorizer configuration

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Invoice upload and review application → Authenticated invoice API

HTTPS with access token; statuses and review responses

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Authenticated invoice API → Upload and approval service

Authenticated invocation; server checks reviewer permission for approval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Upload and approval service → Private invoice PDFs

Scoped upload and review-download URL signing; custom IAM

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Invoice upload and review application → Private invoice PDFs

HTTPS PDF upload/download using restricted signed URLs

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Upload and approval service → Invoice state and review queue

Authorized queries and edits; reviewer-only conditional approval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Private invoice PDFs → Document intake queue

S3 ObjectCreated notification with object version

Integration contract: s3-object-created.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Document intake queue → Duplicate-safe intake worker

Lambda event mapping; partial batch failures

Integration contract: sqs-lambda.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Document intake queue → Failed intake messages

Redrive after bounded intake failures

Integration contract: sqs-redrive.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Duplicate-safe intake worker → Private invoice PDFs

GetObjectVersion for exact notified PDF; custom adapter

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Duplicate-safe intake worker → Invoice state and review queue

Conditional identity claim and workflow handoff record

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Duplicate-safe intake worker → Extraction and approval workflow

StartExecution with stable name; reconcile retries

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 15: Extraction and approval workflow → Invoice field extraction

StartExpenseAnalysis / GetExpenseAnalysis; bounded polling

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 16: Invoice field extraction → Private invoice PDFs

Authorized read of specified PDF object version

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 17: Extraction and approval workflow → Invoice state and review queue

Persist extracted fields and failures; poll approval revision

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 18: Extraction and approval workflow → Approved invoice delivery

Invoke delivery for approved invoice revision

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 19: Approved invoice delivery → Invoice state and review queue

Conditional delivery claim; record receipt or uncertain outcome

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 20: Approved invoice delivery → Existing accounting API

HTTPS to administrator-supplied endpoint; deduplication contract unresolved

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 21: Approved invoice delivery → Accounting integration secret

Scoped GetSecretValue for administrator-supplied accounting credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Uploaders and reviewers

Web browser · tools · region: To be selected · classification: Confidential

Twenty signed-in staff and three reviewers using browsers; existing people outside provisioning scope. Whether reviewers are included in the twenty staff is not established. Ordinary uploaders cannot approve. Server-enforced reviewer permissions are required; no existing company identity provider is assumed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Uploaders and reviewers → Invoice upload and review application: HTTPS upload and review; approval available only to reviewers

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Invoice upload and review application

AWS Amplify Hosting · aws · region: To be selected · classification: Confidential

Proposed AWS Amplify Hosting deployment for a custom browser application: upload PDFs, see processing status, view the source invoice beside extracted fields, correct values and approve a specific revision. Show approval controls only to reviewers, while enforcing permission independently on the server. Browser controls do not enforce authorization. Application code and hosting integration are not implemented by the current generator.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Uploaders and reviewers → Invoice upload and review application: HTTPS upload and review; approval available only to reviewers

Outputs: Invoice upload and review application → User sign-in: OAuth authorization code with PKCE; custom integration; Invoice upload and review application → Authenticated invoice API: HTTPS with access token; statuses and review responses; Invoice upload and review application → Private invoice PDFs: HTTPS PDF upload/download using restricted signed URLs

Requirement traceability: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### User sign-in

Amazon Cognito · aws · region: To be selected · classification: Confidential

Proposed Amazon Cognito user pool with authorization-code sign-in and PKCE. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Propose administrator-managed uploader/reviewer group assignments; users cannot grant themselves reviewer permission. API validates access tokens and application checks reviewer authorization. Existing company sign-in can be integrated later without assuming it exists. This is a custom invoice application identity integration, not the generated RAG user-pool contract.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → User sign-in: OAuth authorization code with PKCE; custom integration

Outputs: User sign-in → Authenticated invoice API: JWT issuer and signing keys; custom authorizer configuration

Requirement traceability: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authenticated invoice API

Amazon API Gateway · aws · region: To be selected · classification: Confidential

Proposed Amazon API Gateway HTTP API with a Cognito JWT authorizer. Routes upload initiation, status, review and approval to the invoice application Lambda. No anonymous invoice routes. A valid token establishes sign-in, not approval permission; the application must reject approval requests from ordinary uploaders. Custom API infrastructure and integration remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: User sign-in → Authenticated invoice API: JWT issuer and signing keys; custom authorizer configuration; Invoice upload and review application → Authenticated invoice API: HTTPS with access token; statuses and review responses

Outputs: Authenticated invoice API → Upload and approval service: Authenticated invocation; server checks reviewer permission for approval

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Upload and approval service

AWS Lambda · aws · region: To be selected · classification: Confidential

Custom Lambda deployment owns upload-session creation, scoped short-lived S3 upload/download URLs, review-list queries, field corrections and approval. Enforces user permissions and object access on every request. Only administrator-assigned reviewers may approve; ordinary uploader approval attempts fail without changing state or initiating delivery. Approval conditionally records reviewer identity, timestamp and exact field revision in DynamoDB; approved revisions cannot be edited or silently replaced. Returns statuses and review data directly. Owns execution role and scoped logs; not a supported text-statistics or word-count implementation. Acceptance tests must cover direct API approval attempts by uploaders, forged roles, concurrent edits and valid reviewer approval.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Authenticated invoice API → Upload and approval service: Authenticated invocation; server checks reviewer permission for approval

Outputs: Upload and approval service → Private invoice PDFs: Scoped upload and review-download URL signing; custom IAM; Upload and approval service → Invoice state and review queue: Authorized queries and edits; reviewer-only conditional approval

Requirement traceability: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Private invoice PDFs

Amazon S3 · aws · region: To be selected · classification: Confidential

Proposed private, encrypted, versioned S3 bucket. The application assigns immutable upload-session object keys and issues restricted upload URLs. Processing validates PDF content and reads the exact event object version; unsupported or unsafe documents remain blocked from extraction and delivery. Retention and deletion periods await business requirements. Browser access is application-mediated, not an invented IAM principal.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Upload and approval service → Private invoice PDFs: Scoped upload and review-download URL signing; custom IAM; Invoice upload and review application → Private invoice PDFs: HTTPS PDF upload/download using restricted signed URLs; Duplicate-safe intake worker → Private invoice PDFs: GetObjectVersion for exact notified PDF; custom adapter; Invoice field extraction → Private invoice PDFs: Authorized read of specified PDF object version

Outputs: Private invoice PDFs → Document intake queue: S3 ObjectCreated notification with object version (integration: s3-object-created)

Requirement traceability: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.

Implementation status: S3 foundation generated

Implementation considerations (guidance):
- Agree object ownership, retention/deletion, lifecycle and encryption/key policy; distinguish source data from Terraform state and build artifacts.
- Add least-privilege bucket access and transport policy; test denied access, version recovery and deletion behavior.

### Document intake queue

Amazon SQS · aws · region: To be selected · classification: Confidential

SQS standard queue buffers object-created notifications. Assume duplicate and out-of-order delivery. Worker uses partial batch failure responses; propose visibility timeout at least six times worker timeout plus batching window. Bounded retries lead to a dedicated DLQ. Queue settings and custom processing connection require validation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Private invoice PDFs → Document intake queue: S3 ObjectCreated notification with object version (integration: s3-object-created)

Outputs: Document intake queue → Duplicate-safe intake worker: Lambda event mapping; partial batch failures (integration: sqs-lambda); Document intake queue → Failed intake messages: Redrive after bounded intake failures (integration: sqs-redrive)

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Choose standard/FIFO semantics, encryption, queue policy, retention, visibility timeout and dead-letter/redrive settings.
- Define producer/consumer IAM and retries; prove duplicate processing is safe and poison messages can be recovered.

### Failed intake messages

Amazon SQS · aws · region: To be selected · classification: Confidential

Dedicated SQS dead-letter queue retains repeatedly failed intake events for operator investigation and controlled replay with original invoice identity. A non-empty-queue alarm and recovery runbook require implementation; no operator notification destination is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Document intake queue → Failed intake messages: Redrive after bounded intake failures (integration: sqs-redrive)

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Choose standard/FIFO semantics, encryption, queue policy, retention, visibility timeout and dead-letter/redrive settings.
- Define producer/consumer IAM and retries; prove duplicate processing is safe and poison messages can be recovered.

### Duplicate-safe intake worker

AWS Lambda · aws · region: To be selected · classification: Confidential

Custom Lambda validates the upload and reads its exact S3 version with scoped GetObjectVersion access. Uses conditional DynamoDB records to map repeated events to one stable invoice identity and starts a deterministically named Standard workflow. Retries reconcile claimed-but-not-started work; acknowledgments follow durable workflow handoff. Propose a content fingerprint to flag repeated uploads for review without automatically merging distinct invoices. Owns role and logs. Current async-word-count code does not implement this behavior.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Document intake queue → Duplicate-safe intake worker: Lambda event mapping; partial batch failures (integration: sqs-lambda)

Outputs: Duplicate-safe intake worker → Private invoice PDFs: GetObjectVersion for exact notified PDF; custom adapter; Duplicate-safe intake worker → Invoice state and review queue: Conditional identity claim and workflow handoff record; Duplicate-safe intake worker → Extraction and approval workflow: StartExecution with stable name; reconcile retries

Requirement traceability: REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Extraction and approval workflow

AWS Step Functions · aws · region: To be selected · classification: Confidential

Proposed Step Functions Standard workflow starts asynchronous Textract expense analysis against the exact document version, using a stable client request token where supported, and polls with bounded waits. Maps extracted supplier, invoice date, total and currency into a durable review record with confidence and missing-field flags. Waits and checks durable approval state before invoking delivery for the approved revision. Catch paths persist failures for investigation; workflow timeouts and recovery preserve invoice identity. SDK integration compatibility, field mapping, retries and recovery require implementation and tests.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Duplicate-safe intake worker → Extraction and approval workflow: StartExecution with stable name; reconcile retries

Outputs: Extraction and approval workflow → Invoice field extraction: StartExpenseAnalysis / GetExpenseAnalysis; bounded polling; Extraction and approval workflow → Invoice state and review queue: Persist extracted fields and failures; poll approval revision; Extraction and approval workflow → Approved invoice delivery: Invoke delivery for approved invoice revision

Requirement traceability: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Invoice field extraction

Amazon Textract · aws · region: To be selected · classification: Confidential

Proposed Amazon Textract asynchronous AnalyzeExpense capability for PDF invoices. Produces extracted fields and confidence evidence, never approval. Workflow must handle pagination, missing fields, document limits and service failures. Representative invoice accuracy, regional availability and exact API integration remain unverified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and approval workflow → Invoice field extraction: StartExpenseAnalysis / GetExpenseAnalysis; bounded polling

Outputs: Invoice field extraction → Private invoice PDFs: Authorized read of specified PDF object version

Requirement traceability: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Invoice state and review queue

Amazon DynamoDB · aws · region: To be selected · classification: Confidential

One proposed DynamoDB table stores upload identity, source version, processing state, extracted fields, field revisions, reviewer approval, delivery attempts and accounting receipt. Status indexes support the human review queue; it is not an SQS approval queue. Conditional writes and transactions enforce one active delivery claim and immutable approved payloads. Preserve audit events and ambiguous delivery outcomes; propose point-in-time recovery. Schema, permissions and retention require engineering, not the word-count-results implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Upload and approval service → Invoice state and review queue: Authorized queries and edits; reviewer-only conditional approval; Duplicate-safe intake worker → Invoice state and review queue: Conditional identity claim and workflow handoff record; Extraction and approval workflow → Invoice state and review queue: Persist extracted fields and failures; poll approval revision; Approved invoice delivery → Invoice state and review queue: Conditional delivery claim; record receipt or uncertain outcome

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.; REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

### Approved invoice delivery

AWS Lambda · aws · region: To be selected · classification: Confidential

Custom Lambda rechecks durable reviewer approval and conditionally claims the exact approved revision before sending supplier, invoice date, total and currency to existing accounting. An administrator supplies the HTTPS endpoint as controlled configuration and credentials through Secrets Manager; neither is collected in chat. Reuses a stable submission key on every attempt and records the external receipt. Never assumes exactly-once HTTP delivery: after an ambiguous response, reconcile by key or stop for investigation if the accounting API cannot deduplicate. Owns scoped execution role and redacted logs. API schema, authentication mechanism and duplicate protection remain unresolved implementation contracts; supplied connection details do not establish compatibility.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and approval workflow → Approved invoice delivery: Invoke delivery for approved invoice revision

Outputs: Approved invoice delivery → Invoice state and review queue: Conditional delivery claim; record receipt or uncertain outcome; Approved invoice delivery → Existing accounting API: HTTPS to administrator-supplied endpoint; deduplication contract unresolved; Approved invoice delivery → Accounting integration secret: Scoped GetSecretValue for administrator-supplied accounting credentials

Requirement traceability: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Existing accounting API

Existing accounting API · tools · region: Existing location not established · classification: Confidential

Client's existing externally managed accounting API, explicitly outside provisioning scope. An administrator supplies its endpoint and credentials through controlled configuration and secret management. Receives approved invoice fields and returns an accounting reference. No creation, import or modification of accounting is proposed. Vendor, request schema, authentication mechanism, idempotency support and lookup/reconciliation behavior remain unestablished; connectivity is not verified.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Approved invoice delivery → Existing accounting API: HTTPS to administrator-supplied endpoint; deduplication contract unresolved

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Accounting integration secret

AWS Secrets Manager · aws · region: To be selected · classification: Confidential

Proposed Secrets Manager secret populated by an administrator with accounting credentials through a secure operational procedure. Only delivery code receives runtime read permission. Keep credentials out of browser code, logs, diagram and Terraform values/state by implementing separate secret population. Authentication format and rotation depend on the existing accounting API contract. No credential values are requested or assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Approved invoice delivery → Accounting integration secret: Scoped GetSecretValue for administrator-supplied accounting credentials

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice upload and review application<br/>AWS"]
  n2["User sign-in<br/>AWS"]
  n3["Authenticated invoice API<br/>AWS"]
  n4["Upload and approval service<br/>AWS"]
  n5["Private invoice PDFs<br/>AWS"]
  n6["Document intake queue<br/>AWS"]
  n7["Failed intake messages<br/>AWS"]
  n8["Duplicate-safe intake worker<br/>AWS"]
  n9["Extraction and approval workflow<br/>AWS"]
  n10["Invoice field extraction<br/>AWS"]
  n11["Invoice state and review queue<br/>AWS"]
  n12["Approved invoice delivery<br/>AWS"]
  n13["Existing accounting API<br/>Tools & data"]
  n14["Accounting integration secret<br/>AWS"]
  n0 -->|HTTPS upload and review; approval available only to reviewers| n1
  n1 -->|OAuth authorization code with PKCE; custom integration| n2
  n2 -->|JWT issuer and signing keys; custom authorizer configuration| n3
  n1 -->|HTTPS with access token; statuses and review responses| n3
  n3 -->|Authenticated invocation; server checks reviewer permission for approval| n4
  n4 -->|Scoped upload and review-download URL signing; custom IAM| n5
  n1 -->|HTTPS PDF upload/download using restricted signed URLs| n5
  n4 -->|Authorized queries and edits; reviewer-only conditional approval| n11
  n5 -->|S3 ObjectCreated notification with object version| n6
  n6 -->|Lambda event mapping; partial batch failures| n8
  n6 -->|Redrive after bounded intake failures| n7
  n8 -->|GetObjectVersion for exact notified PDF; custom adapter| n5
  n8 -->|Conditional identity claim and workflow handoff record| n11
  n8 -->|StartExecution with stable name; reconcile retries| n9
  n9 -->|StartExpenseAnalysis / GetExpenseAnalysis; bounded polling| n10
  n10 -->|Authorized read of specified PDF object version| n5
  n9 -->|Persist extracted fields and failures; poll approval revision| n11
  n9 -->|Invoke delivery for approved invoice revision| n12
  n12 -->|Conditional delivery claim; record receipt or uncertain outcome| n11
  n12 -->|HTTPS to administrator-supplied endpoint; deduplication contract unresolved| n13
  n12 -->|Scoped GetSecretValue for administrator-supplied accounting credentials| n14
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Web browser | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-web | Invoice upload and review application | aws | AWS Amplify Hosting | To be selected | Proposed | Implementation needed |
| invoice-identity | User sign-in | aws | Amazon Cognito | To be selected | Proposed | Implementation needed |
| invoice-api | Authenticated invoice API | aws | Amazon API Gateway | To be selected | Proposed | Implementation needed |
| invoice-application | Upload and approval service | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| invoice-documents | Private invoice PDFs | aws | Amazon S3 | To be selected | Proposed | S3 foundation generated |
| invoice-intake-queue | Document intake queue | aws | Amazon SQS | To be selected | Proposed | Implementation needed |
| invoice-intake-dlq | Failed intake messages | aws | Amazon SQS | To be selected | Proposed | Implementation needed |
| invoice-intake-worker | Duplicate-safe intake worker | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| invoice-workflow | Extraction and approval workflow | aws | AWS Step Functions | To be selected | Proposed | Implementation needed |
| invoice-extraction | Invoice field extraction | aws | Amazon Textract | To be selected | Proposed | Implementation needed |
| invoice-state | Invoice state and review queue | aws | Amazon DynamoDB | To be selected | Proposed | Implementation needed |
| invoice-delivery | Approved invoice delivery | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| invoice-accounting | Existing accounting API | tools | Existing accounting API | Existing location not established | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| invoice-secrets | Accounting integration secret | aws | AWS Secrets Manager | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Invoice upload and review application** (invoice-web): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users.
- **User sign-in** (invoice-identity): aws_cognito_user_pool. Active users and authentication features. Depends on: invoice-web.
- **Authenticated invoice API** (invoice-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: invoice-identity, invoice-web.
- **Upload and approval service** (invoice-application): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: invoice-api.
- **Private invoice PDFs** (invoice-documents): aws_s3_bucket, aws_s3_bucket_public_access_block, aws_s3_bucket_server_side_encryption_configuration, aws_s3_bucket_versioning, aws_s3_bucket_ownership_controls, aws_s3_bucket_policy. Storage, requests, retrieval and transfer. Depends on: invoice-application, invoice-web, invoice-intake-worker, invoice-extraction.
- **Document intake queue** (invoice-intake-queue): aws_sqs_queue. Requests, payload size and transfer. Depends on: invoice-documents.
- **Failed intake messages** (invoice-intake-dlq): aws_sqs_queue. Requests, payload size and transfer. Depends on: invoice-intake-queue.
- **Duplicate-safe intake worker** (invoice-intake-worker): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: invoice-intake-queue.
- **Extraction and approval workflow** (invoice-workflow): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-intake-worker.
- **Invoice field extraction** (invoice-extraction): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-workflow.
- **Invoice state and review queue** (invoice-state): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: invoice-application, invoice-intake-worker, invoice-workflow, invoice-delivery.
- **Approved invoice delivery** (invoice-delivery): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: invoice-workflow.
- **Existing accounting API** (invoice-accounting): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-delivery.
- **Accounting integration secret** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-delivery.

### Engineering work remaining

- Private invoice PDFs: explicit caller access contract is missing.
- Invoice upload and review application: Implementation needed.
- User sign-in: Implementation needed.
- Authenticated invoice API: Implementation needed.
- Upload and approval service: Implementation needed.
- Document intake queue: Implementation needed.
- Failed intake messages: Implementation needed.
- Duplicate-safe intake worker: Implementation needed.
- Extraction and approval workflow: Implementation needed.
- Invoice field extraction: Implementation needed.
- Invoice state and review queue: Implementation needed.
- Approved invoice delivery: Implementation needed.
- Accounting integration secret: Implementation needed.
- Wire invoice-users → invoice-web: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-identity → invoice-api: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-api: implement data flow, access policy and acceptance test.
- Wire invoice-api → invoice-application: implement data flow, access policy and acceptance test.
- Wire invoice-application → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-application → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-documents → invoice-intake-queue: implement data flow, access policy and acceptance test.
- Wire invoice-intake-queue → invoice-intake-worker: implement data flow, access policy and acceptance test.
- Wire invoice-intake-queue → invoice-intake-dlq: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-workflow: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-extraction → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-delivery: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-secrets: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
