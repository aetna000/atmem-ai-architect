# Delivery handoff

Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- User sign-in / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: input needed (data_gb).
- Document intake queue / Data processed: input needed (data_gb).
- Failed intake messages / Storage: input needed (data_gb).
- Duplicate-safe intake worker / Data processed: input needed (data_gb).
- Invoice field extraction / Endpoint hours: price needed.
- Invoice state and review queue / Storage: input needed (data_gb).
- Accounting integration secret / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated invoice API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Upload and approval service: no cost lines; add charges or an explicit zero-cost line with a reason.
- Extraction and approval workflow: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved invoice delivery: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Private invoice PDFs: explicit caller access contract is missing.
- Invoice upload and review application: Implementation needed.
- User sign-in: Implementation needed.
- Authenticated invoice API: Implementation needed.
- Upload and approval service: Implementation needed.
- Document intake queue: Implementation needed.
- Failed intake messages: Implementation needed.
- Duplicate-safe intake worker: Implementation needed.
- Extraction and approval workflow: Implementation needed.
- Invoice field extraction: Implementation needed.
- Invoice state and review queue: Implementation needed.
- Approved invoice delivery: Implementation needed.
- Accounting integration secret: Implementation needed.
- Wire invoice-users → invoice-web: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-identity → invoice-api: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-api: implement data flow, access policy and acceptance test.
- Wire invoice-api → invoice-application: implement data flow, access policy and acceptance test.
- Wire invoice-application → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-application → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-documents → invoice-intake-queue: implement data flow, access policy and acceptance test.
- Wire invoice-intake-queue → invoice-intake-worker: implement data flow, access policy and acceptance test.
- Wire invoice-intake-queue → invoice-intake-dlq: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-workflow: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-extraction → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-delivery: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-secrets: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
