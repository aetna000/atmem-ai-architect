# Component and interface contracts

Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component invoice-users: Uploaders and reviewers

- Responsibility: Twenty signed-in staff and three reviewers using browsers; existing people outside provisioning scope. Whether reviewers are included in the twenty staff is not established. Ordinary uploaders cannot approve. Server-enforced reviewer permissions are required; no existing company identity provider is assumed.
- Service: Web browser
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component invoice-web: Invoice upload and review application

- Responsibility: Proposed AWS Amplify Hosting deployment for a custom browser application: upload PDFs, see processing status, view the source invoice beside extracted fields, correct values and approve a specific revision. Show approval controls only to reviewers, while enforcing permission independently on the server. Browser controls do not enforce authorization. Application code and hosting integration are not implemented by the current generator.
- Service: AWS Amplify Hosting
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-identity: User sign-in

- Responsibility: Proposed Amazon Cognito user pool with authorization-code sign-in and PKCE. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Propose administrator-managed uploader/reviewer group assignments; users cannot grant themselves reviewer permission. API validates access tokens and application checks reviewer authorization. Existing company sign-in can be integrated later without assuming it exists. This is a custom invoice application identity integration, not the generated RAG user-pool contract.
- Service: Amazon Cognito
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-api: Authenticated invoice API

- Responsibility: Proposed Amazon API Gateway HTTP API with a Cognito JWT authorizer. Routes upload initiation, status, review and approval to the invoice application Lambda. No anonymous invoice routes. A valid token establishes sign-in, not approval permission; the application must reject approval requests from ordinary uploaders. Custom API infrastructure and integration remain engineering work.
- Service: Amazon API Gateway
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-application: Upload and approval service

- Responsibility: Custom Lambda deployment owns upload-session creation, scoped short-lived S3 upload/download URLs, review-list queries, field corrections and approval. Enforces user permissions and object access on every request. Only administrator-assigned reviewers may approve; ordinary uploader approval attempts fail without changing state or initiating delivery. Approval conditionally records reviewer identity, timestamp and exact field revision in DynamoDB; approved revisions cannot be edited or silently replaced. Returns statuses and review data directly. Owns execution role and scoped logs; not a supported text-statistics or word-count implementation. Acceptance tests must cover direct API approval attempts by uploaders, forged roles, concurrent edits and valid reviewer approval.
- Service: AWS Lambda
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component invoice-documents: Private invoice PDFs

- Responsibility: Proposed private, encrypted, versioned S3 bucket. The application assigns immutable upload-session object keys and issues restricted upload URLs. Processing validates PDF content and reads the exact event object version; unsupported or unsafe documents remain blocked from extraction and delivery. Retention and deletion periods await business requirements. Browser access is application-mediated, not an invented IAM principal.
- Service: Amazon S3
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d646f63756d656e7473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Agree object ownership, retention/deletion, lifecycle and encryption/key policy; distinguish source data from Terraform state and build artifacts.
- Add least-privilege bucket access and transport policy; test denied access, version recovery and deletion behavior.

## Component invoice-intake-queue: Document intake queue

- Responsibility: SQS standard queue buffers object-created notifications. Assume duplicate and out-of-order delivery. Worker uses partial batch failure responses; propose visibility timeout at least six times worker timeout plus batching window. Bounded retries lead to a dedicated DLQ. Queue settings and custom processing connection require validation.
- Service: Amazon SQS
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Choose standard/FIFO semantics, encryption, queue policy, retention, visibility timeout and dead-letter/redrive settings.
- Define producer/consumer IAM and retries; prove duplicate processing is safe and poison messages can be recovered.

## Component invoice-intake-dlq: Failed intake messages

- Responsibility: Dedicated SQS dead-letter queue retains repeatedly failed intake events for operator investigation and controlled replay with original invoice identity. A non-empty-queue alarm and recovery runbook require implementation; no operator notification destination is assumed.
- Service: Amazon SQS
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d696e74616b652d646c71
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Choose standard/FIFO semantics, encryption, queue policy, retention, visibility timeout and dead-letter/redrive settings.
- Define producer/consumer IAM and retries; prove duplicate processing is safe and poison messages can be recovered.

## Component invoice-intake-worker: Duplicate-safe intake worker

- Responsibility: Custom Lambda validates the upload and reads its exact S3 version with scoped GetObjectVersion access. Uses conditional DynamoDB records to map repeated events to one stable invoice identity and starts a deterministically named Standard workflow. Retries reconcile claimed-but-not-started work; acknowledgments follow durable workflow handoff. Propose a content fingerprint to flag repeated uploads for review without automatically merging distinct invoices. Owns role and logs. Current async-word-count code does not implement this behavior.
- Service: AWS Lambda
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component invoice-workflow: Extraction and approval workflow

- Responsibility: Proposed Step Functions Standard workflow starts asynchronous Textract expense analysis against the exact document version, using a stable client request token where supported, and polls with bounded waits. Maps extracted supplier, invoice date, total and currency into a durable review record with confidence and missing-field flags. Waits and checks durable approval state before invoking delivery for the approved revision. Catch paths persist failures for investigation; workflow timeouts and recovery preserve invoice identity. SDK integration compatibility, field mapping, retries and recovery require implementation and tests.
- Service: AWS Step Functions
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d776f726b666c6f77
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-extraction: Invoice field extraction

- Responsibility: Proposed Amazon Textract asynchronous AnalyzeExpense capability for PDF invoices. Produces extracted fields and confidence evidence, never approval. Workflow must handle pagination, missing fields, document limits and service failures. Representative invoice accuracy, regional availability and exact API integration remain unverified.
- Service: Amazon Textract
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d65787472616374696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-state: Invoice state and review queue

- Responsibility: One proposed DynamoDB table stores upload identity, source version, processing state, extracted fields, field revisions, reviewer approval, delivery attempts and accounting receipt. Status indexes support the human review queue; it is not an SQS approval queue. Conditional writes and transactions enforce one active delivery claim and immutable approved payloads. Preserve audit events and ambiguous delivery outcomes; propose point-in-time recovery. Schema, permissions and retention require engineering, not the word-count-results implementation.
- Service: Amazon DynamoDB
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

## Component invoice-delivery: Approved invoice delivery

- Responsibility: Custom Lambda rechecks durable reviewer approval and conditionally claims the exact approved revision before sending supplier, invoice date, total and currency to existing accounting. An administrator supplies the HTTPS endpoint as controlled configuration and credentials through Secrets Manager; neither is collected in chat. Reuses a stable submission key on every attempt and records the external receipt. Never assumes exactly-once HTTP delivery: after an ambiguous response, reconcile by key or stop for investigation if the accounting API cannot deduplicate. Owns scoped execution role and redacted logs. API schema, authentication mechanism and duplicate protection remain unresolved implementation contracts; supplied connection details do not establish compatibility.
- Service: AWS Lambda
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d64656c6976657279
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component invoice-accounting: Existing accounting API

- Responsibility: Client's existing externally managed accounting API, explicitly outside provisioning scope. An administrator supplies its endpoint and credentials through controlled configuration and secret management. Receives approved invoice fields and returns an accounting reference. No creation, import or modification of accounting is proposed. Vendor, request schema, authentication mechanism, idempotency support and lookup/reconciliation behavior remain unestablished; connectivity is not verified.
- Service: Existing accounting API
- Provider / placement: tools / Existing location not established
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d6163636f756e74696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component invoice-secrets: Accounting integration secret

- Responsibility: Proposed Secrets Manager secret populated by an administrator with accounting credentials through a secure operational procedure. Only delivery code receives runtime read permission. Keep credentials out of browser code, logs, diagram and Terraform values/state by implementing separate secret population. Authentication format and rotation depend on the existing accounting API contract. No credential values are requested or assumed.
- Service: AWS Secrets Manager
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### users-web: invoice-users → invoice-web

- Drawn payload/purpose: HTTPS upload and review; approval available only to reviewers
- Contract task: TASK-CONTRACT-75736572732d776562
- Integration task: TASK-INTEGRATION-75736572732d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-identity: invoice-web → invoice-identity

- Drawn payload/purpose: OAuth authorization code with PKCE; custom integration
- Contract task: TASK-CONTRACT-7765622d6964656e74697479
- Integration task: TASK-INTEGRATION-7765622d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### identity-api: invoice-identity → invoice-api

- Drawn payload/purpose: JWT issuer and signing keys; custom authorizer configuration
- Contract task: TASK-CONTRACT-6964656e746974792d617069
- Integration task: TASK-INTEGRATION-6964656e746974792d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-api: invoice-web → invoice-api

- Drawn payload/purpose: HTTPS with access token; statuses and review responses
- Contract task: TASK-CONTRACT-7765622d617069
- Integration task: TASK-INTEGRATION-7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-application: invoice-api → invoice-application

- Drawn payload/purpose: Authenticated invocation; server checks reviewer permission for approval
- Contract task: TASK-CONTRACT-6170692d6170706c69636174696f6e
- Integration task: TASK-INTEGRATION-6170692d6170706c69636174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### application-documents: invoice-application → invoice-documents

- Drawn payload/purpose: Scoped upload and review-download URL signing; custom IAM
- Contract task: TASK-CONTRACT-6170706c69636174696f6e2d646f63756d656e7473
- Integration task: TASK-INTEGRATION-6170706c69636174696f6e2d646f63756d656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-documents: invoice-web → invoice-documents

- Drawn payload/purpose: HTTPS PDF upload/download using restricted signed URLs
- Contract task: TASK-CONTRACT-7765622d646f63756d656e7473
- Integration task: TASK-INTEGRATION-7765622d646f63756d656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### application-state: invoice-application → invoice-state

- Drawn payload/purpose: Authorized queries and edits; reviewer-only conditional approval
- Contract task: TASK-CONTRACT-6170706c69636174696f6e2d7374617465
- Integration task: TASK-INTEGRATION-6170706c69636174696f6e2d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### documents-queue: invoice-documents → invoice-intake-queue

- Drawn payload/purpose: S3 ObjectCreated notification with object version
- Contract task: TASK-CONTRACT-646f63756d656e74732d7175657565
- Integration task: TASK-INTEGRATION-646f63756d656e74732d7175657565
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### queue-worker: invoice-intake-queue → invoice-intake-worker

- Drawn payload/purpose: Lambda event mapping; partial batch failures
- Contract task: TASK-CONTRACT-71756575652d776f726b6572
- Integration task: TASK-INTEGRATION-71756575652d776f726b6572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### queue-dlq: invoice-intake-queue → invoice-intake-dlq

- Drawn payload/purpose: Redrive after bounded intake failures
- Contract task: TASK-CONTRACT-71756575652d646c71
- Integration task: TASK-INTEGRATION-71756575652d646c71
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-documents: invoice-intake-worker → invoice-documents

- Drawn payload/purpose: GetObjectVersion for exact notified PDF; custom adapter
- Contract task: TASK-CONTRACT-776f726b65722d646f63756d656e7473
- Integration task: TASK-INTEGRATION-776f726b65722d646f63756d656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-state: invoice-intake-worker → invoice-state

- Drawn payload/purpose: Conditional identity claim and workflow handoff record
- Contract task: TASK-CONTRACT-776f726b65722d7374617465
- Integration task: TASK-INTEGRATION-776f726b65722d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-workflow: invoice-intake-worker → invoice-workflow

- Drawn payload/purpose: StartExecution with stable name; reconcile retries
- Contract task: TASK-CONTRACT-776f726b65722d776f726b666c6f77
- Integration task: TASK-INTEGRATION-776f726b65722d776f726b666c6f77
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### workflow-extraction: invoice-workflow → invoice-extraction

- Drawn payload/purpose: StartExpenseAnalysis / GetExpenseAnalysis; bounded polling
- Contract task: TASK-CONTRACT-776f726b666c6f772d65787472616374696f6e
- Integration task: TASK-INTEGRATION-776f726b666c6f772d65787472616374696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### extraction-documents: invoice-extraction → invoice-documents

- Drawn payload/purpose: Authorized read of specified PDF object version
- Contract task: TASK-CONTRACT-65787472616374696f6e2d646f63756d656e7473
- Integration task: TASK-INTEGRATION-65787472616374696f6e2d646f63756d656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### workflow-state: invoice-workflow → invoice-state

- Drawn payload/purpose: Persist extracted fields and failures; poll approval revision
- Contract task: TASK-CONTRACT-776f726b666c6f772d7374617465
- Integration task: TASK-INTEGRATION-776f726b666c6f772d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### workflow-delivery: invoice-workflow → invoice-delivery

- Drawn payload/purpose: Invoke delivery for approved invoice revision
- Contract task: TASK-CONTRACT-776f726b666c6f772d64656c6976657279
- Integration task: TASK-INTEGRATION-776f726b666c6f772d64656c6976657279
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### delivery-state: invoice-delivery → invoice-state

- Drawn payload/purpose: Conditional delivery claim; record receipt or uncertain outcome
- Contract task: TASK-CONTRACT-64656c69766572792d7374617465
- Integration task: TASK-INTEGRATION-64656c69766572792d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### delivery-accounting: invoice-delivery → invoice-accounting

- Drawn payload/purpose: HTTPS to administrator-supplied endpoint; deduplication contract unresolved
- Contract task: TASK-CONTRACT-64656c69766572792d6163636f756e74696e67
- Integration task: TASK-INTEGRATION-64656c69766572792d6163636f756e74696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### delivery-secrets: invoice-delivery → invoice-secrets

- Drawn payload/purpose: Scoped GetSecretValue for administrator-supplied accounting credentials
- Contract task: TASK-CONTRACT-64656c69766572792d73656372657473
- Integration task: TASK-INTEGRATION-64656c69766572792d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
