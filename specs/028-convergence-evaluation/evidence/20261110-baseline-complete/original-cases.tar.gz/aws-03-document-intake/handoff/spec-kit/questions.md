# Questions and assumptions to resolve

Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

- [ai-invoice-extraction] Confirm REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.
- [ai-invoice-approval] Confirm REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.
- [ai-invoice-idempotency] Confirm REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.
- [ai-invoice-accounting-boundary] Confirm REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.
- [acceptance-ai-invoice-extraction] Agree a measurable acceptance check for REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.
- [acceptance-ai-invoice-approval] Agree a measurable acceptance check for REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.
- [acceptance-ai-invoice-idempotency] Agree a measurable acceptance check for REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.
- [acceptance-ai-invoice-accounting-boundary] Agree a measurable acceptance check for REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d696e766f6963652d617070726f76616c] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d696e766f6963652d65787472616374696f6e] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d696e766f6963652d6964656d706f74656e6379] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
