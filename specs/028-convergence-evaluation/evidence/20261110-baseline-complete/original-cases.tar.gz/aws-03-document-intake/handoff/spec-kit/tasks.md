# Detailed implementation tasks

Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-75736572732d776562 — Define Uploaders and reviewers → Invoice upload and review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-users, invoice-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-web: HTTPS upload and review; approval available only to reviewers. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-web
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d6964656e74697479 — Define Invoice upload and review application → User sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-web, invoice-identity
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-identity: OAuth authorization code with PKCE; custom integration. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-identity
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6964656e746974792d617069 — Define User sign-in → Authenticated invoice API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-identity, invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection identity-api: JWT issuer and signing keys; custom authorizer configuration. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge identity-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d617069 — Define Invoice upload and review application → Authenticated invoice API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-web, invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-api: HTTPS with access token; statuses and review responses. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170692d6170706c69636174696f6e — Define Authenticated invoice API → Upload and approval service

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-api, invoice-application
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection api-application: Authenticated invocation; server checks reviewer permission for approval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge api-application
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170706c69636174696f6e2d646f63756d656e7473 — Define Upload and approval service → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-application, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection application-documents: Scoped upload and review-download URL signing; custom IAM. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge application-documents
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d646f63756d656e7473 — Define Invoice upload and review application → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-web, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-documents: HTTPS PDF upload/download using restricted signed URLs. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-documents
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170706c69636174696f6e2d7374617465 — Define Upload and approval service → Invoice state and review queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-application, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection application-state: Authorized queries and edits; reviewer-only conditional approval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge application-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-646f63756d656e74732d7175657565 — Define Private invoice PDFs → Document intake queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-documents, invoice-intake-queue
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection documents-queue: S3 ObjectCreated notification with object version. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge documents-queue
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-71756575652d776f726b6572 — Define Document intake queue → Duplicate-safe intake worker

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-intake-queue, invoice-intake-worker
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection queue-worker: Lambda event mapping; partial batch failures. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge queue-worker
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-71756575652d646c71 — Define Document intake queue → Failed intake messages

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-intake-queue, invoice-intake-dlq
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection queue-dlq: Redrive after bounded intake failures. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge queue-dlq
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d646f63756d656e7473 — Define Duplicate-safe intake worker → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-intake-worker, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-documents: GetObjectVersion for exact notified PDF; custom adapter. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-documents
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d7374617465 — Define Duplicate-safe intake worker → Invoice state and review queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-intake-worker, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-state: Conditional identity claim and workflow handoff record. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d776f726b666c6f77 — Define Duplicate-safe intake worker → Extraction and approval workflow

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-intake-worker, invoice-workflow
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-workflow: StartExecution with stable name; reconcile retries. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-workflow
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b666c6f772d65787472616374696f6e — Define Extraction and approval workflow → Invoice field extraction

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-workflow, invoice-extraction
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection workflow-extraction: StartExpenseAnalysis / GetExpenseAnalysis; bounded polling. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge workflow-extraction
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-65787472616374696f6e2d646f63756d656e7473 — Define Invoice field extraction → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-extraction, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection extraction-documents: Authorized read of specified PDF object version. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge extraction-documents
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b666c6f772d7374617465 — Define Extraction and approval workflow → Invoice state and review queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-workflow, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection workflow-state: Persist extracted fields and failures; poll approval revision. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge workflow-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b666c6f772d64656c6976657279 — Define Extraction and approval workflow → Approved invoice delivery

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-workflow, invoice-delivery
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection workflow-delivery: Invoke delivery for approved invoice revision. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge workflow-delivery
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-64656c69766572792d7374617465 — Define Approved invoice delivery → Invoice state and review queue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-delivery, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection delivery-state: Conditional delivery claim; record receipt or uncertain outcome. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge delivery-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-64656c69766572792d6163636f756e74696e67 — Define Approved invoice delivery → Existing accounting API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-delivery, invoice-accounting
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection delivery-accounting: HTTPS to administrator-supplied endpoint; deduplication contract unresolved. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge delivery-accounting
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-64656c69766572792d73656372657473 — Define Approved invoice delivery → Accounting integration secret

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-delivery, invoice-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection delivery-secrets: Scoped GetSecretValue for administrator-supplied accounting credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge delivery-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-696e766f6963652d7573657273 — Integrate existing Uploaders and reviewers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d776562
- Components: invoice-users
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Twenty signed-in staff and three reviewers using browsers; existing people outside provisioning scope. Whether reviewers are included in the twenty staff is not established. Ordinary uploaders cannot approve. Server-enforced reviewer permissions are required; no existing company identity provider is assumed.
2. Verify Web browser on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-users
- Application/configuration and tests for Uploaders and reviewers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d776562 — Implement Invoice upload and review application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d776562, TASK-CONTRACT-7765622d6964656e74697479, TASK-CONTRACT-7765622d617069, TASK-CONTRACT-7765622d646f63756d656e7473
- Components: invoice-web
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Responsibility from the board: Proposed AWS Amplify Hosting deployment for a custom browser application: upload PDFs, see processing status, view the source invoice beside extracted fields, correct values and approve a specific revision. Show approval controls only to reviewers, while enforcing permission independently on the server. Browser controls do not enforce authorization. Application code and hosting integration are not implemented by the current generator.
2. Verify AWS Amplify Hosting on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Amplify Hosting; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-web
- Application/configuration and tests for Invoice upload and review application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6964656e74697479 — Implement User sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7765622d6964656e74697479, TASK-CONTRACT-6964656e746974792d617069
- Components: invoice-identity
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Proposed Amazon Cognito user pool with authorization-code sign-in and PKCE. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Propose administrator-managed uploader/reviewer group assignments; users cannot grant themselves reviewer permission. API validates access tokens and application checks reviewer authorization. Existing company sign-in can be integrated later without assuming it exists. This is a custom invoice application identity integration, not the generated RAG user-pool contract.
2. Verify Amazon Cognito on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon Cognito; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-identity
- Application/configuration and tests for User sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d617069 — Implement Authenticated invoice API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6964656e746974792d617069, TASK-CONTRACT-7765622d617069, TASK-CONTRACT-6170692d6170706c69636174696f6e
- Components: invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Amazon API Gateway HTTP API with a Cognito JWT authorizer. Routes upload initiation, status, review and approval to the invoice application Lambda. No anonymous invoice routes. A valid token establishes sign-in, not approval permission; the application must reject approval requests from ordinary uploaders. Custom API infrastructure and integration remain engineering work.
2. Verify Amazon API Gateway on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon API Gateway; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-api
- Application/configuration and tests for Authenticated invoice API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e — Implement Upload and approval service

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170692d6170706c69636174696f6e, TASK-CONTRACT-6170706c69636174696f6e2d646f63756d656e7473, TASK-CONTRACT-6170706c69636174696f6e2d7374617465
- Components: invoice-application
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Custom Lambda deployment owns upload-session creation, scoped short-lived S3 upload/download URLs, review-list queries, field corrections and approval. Enforces user permissions and object access on every request. Only administrator-assigned reviewers may approve; ordinary uploader approval attempts fail without changing state or initiating delivery. Approval conditionally records reviewer identity, timestamp and exact field revision in DynamoDB; approved revisions cannot be edited or silently replaced. Returns statuses and review data directly. Owns execution role and scoped logs; not a supported text-statistics or word-count implementation. Acceptance tests must cover direct API approval attempts by uploaders, forged roles, concurrent edits and valid reviewer approval.
2. Verify AWS Lambda on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-application
- Application/configuration and tests for Upload and approval service

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d646f63756d656e7473 — Validate generated Private invoice PDFs

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170706c69636174696f6e2d646f63756d656e7473, TASK-CONTRACT-7765622d646f63756d656e7473, TASK-CONTRACT-646f63756d656e74732d7175657565, TASK-CONTRACT-776f726b65722d646f63756d656e7473, TASK-CONTRACT-65787472616374696f6e2d646f63756d656e7473
- Components: invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Responsibility from the board: Proposed private, encrypted, versioned S3 bucket. The application assigns immutable upload-session object keys and issues restricted upload URLs. Processing validates PDF content and reads the exact event object version; unsupported or unsafe documents remain blocked from extraction and delivery. Retention and deletion periods await business requirements. Browser access is application-mediated, not an invented IAM principal.
2. Verify Amazon S3 on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Inspect the generated S3 resources in terraform/main.tf.json. Complete IAM, retention, lifecycle, key management and application access according to confirmed requirements.
4. Agree object ownership, retention/deletion, lifecycle and encryption/key policy; distinguish source data from Terraform state and build artifacts.
5. Add least-privilege bucket access and transport policy; test denied access, version recovery and deletion behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-documents
- Application/configuration and tests for Private invoice PDFs

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565 — Implement Document intake queue

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-646f63756d656e74732d7175657565, TASK-CONTRACT-71756575652d776f726b6572, TASK-CONTRACT-71756575652d646c71
- Components: invoice-intake-queue
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: SQS standard queue buffers object-created notifications. Assume duplicate and out-of-order delivery. Worker uses partial batch failure responses; propose visibility timeout at least six times worker timeout plus batching window. Bounded retries lead to a dedicated DLQ. Queue settings and custom processing connection require validation.
2. Verify Amazon SQS on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon SQS; determine exact resource types and required application code. The export has not generated this implementation.
4. Choose standard/FIFO semantics, encryption, queue policy, retention, visibility timeout and dead-letter/redrive settings.
5. Define producer/consumer IAM and retries; prove duplicate processing is safe and poison messages can be recovered.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-intake-queue
- Application/configuration and tests for Document intake queue

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d696e74616b652d646c71 — Implement Failed intake messages

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-71756575652d646c71
- Components: invoice-intake-dlq
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Dedicated SQS dead-letter queue retains repeatedly failed intake events for operator investigation and controlled replay with original invoice identity. A non-empty-queue alarm and recovery runbook require implementation; no operator notification destination is assumed.
2. Verify Amazon SQS on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon SQS; determine exact resource types and required application code. The export has not generated this implementation.
4. Choose standard/FIFO semantics, encryption, queue policy, retention, visibility timeout and dead-letter/redrive settings.
5. Define producer/consumer IAM and retries; prove duplicate processing is safe and poison messages can be recovered.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-intake-dlq
- Application/configuration and tests for Failed intake messages

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572 — Implement Duplicate-safe intake worker

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-71756575652d776f726b6572, TASK-CONTRACT-776f726b65722d646f63756d656e7473, TASK-CONTRACT-776f726b65722d7374617465, TASK-CONTRACT-776f726b65722d776f726b666c6f77
- Components: invoice-intake-worker
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-idempotency

### Implementation steps

1. Responsibility from the board: Custom Lambda validates the upload and reads its exact S3 version with scoped GetObjectVersion access. Uses conditional DynamoDB records to map repeated events to one stable invoice identity and starts a deterministically named Standard workflow. Retries reconcile claimed-but-not-started work; acknowledgments follow durable workflow handoff. Propose a content fingerprint to flag repeated uploads for review without automatically merging distinct invoices. Owns role and logs. Current async-word-count code does not implement this behavior.
2. Verify AWS Lambda on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-intake-worker
- Application/configuration and tests for Duplicate-safe intake worker

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d776f726b666c6f77 — Implement Extraction and approval workflow

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d776f726b666c6f77, TASK-CONTRACT-776f726b666c6f772d65787472616374696f6e, TASK-CONTRACT-776f726b666c6f772d7374617465, TASK-CONTRACT-776f726b666c6f772d64656c6976657279
- Components: invoice-workflow
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-extraction, ai-invoice-idempotency

### Implementation steps

1. Responsibility from the board: Proposed Step Functions Standard workflow starts asynchronous Textract expense analysis against the exact document version, using a stable client request token where supported, and polls with bounded waits. Maps extracted supplier, invoice date, total and currency into a durable review record with confidence and missing-field flags. Waits and checks durable approval state before invoking delivery for the approved revision. Catch paths persist failures for investigation; workflow timeouts and recovery preserve invoice identity. SDK integration compatibility, field mapping, retries and recovery require implementation and tests.
2. Verify AWS Step Functions on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Step Functions; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-workflow
- Application/configuration and tests for Extraction and approval workflow

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d65787472616374696f6e — Implement Invoice field extraction

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b666c6f772d65787472616374696f6e, TASK-CONTRACT-65787472616374696f6e2d646f63756d656e7473
- Components: invoice-extraction
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Responsibility from the board: Proposed Amazon Textract asynchronous AnalyzeExpense capability for PDF invoices. Produces extracted fields and confidence evidence, never approval. Workflow must handle pagination, missing fields, document limits and service failures. Representative invoice accuracy, regional availability and exact API integration remain unverified.
2. Verify Amazon Textract on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon Textract; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-extraction
- Application/configuration and tests for Invoice field extraction

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d7374617465 — Implement Invoice state and review queue

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170706c69636174696f6e2d7374617465, TASK-CONTRACT-776f726b65722d7374617465, TASK-CONTRACT-776f726b666c6f772d7374617465, TASK-CONTRACT-64656c69766572792d7374617465
- Components: invoice-state
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-extraction, ai-invoice-approval, ai-invoice-idempotency

### Implementation steps

1. Responsibility from the board: One proposed DynamoDB table stores upload identity, source version, processing state, extracted fields, field revisions, reviewer approval, delivery attempts and accounting receipt. Status indexes support the human review queue; it is not an SQS approval queue. Conditional writes and transactions enforce one active delivery claim and immutable approved payloads. Preserve audit events and ambiguous delivery outcomes; propose point-in-time recovery. Schema, permissions and retention require engineering, not the word-count-results implementation.
2. Verify Amazon DynamoDB on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon DynamoDB; determine exact resource types and required application code. The export has not generated this implementation.
4. Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
5. Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.; REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-state
- Application/configuration and tests for Invoice state and review queue

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d64656c6976657279 — Implement Approved invoice delivery

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b666c6f772d64656c6976657279, TASK-CONTRACT-64656c69766572792d7374617465, TASK-CONTRACT-64656c69766572792d6163636f756e74696e67, TASK-CONTRACT-64656c69766572792d73656372657473
- Components: invoice-delivery
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-approval, ai-invoice-idempotency, ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Custom Lambda rechecks durable reviewer approval and conditionally claims the exact approved revision before sending supplier, invoice date, total and currency to existing accounting. An administrator supplies the HTTPS endpoint as controlled configuration and credentials through Secrets Manager; neither is collected in chat. Reuses a stable submission key on every attempt and records the external receipt. Never assumes exactly-once HTTP delivery: after an ambiguous response, reconcile by key or stop for investigation if the accounting API cannot deduplicate. Owns scoped execution role and redacted logs. API schema, authentication mechanism and duplicate protection remain unresolved implementation contracts; supplied connection details do not establish compatibility.
2. Verify AWS Lambda on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-delivery
- Application/configuration and tests for Approved invoice delivery

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6163636f756e74696e67 — Integrate existing Existing accounting API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-64656c69766572792d6163636f756e74696e67
- Components: invoice-accounting
- Generated files: No implementation files generated yet
- Requirements: ai-invoice-approval, ai-invoice-idempotency, ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Client's existing externally managed accounting API, explicitly outside provisioning scope. An administrator supplies its endpoint and credentials through controlled configuration and secret management. Receives approved invoice fields and returns an accounting reference. No creation, import or modification of accounting is proposed. Vendor, request schema, authentication mechanism, idempotency support and lookup/reconciliation behavior remain unestablished; connectivity is not verified.
2. Verify Existing accounting API on tools in Existing location not established; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.; REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-accounting
- Application/configuration and tests for Existing accounting API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d73656372657473 — Implement Accounting integration secret

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-64656c69766572792d73656372657473
- Components: invoice-secrets
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Proposed Secrets Manager secret populated by an administrator with accounting credentials through a secure operational procedure. Only delivery code receives runtime read permission. Keep credentials out of browser code, logs, diagram and Terraform values/state by implementing separate secret population. Authentication format and rotation depend on the existing accounting API contract. No credential values are requested or assumed.
2. Verify AWS Secrets Manager on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Secrets Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-secrets
- Application/configuration and tests for Accounting integration secret

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-75736572732d776562 — Wire Uploaders and reviewers to Invoice upload and review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d776562, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d776562
- Components: invoice-users, invoice-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-web carrying HTTPS upload and review; approval available only to reviewers, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-web
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d6964656e74697479 — Wire Invoice upload and review application to User sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d6964656e74697479, TASK-RESOURCE-696e766f6963652d776562, TASK-RESOURCE-696e766f6963652d6964656e74697479
- Components: invoice-web, invoice-identity
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-identity carrying OAuth authorization code with PKCE; custom integration, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-identity
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6964656e746974792d617069 — Wire User sign-in to Authenticated invoice API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6964656e746974792d617069, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d617069
- Components: invoice-identity, invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge identity-api carrying JWT issuer and signing keys; custom authorizer configuration, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation identity-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d617069 — Wire Invoice upload and review application to Authenticated invoice API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d617069, TASK-RESOURCE-696e766f6963652d776562, TASK-RESOURCE-696e766f6963652d617069
- Components: invoice-web, invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-api carrying HTTPS with access token; statuses and review responses, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170692d6170706c69636174696f6e — Wire Authenticated invoice API to Upload and approval service

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170692d6170706c69636174696f6e, TASK-RESOURCE-696e766f6963652d617069, TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e
- Components: invoice-api, invoice-application
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge api-application carrying Authenticated invocation; server checks reviewer permission for approval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation api-application
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170706c69636174696f6e2d646f63756d656e7473 — Wire Upload and approval service to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170706c69636174696f6e2d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e, TASK-RESOURCE-696e766f6963652d646f63756d656e7473
- Components: invoice-application, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge application-documents carrying Scoped upload and review-download URL signing; custom IAM, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation application-documents
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d646f63756d656e7473 — Wire Invoice upload and review application to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d776562, TASK-RESOURCE-696e766f6963652d646f63756d656e7473
- Components: invoice-web, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-documents carrying HTTPS PDF upload/download using restricted signed URLs, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-documents
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170706c69636174696f6e2d7374617465 — Wire Upload and approval service to Invoice state and review queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170706c69636174696f6e2d7374617465, TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e, TASK-RESOURCE-696e766f6963652d7374617465
- Components: invoice-application, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge application-state carrying Authorized queries and edits; reviewer-only conditional approval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation application-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-646f63756d656e74732d7175657565 — Wire Private invoice PDFs to Document intake queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-646f63756d656e74732d7175657565, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565
- Components: invoice-documents, invoice-intake-queue
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge documents-queue carrying S3 ObjectCreated notification with object version, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation documents-queue
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-71756575652d776f726b6572 — Wire Document intake queue to Duplicate-safe intake worker

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-71756575652d776f726b6572, TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572
- Components: invoice-intake-queue, invoice-intake-worker
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge queue-worker carrying Lambda event mapping; partial batch failures, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation queue-worker
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-71756575652d646c71 — Wire Document intake queue to Failed intake messages

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-71756575652d646c71, TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565, TASK-RESOURCE-696e766f6963652d696e74616b652d646c71
- Components: invoice-intake-queue, invoice-intake-dlq
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge queue-dlq carrying Redrive after bounded intake failures, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation queue-dlq
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d646f63756d656e7473 — Wire Duplicate-safe intake worker to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572
- Components: invoice-intake-worker, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-documents carrying GetObjectVersion for exact notified PDF; custom adapter, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-documents
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d7374617465 — Wire Duplicate-safe intake worker to Invoice state and review queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d7374617465, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572, TASK-RESOURCE-696e766f6963652d7374617465
- Components: invoice-intake-worker, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-state carrying Conditional identity claim and workflow handoff record, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d776f726b666c6f77 — Wire Duplicate-safe intake worker to Extraction and approval workflow

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572, TASK-RESOURCE-696e766f6963652d776f726b666c6f77
- Components: invoice-intake-worker, invoice-workflow
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-workflow carrying StartExecution with stable name; reconcile retries, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-workflow
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b666c6f772d65787472616374696f6e — Wire Extraction and approval workflow to Invoice field extraction

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b666c6f772d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d65787472616374696f6e
- Components: invoice-workflow, invoice-extraction
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge workflow-extraction carrying StartExpenseAnalysis / GetExpenseAnalysis; bounded polling, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation workflow-extraction
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-65787472616374696f6e2d646f63756d656e7473 — Wire Invoice field extraction to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-65787472616374696f6e2d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d65787472616374696f6e
- Components: invoice-extraction, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge extraction-documents carrying Authorized read of specified PDF object version, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation extraction-documents
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b666c6f772d7374617465 — Wire Extraction and approval workflow to Invoice state and review queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b666c6f772d7374617465, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d7374617465
- Components: invoice-workflow, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge workflow-state carrying Persist extracted fields and failures; poll approval revision, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation workflow-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b666c6f772d64656c6976657279 — Wire Extraction and approval workflow to Approved invoice delivery

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b666c6f772d64656c6976657279, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d64656c6976657279
- Components: invoice-workflow, invoice-delivery
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge workflow-delivery carrying Invoke delivery for approved invoice revision, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation workflow-delivery
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-64656c69766572792d7374617465 — Wire Approved invoice delivery to Invoice state and review queue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-64656c69766572792d7374617465, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d64656c6976657279
- Components: invoice-delivery, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge delivery-state carrying Conditional delivery claim; record receipt or uncertain outcome, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation delivery-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-64656c69766572792d6163636f756e74696e67 — Wire Approved invoice delivery to Existing accounting API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-64656c69766572792d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67
- Components: invoice-delivery, invoice-accounting
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge delivery-accounting carrying HTTPS to administrator-supplied endpoint; deduplication contract unresolved, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation delivery-accounting
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-64656c69766572792d73656372657473 — Wire Approved invoice delivery to Accounting integration secret

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-64656c69766572792d73656372657473, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d73656372657473
- Components: invoice-delivery, invoice-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge delivery-secrets carrying Scoped GetSecretValue for administrator-supplied accounting credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation delivery-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-75736572732d776562 — Verify live Uploaders and reviewers → Invoice upload and review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d776562
- Components: invoice-users, invoice-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-web with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-web

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d6964656e74697479 — Verify live Invoice upload and review application → User sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d6964656e74697479
- Components: invoice-web, invoice-identity
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-identity with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-identity

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6964656e746974792d617069 — Verify live User sign-in → Authenticated invoice API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6964656e746974792d617069
- Components: invoice-identity, invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge identity-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence identity-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d617069 — Verify live Invoice upload and review application → Authenticated invoice API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d617069
- Components: invoice-web, invoice-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170692d6170706c69636174696f6e — Verify live Authenticated invoice API → Upload and approval service

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170692d6170706c69636174696f6e
- Components: invoice-api, invoice-application
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge api-application with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence api-application

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d646f63756d656e7473 — Verify live Upload and approval service → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170706c69636174696f6e2d646f63756d656e7473
- Components: invoice-application, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge application-documents with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence application-documents

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d646f63756d656e7473 — Verify live Invoice upload and review application → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d646f63756d656e7473
- Components: invoice-web, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-documents with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-documents

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d7374617465 — Verify live Upload and approval service → Invoice state and review queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170706c69636174696f6e2d7374617465
- Components: invoice-application, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge application-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence application-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-646f63756d656e74732d7175657565 — Verify live Private invoice PDFs → Document intake queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-646f63756d656e74732d7175657565
- Components: invoice-documents, invoice-intake-queue
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge documents-queue with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence documents-queue

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-71756575652d776f726b6572 — Verify live Document intake queue → Duplicate-safe intake worker

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-71756575652d776f726b6572
- Components: invoice-intake-queue, invoice-intake-worker
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge queue-worker with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence queue-worker

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-71756575652d646c71 — Verify live Document intake queue → Failed intake messages

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-71756575652d646c71
- Components: invoice-intake-queue, invoice-intake-dlq
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge queue-dlq with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence queue-dlq

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473 — Verify live Duplicate-safe intake worker → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d646f63756d656e7473
- Components: invoice-intake-worker, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-documents with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-documents

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d7374617465 — Verify live Duplicate-safe intake worker → Invoice state and review queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d7374617465
- Components: invoice-intake-worker, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d776f726b666c6f77 — Verify live Duplicate-safe intake worker → Extraction and approval workflow

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d776f726b666c6f77
- Components: invoice-intake-worker, invoice-workflow
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-workflow with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-workflow

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b666c6f772d65787472616374696f6e — Verify live Extraction and approval workflow → Invoice field extraction

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b666c6f772d65787472616374696f6e
- Components: invoice-workflow, invoice-extraction
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge workflow-extraction with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence workflow-extraction

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-65787472616374696f6e2d646f63756d656e7473 — Verify live Invoice field extraction → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-65787472616374696f6e2d646f63756d656e7473
- Components: invoice-extraction, invoice-documents
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge extraction-documents with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence extraction-documents

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b666c6f772d7374617465 — Verify live Extraction and approval workflow → Invoice state and review queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b666c6f772d7374617465
- Components: invoice-workflow, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge workflow-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence workflow-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279 — Verify live Extraction and approval workflow → Approved invoice delivery

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b666c6f772d64656c6976657279
- Components: invoice-workflow, invoice-delivery
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge workflow-delivery with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence workflow-delivery

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-64656c69766572792d7374617465 — Verify live Approved invoice delivery → Invoice state and review queue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-64656c69766572792d7374617465
- Components: invoice-delivery, invoice-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge delivery-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence delivery-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-64656c69766572792d6163636f756e74696e67 — Verify live Approved invoice delivery → Existing accounting API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-64656c69766572792d6163636f756e74696e67
- Components: invoice-delivery, invoice-accounting
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge delivery-accounting with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence delivery-accounting

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-64656c69766572792d73656372657473 — Verify live Approved invoice delivery → Accounting integration secret

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-64656c69766572792d73656372657473
- Components: invoice-delivery, invoice-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge delivery-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence delivery-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e — Verify REQ-003: For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d776562, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d7374617465, TASK-INTEGRATION-LIVE-75736572732d776562, TASK-INTEGRATION-LIVE-7765622d6964656e74697479, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-7765622d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d7374617465, TASK-INTEGRATION-LIVE-646f63756d656e74732d7175657565, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d776f726b666c6f77, TASK-INTEGRATION-LIVE-776f726b666c6f772d65787472616374696f6e, TASK-INTEGRATION-LIVE-65787472616374696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b666c6f772d7374617465, TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-LIVE-64656c69766572792d7374617465
- Components: invoice-documents, invoice-workflow, invoice-extraction, invoice-state, invoice-web
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.” Confidence flags and source comparison are proposed safeguards.; rationale: Gives reviewers a usable invoice record while exposing uncertain extraction instead of silently accepting incorrect financial data.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c — Verify REQ-004: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-INTEGRATION-LIVE-7765622d6964656e74697479, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-6170692d6170706c69636174696f6e, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b666c6f772d7374617465, TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-LIVE-64656c69766572792d7374617465, TASK-INTEGRATION-LIVE-64656c69766572792d6163636f756e74696e67, TASK-INTEGRATION-LIVE-64656c69766572792d73656372657473
- Components: invoice-identity, invoice-application, invoice-state, invoice-delivery, invoice-accounting
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Basis: “A reviewer approves a result before it is sent to our existing accounting API.” Revision-bound approval and audit history are proposed enforcement details.; rationale: Prevents unreviewed or subsequently altered financial values from crossing into accounting and makes each approval attributable.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379 — Verify REQ-005: Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d7374617465, TASK-INTEGRATION-LIVE-71756575652d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d776f726b666c6f77, TASK-INTEGRATION-LIVE-776f726b666c6f772d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b666c6f772d7374617465, TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-LIVE-64656c69766572792d7374617465, TASK-INTEGRATION-LIVE-64656c69766572792d6163636f756e74696e67, TASK-INTEGRATION-LIVE-64656c69766572792d73656372657473
- Components: invoice-intake-worker, invoice-workflow, invoice-state, invoice-delivery, invoice-accounting
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-idempotency

### Implementation steps

1. Basis: “Delivery can repeat; retries must not create duplicate invoices.” Accounting-side idempotency or reconciliation is not yet established.; rationale: At-least-once events and lost accounting responses can repeat processing or create duplicate financial entries; local deduplication alone cannot prevent remote duplicates.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279 — Verify REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-LIVE-64656c69766572792d7374617465, TASK-INTEGRATION-LIVE-64656c69766572792d6163636f756e74696e67, TASK-INTEGRATION-LIVE-64656c69766572792d73656372657473
- Components: invoice-accounting, invoice-delivery, invoice-secrets
- Generated files: terraform/main.tf.json
- Requirements: ai-invoice-accounting-boundary

### Implementation steps

1. Basis: “The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.” Supported by invoice-accounting, invoice-delivery and invoice-secrets.; rationale: Preserves ownership of the existing accounting system and prevents integration credentials from reaching browsers or logs; endpoint and credentials alone do not prove API compatibility.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d776562, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d617069, TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565, TASK-RESOURCE-696e766f6963652d696e74616b652d646c71, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-INTEGRATION-75736572732d776562, TASK-INTEGRATION-7765622d6964656e74697479, TASK-INTEGRATION-6964656e746974792d617069, TASK-INTEGRATION-7765622d617069, TASK-INTEGRATION-6170692d6170706c69636174696f6e, TASK-INTEGRATION-6170706c69636174696f6e2d646f63756d656e7473, TASK-INTEGRATION-7765622d646f63756d656e7473, TASK-INTEGRATION-6170706c69636174696f6e2d7374617465, TASK-INTEGRATION-646f63756d656e74732d7175657565, TASK-INTEGRATION-71756575652d776f726b6572, TASK-INTEGRATION-71756575652d646c71, TASK-INTEGRATION-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-776f726b65722d7374617465, TASK-INTEGRATION-776f726b65722d776f726b666c6f77, TASK-INTEGRATION-776f726b666c6f772d65787472616374696f6e, TASK-INTEGRATION-65787472616374696f6e2d646f63756d656e7473, TASK-INTEGRATION-776f726b666c6f772d7374617465, TASK-INTEGRATION-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-64656c69766572792d7374617465, TASK-INTEGRATION-64656c69766572792d6163636f756e74696e67, TASK-INTEGRATION-64656c69766572792d73656372657473
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d776562, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d617069, TASK-RESOURCE-696e766f6963652d6170706c69636174696f6e, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d696e74616b652d7175657565, TASK-RESOURCE-696e766f6963652d696e74616b652d646c71, TASK-RESOURCE-696e766f6963652d696e74616b652d776f726b6572, TASK-RESOURCE-696e766f6963652d776f726b666c6f77, TASK-RESOURCE-696e766f6963652d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d64656c6976657279, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-INTEGRATION-LIVE-75736572732d776562, TASK-INTEGRATION-LIVE-7765622d6964656e74697479, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d6170706c69636174696f6e, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-7765622d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d7374617465, TASK-INTEGRATION-LIVE-646f63756d656e74732d7175657565, TASK-INTEGRATION-LIVE-71756575652d776f726b6572, TASK-INTEGRATION-LIVE-71756575652d646c71, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d776f726b666c6f77, TASK-INTEGRATION-LIVE-776f726b666c6f772d65787472616374696f6e, TASK-INTEGRATION-LIVE-65787472616374696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b666c6f772d7374617465, TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-LIVE-64656c69766572792d7374617465, TASK-INTEGRATION-LIVE-64656c69766572792d6163636f756e74696e67, TASK-INTEGRATION-LIVE-64656c69766572792d73656372657473
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e, TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c, TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379, TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279, TASK-INTEGRATION-LIVE-75736572732d776562, TASK-INTEGRATION-LIVE-7765622d6964656e74697479, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d6170706c69636174696f6e, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-7765622d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170706c69636174696f6e2d7374617465, TASK-INTEGRATION-LIVE-646f63756d656e74732d7175657565, TASK-INTEGRATION-LIVE-71756575652d776f726b6572, TASK-INTEGRATION-LIVE-71756575652d646c71, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d776f726b666c6f77, TASK-INTEGRATION-LIVE-776f726b666c6f772d65787472616374696f6e, TASK-INTEGRATION-LIVE-65787472616374696f6e2d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b666c6f772d7374617465, TASK-INTEGRATION-LIVE-776f726b666c6f772d64656c6976657279, TASK-INTEGRATION-LIVE-64656c69766572792d7374617465, TASK-INTEGRATION-LIVE-64656c69766572792d6163636f756e74696e67, TASK-INTEGRATION-LIVE-64656c69766572792d73656372657473
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
