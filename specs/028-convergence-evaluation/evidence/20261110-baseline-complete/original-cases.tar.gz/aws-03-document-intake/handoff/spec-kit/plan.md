# Implementation Spec Kit

Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

7 priority decisions; infrastructure: partial_implementation. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: aws

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Uploaders and reviewers (invoice-users): External browser — no infrastructure to provision; connection behavior still requires validation; tools, To be selected.
- Invoice upload and review application (invoice-web): Implementation needed; aws, To be selected.
- User sign-in (invoice-identity): Implementation needed; aws, To be selected.
- Authenticated invoice API (invoice-api): Implementation needed; aws, To be selected.
- Upload and approval service (invoice-application): Implementation needed; aws, To be selected.
- Private invoice PDFs (invoice-documents): S3 foundation generated; aws, To be selected.
- Document intake queue (invoice-intake-queue): Implementation needed; aws, To be selected.
- Failed intake messages (invoice-intake-dlq): Implementation needed; aws, To be selected.
- Duplicate-safe intake worker (invoice-intake-worker): Implementation needed; aws, To be selected.
- Extraction and approval workflow (invoice-workflow): Implementation needed; aws, To be selected.
- Invoice field extraction (invoice-extraction): Implementation needed; aws, To be selected.
- Invoice state and review queue (invoice-state): Implementation needed; aws, To be selected.
- Approved invoice delivery (invoice-delivery): Implementation needed; aws, To be selected.
- Existing accounting API (invoice-accounting): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location not established.
- Accounting integration secret (invoice-secrets): Implementation needed; aws, To be selected.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
