Snapshot f78d6e62-b375-408e-a91b-788a75cf5e1b · design r3 · generated 2026-11-09T16:56:28.238Z

# Asynchronous document intake — deployment document

Generated 2026-11-09 16:56 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 10 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** Twenty signed-in staff and three reviewers; ordinary uploaders cannot approve. The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.
- **How good, fast and safe:** —
- **Cloud preference:** AWS
- **Budget and timeline:** —

## 3. Architecture

**Upload and review**

- Uploaders and reviewers (Tools & data, existing, sketch) — Twenty signed-in staff and three reviewers using browsers; existing people outside provisioning scope. Whether reviewers are included in the twenty staff is not established. Ordinary uploaders cannot approve. Server-enforced reviewer permissions are required; no existing company identity provider is assumed.
- Invoice upload and review application (AWS, sketch) — Proposed AWS Amplify Hosting deployment for a custom browser application: upload PDFs, see processing status, view the source invoice beside extracted fields, correct values and approve a specific revision. Show approval controls only to reviewers, while enforcing permission independently on the server. Browser controls do not enforce authorization. Application code and hosting integration are not implemented by the current generator.
- User sign-in (AWS, sketch) — Proposed Amazon Cognito user pool with authorization-code sign-in and PKCE. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Propose administrator-managed uploader/reviewer group assignments; users cannot grant themselves reviewer permission. API validates access tokens and application checks reviewer authorization. Existing company sign-in can be integrated later without assuming it exists. This is a custom invoice application identity integration, not the generated RAG user-pool contract.
- Authenticated invoice API (AWS, sketch) — Proposed Amazon API Gateway HTTP API with a Cognito JWT authorizer. Routes upload initiation, status, review and approval to the invoice application Lambda. No anonymous invoice routes. A valid token establishes sign-in, not approval permission; the application must reject approval requests from ordinary uploaders. Custom API infrastructure and integration remain engineering work.
- Upload and approval service (AWS, sketch) — Custom Lambda deployment owns upload-session creation, scoped short-lived S3 upload/download URLs, review-list queries, field corrections and approval. Enforces user permissions and object access on every request. Only administrator-assigned reviewers may approve; ordinary uploader approval attempts fail without changing state or initiating delivery. Approval conditionally records reviewer identity, timestamp and exact field revision in DynamoDB; approved revisions cannot be edited or silently replaced. Returns statuses and review data directly. Owns execution role and scoped logs; not a supported text-statistics or word-count implementation. Acceptance tests must cover direct API approval attempts by uploaders, forged roles, concurrent edits and valid reviewer approval.

**Document processing**

- Private invoice PDFs (AWS) — Proposed private, encrypted, versioned S3 bucket. The application assigns immutable upload-session object keys and issues restricted upload URLs. Processing validates PDF content and reads the exact event object version; unsupported or unsafe documents remain blocked from extraction and delivery. Retention and deletion periods await business requirements. Browser access is application-mediated, not an invented IAM principal.
- Document intake queue (AWS, sketch) — SQS standard queue buffers object-created notifications. Assume duplicate and out-of-order delivery. Worker uses partial batch failure responses; propose visibility timeout at least six times worker timeout plus batching window. Bounded retries lead to a dedicated DLQ. Queue settings and custom processing connection require validation.
- Failed intake messages (AWS, sketch) — Dedicated SQS dead-letter queue retains repeatedly failed intake events for operator investigation and controlled replay with original invoice identity. A non-empty-queue alarm and recovery runbook require implementation; no operator notification destination is assumed.
- Duplicate-safe intake worker (AWS, sketch) — Custom Lambda validates the upload and reads its exact S3 version with scoped GetObjectVersion access. Uses conditional DynamoDB records to map repeated events to one stable invoice identity and starts a deterministically named Standard workflow. Retries reconcile claimed-but-not-started work; acknowledgments follow durable workflow handoff. Propose a content fingerprint to flag repeated uploads for review without automatically merging distinct invoices. Owns role and logs. Current async-word-count code does not implement this behavior.
- Extraction and approval workflow (AWS, sketch) — Proposed Step Functions Standard workflow starts asynchronous Textract expense analysis against the exact document version, using a stable client request token where supported, and polls with bounded waits. Maps extracted supplier, invoice date, total and currency into a durable review record with confidence and missing-field flags. Waits and checks durable approval state before invoking delivery for the approved revision. Catch paths persist failures for investigation; workflow timeouts and recovery preserve invoice identity. SDK integration compatibility, field mapping, retries and recovery require implementation and tests.
- Invoice field extraction (AWS, sketch) — Proposed Amazon Textract asynchronous AnalyzeExpense capability for PDF invoices. Produces extracted fields and confidence evidence, never approval. Workflow must handle pagination, missing fields, document limits and service failures. Representative invoice accuracy, regional availability and exact API integration remain unverified.

**Approval and delivery**

- Invoice state and review queue (AWS, sketch) — One proposed DynamoDB table stores upload identity, source version, processing state, extracted fields, field revisions, reviewer approval, delivery attempts and accounting receipt. Status indexes support the human review queue; it is not an SQS approval queue. Conditional writes and transactions enforce one active delivery claim and immutable approved payloads. Preserve audit events and ambiguous delivery outcomes; propose point-in-time recovery. Schema, permissions and retention require engineering, not the word-count-results implementation.
- Approved invoice delivery (AWS, sketch) — Custom Lambda rechecks durable reviewer approval and conditionally claims the exact approved revision before sending supplier, invoice date, total and currency to existing accounting. An administrator supplies the HTTPS endpoint as controlled configuration and credentials through Secrets Manager; neither is collected in chat. Reuses a stable submission key on every attempt and records the external receipt. Never assumes exactly-once HTTP delivery: after an ambiguous response, reconcile by key or stop for investigation if the accounting API cannot deduplicate. Owns scoped execution role and redacted logs. API schema, authentication mechanism and duplicate protection remain unresolved implementation contracts; supplied connection details do not establish compatibility.
- Existing accounting API (Tools & data, existing, sketch) — Client's existing externally managed accounting API, explicitly outside provisioning scope. An administrator supplies its endpoint and credentials through controlled configuration and secret management. Receives approved invoice fields and returns an accounting reference. No creation, import or modification of accounting is proposed. Vendor, request schema, authentication mechanism, idempotency support and lookup/reconciliation behavior remain unestablished; connectivity is not verified.
- Accounting integration secret (AWS, sketch) — Proposed Secrets Manager secret populated by an administrator with accounting credentials through a secure operational procedure. Only delivery code receives runtime read permission. Keep credentials out of browser code, logs, diagram and Terraform values/state by implementing separate secret population. Authentication format and rotation depend on the existing accounting API contract. No credential values are requested or assumed.

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice upload and review application<br/>AWS"]
  n2["User sign-in<br/>AWS"]
  n3["Authenticated invoice API<br/>AWS"]
  n4["Upload and approval service<br/>AWS"]
  n5["Private invoice PDFs<br/>AWS"]
  n6["Document intake queue<br/>AWS"]
  n7["Failed intake messages<br/>AWS"]
  n8["Duplicate-safe intake worker<br/>AWS"]
  n9["Extraction and approval workflow<br/>AWS"]
  n10["Invoice field extraction<br/>AWS"]
  n11["Invoice state and review queue<br/>AWS"]
  n12["Approved invoice delivery<br/>AWS"]
  n13["Existing accounting API<br/>Tools & data"]
  n14["Accounting integration secret<br/>AWS"]
  n0 -->|HTTPS upload and review; approval available only to reviewers| n1
  n1 -->|OAuth authorization code with PKCE; custom integration| n2
  n2 -->|JWT issuer and signing keys; custom authorizer configuration| n3
  n1 -->|HTTPS with access token; statuses and review responses| n3
  n3 -->|Authenticated invocation; server checks reviewer permission for approval| n4
  n4 -->|Scoped upload and review-download URL signing; custom IAM| n5
  n1 -->|HTTPS PDF upload/download using restricted signed URLs| n5
  n4 -->|Authorized queries and edits; reviewer-only conditional approval| n11
  n5 -->|S3 ObjectCreated notification with object version| n6
  n6 -->|Lambda event mapping; partial batch failures| n8
  n6 -->|Redrive after bounded intake failures| n7
  n8 -->|GetObjectVersion for exact notified PDF; custom adapter| n5
  n8 -->|Conditional identity claim and workflow handoff record| n11
  n8 -->|StartExecution with stable name; reconcile retries| n9
  n9 -->|StartExpenseAnalysis / GetExpenseAnalysis; bounded polling| n10
  n10 -->|Authorized read of specified PDF object version| n5
  n9 -->|Persist extracted fields and failures; poll approval revision| n11
  n9 -->|Invoke delivery for approved invoice revision| n12
  n12 -->|Conditional delivery claim; record receipt or uncertain outcome| n11
  n12 -->|HTTPS to administrator-supplied endpoint; deduplication contract unresolved| n13
  n12 -->|Scoped GetSecretValue for administrator-supplied accounting credentials| n14
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Web browser | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-web | Invoice upload and review application | aws | AWS Amplify Hosting | To be selected | Proposed | Implementation needed |
| invoice-identity | User sign-in | aws | Amazon Cognito | To be selected | Proposed | Implementation needed |
| invoice-api | Authenticated invoice API | aws | Amazon API Gateway | To be selected | Proposed | Implementation needed |
| invoice-application | Upload and approval service | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| invoice-documents | Private invoice PDFs | aws | Amazon S3 | To be selected | Proposed | S3 foundation generated |
| invoice-intake-queue | Document intake queue | aws | Amazon SQS | To be selected | Proposed | Implementation needed |
| invoice-intake-dlq | Failed intake messages | aws | Amazon SQS | To be selected | Proposed | Implementation needed |
| invoice-intake-worker | Duplicate-safe intake worker | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| invoice-workflow | Extraction and approval workflow | aws | AWS Step Functions | To be selected | Proposed | Implementation needed |
| invoice-extraction | Invoice field extraction | aws | Amazon Textract | To be selected | Proposed | Implementation needed |
| invoice-state | Invoice state and review queue | aws | Amazon DynamoDB | To be selected | Proposed | Implementation needed |
| invoice-delivery | Approved invoice delivery | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| invoice-accounting | Existing accounting API | tools | Existing accounting API | Existing location not established | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| invoice-secrets | Accounting integration secret | aws | AWS Secrets Manager | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Invoice upload and review application** (invoice-web): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users.
- **User sign-in** (invoice-identity): aws_cognito_user_pool. Active users and authentication features. Depends on: invoice-web.
- **Authenticated invoice API** (invoice-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: invoice-identity, invoice-web.
- **Upload and approval service** (invoice-application): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: invoice-api.
- **Private invoice PDFs** (invoice-documents): aws_s3_bucket, aws_s3_bucket_public_access_block, aws_s3_bucket_server_side_encryption_configuration, aws_s3_bucket_versioning, aws_s3_bucket_ownership_controls, aws_s3_bucket_policy. Storage, requests, retrieval and transfer. Depends on: invoice-application, invoice-web, invoice-intake-worker, invoice-extraction.
- **Document intake queue** (invoice-intake-queue): aws_sqs_queue. Requests, payload size and transfer. Depends on: invoice-documents.
- **Failed intake messages** (invoice-intake-dlq): aws_sqs_queue. Requests, payload size and transfer. Depends on: invoice-intake-queue.
- **Duplicate-safe intake worker** (invoice-intake-worker): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: invoice-intake-queue.
- **Extraction and approval workflow** (invoice-workflow): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-intake-worker.
- **Invoice field extraction** (invoice-extraction): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-workflow.
- **Invoice state and review queue** (invoice-state): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: invoice-application, invoice-intake-worker, invoice-workflow, invoice-delivery.
- **Approved invoice delivery** (invoice-delivery): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: invoice-workflow.
- **Existing accounting API** (invoice-accounting): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-delivery.
- **Accounting integration secret** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-delivery.

### Engineering work remaining

- Private invoice PDFs: explicit caller access contract is missing.
- Invoice upload and review application: Implementation needed.
- User sign-in: Implementation needed.
- Authenticated invoice API: Implementation needed.
- Upload and approval service: Implementation needed.
- Document intake queue: Implementation needed.
- Failed intake messages: Implementation needed.
- Duplicate-safe intake worker: Implementation needed.
- Extraction and approval workflow: Implementation needed.
- Invoice field extraction: Implementation needed.
- Invoice state and review queue: Implementation needed.
- Approved invoice delivery: Implementation needed.
- Accounting integration secret: Implementation needed.
- Wire invoice-users → invoice-web: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-identity → invoice-api: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-api: implement data flow, access policy and acceptance test.
- Wire invoice-api → invoice-application: implement data flow, access policy and acceptance test.
- Wire invoice-application → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-web → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-application → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-documents → invoice-intake-queue: implement data flow, access policy and acceptance test.
- Wire invoice-intake-queue → invoice-intake-worker: implement data flow, access policy and acceptance test.
- Wire invoice-intake-queue → invoice-intake-dlq: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-intake-worker → invoice-workflow: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-extraction → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-workflow → invoice-delivery: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-delivery → invoice-secrets: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Uploaders and reviewers | Invoice upload and review application | HTTPS upload and review; approval available only to reviewers | Confidential |
| Invoice upload and review application | User sign-in | OAuth authorization code with PKCE; custom integration | Confidential |
| User sign-in | Authenticated invoice API | JWT issuer and signing keys; custom authorizer configuration | Confidential |
| Invoice upload and review application | Authenticated invoice API | HTTPS with access token; statuses and review responses | Confidential |
| Authenticated invoice API | Upload and approval service | Authenticated invocation; server checks reviewer permission for approval | Confidential |
| Upload and approval service | Private invoice PDFs | Scoped upload and review-download URL signing; custom IAM | Confidential |
| Invoice upload and review application | Private invoice PDFs | HTTPS PDF upload/download using restricted signed URLs | Confidential |
| Upload and approval service | Invoice state and review queue | Authorized queries and edits; reviewer-only conditional approval | Confidential |
| Private invoice PDFs | Document intake queue | S3 ObjectCreated notification with object version | Confidential |
| Document intake queue | Duplicate-safe intake worker | Lambda event mapping; partial batch failures | Confidential |
| Document intake queue | Failed intake messages | Redrive after bounded intake failures | Confidential |
| Duplicate-safe intake worker | Private invoice PDFs | GetObjectVersion for exact notified PDF; custom adapter | Confidential |
| Duplicate-safe intake worker | Invoice state and review queue | Conditional identity claim and workflow handoff record | Confidential |
| Duplicate-safe intake worker | Extraction and approval workflow | StartExecution with stable name; reconcile retries | Confidential |
| Extraction and approval workflow | Invoice field extraction | StartExpenseAnalysis / GetExpenseAnalysis; bounded polling | Confidential |
| Invoice field extraction | Private invoice PDFs | Authorized read of specified PDF object version | Confidential |
| Extraction and approval workflow | Invoice state and review queue | Persist extracted fields and failures; poll approval revision | Confidential |
| Extraction and approval workflow | Approved invoice delivery | Invoke delivery for approved invoice revision | Confidential |
| Approved invoice delivery | Invoice state and review queue | Conditional delivery claim; record receipt or uncertain outcome | Confidential |
| Approved invoice delivery | Existing accounting API | HTTPS to administrator-supplied endpoint; deduplication contract unresolved | Confidential |
| Approved invoice delivery | Accounting integration secret | Scoped GetSecretValue for administrator-supplied accounting credentials | Confidential |

## 5. Security controls

- **Uploaders and reviewers** — Twenty signed-in staff and three reviewers using browsers; existing people outside provisioning scope. Whether reviewers are included in the twenty staff is not established. Ordinary uploaders cannot approve. Server-enforced reviewer permissions are required; no existing company identity provider is assumed.
- **User sign-in** — Proposed Amazon Cognito user pool with authorization-code sign-in and PKCE. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Propose administrator-managed uploader/reviewer group assignments; users cannot grant themselves reviewer permission. API validates access tokens and application checks reviewer authorization. Existing company sign-in can be integrated later without assuming it exists. This is a custom invoice application identity integration, not the generated RAG user-pool contract.
- **Accounting integration secret** — Proposed Secrets Manager secret populated by an administrator with accounting credentials through a secure operational procedure. Only delivery code receives runtime read permission. Keep credentials out of browser code, logs, diagram and Terraform values/state by implementing separate secret population. Authentication format and rotation depend on the existing accounting API contract. No credential values are requested or assumed.
- Requirement: Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions. (must)
- Requirement: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions. (must)
- Open finding SEC-002: Sensitive data is involved but where it must be stored is not stated.

## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved. | reliability | not measurable yet | Open |

**Functional**

- For each accepted PDF invoice, extract supplier, invoice date, total and currency into a durable review record linked to its exact source version; flag missing or uncertain fields and permit authorized reviewer correction before approval. (must, open)
- Only an authorized reviewer's explicit approval of a specific invoice revision may enable accounting submission; record reviewer identity and approved values durably, and prevent delivery of unapproved or changed revisions. (must, open)
- Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint through administrator-controlled configuration and its credentials through secure secret management; restrict runtime credential access to the delivery service and exclude secret values from browser assets and logs. Validate the API request, authentication and retry contracts before enabling submissions. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Security & controls**

- [major] Sensitive data is involved but where it must be stored is not stated. Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks. _(AtMem AI Architect rule SEC-002 v1.0.0)_

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_
- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Repeated events and retries for the same intake must retain one invoice identity and approved submission payload. Accounting retries must reuse a stable submission identity and rely on verified remote deduplication or reconciliation; ambiguous outcomes must remain blocked from blind resubmission until resolved.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 14 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| User sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Private invoice PDFs | Storage | needs data_gb | price needed | — | — |
| Document intake queue | Data processed | needs data_gb | price needed | — | — |
| Failed intake messages | Storage | needs data_gb | price needed | — | — |
| Duplicate-safe intake worker | Data processed | needs data_gb | price needed | — | — |
| Invoice field extraction | Endpoint hours | 730 hours | price needed | — | — |
| Invoice state and review queue | Storage | needs data_gb | price needed | — | — |
| Accounting integration secret | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Uploaders and reviewers, Invoice upload and review application, Authenticated invoice API, Upload and approval service, Extraction and approval workflow, Approved invoice delivery, Existing accounting API.

**Estimate gaps:**

- User sign-in / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: input needed (data_gb).
- Document intake queue / Data processed: input needed (data_gb).
- Failed intake messages / Storage: input needed (data_gb).
- Duplicate-safe intake worker / Data processed: input needed (data_gb).
- Invoice field extraction / Endpoint hours: price needed.
- Invoice state and review queue / Storage: input needed (data_gb).
- Accounting integration secret / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated invoice API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Upload and approval service: no cost lines; add charges or an explicit zero-cost line with a reason.
- Extraction and approval workflow: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved invoice delivery: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision upload and review: Invoice upload and review application, User sign-in, Authenticated invoice API, Upload and approval service.
4. Provision document processing: Private invoice PDFs, Document intake queue, Failed intake messages, Duplicate-safe intake worker, Extraction and approval workflow, Invoice field extraction.
5. Provision approval and delivery: Invoice state and review queue, Approved invoice delivery, Accounting integration secret.
6. Connect existing systems: Uploaders and reviewers, Existing accounting API; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- User sign-in: needs requests_per_month _(estimate)_
- Private invoice PDFs: needs data_gb _(estimate)_
- Document intake queue: needs data_gb _(estimate)_
- Failed intake messages: needs data_gb _(estimate)_
- Duplicate-safe intake worker: needs data_gb _(estimate)_
- Invoice field extraction: needs a unit price with a source _(estimate)_
- Invoice state and review queue: needs data_gb _(estimate)_
- Accounting integration secret: needs requests_per_month _(estimate)_
