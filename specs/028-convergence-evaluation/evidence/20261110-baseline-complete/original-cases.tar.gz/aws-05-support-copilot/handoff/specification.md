Snapshot be1a503f-a2ef-4825-8eeb-dc9cae607908 · design r3 · generated 2026-11-09T17:05:09.605Z

# Human-approved support copilot — solution specification

## Problem and intended outcome

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution. (must, open); target: acceptance target needed; linked blocks: copilot-backend, approval-ledger, action-executor, review-web

Design explanation: Prevents generated content or a forged/replayed request from authorizing a different send or account change.

Basis: User: “Nothing is sent or changed until a staff member explicitly approves it.” Exact-revision binding and server authorization are proposed enforcement details.
- [REQ-004] Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome. (must, open); target: acceptance target needed; linked blocks: action-executor, approval-ledger, existing-crm

Design explanation: A CRM may complete a change before its response times out; a local lock alone cannot prevent a duplicate external effect.

Basis: User: “Retries must not perform an action twice.” Durable keys, conditional claims and uncertain-outcome reconciliation are proposed mechanisms.
- [REQ-005] The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only. (must, open); target: acceptance target needed; linked blocks: copilot-backend, existing-crm, approved-knowledge, draft-model, review-web

Design explanation: Keeps staff review grounded in approved evidence and prevents draft generation from obtaining action privileges.

Basis: User: “reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions.” Citations, access filtering and abstention are proposed safeguards.
- [REQ-006] Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment. (must, open); target: acceptance target needed; linked blocks: existing-crm, existing-outbound-mail, copilot-backend, action-executor

Design explanation: Preserves client-owned services and prevents accidental replacement or provisioning of systems the administrator already operates.

Basis: “CRM and outbound mail already exist, with administrator-supplied API credentials. Do not recreate them.”
- [REQ-007] Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions. (must, open); target: acceptance target needed; linked blocks: connector-secrets, copilot-backend, action-executor, existing-crm, existing-outbound-mail

Design explanation: Proposed safeguard: separating credential access prevents drafting or untrusted model output from acquiring authority to send mail or change accounts.

Basis: Administrator-supplied API credentials in the current message; existing read-only backend and separate approved-action executor on the diagram.

## How the system works

The current design contains 13 components and 17 connections. 5 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Support staff → Staff review application

HTTPS: review drafts, approve exact revisions, see status

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Staff review application → Staff sign-in

OAuth authorization code with PKCE; custom integration

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Staff sign-in → Authenticated copilot API

JWT issuer and scope validation; custom authorizer configuration

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Staff review application → Authenticated copilot API

HTTPS access token: draft, review, approve, status

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Authenticated copilot API → Draft and approval backend

Authorized Lambda requests; return cited drafts and action status

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Draft and approval backend → Existing CRM

Read authorized case and version; vendor API unresolved

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Draft and approval backend → Approved support knowledge

Read approved accessible evidence and source versions; adapter unresolved

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Draft and approval backend → Drafting model

Converse: case and evidence → draft and proposed actions; custom runtime

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Draft and approval backend → Draft, approval and action ledger

Conditional revision and approval writes; authorized status reads

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Draft and approval backend → Approved action executor

IAM-restricted invocation with stored approved action ID; custom integration

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Approved action executor → Draft, approval and action ledger

Validate approval; claim each operation; persist result, partial completion or u

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Approved action executor → Existing CRM

Approved account change via existing API; stable action key and outcome reconcil

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Draft and approval backend → Connector credentials

IAM-scoped GetSecretValue: read-only connector credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Approved action executor → Connector credentials

IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 15: Draft and approval backend → Operational monitoring

Redacted logs and correlated draft/approval metrics

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 16: Approved action executor → Operational monitoring

Execution, denial, partial-completion and uncertain CRM/mail outcome metrics

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 17: Approved action executor → Existing outbound mail

Existing mail API: approved recipient/body; stable send key; reconcile submissio

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Support staff

Approval workflow · tools · region: Not applicable · classification: Confidential

Existing staff using a browser to inspect drafts, citations and exact proposed changes, then approve or reject. External caller outside provisioning scope.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Support staff → Staff review application: HTTPS: review drafts, approve exact revisions, see status (integration: browser-https)

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Staff review application

Amazon CloudFront · aws · region: To be selected · classification: Confidential

Proposed Amazon CloudFront distribution serving a custom staff application from owned private S3 web assets. Shows cases, cited drafts, action parameters and execution status. Approval submits an exact revision; browser controls never replace server authorization. Custom UI and hosting implementation required; the bounded-RAG web adapter does not implement this workflow.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Support staff → Staff review application: HTTPS: review drafts, approve exact revisions, see status (integration: browser-https)

Outputs: Staff review application → Staff sign-in: OAuth authorization code with PKCE; custom integration; Staff review application → Authenticated copilot API: HTTPS access token: draft, review, approve, status

Requirement traceability: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Staff sign-in

Amazon Cognito · aws · region: To be selected · classification: Confidential

Proposed Amazon Cognito user pool for authenticated staff sessions, with MFA and federation to the existing workforce identity provider where available. Identity provider and onboarding ownership are unconfirmed. API validates access tokens; application separately enforces case access and action permissions. Custom integration required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff review application → Staff sign-in: OAuth authorization code with PKCE; custom integration

Outputs: Staff sign-in → Authenticated copilot API: JWT issuer and scope validation; custom authorizer configuration

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authenticated copilot API

Amazon API Gateway · aws · region: To be selected · classification: Confidential

Proposed Amazon API Gateway HTTP API with JWT authorization for case retrieval, drafting, revision review, approval/rejection and status. Request identifiers support safe retries. Routes invoke the copilot backend only; no browser route directly invokes the privileged executor. Custom API contract and authorization integration required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff sign-in → Authenticated copilot API: JWT issuer and scope validation; custom authorizer configuration; Staff review application → Authenticated copilot API: HTTPS access token: draft, review, approve, status

Outputs: Authenticated copilot API → Draft and approval backend: Authorized Lambda requests; return cited drafts and action status

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Draft and approval backend

AWS Lambda · aws · region: To be selected · classification: Confidential

Custom AWS Lambda reads authorized CRM cases and approved knowledge, builds cited drafts and structured action proposals, and returns them to the review application. Treats cases, documents and model output as untrusted data. Has read-only CRM access and no mail-send or account-change credentials. Persists exact revisions and conditionally records authenticated approval bound to case version, content hash, mail recipient/body and action parameters. Only validated stored actions enter the executor. Owns execution IAM role and log group. Retrieval method awaits source characteristics; insufficient evidence produces an explicit unable-to-draft result. Administrator-supplied CRM credentials require scope validation; separate read-only credentials are proposed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Authenticated copilot API → Draft and approval backend: Authorized Lambda requests; return cited drafts and action status

Outputs: Draft and approval backend → Existing CRM: Read authorized case and version; vendor API unresolved; Draft and approval backend → Approved support knowledge: Read approved accessible evidence and source versions; adapter unresolved; Draft and approval backend → Drafting model: Converse: case and evidence → draft and proposed actions; custom runtime; Draft and approval backend → Draft, approval and action ledger: Conditional revision and approval writes; authorized status reads; Draft and approval backend → Approved action executor: IAM-restricted invocation with stored approved action ID; custom integration; Draft and approval backend → Connector credentials: IAM-scoped GetSecretValue: read-only connector credentials; Draft and approval backend → Operational monitoring: Redacted logs and correlated draft/approval metrics

Requirement traceability: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.; REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Approved action executor

AWS Lambda · aws · region: To be selected · classification: Confidential

Separate custom AWS Lambda is the only proposed runtime allowed to send replies through existing outbound mail or change accounts through the existing CRM. Accepts stored action IDs and revalidates authorization, exact approval revision, recipient/content or action parameters, allowlisted operation and current case state before conditionally claiming execution. Each external operation has a durable key and independent outcome; a completed operation is never replayed because another operation failed. Reuses destination idempotency keys where supported. Lost responses enter an unknown state requiring reliable destination reconciliation; affected operations remain blocked when safe recovery cannot be established. Mail submission and final delivery are distinct states. Only executor accesses administrator-supplied send/change credentials. Owns separate least-privilege role and logs. Custom adapters and denial, concurrency and recovery tests required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Draft and approval backend → Approved action executor: IAM-restricted invocation with stored approved action ID; custom integration

Outputs: Approved action executor → Draft, approval and action ledger: Validate approval; claim each operation; persist result, partial completion or u; Approved action executor → Existing CRM: Approved account change via existing API; stable action key and outcome reconcil; Approved action executor → Connector credentials: IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede; Approved action executor → Operational monitoring: Execution, denial, partial-completion and uncertain CRM/mail outcome metrics; Approved action executor → Existing outbound mail: Existing mail API: approved recipient/body; stable send key; reconcile submissio

Requirement traceability: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.; REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Draft, approval and action ledger

Amazon DynamoDB · aws · region: To be selected · classification: Confidential

Proposed Amazon DynamoDB table stores draft revisions, source references, authenticated approvals and separate durable records for each CRM change or outbound mail submission. Records exact approved parameters, stable operation keys, claims, destination references and outcomes, including partial completion and unknown outcomes. Conditional writes and transactions prevent concurrent claims and bind approvals to exact content. Backend creates proposals/approvals; only executor transitions execution outcomes. Proposed encryption and point-in-time recovery; retention and recovery targets remain open. Local records alone cannot guarantee exactly-once external effects or atomic completion across CRM and mail.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Draft and approval backend → Draft, approval and action ledger: Conditional revision and approval writes; authorized status reads; Approved action executor → Draft, approval and action ledger: Validate approval; claim each operation; persist result, partial completion or u

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

### Drafting model

Amazon Bedrock · aws · region: To be selected · classification: Confidential

Amazon Bedrock managed inference dependency for grounded draft generation and structured action recommendations only. No action tools or CRM write credentials. Direct model, regional availability, data handling, quotas and output bounds require review after residency is established. Existing provider-managed service reference; no model entitlement or interoperability is verified.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Draft and approval backend → Drafting model: Converse: case and evidence → draft and proposed actions; custom runtime

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### Existing CRM

Storage or existing data connector · tools · region: Existing location unknown · classification: Confidential

Client-owned existing CRM with administrator-supplied API credentials. Remains system of record for cases and account state; outside provisioning, import and modification scope. Vendor and API interfaces remain unresolved. Separate read and account-action credentials are proposed, subject to actual supported scopes. Authorization, version checks, rate limits, operation allowlist, idempotency and reconciliation need custom integration and verification. Outbound replies use the separate existing mail service; CRM response-record linkage remains adapter work.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Draft and approval backend → Existing CRM: Read authorized case and version; vendor API unresolved; Approved action executor → Existing CRM: Approved account change via existing API; stable action key and outcome reconcil

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.; REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.; REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Approved support knowledge

Storage or existing data connector · tools · region: Existing location unknown · classification: Confidential

Existing client-approved support knowledge, with source system and format unresolved. Proposed read-only retrieval must preserve document approval state, source version, citations and staff access boundaries. Source connector and retrieval implementation remain engineering work; no vector or keyword mode is assumed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Draft and approval backend → Approved support knowledge: Read approved accessible evidence and source versions; adapter unresolved

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Connector credentials

AWS Secrets Manager · aws · region: To be selected · classification: Confidential

Proposed AWS Secrets Manager stores administrator-supplied CRM and outbound mail API credentials in separate scoped secret resources owned by this component, plus knowledge credentials if required. Backend can retrieve only read-only connector credentials; executor alone retrieves CRM action and mail-send credentials. Actual API scopes require validation; existing credential availability does not prove least privilege. Secure administrator loading, rotation and revocation require implementation. Secret values never enter browser responses, model context, logs or diagram.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Draft and approval backend → Connector credentials: IAM-scoped GetSecretValue: read-only connector credentials; Approved action executor → Connector credentials: IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Operational monitoring

Amazon CloudWatch · aws · region: To be selected · classification: Confidential

Proposed Amazon CloudWatch metrics, dashboard and alarms for draft failures, denied execution, stuck approvals, unknown CRM or mail outcomes, partial completion and connector authentication errors. Function log groups are owned by their Lambda components. Correlate action IDs without logging full case text or credentials. Alarm recipient, retention and operational ownership remain open; notification integration requires implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Draft and approval backend → Operational monitoring: Redacted logs and correlated draft/approval metrics; Approved action executor → Operational monitoring: Execution, denial, partial-completion and uncertain CRM/mail outcome metrics

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Define structured redacted logs, retention, metrics, alarms, dashboards and alert ownership for each component.
- Test ingestion failure, denied access and latency alarms; verify sensitive prompts, source text and credentials are excluded.

### Existing outbound mail

Application runtime and API · tools · region: Existing location unknown · classification: Confidential

Client-owned existing outbound mail service with administrator-supplied API credentials. Reference only; no replacement, import or provisioning. Receives exact staff-approved recipient and message through the executor only. Vendor API, sender permissions, deduplication support, submission lookup and delivery-status interfaces remain unverified. Adapter must distinguish accepted submission from delivery and block automatic resubmission after an uncertain outcome unless reconciliation establishes safety. No Amazon SES replacement is assumed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Approved action executor → Existing outbound mail: Existing mail API: approved recipient/body; stable send key; reconcile submissio

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Architecture

```mermaid
flowchart LR
  n0["Support staff<br/>Tools & data"]
  n1["Staff review application<br/>AWS"]
  n2["Staff sign-in<br/>AWS"]
  n3["Authenticated copilot API<br/>AWS"]
  n4["Draft and approval backend<br/>AWS"]
  n5["Approved action executor<br/>AWS"]
  n6["Draft, approval and action ledger<br/>AWS"]
  n7["Drafting model<br/>AWS"]
  n8["Existing CRM<br/>Tools & data"]
  n9["Approved support knowledge<br/>Tools & data"]
  n10["Connector credentials<br/>AWS"]
  n11["Operational monitoring<br/>AWS"]
  n12["Existing outbound mail<br/>Tools & data"]
  n0 -->|HTTPS: review drafts, approve exact revisions, see status| n1
  n1 -->|OAuth authorization code with PKCE; custom integration| n2
  n2 -->|JWT issuer and scope validation; custom authorizer configuration| n3
  n1 -->|HTTPS access token: draft, review, approve, status| n3
  n3 -->|Authorized Lambda requests; return cited drafts and action status| n4
  n4 -->|Read authorized case and version; vendor API unresolved| n8
  n4 -->|Read approved accessible evidence and source versions; adapter unresolved| n9
  n4 -->|Converse: case and evidence → draft and proposed actions; custom runtime| n7
  n4 -->|Conditional revision and approval writes; authorized status reads| n6
  n4 -->|IAM-restricted invocation with stored approved action ID; custom integration| n5
  n5 -->|Validate approval; claim each operation; persist result, partial completion or u| n6
  n5 -->|Approved account change via existing API; stable action key and outcome reconcil| n8
  n4 -->|IAM-scoped GetSecretValue: read-only connector credentials| n10
  n5 -->|IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede| n10
  n4 -->|Redacted logs and correlated draft/approval metrics| n11
  n5 -->|Execution, denial, partial-completion and uncertain CRM/mail outcome metrics| n11
  n5 -->|Existing mail API: approved recipient/body; stable send key; reconcile submissio| n12
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| support-staff | Support staff | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| review-web | Staff review application | aws | Amazon CloudFront | To be selected | Proposed | Implementation needed |
| staff-auth | Staff sign-in | aws | Amazon Cognito | To be selected | Proposed | Implementation needed |
| copilot-api | Authenticated copilot API | aws | Amazon API Gateway | To be selected | Proposed | Implementation needed |
| copilot-backend | Draft and approval backend | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| action-executor | Approved action executor | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| approval-ledger | Draft, approval and action ledger | aws | Amazon DynamoDB | To be selected | Proposed | Implementation needed |
| draft-model | Drafting model | aws | Amazon Bedrock | To be selected | Existing | Existing — reference/import plan needed |
| existing-crm | Existing CRM | tools | Storage or existing data connector | Existing location unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| approved-knowledge | Approved support knowledge | tools | Storage or existing data connector | Existing location unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| connector-secrets | Connector credentials | aws | AWS Secrets Manager | To be selected | Proposed | Implementation needed |
| copilot-observability | Operational monitoring | aws | Amazon CloudWatch | To be selected | Proposed | Implementation needed |
| existing-outbound-mail | Existing outbound mail | tools | Application runtime and API | Existing location unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |

### Resources and cost dimensions

- **Support staff** (support-staff): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Staff review application** (review-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: support-staff.
- **Staff sign-in** (staff-auth): aws_cognito_user_pool. Active users and authentication features. Depends on: review-web.
- **Authenticated copilot API** (copilot-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: staff-auth, review-web.
- **Draft and approval backend** (copilot-backend): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: copilot-api.
- **Approved action executor** (action-executor): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: copilot-backend.
- **Draft, approval and action ledger** (approval-ledger): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: copilot-backend, action-executor.
- **Drafting model** (draft-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: copilot-backend.
- **Existing CRM** (existing-crm): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-backend, action-executor.
- **Approved support knowledge** (approved-knowledge): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-backend.
- **Connector credentials** (connector-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-backend, action-executor.
- **Operational monitoring** (copilot-observability): aws_cloudwatch_log_group. Logs, metrics, alarms and retention. Depends on: copilot-backend, action-executor.
- **Existing outbound mail** (existing-outbound-mail): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: action-executor.

### Engineering work remaining

- Staff review application: Implementation needed.
- Staff sign-in: Implementation needed.
- Authenticated copilot API: Implementation needed.
- Draft and approval backend: Implementation needed.
- Approved action executor: Implementation needed.
- Draft, approval and action ledger: Implementation needed.
- Drafting model: Existing — reference/import plan needed.
- Connector credentials: Implementation needed.
- Operational monitoring: Implementation needed.
- Wire support-staff → review-web: implement data flow, access policy and acceptance test.
- Wire review-web → staff-auth: implement data flow, access policy and acceptance test.
- Wire staff-auth → copilot-api: implement data flow, access policy and acceptance test.
- Wire review-web → copilot-api: implement data flow, access policy and acceptance test.
- Wire copilot-api → copilot-backend: implement data flow, access policy and acceptance test.
- Wire copilot-backend → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-backend → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-backend → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-backend → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-backend → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-backend → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-backend → copilot-observability: implement data flow, access policy and acceptance test.
- Wire action-executor → copilot-observability: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-outbound-mail: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
