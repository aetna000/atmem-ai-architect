Snapshot be1a503f-a2ef-4825-8eeb-dc9cae607908 · design r3 · generated 2026-11-09T17:05:09.605Z

# Human-approved support copilot — deployment document

Generated 2026-11-09 17:05 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 9 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** CRM and outbound mail already exist, with administrator-supplied API credentials. Do not recreate them.
- **How good, fast and safe:** —
- **Cloud preference:** AWS
- **Budget and timeline:** —

## 3. Architecture

**Staff review**

- Support staff (Tools & data, existing, sketch) — Existing staff using a browser to inspect drafts, citations and exact proposed changes, then approve or reject. External caller outside provisioning scope.
- Staff review application (AWS, sketch) — Proposed Amazon CloudFront distribution serving a custom staff application from owned private S3 web assets. Shows cases, cited drafts, action parameters and execution status. Approval submits an exact revision; browser controls never replace server authorization. Custom UI and hosting implementation required; the bounded-RAG web adapter does not implement this workflow.
- Staff sign-in (AWS, sketch) — Proposed Amazon Cognito user pool for authenticated staff sessions, with MFA and federation to the existing workforce identity provider where available. Identity provider and onboarding ownership are unconfirmed. API validates access tokens; application separately enforces case access and action permissions. Custom integration required.

**Copilot processing**

- Authenticated copilot API (AWS, sketch) — Proposed Amazon API Gateway HTTP API with JWT authorization for case retrieval, drafting, revision review, approval/rejection and status. Request identifiers support safe retries. Routes invoke the copilot backend only; no browser route directly invokes the privileged executor. Custom API contract and authorization integration required.
- Draft and approval backend (AWS, sketch) — Custom AWS Lambda reads authorized CRM cases and approved knowledge, builds cited drafts and structured action proposals, and returns them to the review application. Treats cases, documents and model output as untrusted data. Has read-only CRM access and no mail-send or account-change credentials. Persists exact revisions and conditionally records authenticated approval bound to case version, content hash, mail recipient/body and action parameters. Only validated stored actions enter the executor. Owns execution IAM role and log group. Retrieval method awaits source characteristics; insufficient evidence produces an explicit unable-to-draft result. Administrator-supplied CRM credentials require scope validation; separate read-only credentials are proposed.
- Drafting model (AWS, existing, sketch) — Amazon Bedrock managed inference dependency for grounded draft generation and structured action recommendations only. No action tools or CRM write credentials. Direct model, regional availability, data handling, quotas and output bounds require review after residency is established. Existing provider-managed service reference; no model entitlement or interoperability is verified.

**Controlled actions**

- Approved action executor (AWS, sketch) — Separate custom AWS Lambda is the only proposed runtime allowed to send replies through existing outbound mail or change accounts through the existing CRM. Accepts stored action IDs and revalidates authorization, exact approval revision, recipient/content or action parameters, allowlisted operation and current case state before conditionally claiming execution. Each external operation has a durable key and independent outcome; a completed operation is never replayed because another operation failed. Reuses destination idempotency keys where supported. Lost responses enter an unknown state requiring reliable destination reconciliation; affected operations remain blocked when safe recovery cannot be established. Mail submission and final delivery are distinct states. Only executor accesses administrator-supplied send/change credentials. Owns separate least-privilege role and logs. Custom adapters and denial, concurrency and recovery tests required.
- Draft, approval and action ledger (AWS, sketch) — Proposed Amazon DynamoDB table stores draft revisions, source references, authenticated approvals and separate durable records for each CRM change or outbound mail submission. Records exact approved parameters, stable operation keys, claims, destination references and outcomes, including partial completion and unknown outcomes. Conditional writes and transactions prevent concurrent claims and bind approvals to exact content. Backend creates proposals/approvals; only executor transitions execution outcomes. Proposed encryption and point-in-time recovery; retention and recovery targets remain open. Local records alone cannot guarantee exactly-once external effects or atomic completion across CRM and mail.

**Existing systems**

- Existing CRM (Tools & data, existing, sketch) — Client-owned existing CRM with administrator-supplied API credentials. Remains system of record for cases and account state; outside provisioning, import and modification scope. Vendor and API interfaces remain unresolved. Separate read and account-action credentials are proposed, subject to actual supported scopes. Authorization, version checks, rate limits, operation allowlist, idempotency and reconciliation need custom integration and verification. Outbound replies use the separate existing mail service; CRM response-record linkage remains adapter work.
- Approved support knowledge (Tools & data, existing, sketch) — Existing client-approved support knowledge, with source system and format unresolved. Proposed read-only retrieval must preserve document approval state, source version, citations and staff access boundaries. Source connector and retrieval implementation remain engineering work; no vector or keyword mode is assumed.
- Existing outbound mail (Tools & data, existing, sketch) — Client-owned existing outbound mail service with administrator-supplied API credentials. Reference only; no replacement, import or provisioning. Receives exact staff-approved recipient and message through the executor only. Vendor API, sender permissions, deduplication support, submission lookup and delivery-status interfaces remain unverified. Adapter must distinguish accepted submission from delivery and block automatic resubmission after an uncertain outcome unless reconciliation establishes safety. No Amazon SES replacement is assumed.

**Operations**

- Connector credentials (AWS, sketch) — Proposed AWS Secrets Manager stores administrator-supplied CRM and outbound mail API credentials in separate scoped secret resources owned by this component, plus knowledge credentials if required. Backend can retrieve only read-only connector credentials; executor alone retrieves CRM action and mail-send credentials. Actual API scopes require validation; existing credential availability does not prove least privilege. Secure administrator loading, rotation and revocation require implementation. Secret values never enter browser responses, model context, logs or diagram.
- Operational monitoring (AWS, sketch) — Proposed Amazon CloudWatch metrics, dashboard and alarms for draft failures, denied execution, stuck approvals, unknown CRM or mail outcomes, partial completion and connector authentication errors. Function log groups are owned by their Lambda components. Correlate action IDs without logging full case text or credentials. Alarm recipient, retention and operational ownership remain open; notification integration requires implementation.

```mermaid
flowchart LR
  n0["Support staff<br/>Tools & data"]
  n1["Staff review application<br/>AWS"]
  n2["Staff sign-in<br/>AWS"]
  n3["Authenticated copilot API<br/>AWS"]
  n4["Draft and approval backend<br/>AWS"]
  n5["Approved action executor<br/>AWS"]
  n6["Draft, approval and action ledger<br/>AWS"]
  n7["Drafting model<br/>AWS"]
  n8["Existing CRM<br/>Tools & data"]
  n9["Approved support knowledge<br/>Tools & data"]
  n10["Connector credentials<br/>AWS"]
  n11["Operational monitoring<br/>AWS"]
  n12["Existing outbound mail<br/>Tools & data"]
  n0 -->|HTTPS: review drafts, approve exact revisions, see status| n1
  n1 -->|OAuth authorization code with PKCE; custom integration| n2
  n2 -->|JWT issuer and scope validation; custom authorizer configuration| n3
  n1 -->|HTTPS access token: draft, review, approve, status| n3
  n3 -->|Authorized Lambda requests; return cited drafts and action status| n4
  n4 -->|Read authorized case and version; vendor API unresolved| n8
  n4 -->|Read approved accessible evidence and source versions; adapter unresolved| n9
  n4 -->|Converse: case and evidence → draft and proposed actions; custom runtime| n7
  n4 -->|Conditional revision and approval writes; authorized status reads| n6
  n4 -->|IAM-restricted invocation with stored approved action ID; custom integration| n5
  n5 -->|Validate approval; claim each operation; persist result, partial completion or u| n6
  n5 -->|Approved account change via existing API; stable action key and outcome reconcil| n8
  n4 -->|IAM-scoped GetSecretValue: read-only connector credentials| n10
  n5 -->|IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede| n10
  n4 -->|Redacted logs and correlated draft/approval metrics| n11
  n5 -->|Execution, denial, partial-completion and uncertain CRM/mail outcome metrics| n11
  n5 -->|Existing mail API: approved recipient/body; stable send key; reconcile submissio| n12
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| support-staff | Support staff | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| review-web | Staff review application | aws | Amazon CloudFront | To be selected | Proposed | Implementation needed |
| staff-auth | Staff sign-in | aws | Amazon Cognito | To be selected | Proposed | Implementation needed |
| copilot-api | Authenticated copilot API | aws | Amazon API Gateway | To be selected | Proposed | Implementation needed |
| copilot-backend | Draft and approval backend | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| action-executor | Approved action executor | aws | AWS Lambda | To be selected | Proposed | Implementation needed |
| approval-ledger | Draft, approval and action ledger | aws | Amazon DynamoDB | To be selected | Proposed | Implementation needed |
| draft-model | Drafting model | aws | Amazon Bedrock | To be selected | Existing | Existing — reference/import plan needed |
| existing-crm | Existing CRM | tools | Storage or existing data connector | Existing location unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| approved-knowledge | Approved support knowledge | tools | Storage or existing data connector | Existing location unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| connector-secrets | Connector credentials | aws | AWS Secrets Manager | To be selected | Proposed | Implementation needed |
| copilot-observability | Operational monitoring | aws | Amazon CloudWatch | To be selected | Proposed | Implementation needed |
| existing-outbound-mail | Existing outbound mail | tools | Application runtime and API | Existing location unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |

### Resources and cost dimensions

- **Support staff** (support-staff): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Staff review application** (review-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: support-staff.
- **Staff sign-in** (staff-auth): aws_cognito_user_pool. Active users and authentication features. Depends on: review-web.
- **Authenticated copilot API** (copilot-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: staff-auth, review-web.
- **Draft and approval backend** (copilot-backend): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: copilot-api.
- **Approved action executor** (action-executor): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: copilot-backend.
- **Draft, approval and action ledger** (approval-ledger): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: copilot-backend, action-executor.
- **Drafting model** (draft-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: copilot-backend.
- **Existing CRM** (existing-crm): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-backend, action-executor.
- **Approved support knowledge** (approved-knowledge): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-backend.
- **Connector credentials** (connector-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-backend, action-executor.
- **Operational monitoring** (copilot-observability): aws_cloudwatch_log_group. Logs, metrics, alarms and retention. Depends on: copilot-backend, action-executor.
- **Existing outbound mail** (existing-outbound-mail): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: action-executor.

### Engineering work remaining

- Staff review application: Implementation needed.
- Staff sign-in: Implementation needed.
- Authenticated copilot API: Implementation needed.
- Draft and approval backend: Implementation needed.
- Approved action executor: Implementation needed.
- Draft, approval and action ledger: Implementation needed.
- Drafting model: Existing — reference/import plan needed.
- Connector credentials: Implementation needed.
- Operational monitoring: Implementation needed.
- Wire support-staff → review-web: implement data flow, access policy and acceptance test.
- Wire review-web → staff-auth: implement data flow, access policy and acceptance test.
- Wire staff-auth → copilot-api: implement data flow, access policy and acceptance test.
- Wire review-web → copilot-api: implement data flow, access policy and acceptance test.
- Wire copilot-api → copilot-backend: implement data flow, access policy and acceptance test.
- Wire copilot-backend → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-backend → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-backend → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-backend → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-backend → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-backend → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-backend → copilot-observability: implement data flow, access policy and acceptance test.
- Wire action-executor → copilot-observability: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-outbound-mail: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Support staff | Staff review application | HTTPS: review drafts, approve exact revisions, see status | Confidential |
| Staff review application | Staff sign-in | OAuth authorization code with PKCE; custom integration | Confidential |
| Staff sign-in | Authenticated copilot API | JWT issuer and scope validation; custom authorizer configuration | Confidential |
| Staff review application | Authenticated copilot API | HTTPS access token: draft, review, approve, status | Confidential |
| Authenticated copilot API | Draft and approval backend | Authorized Lambda requests; return cited drafts and action status | Confidential |
| Draft and approval backend | Existing CRM | Read authorized case and version; vendor API unresolved | Confidential |
| Draft and approval backend | Approved support knowledge | Read approved accessible evidence and source versions; adapter unresolved | Confidential |
| Draft and approval backend | Drafting model | Converse: case and evidence → draft and proposed actions; custom runtime | Confidential |
| Draft and approval backend | Draft, approval and action ledger | Conditional revision and approval writes; authorized status reads | Confidential |
| Draft and approval backend | Approved action executor | IAM-restricted invocation with stored approved action ID; custom integration | Confidential |
| Approved action executor | Draft, approval and action ledger | Validate approval; claim each operation; persist result, partial completion or u | Confidential |
| Approved action executor | Existing CRM | Approved account change via existing API; stable action key and outcome reconcil | Confidential |
| Draft and approval backend | Connector credentials | IAM-scoped GetSecretValue: read-only connector credentials | Confidential |
| Approved action executor | Connector credentials | IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede | Confidential |
| Draft and approval backend | Operational monitoring | Redacted logs and correlated draft/approval metrics | Confidential |
| Approved action executor | Operational monitoring | Execution, denial, partial-completion and uncertain CRM/mail outcome metrics | Confidential |
| Approved action executor | Existing outbound mail | Existing mail API: approved recipient/body; stable send key; reconcile submissio | Confidential |

## 5. Security controls

- **Support staff** — Existing staff using a browser to inspect drafts, citations and exact proposed changes, then approve or reject. External caller outside provisioning scope.
- **Staff sign-in** — Proposed Amazon Cognito user pool for authenticated staff sessions, with MFA and federation to the existing workforce identity provider where available. Identity provider and onboarding ownership are unconfirmed. API validates access tokens; application separately enforces case access and action permissions. Custom integration required.
- **Connector credentials** — Proposed AWS Secrets Manager stores administrator-supplied CRM and outbound mail API credentials in separate scoped secret resources owned by this component, plus knowledge credentials if required. Backend can retrieve only read-only connector credentials; executor alone retrieves CRM action and mail-send credentials. Actual API scopes require validation; existing credential availability does not prove least privilege. Secure administrator loading, rotation and revocation require implementation. Secret values never enter browser responses, model context, logs or diagram.
- Requirement: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution. (must)
- Requirement: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only. (must)
- Requirement: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions. (must)
- Open finding SEC-002: Sensitive data is involved but where it must be stored is not stated.

## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome. | reliability | not measurable yet | Open |
| Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions. | security | not measurable yet | Open |

**Functional**

- Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution. (must, open)
- The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only. (must, open)
- Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Security & controls**

- [major] Sensitive data is involved but where it must be stored is not stated. Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks. _(AtMem AI Architect rule SEC-002 v1.0.0)_

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.”, “Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 13 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Draft, approval and action ledger | Storage | needs data_gb | price needed | — | — |
| Drafting model | Endpoint hours | 730 hours | price needed | — | — |
| Existing CRM | Storage | needs data_gb | price needed | — | — |
| Approved support knowledge | Storage | needs data_gb | price needed | — | — |
| Connector credentials | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Support staff, Staff review application, Authenticated copilot API, Draft and approval backend, Approved action executor, Operational monitoring, Existing outbound mail.

**Estimate gaps:**

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Draft, approval and action ledger / Storage: input needed (data_gb).
- Drafting model / Endpoint hours: price needed.
- Existing CRM / Storage: input needed (data_gb).
- Approved support knowledge / Storage: input needed (data_gb).
- Connector credentials / Checked requests: input needed (requests_per_month).
- Support staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Staff review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated copilot API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Draft and approval backend: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved action executor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing outbound mail: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff review: Staff review application, Staff sign-in.
4. Provision copilot processing: Authenticated copilot API, Draft and approval backend.
5. Provision controlled actions: Approved action executor, Draft, approval and action ledger.
6. Provision operations: Connector credentials, Operational monitoring.
7. Connect existing systems: Support staff, Drafting model, Existing CRM, Approved support knowledge, Existing outbound mail; test failure behaviour.
8. Run the acceptance checks (success measures and requirements) in staging; record results.
9. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Staff sign-in: needs requests_per_month _(estimate)_
- Draft, approval and action ledger: needs data_gb _(estimate)_
- Drafting model: needs a unit price with a source _(estimate)_
- Existing CRM: needs data_gb _(estimate)_
- Approved support knowledge: needs data_gb _(estimate)_
- Connector credentials: needs requests_per_month _(estimate)_
