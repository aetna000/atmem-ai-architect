# Delivery handoff

Snapshot be1a503f-a2ef-4825-8eeb-dc9cae607908 · design r3 · generated 2026-11-09T17:05:09.605Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Draft, approval and action ledger / Storage: input needed (data_gb).
- Drafting model / Endpoint hours: price needed.
- Existing CRM / Storage: input needed (data_gb).
- Approved support knowledge / Storage: input needed (data_gb).
- Connector credentials / Checked requests: input needed (requests_per_month).
- Support staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Staff review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated copilot API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Draft and approval backend: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved action executor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing outbound mail: no cost lines; add charges or an explicit zero-cost line with a reason.
- Staff review application: Implementation needed.
- Staff sign-in: Implementation needed.
- Authenticated copilot API: Implementation needed.
- Draft and approval backend: Implementation needed.
- Approved action executor: Implementation needed.
- Draft, approval and action ledger: Implementation needed.
- Drafting model: Existing — reference/import plan needed.
- Connector credentials: Implementation needed.
- Operational monitoring: Implementation needed.
- Wire support-staff → review-web: implement data flow, access policy and acceptance test.
- Wire review-web → staff-auth: implement data flow, access policy and acceptance test.
- Wire staff-auth → copilot-api: implement data flow, access policy and acceptance test.
- Wire review-web → copilot-api: implement data flow, access policy and acceptance test.
- Wire copilot-api → copilot-backend: implement data flow, access policy and acceptance test.
- Wire copilot-backend → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-backend → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-backend → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-backend → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-backend → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-crm: implement data flow, access policy and acceptance test.
- Wire copilot-backend → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire copilot-backend → copilot-observability: implement data flow, access policy and acceptance test.
- Wire action-executor → copilot-observability: implement data flow, access policy and acceptance test.
- Wire action-executor → existing-outbound-mail: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
