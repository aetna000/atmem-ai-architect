# Detailed implementation tasks

Snapshot be1a503f-a2ef-4825-8eeb-dc9cae607908 · design r3 · generated 2026-11-09T17:05:09.605Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-73746166662d776562 — Define Support staff → Staff review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: support-staff, review-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection staff-web: HTTPS: review drafts, approve exact revisions, see status. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge staff-web
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d61757468 — Define Staff review application → Staff sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: review-web, staff-auth
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-auth: OAuth authorization code with PKCE; custom integration. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-auth
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617574682d617069 — Define Staff sign-in → Authenticated copilot API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: staff-auth, copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection auth-api: JWT issuer and scope validation; custom authorizer configuration. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge auth-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d617069 — Define Staff review application → Authenticated copilot API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: review-web, copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-api: HTTPS access token: draft, review, approve, status. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170692d6261636b656e64 — Define Authenticated copilot API → Draft and approval backend

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-api, copilot-backend
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection api-backend: Authorized Lambda requests; return cited drafts and action status. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge api-backend
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d63726d2d72656164 — Define Draft and approval backend → Existing CRM

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-crm-read: Read authorized case and version; vendor API unresolved. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-crm-read
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d6b6e6f776c65646765 — Define Draft and approval backend → Approved support knowledge

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, approved-knowledge
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-knowledge: Read approved accessible evidence and source versions; adapter unresolved. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-knowledge
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d6d6f64656c — Define Draft and approval backend → Drafting model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, draft-model
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-model: Converse: case and evidence → draft and proposed actions; custom runtime. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d6c6564676572 — Define Draft and approval backend → Draft, approval and action ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-ledger: Conditional revision and approval writes; authorized status reads. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-ledger
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d6578656375746f72 — Define Draft and approval backend → Approved action executor

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, action-executor
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-executor: IAM-restricted invocation with stored approved action ID; custom integration. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-executor
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d6c6564676572 — Define Approved action executor → Draft, approval and action ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-ledger: Validate approval; claim each operation; persist result, partial completion or u. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-ledger
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d63726d — Define Approved action executor → Existing CRM

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-crm: Approved account change via existing API; stable action key and outcome reconcil. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-crm
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d73656372657473 — Define Draft and approval backend → Connector credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-secrets: IAM-scoped GetSecretValue: read-only connector credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d73656372657473 — Define Approved action executor → Connector credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-secrets: IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6261636b656e642d6d6f6e69746f72 — Define Draft and approval backend → Operational monitoring

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-backend, copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection backend-monitor: Redacted logs and correlated draft/approval metrics. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge backend-monitor
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d6d6f6e69746f72 — Define Approved action executor → Operational monitoring

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-monitor: Execution, denial, partial-completion and uncertain CRM/mail outcome metrics. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-monitor
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6578656375746f722d6d61696c — Define Approved action executor → Existing outbound mail

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, existing-outbound-mail
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection executor-mail: Existing mail API: approved recipient/body; stable send key; reconcile submissio. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge executor-mail
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-737570706f72742d7374616666 — Integrate existing Support staff

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d776562
- Components: support-staff
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing staff using a browser to inspect drafts, citations and exact proposed changes, then approve or reject. External caller outside provisioning scope.
2. Verify Approval workflow on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component support-staff
- Application/configuration and tests for Support staff

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7265766965772d776562 — Implement Staff review application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d776562, TASK-CONTRACT-7765622d61757468, TASK-CONTRACT-7765622d617069
- Components: review-web
- Generated files: terraform/main.tf.json
- Requirements: ai-explicit-approval, ai-grounded-support-drafts

### Implementation steps

1. Responsibility from the board: Proposed Amazon CloudFront distribution serving a custom staff application from owned private S3 web assets. Shows cases, cited drafts, action parameters and execution status. Approval submits an exact revision; browser controls never replace server authorization. Custom UI and hosting implementation required; the bounded-RAG web adapter does not implement this workflow.
2. Verify Amazon CloudFront on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon CloudFront; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component review-web
- Application/configuration and tests for Staff review application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73746166662d61757468 — Implement Staff sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7765622d61757468, TASK-CONTRACT-617574682d617069
- Components: staff-auth
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Amazon Cognito user pool for authenticated staff sessions, with MFA and federation to the existing workforce identity provider where available. Identity provider and onboarding ownership are unconfirmed. API validates access tokens; application separately enforces case access and action permissions. Custom integration required.
2. Verify Amazon Cognito on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon Cognito; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-auth
- Application/configuration and tests for Staff sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f70696c6f742d617069 — Implement Authenticated copilot API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-617574682d617069, TASK-CONTRACT-7765622d617069, TASK-CONTRACT-6170692d6261636b656e64
- Components: copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Amazon API Gateway HTTP API with JWT authorization for case retrieval, drafting, revision review, approval/rejection and status. Request identifiers support safe retries. Routes invoke the copilot backend only; no browser route directly invokes the privileged executor. Custom API contract and authorization integration required.
2. Verify Amazon API Gateway on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon API Gateway; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component copilot-api
- Application/configuration and tests for Authenticated copilot API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f70696c6f742d6261636b656e64 — Implement Draft and approval backend

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170692d6261636b656e64, TASK-CONTRACT-6261636b656e642d63726d2d72656164, TASK-CONTRACT-6261636b656e642d6b6e6f776c65646765, TASK-CONTRACT-6261636b656e642d6d6f64656c, TASK-CONTRACT-6261636b656e642d6c6564676572, TASK-CONTRACT-6261636b656e642d6578656375746f72, TASK-CONTRACT-6261636b656e642d73656372657473, TASK-CONTRACT-6261636b656e642d6d6f6e69746f72
- Components: copilot-backend
- Generated files: terraform/main.tf.json
- Requirements: ai-explicit-approval, ai-grounded-support-drafts, ai-existing-system-boundary, ai-connector-credential-isolation

### Implementation steps

1. Responsibility from the board: Custom AWS Lambda reads authorized CRM cases and approved knowledge, builds cited drafts and structured action proposals, and returns them to the review application. Treats cases, documents and model output as untrusted data. Has read-only CRM access and no mail-send or account-change credentials. Persists exact revisions and conditionally records authenticated approval bound to case version, content hash, mail recipient/body and action parameters. Only validated stored actions enter the executor. Owns execution IAM role and log group. Retrieval method awaits source characteristics; insufficient evidence produces an explicit unable-to-draft result. Administrator-supplied CRM credentials require scope validation; separate read-only credentials are proposed.
2. Verify AWS Lambda on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.; REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component copilot-backend
- Application/configuration and tests for Draft and approval backend

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-616374696f6e2d6578656375746f72 — Implement Approved action executor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d6578656375746f72, TASK-CONTRACT-6578656375746f722d6c6564676572, TASK-CONTRACT-6578656375746f722d63726d, TASK-CONTRACT-6578656375746f722d73656372657473, TASK-CONTRACT-6578656375746f722d6d6f6e69746f72, TASK-CONTRACT-6578656375746f722d6d61696c
- Components: action-executor
- Generated files: terraform/main.tf.json
- Requirements: ai-explicit-approval, ai-no-duplicate-effects, ai-existing-system-boundary, ai-connector-credential-isolation

### Implementation steps

1. Responsibility from the board: Separate custom AWS Lambda is the only proposed runtime allowed to send replies through existing outbound mail or change accounts through the existing CRM. Accepts stored action IDs and revalidates authorization, exact approval revision, recipient/content or action parameters, allowlisted operation and current case state before conditionally claiming execution. Each external operation has a durable key and independent outcome; a completed operation is never replayed because another operation failed. Reuses destination idempotency keys where supported. Lost responses enter an unknown state requiring reliable destination reconciliation; affected operations remain blocked when safe recovery cannot be established. Mail submission and final delivery are distinct states. Only executor accesses administrator-supplied send/change credentials. Owns separate least-privilege role and logs. Custom adapters and denial, concurrency and recovery tests required.
2. Verify AWS Lambda on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.; REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component action-executor
- Application/configuration and tests for Approved action executor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617070726f76616c2d6c6564676572 — Implement Draft, approval and action ledger

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d6c6564676572, TASK-CONTRACT-6578656375746f722d6c6564676572
- Components: approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: ai-explicit-approval, ai-no-duplicate-effects

### Implementation steps

1. Responsibility from the board: Proposed Amazon DynamoDB table stores draft revisions, source references, authenticated approvals and separate durable records for each CRM change or outbound mail submission. Records exact approved parameters, stable operation keys, claims, destination references and outcomes, including partial completion and unknown outcomes. Conditional writes and transactions prevent concurrent claims and bind approvals to exact content. Backend creates proposals/approvals; only executor transitions execution outcomes. Proposed encryption and point-in-time recovery; retention and recovery targets remain open. Local records alone cannot guarantee exactly-once external effects or atomic completion across CRM and mail.
2. Verify Amazon DynamoDB on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon DynamoDB; determine exact resource types and required application code. The export has not generated this implementation.
4. Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
5. Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.; REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component approval-ledger
- Application/configuration and tests for Draft, approval and action ledger

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-64726166742d6d6f64656c — Integrate existing Drafting model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d6d6f64656c
- Components: draft-model
- Generated files: terraform/main.tf.json
- Requirements: ai-grounded-support-drafts

### Implementation steps

1. Responsibility from the board: Amazon Bedrock managed inference dependency for grounded draft generation and structured action recommendations only. No action tools or CRM write credentials. Direct model, regional availability, data handling, quotas and output bounds require review after residency is established. Existing provider-managed service reference; no model entitlement or interoperability is verified.
2. Verify Amazon Bedrock on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component draft-model
- Application/configuration and tests for Drafting model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6578697374696e672d63726d — Integrate existing Existing CRM

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d63726d2d72656164, TASK-CONTRACT-6578656375746f722d63726d
- Components: existing-crm
- Generated files: No implementation files generated yet
- Requirements: ai-no-duplicate-effects, ai-grounded-support-drafts, ai-existing-system-boundary, ai-connector-credential-isolation

### Implementation steps

1. Responsibility from the board: Client-owned existing CRM with administrator-supplied API credentials. Remains system of record for cases and account state; outside provisioning, import and modification scope. Vendor and API interfaces remain unresolved. Separate read and account-action credentials are proposed, subject to actual supported scopes. Authorization, version checks, rate limits, operation allowlist, idempotency and reconciliation need custom integration and verification. Outbound replies use the separate existing mail service; CRM response-record linkage remains adapter work.
2. Verify Storage or existing data connector on tools in Existing location unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.; REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.; REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component existing-crm
- Application/configuration and tests for Existing CRM

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765 — Integrate existing Approved support knowledge

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d6b6e6f776c65646765
- Components: approved-knowledge
- Generated files: No implementation files generated yet
- Requirements: ai-grounded-support-drafts

### Implementation steps

1. Responsibility from the board: Existing client-approved support knowledge, with source system and format unresolved. Proposed read-only retrieval must preserve document approval state, source version, citations and staff access boundaries. Source connector and retrieval implementation remain engineering work; no vector or keyword mode is assumed.
2. Verify Storage or existing data connector on tools in Existing location unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component approved-knowledge
- Application/configuration and tests for Approved support knowledge

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e6e6563746f722d73656372657473 — Implement Connector credentials

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d73656372657473, TASK-CONTRACT-6578656375746f722d73656372657473
- Components: connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: ai-connector-credential-isolation

### Implementation steps

1. Responsibility from the board: Proposed AWS Secrets Manager stores administrator-supplied CRM and outbound mail API credentials in separate scoped secret resources owned by this component, plus knowledge credentials if required. Backend can retrieve only read-only connector credentials; executor alone retrieves CRM action and mail-send credentials. Actual API scopes require validation; existing credential availability does not prove least privilege. Secure administrator loading, rotation and revocation require implementation. Secret values never enter browser responses, model context, logs or diagram.
2. Verify AWS Secrets Manager on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Secrets Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component connector-secrets
- Application/configuration and tests for Connector credentials

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f70696c6f742d6f62736572766162696c697479 — Implement Operational monitoring

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6261636b656e642d6d6f6e69746f72, TASK-CONTRACT-6578656375746f722d6d6f6e69746f72
- Components: copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Amazon CloudWatch metrics, dashboard and alarms for draft failures, denied execution, stuck approvals, unknown CRM or mail outcomes, partial completion and connector authentication errors. Function log groups are owned by their Lambda components. Correlate action IDs without logging full case text or credentials. Alarm recipient, retention and operational ownership remain open; notification integration requires implementation.
2. Verify Amazon CloudWatch on aws in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon CloudWatch; determine exact resource types and required application code. The export has not generated this implementation.
4. Define structured redacted logs, retention, metrics, alarms, dashboards and alert ownership for each component.
5. Test ingestion failure, denied access and latency alarms; verify sensitive prompts, source text and credentials are excluded.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component copilot-observability
- Application/configuration and tests for Operational monitoring

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c — Integrate existing Existing outbound mail

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6578656375746f722d6d61696c
- Components: existing-outbound-mail
- Generated files: No implementation files generated yet
- Requirements: ai-existing-system-boundary, ai-connector-credential-isolation

### Implementation steps

1. Responsibility from the board: Client-owned existing outbound mail service with administrator-supplied API credentials. Reference only; no replacement, import or provisioning. Receives exact staff-approved recipient and message through the executor only. Vendor API, sender permissions, deduplication support, submission lookup and delivery-status interfaces remain unverified. Adapter must distinguish accepted submission from delivery and block automatic resubmission after an uncertain outcome unless reconciliation establishes safety. No Amazon SES replacement is assumed.
2. Verify Application runtime and API on tools in Existing location unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.; REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component existing-outbound-mail
- Application/configuration and tests for Existing outbound mail

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-73746166662d776562 — Wire Support staff to Staff review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73746166662d776562, TASK-RESOURCE-737570706f72742d7374616666, TASK-RESOURCE-7265766965772d776562
- Components: support-staff, review-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge staff-web carrying HTTPS: review drafts, approve exact revisions, see status, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation staff-web
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d61757468 — Wire Staff review application to Staff sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d61757468, TASK-RESOURCE-7265766965772d776562, TASK-RESOURCE-73746166662d61757468
- Components: review-web, staff-auth
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-auth carrying OAuth authorization code with PKCE; custom integration, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-auth
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617574682d617069 — Wire Staff sign-in to Authenticated copilot API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617574682d617069, TASK-RESOURCE-73746166662d61757468, TASK-RESOURCE-636f70696c6f742d617069
- Components: staff-auth, copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge auth-api carrying JWT issuer and scope validation; custom authorizer configuration, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation auth-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d617069 — Wire Staff review application to Authenticated copilot API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d617069, TASK-RESOURCE-7265766965772d776562, TASK-RESOURCE-636f70696c6f742d617069
- Components: review-web, copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-api carrying HTTPS access token: draft, review, approve, status, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170692d6261636b656e64 — Wire Authenticated copilot API to Draft and approval backend

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170692d6261636b656e64, TASK-RESOURCE-636f70696c6f742d617069, TASK-RESOURCE-636f70696c6f742d6261636b656e64
- Components: copilot-api, copilot-backend
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge api-backend carrying Authorized Lambda requests; return cited drafts and action status, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation api-backend
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d63726d2d72656164 — Wire Draft and approval backend to Existing CRM

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d63726d2d72656164, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-6578697374696e672d63726d
- Components: copilot-backend, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-crm-read carrying Read authorized case and version; vendor API unresolved, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-crm-read
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d6b6e6f776c65646765 — Wire Draft and approval backend to Approved support knowledge

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d6b6e6f776c65646765, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Components: copilot-backend, approved-knowledge
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-knowledge carrying Read approved accessible evidence and source versions; adapter unresolved, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-knowledge
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d6d6f64656c — Wire Draft and approval backend to Drafting model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d6d6f64656c, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-64726166742d6d6f64656c
- Components: copilot-backend, draft-model
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-model carrying Converse: case and evidence → draft and proposed actions; custom runtime, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d6c6564676572 — Wire Draft and approval backend to Draft, approval and action ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d6c6564676572, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-617070726f76616c2d6c6564676572
- Components: copilot-backend, approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-ledger carrying Conditional revision and approval writes; authorized status reads, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-ledger
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d6578656375746f72 — Wire Draft and approval backend to Approved action executor

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d6578656375746f72, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-616374696f6e2d6578656375746f72
- Components: copilot-backend, action-executor
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-executor carrying IAM-restricted invocation with stored approved action ID; custom integration, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-executor
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d6c6564676572 — Wire Approved action executor to Draft, approval and action ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-617070726f76616c2d6c6564676572
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-ledger carrying Validate approval; claim each operation; persist result, partial completion or u, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-ledger
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d63726d — Wire Approved action executor to Existing CRM

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d63726d, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-6578697374696e672d63726d
- Components: action-executor, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-crm carrying Approved account change via existing API; stable action key and outcome reconcil, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-crm
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d73656372657473 — Wire Draft and approval backend to Connector credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d73656372657473, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Components: copilot-backend, connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-secrets carrying IAM-scoped GetSecretValue: read-only connector credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d73656372657473 — Wire Approved action executor to Connector credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d73656372657473, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Components: action-executor, connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-secrets carrying IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6261636b656e642d6d6f6e69746f72 — Wire Draft and approval backend to Operational monitoring

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6261636b656e642d6d6f6e69746f72, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-636f70696c6f742d6f62736572766162696c697479
- Components: copilot-backend, copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge backend-monitor carrying Redacted logs and correlated draft/approval metrics, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation backend-monitor
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d6d6f6e69746f72 — Wire Approved action executor to Operational monitoring

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d6d6f6e69746f72, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-636f70696c6f742d6f62736572766162696c697479
- Components: action-executor, copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-monitor carrying Execution, denial, partial-completion and uncertain CRM/mail outcome metrics, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-monitor
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6578656375746f722d6d61696c — Wire Approved action executor to Existing outbound mail

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6578656375746f722d6d61696c, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c
- Components: action-executor, existing-outbound-mail
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge executor-mail carrying Existing mail API: approved recipient/body; stable send key; reconcile submissio, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation executor-mail
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-73746166662d776562 — Verify live Support staff → Staff review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73746166662d776562
- Components: support-staff, review-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge staff-web with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence staff-web

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d61757468 — Verify live Staff review application → Staff sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d61757468
- Components: review-web, staff-auth
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-auth with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-auth

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617574682d617069 — Verify live Staff sign-in → Authenticated copilot API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617574682d617069
- Components: staff-auth, copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge auth-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence auth-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d617069 — Verify live Staff review application → Authenticated copilot API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d617069
- Components: review-web, copilot-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170692d6261636b656e64 — Verify live Authenticated copilot API → Draft and approval backend

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170692d6261636b656e64
- Components: copilot-api, copilot-backend
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge api-backend with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence api-backend

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164 — Verify live Draft and approval backend → Existing CRM

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d63726d2d72656164
- Components: copilot-backend, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-crm-read with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-crm-read

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765 — Verify live Draft and approval backend → Approved support knowledge

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d6b6e6f776c65646765
- Components: copilot-backend, approved-knowledge
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-knowledge with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-knowledge

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c — Verify live Draft and approval backend → Drafting model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d6d6f64656c
- Components: copilot-backend, draft-model
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572 — Verify live Draft and approval backend → Draft, approval and action ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d6c6564676572
- Components: copilot-backend, approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-ledger with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-ledger

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72 — Verify live Draft and approval backend → Approved action executor

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d6578656375746f72
- Components: copilot-backend, action-executor
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-executor with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-executor

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572 — Verify live Approved action executor → Draft, approval and action ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d6c6564676572
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-ledger with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-ledger

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d63726d — Verify live Approved action executor → Existing CRM

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d63726d
- Components: action-executor, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-crm with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-crm

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473 — Verify live Draft and approval backend → Connector credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d73656372657473
- Components: copilot-backend, connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473 — Verify live Approved action executor → Connector credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d73656372657473
- Components: action-executor, connector-secrets
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72 — Verify live Draft and approval backend → Operational monitoring

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6261636b656e642d6d6f6e69746f72
- Components: copilot-backend, copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge backend-monitor with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence backend-monitor

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72 — Verify live Approved action executor → Operational monitoring

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d6d6f6e69746f72
- Components: action-executor, copilot-observability
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-monitor with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-monitor

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c — Verify live Approved action executor → Existing outbound mail

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6578656375746f722d6d61696c
- Components: action-executor, existing-outbound-mail
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge executor-mail with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence executor-mail

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c — Verify REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7265766965772d776562, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-INTEGRATION-LIVE-73746166662d776562, TASK-INTEGRATION-LIVE-7765622d61757468, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d6261636b656e64, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c
- Components: copilot-backend, approval-ledger, action-executor, review-web
- Generated files: terraform/main.tf.json
- Requirements: ai-explicit-approval

### Implementation steps

1. Basis: User: “Nothing is sent or changed until a staff member explicitly approves it.” Exact-revision binding and server authorization are proposed enforcement details.; rationale: Prevents generated content or a forged/replayed request from authorizing a different send or account change.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d65666665637473 — Verify REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-6578697374696e672d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c
- Components: action-executor, approval-ledger, existing-crm
- Generated files: terraform/main.tf.json
- Requirements: ai-no-duplicate-effects

### Implementation steps

1. Basis: User: “Retries must not perform an action twice.” Durable keys, conditional claims and uncertain-outcome reconciliation are proposed mechanisms.; rationale: A CRM may complete a change before its response times out; a local lock alone cannot prevent a duplicate external effect.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d737570706f72742d647261667473 — Verify REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7265766965772d776562, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-73746166662d776562, TASK-INTEGRATION-LIVE-7765622d61757468, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d6261636b656e64, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72
- Components: copilot-backend, existing-crm, approved-knowledge, draft-model, review-web
- Generated files: terraform/main.tf.json
- Requirements: ai-grounded-support-drafts

### Implementation steps

1. Basis: User: “reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions.” Citations, access filtering and abstention are proposed safeguards.; rationale: Keeps staff review grounded in approved evidence and prevents draft generation from obtaining action privileges.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6578697374696e672d73797374656d2d626f756e64617279 — Verify REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c, TASK-INTEGRATION-LIVE-6170692d6261636b656e64, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c
- Components: existing-crm, existing-outbound-mail, copilot-backend, action-executor
- Generated files: terraform/main.tf.json
- Requirements: ai-existing-system-boundary

### Implementation steps

1. Basis: “CRM and outbound mail already exist, with administrator-supplied API credentials. Do not recreate them.”; rationale: Preserves client-owned services and prevents accidental replacement or provisioning of systems the administrator already operates.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d636f6e6e6563746f722d63726564656e7469616c2d69736f6c6174696f6e — Verify REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c, TASK-INTEGRATION-LIVE-6170692d6261636b656e64, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c
- Components: connector-secrets, copilot-backend, action-executor, existing-crm, existing-outbound-mail
- Generated files: terraform/main.tf.json
- Requirements: ai-connector-credential-isolation

### Implementation steps

1. Basis: Administrator-supplied API credentials in the current message; existing read-only backend and separate approved-action executor on the diagram.; rationale: Proposed safeguard: separating credential access prevents drafting or untrusted model output from acquiring authority to send mail or change accounts.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-737570706f72742d7374616666, TASK-RESOURCE-7265766965772d776562, TASK-RESOURCE-73746166662d61757468, TASK-RESOURCE-636f70696c6f742d617069, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-636f70696c6f742d6f62736572766162696c697479, TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c, TASK-INTEGRATION-73746166662d776562, TASK-INTEGRATION-7765622d61757468, TASK-INTEGRATION-617574682d617069, TASK-INTEGRATION-7765622d617069, TASK-INTEGRATION-6170692d6261636b656e64, TASK-INTEGRATION-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-6261636b656e642d6d6f64656c, TASK-INTEGRATION-6261636b656e642d6c6564676572, TASK-INTEGRATION-6261636b656e642d6578656375746f72, TASK-INTEGRATION-6578656375746f722d6c6564676572, TASK-INTEGRATION-6578656375746f722d63726d, TASK-INTEGRATION-6261636b656e642d73656372657473, TASK-INTEGRATION-6578656375746f722d73656372657473, TASK-INTEGRATION-6261636b656e642d6d6f6e69746f72, TASK-INTEGRATION-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-6578656375746f722d6d61696c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-737570706f72742d7374616666, TASK-RESOURCE-7265766965772d776562, TASK-RESOURCE-73746166662d61757468, TASK-RESOURCE-636f70696c6f742d617069, TASK-RESOURCE-636f70696c6f742d6261636b656e64, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-6578697374696e672d63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-636f70696c6f742d6f62736572766162696c697479, TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c, TASK-INTEGRATION-LIVE-73746166662d776562, TASK-INTEGRATION-LIVE-7765622d61757468, TASK-INTEGRATION-LIVE-617574682d617069, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d6261636b656e64, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c, TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d65666665637473, TASK-ACCEPTANCE-61692d67726f756e6465642d737570706f72742d647261667473, TASK-ACCEPTANCE-61692d6578697374696e672d73797374656d2d626f756e64617279, TASK-ACCEPTANCE-61692d636f6e6e6563746f722d63726564656e7469616c2d69736f6c6174696f6e, TASK-INTEGRATION-LIVE-73746166662d776562, TASK-INTEGRATION-LIVE-7765622d61757468, TASK-INTEGRATION-LIVE-617574682d617069, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d6261636b656e64, TASK-INTEGRATION-LIVE-6261636b656e642d63726d2d72656164, TASK-INTEGRATION-LIVE-6261636b656e642d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f64656c, TASK-INTEGRATION-LIVE-6261636b656e642d6c6564676572, TASK-INTEGRATION-LIVE-6261636b656e642d6578656375746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6c6564676572, TASK-INTEGRATION-LIVE-6578656375746f722d63726d, TASK-INTEGRATION-LIVE-6261636b656e642d73656372657473, TASK-INTEGRATION-LIVE-6578656375746f722d73656372657473, TASK-INTEGRATION-LIVE-6261636b656e642d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d6f6e69746f72, TASK-INTEGRATION-LIVE-6578656375746f722d6d61696c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
