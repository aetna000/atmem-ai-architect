# Component and interface contracts

Snapshot be1a503f-a2ef-4825-8eeb-dc9cae607908 · design r3 · generated 2026-11-09T17:05:09.605Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component support-staff: Support staff

- Responsibility: Existing staff using a browser to inspect drafts, citations and exact proposed changes, then approve or reject. External caller outside provisioning scope.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-737570706f72742d7374616666
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component review-web: Staff review application

- Responsibility: Proposed Amazon CloudFront distribution serving a custom staff application from owned private S3 web assets. Shows cases, cited drafts, action parameters and execution status. Approval submits an exact revision; browser controls never replace server authorization. Custom UI and hosting implementation required; the bounded-RAG web adapter does not implement this workflow.
- Service: Amazon CloudFront
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7265766965772d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component staff-auth: Staff sign-in

- Responsibility: Proposed Amazon Cognito user pool for authenticated staff sessions, with MFA and federation to the existing workforce identity provider where available. Identity provider and onboarding ownership are unconfirmed. API validates access tokens; application separately enforces case access and action permissions. Custom integration required.
- Service: Amazon Cognito
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d61757468
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component copilot-api: Authenticated copilot API

- Responsibility: Proposed Amazon API Gateway HTTP API with JWT authorization for case retrieval, drafting, revision review, approval/rejection and status. Request identifiers support safe retries. Routes invoke the copilot backend only; no browser route directly invokes the privileged executor. Custom API contract and authorization integration required.
- Service: Amazon API Gateway
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f70696c6f742d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component copilot-backend: Draft and approval backend

- Responsibility: Custom AWS Lambda reads authorized CRM cases and approved knowledge, builds cited drafts and structured action proposals, and returns them to the review application. Treats cases, documents and model output as untrusted data. Has read-only CRM access and no mail-send or account-change credentials. Persists exact revisions and conditionally records authenticated approval bound to case version, content hash, mail recipient/body and action parameters. Only validated stored actions enter the executor. Owns execution IAM role and log group. Retrieval method awaits source characteristics; insufficient evidence produces an explicit unable-to-draft result. Administrator-supplied CRM credentials require scope validation; separate read-only credentials are proposed.
- Service: AWS Lambda
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f70696c6f742d6261636b656e64
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component action-executor: Approved action executor

- Responsibility: Separate custom AWS Lambda is the only proposed runtime allowed to send replies through existing outbound mail or change accounts through the existing CRM. Accepts stored action IDs and revalidates authorization, exact approval revision, recipient/content or action parameters, allowlisted operation and current case state before conditionally claiming execution. Each external operation has a durable key and independent outcome; a completed operation is never replayed because another operation failed. Reuses destination idempotency keys where supported. Lost responses enter an unknown state requiring reliable destination reconciliation; affected operations remain blocked when safe recovery cannot be established. Mail submission and final delivery are distinct states. Only executor accesses administrator-supplied send/change credentials. Owns separate least-privilege role and logs. Custom adapters and denial, concurrency and recovery tests required.
- Service: AWS Lambda
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-616374696f6e2d6578656375746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component approval-ledger: Draft, approval and action ledger

- Responsibility: Proposed Amazon DynamoDB table stores draft revisions, source references, authenticated approvals and separate durable records for each CRM change or outbound mail submission. Records exact approved parameters, stable operation keys, claims, destination references and outcomes, including partial completion and unknown outcomes. Conditional writes and transactions prevent concurrent claims and bind approvals to exact content. Backend creates proposals/approvals; only executor transitions execution outcomes. Proposed encryption and point-in-time recovery; retention and recovery targets remain open. Local records alone cannot guarantee exactly-once external effects or atomic completion across CRM and mail.
- Service: Amazon DynamoDB
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617070726f76616c2d6c6564676572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

## Component draft-model: Drafting model

- Responsibility: Amazon Bedrock managed inference dependency for grounded draft generation and structured action recommendations only. No action tools or CRM write credentials. Direct model, regional availability, data handling, quotas and output bounds require review after residency is established. Existing provider-managed service reference; no model entitlement or interoperability is verified.
- Service: Amazon Bedrock
- Provider / placement: aws / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-64726166742d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component existing-crm: Existing CRM

- Responsibility: Client-owned existing CRM with administrator-supplied API credentials. Remains system of record for cases and account state; outside provisioning, import and modification scope. Vendor and API interfaces remain unresolved. Separate read and account-action credentials are proposed, subject to actual supported scopes. Authorization, version checks, rate limits, operation allowlist, idempotency and reconciliation need custom integration and verification. Outbound replies use the separate existing mail service; CRM response-record linkage remains adapter work.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing location unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6578697374696e672d63726d
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component approved-knowledge: Approved support knowledge

- Responsibility: Existing client-approved support knowledge, with source system and format unresolved. Proposed read-only retrieval must preserve document approval state, source version, citations and staff access boundaries. Source connector and retrieval implementation remain engineering work; no vector or keyword mode is assumed.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing location unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component connector-secrets: Connector credentials

- Responsibility: Proposed AWS Secrets Manager stores administrator-supplied CRM and outbound mail API credentials in separate scoped secret resources owned by this component, plus knowledge credentials if required. Backend can retrieve only read-only connector credentials; executor alone retrieves CRM action and mail-send credentials. Actual API scopes require validation; existing credential availability does not prove least privilege. Secure administrator loading, rotation and revocation require implementation. Secret values never enter browser responses, model context, logs or diagram.
- Service: AWS Secrets Manager
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component copilot-observability: Operational monitoring

- Responsibility: Proposed Amazon CloudWatch metrics, dashboard and alarms for draft failures, denied execution, stuck approvals, unknown CRM or mail outcomes, partial completion and connector authentication errors. Function log groups are owned by their Lambda components. Correlate action IDs without logging full case text or credentials. Alarm recipient, retention and operational ownership remain open; notification integration requires implementation.
- Service: Amazon CloudWatch
- Provider / placement: aws / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f70696c6f742d6f62736572766162696c697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define structured redacted logs, retention, metrics, alarms, dashboards and alert ownership for each component.
- Test ingestion failure, denied access and latency alarms; verify sensitive prompts, source text and credentials are excluded.

## Component existing-outbound-mail: Existing outbound mail

- Responsibility: Client-owned existing outbound mail service with administrator-supplied API credentials. Reference only; no replacement, import or provisioning. Receives exact staff-approved recipient and message through the executor only. Vendor API, sender permissions, deduplication support, submission lookup and delivery-status interfaces remain unverified. Adapter must distinguish accepted submission from delivery and block automatic resubmission after an uncertain outcome unless reconciliation establishes safety. No Amazon SES replacement is assumed.
- Service: Application runtime and API
- Provider / placement: tools / Existing location unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6578697374696e672d6f7574626f756e642d6d61696c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Interfaces

### staff-web: support-staff → review-web

- Drawn payload/purpose: HTTPS: review drafts, approve exact revisions, see status
- Contract task: TASK-CONTRACT-73746166662d776562
- Integration task: TASK-INTEGRATION-73746166662d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-auth: review-web → staff-auth

- Drawn payload/purpose: OAuth authorization code with PKCE; custom integration
- Contract task: TASK-CONTRACT-7765622d61757468
- Integration task: TASK-INTEGRATION-7765622d61757468
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### auth-api: staff-auth → copilot-api

- Drawn payload/purpose: JWT issuer and scope validation; custom authorizer configuration
- Contract task: TASK-CONTRACT-617574682d617069
- Integration task: TASK-INTEGRATION-617574682d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-api: review-web → copilot-api

- Drawn payload/purpose: HTTPS access token: draft, review, approve, status
- Contract task: TASK-CONTRACT-7765622d617069
- Integration task: TASK-INTEGRATION-7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-backend: copilot-api → copilot-backend

- Drawn payload/purpose: Authorized Lambda requests; return cited drafts and action status
- Contract task: TASK-CONTRACT-6170692d6261636b656e64
- Integration task: TASK-INTEGRATION-6170692d6261636b656e64
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-crm-read: copilot-backend → existing-crm

- Drawn payload/purpose: Read authorized case and version; vendor API unresolved
- Contract task: TASK-CONTRACT-6261636b656e642d63726d2d72656164
- Integration task: TASK-INTEGRATION-6261636b656e642d63726d2d72656164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-knowledge: copilot-backend → approved-knowledge

- Drawn payload/purpose: Read approved accessible evidence and source versions; adapter unresolved
- Contract task: TASK-CONTRACT-6261636b656e642d6b6e6f776c65646765
- Integration task: TASK-INTEGRATION-6261636b656e642d6b6e6f776c65646765
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-model: copilot-backend → draft-model

- Drawn payload/purpose: Converse: case and evidence → draft and proposed actions; custom runtime
- Contract task: TASK-CONTRACT-6261636b656e642d6d6f64656c
- Integration task: TASK-INTEGRATION-6261636b656e642d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-ledger: copilot-backend → approval-ledger

- Drawn payload/purpose: Conditional revision and approval writes; authorized status reads
- Contract task: TASK-CONTRACT-6261636b656e642d6c6564676572
- Integration task: TASK-INTEGRATION-6261636b656e642d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-executor: copilot-backend → action-executor

- Drawn payload/purpose: IAM-restricted invocation with stored approved action ID; custom integration
- Contract task: TASK-CONTRACT-6261636b656e642d6578656375746f72
- Integration task: TASK-INTEGRATION-6261636b656e642d6578656375746f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-ledger: action-executor → approval-ledger

- Drawn payload/purpose: Validate approval; claim each operation; persist result, partial completion or u
- Contract task: TASK-CONTRACT-6578656375746f722d6c6564676572
- Integration task: TASK-INTEGRATION-6578656375746f722d6c6564676572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-crm: action-executor → existing-crm

- Drawn payload/purpose: Approved account change via existing API; stable action key and outcome reconcil
- Contract task: TASK-CONTRACT-6578656375746f722d63726d
- Integration task: TASK-INTEGRATION-6578656375746f722d63726d
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-secrets: copilot-backend → connector-secrets

- Drawn payload/purpose: IAM-scoped GetSecretValue: read-only connector credentials
- Contract task: TASK-CONTRACT-6261636b656e642d73656372657473
- Integration task: TASK-INTEGRATION-6261636b656e642d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-secrets: action-executor → connector-secrets

- Drawn payload/purpose: IAM-scoped GetSecretValue: administrator-supplied CRM action and mail-send crede
- Contract task: TASK-CONTRACT-6578656375746f722d73656372657473
- Integration task: TASK-INTEGRATION-6578656375746f722d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### backend-monitor: copilot-backend → copilot-observability

- Drawn payload/purpose: Redacted logs and correlated draft/approval metrics
- Contract task: TASK-CONTRACT-6261636b656e642d6d6f6e69746f72
- Integration task: TASK-INTEGRATION-6261636b656e642d6d6f6e69746f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-monitor: action-executor → copilot-observability

- Drawn payload/purpose: Execution, denial, partial-completion and uncertain CRM/mail outcome metrics
- Contract task: TASK-CONTRACT-6578656375746f722d6d6f6e69746f72
- Integration task: TASK-INTEGRATION-6578656375746f722d6d6f6e69746f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### executor-mail: action-executor → existing-outbound-mail

- Drawn payload/purpose: Existing mail API: approved recipient/body; stable send key; reconcile submissio
- Contract task: TASK-CONTRACT-6578656375746f722d6d61696c
- Integration task: TASK-INTEGRATION-6578656375746f722d6d61696c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
