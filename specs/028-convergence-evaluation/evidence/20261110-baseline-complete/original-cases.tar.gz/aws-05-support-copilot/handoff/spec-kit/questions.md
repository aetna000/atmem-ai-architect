# Questions and assumptions to resolve

Snapshot be1a503f-a2ef-4825-8eeb-dc9cae607908 · design r3 · generated 2026-11-09T17:05:09.605Z

- [ai-explicit-approval] Confirm REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.
- [ai-no-duplicate-effects] Confirm REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.
- [ai-grounded-support-drafts] Confirm REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.
- [ai-existing-system-boundary] Confirm REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.
- [ai-connector-credential-isolation] Confirm REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
- [acceptance-ai-explicit-approval] Agree a measurable acceptance check for REQ-003: Every outgoing response and account change must require authenticated, authorized staff approval bound to the exact response or action parameters and case revision; missing, rejected or stale approval must prevent execution.
- [acceptance-ai-no-duplicate-effects] Agree a measurable acceptance check for REQ-004: Repeated approvals, concurrent requests, retries and recovery after a lost CRM response must not repeat a send or account change. Preserve a stable action identifier and outcome; block uncertain actions from re-execution until CRM deduplication or reconciliation establishes a safe outcome.
- [acceptance-ai-grounded-support-drafts] Agree a measurable acceptance check for REQ-005: The copilot must use the staff member’s authorized CRM case and approved support knowledge to produce a reviewable draft and proposed actions. Proposed safeguards: show source references, identify insufficient evidence, and keep drafting credentials read-only.
- [acceptance-ai-existing-system-boundary] Agree a measurable acceptance check for REQ-006: Integrate with the existing CRM and outbound mail through their supported APIs using administrator-supplied credentials; exclude recreation, import and infrastructure changes to those systems from the copilot deployment.
- [acceptance-ai-connector-credential-isolation] Agree a measurable acceptance check for REQ-007: Proposed: store connector credentials in Secrets Manager with separately scoped access; drafting may retrieve only read credentials, and only the approved-action executor may retrieve CRM change and outbound mail credentials. Exclude secret values from browser responses, model inputs and logs; validate destination credential scopes before enabling actions.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d636f6e6e6563746f722d63726564656e7469616c2d69736f6c6174696f6e] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6578697374696e672d73797374656d2d626f756e64617279] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6578706c696369742d617070726f76616c] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d737570706f72742d647261667473] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6e6f2d6475706c69636174652d65666665637473] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
