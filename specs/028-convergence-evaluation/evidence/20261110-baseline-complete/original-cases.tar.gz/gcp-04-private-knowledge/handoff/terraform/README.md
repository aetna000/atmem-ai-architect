# Infrastructure implementation required

Requested providers: gcp. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Company sign-in boundary: Implementation needed.
- Assistant and access enforcement: Implementation needed.
- Documents, retrieval and change state: Implementation needed.
- Embeddings and grounded answers: Implementation needed.
- Source synchronization worker: Implementation needed.
- Incremental sync and reconciliation schedule: Implementation needed.
- Source integration secrets: Implementation needed.
- Access decisions and sync evidence: Implementation needed.
- Wire internal-users → assistant-access: implement data flow, access policy and acceptance test.
- Wire assistant-access → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → internal-users: implement data flow, access policy and acceptance test.
- Wire assistant-app → retrieval-store: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → model-runtime: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → retrieval-store: implement data flow, access policy and acceptance test.
- Wire source-sync → model-runtime: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire assistant-app → integration-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → integration-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → audit-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → audit-logs: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
