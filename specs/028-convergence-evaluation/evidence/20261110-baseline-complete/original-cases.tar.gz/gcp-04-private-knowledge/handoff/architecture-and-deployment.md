Snapshot dee17f7c-a843-4a42-b02b-8d1c368281aa · design r3 · generated 2026-11-09T17:44:19.817Z

# Permission-aware knowledge assistant — deployment document

Generated 2026-11-09 17:44 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Google Cloud
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** Ten thousand company documents. Source permissions are authoritative; content and authorization can change independently. Australia for content, indexes and processing; explain service/model residency gaps.
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**Staff access**

- Internal staff (Tools & data, existing) — Existing people using a proposed browser interface. Outside provisioning scope; each request must carry a verified individual identity. No shared end-user identity. User locations and browser delivery boundaries remain unconfirmed; Australian cloud placement does not establish where users access answers.
- Company sign-in boundary (Google Cloud, sketch) — Proposed Identity-Aware Proxy protects the assistant using company sign-in. Existing identity provider and compatible federation path must be established; no identity provider is assumed. Restrict Cloud Run ingress to the intended protected path and validate signed identity assertions server-side. Sign-in alone does not grant document access. Identity-Aware Proxy is not assigned a regional data-residency guarantee by this drawing; authentication, routing and identity/control-plane metadata handling require separate qualification. The protected Cloud Run path and any required ingress infrastructure remain implementation work.

**Answering**

- Assistant and access enforcement (Google Cloud, sketch) — Proposed Cloud Run service owns browser UI, question API, retrieval, source authorization and cited responses. Initial scope proposal is read-only assistance without source edits or autonomous actions. Map verified users to source identities without assuming matching email addresses. Fetch bounded candidates internally, then independently check effective user access, document existence and current content revision through native source APIs before sending passages to Vertex AI. Permission, inherited restriction and group-membership changes can occur without a content revision: an unchanged revision or copied ACL never proves current access. Do not cache positive authorization decisions initially. Buffer the answer and repeat effective-access, existence and revision checks for every supporting document before release; discard and regenerate from remaining eligible evidence or abstain after any invalidation. Exclude affected-source content when its checks fail, while allowing independently authorized healthy-source answers with a coverage warning. Fail closed for unknown identities, unavailable authorization, stale revisions and deleted documents; never substitute connector credentials. No shared answer cache or retained conversation history initially; do not log prompts, passages or answers. Source text cannot grant tool permissions. Sydney runtime is proposed; only qualified Australian model endpoints may receive content. Native APIs may have propagation delays and cannot provide an atomic transaction spanning authorization and answer delivery; document and test this limitation rather than promising instantaneous revocation. Native code, ingress controls and security tests remain required.
- Embeddings and grounded answers (Google Cloud, sketch) — Proposed Vertex AI service provides embedding and generative model APIs. The assistant supplies only currently authorized passages and requests document/version citations; abstain when evidence is insufficient. The synchronization worker embeds newly staged content. Both embedding and generation must have independently qualified Australian processing endpoints and data-handling terms; placing Cloud Run in Sydney does not establish model processing residency. Exact models, model versions, regional availability, quotas, prompt retention, abuse-monitoring handling and endpoint guarantees remain unverified. No global endpoint, cross-region routing or overseas fallback is assumed. If no suitable Australian model configuration meets the requirement, preserve the residency requirement and resolve the model implementation gap before enabling inference. Model output does not enforce permissions.

**Knowledge state**

- Documents, retrieval and change state (Google Cloud, sketch) — Proposed Cloud SQL for PostgreSQL with pgvector stores normalized passages, embeddings, source IDs, content revisions, ACL metadata, tombstones and independent source checkpoints for an initial 10,000-document corpus. Document count alone does not establish bytes, passage count, query load or instance sizing. Keyword/vector candidates carry explicit source/version provenance; copied ACLs only narrow candidates and never replace live authorization. Track authorization freshness separately from content revisions; do not assume vendors expose a complete permission-version token. Atomically activate complete document revisions, make tombstones immediately ineligible and remove superseded text and vectors through tracked cleanup. Separate application read privileges from synchronization writes and restrict network access. Propose regional multi-zone availability in Sydney, subject to service qualification; this does not provide region-wide disaster recovery. Require Australian placement for replicas, backups, recovery logs and temporary exports; backup retention and deletion policy remain unresolved. Restore into quarantine and reconcile content and permissions against sources before enabling retrieval. Extension compatibility, capacity and recovery behavior require validation.

**Existing knowledge**

- Existing SharePoint (Tools & data, existing) — Existing authoritative documents and permissions; outside provisioning scope. Native Microsoft Graph/SharePoint integration must establish change tracking, deletions, inherited permissions, group membership and user-delegated access checks. Permissions and membership can change independently of content revisions; content change tracking alone is insufficient. Connector read access is not evidence of an end user's access. Tenant configuration, API coverage, propagation behavior and effective authorization semantics require qualification. Existing content hosting, API processing locations and delegated-token handling remain unconfirmed; Google Cloud placement does not relocate or establish residency for SharePoint.
- Existing Confluence (Tools & data, existing) — Existing authoritative pages and permissions; outside provisioning scope. Native connector must qualify the actual Confluence edition and APIs for content versions, deletion, space/page restrictions, inherited access and group changes. Restrictions and membership can change without page-version changes. User-context permission checks must reflect actual effective access; broad connector credentials cannot substitute. Vendor compatibility, authorization consistency and propagation behavior remain unverified. Existing hosting, API processing locations and delegated-token handling require residency evidence; the assistant's Australian placement does not establish Confluence residency.

**Knowledge updates**

- Source synchronization worker (Google Cloud, sketch) — Separate proposed Cloud Run Job owns native SharePoint and Confluence connector modules, normalization and incremental indexing for 10,000 documents. Keep independent checkpoints, leases and recovery state per source, and separate content-change progress from permission/membership reconciliation where vendor APIs permit. Do not assume a content delta feed reports every authorization change. Use bounded retries with backoff, idempotent source-ID/revision writes, staged updates, deletion tombstones and periodic full reconciliation. Permission-only changes must invalidate copied access metadata even when text and embeddings are unchanged. Do not advance checkpoints after partial failure or interpret incomplete listings as deletion. Track freshness and quarantine incomplete revisions. Read-only source scopes, connector secrets, API limits and permission coverage require implementation. Extracted text, metadata and embeddings reside in Cloud SQL; no extra document bucket is assumed. Propose Sydney execution with Australian temporary processing and qualified Australian embedding endpoints. Sync frequency does not replace request-time source authorization.
- Incremental sync and reconciliation schedule (Google Cloud, sketch) — Proposed Cloud Scheduler invokes Cloud Run Jobs through an authenticated execution API. Routine schedule is configurable; business freshness targets remain open. Worker leases prevent overlapping runs from corrupting checkpoints. Scheduled retries and reconciliation recover missed content and permission changes; live user authorization remains required independently of synchronization frequency. Propose Sydney scheduling subject to qualification, with identifiers rather than document content in execution payloads. Regional execution does not by itself establish control-plane metadata residency.

**Operations**

- Source integration secrets (Google Cloud, sketch) — Proposed Secret Manager holds necessary source connector credentials and federation configuration, with workload-specific access and rotation. Use workload identities for Google Cloud access instead of exported keys. User-delegated authorization flow must be implemented separately with protected token handling; no credentials or identity identifiers are supplied in the diagram. Propose explicitly restricted Australian secret replication rather than assuming automatic replication meets residency. Exact regional-secret or replication configuration, metadata handling and compatibility require qualification. No persistent end-user token store is assumed.
- Access decisions and sync evidence (Google Cloud, sketch) — Proposed Cloud Logging receives restricted structured events for authorization decisions, source/version references, sync lag, independent permission reconciliation, checkpoints, failures and correlation IDs. Exclude document text, prompts, answers and authentication tokens; identifiers themselves remain sensitive. Restrict log readers and propose explicitly located Australian log buckets. Verify application logs, platform audit logs, default sinks, diagnostic exports and metadata handling individually; an Australian runtime does not establish log residency. Retention, alert routing and operational ownership remain open. Logs support investigation and do not prove correct permission enforcement.

```mermaid
flowchart LR
  n0["Internal staff<br/>Tools & data"]
  n1["Company sign-in boundary<br/>Google Cloud"]
  n2["Assistant and access enforcement<br/>Google Cloud"]
  n3["Documents, retrieval and change state<br/>Google Cloud"]
  n4["Embeddings and grounded answers<br/>Google Cloud"]
  n5["Existing SharePoint<br/>Tools & data"]
  n6["Existing Confluence<br/>Tools & data"]
  n7["Source synchronization worker<br/>Google Cloud"]
  n8["Incremental sync and reconciliation schedule<br/>Google Cloud"]
  n9["Source integration secrets<br/>Google Cloud"]
  n10["Access decisions and sync evidence<br/>Google Cloud"]
  n0 -->|HTTPS browser session; company sign-in| n1
  n1 -->|Protected HTTPS; verified individual identity| n2
  n2 -->|Protected session: buffered cited answer after final checks, or safe abstention| n0
  n2 -->|Private PostgreSQL/TLS: bounded candidates, provenance and revision checks| n3
  n2 -->|Native HTTPS: effective user access, existence and revision before model use and| n5
  n2 -->|Native HTTPS: effective user access, existence and revision before model use and| n6
  n2 -->|IAM-authenticated Australian endpoints required: query embedding and authorized-| n4
  n7 -->|Read-only native API: content changes plus independent permission/group reconcil| n5
  n7 -->|Read-only native API: versions, restrictions, group changes, deletions and recon| n6
  n7 -->|Transactional revisions, permission metadata, tombstones and independent checkpo| n3
  n7 -->|IAM-authenticated Australian embedding endpoint required for staged document rev| n4
  n8 -->|Authenticated Cloud Run Jobs execution API; incremental and full reconciliation| n7
  n2 -->|Workload identity: read only required integration secrets| n9
  n7 -->|Workload identity: read only connector-specific secrets| n9
  n2 -->|Redacted access decisions and provenance to explicitly located Australian log st| n10
  n7 -->|Content/permission freshness, retries, reconciliation and failure events; no doc| n10
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| internal-users | Internal staff | tools | Approval workflow | Existing user locations | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| assistant-access | Company sign-in boundary | gcp | Identity-Aware Proxy | Identity/control-plane residency unresolved | Proposed | Implementation needed |
| assistant-app | Assistant and access enforcement | gcp | Google Cloud Run | australia-southeast1 (proposed) | Proposed | Implementation needed |
| retrieval-store | Documents, retrieval and change state | gcp | Cloud SQL for PostgreSQL | australia-southeast1 (proposed) | Proposed | Implementation needed |
| model-runtime | Embeddings and grounded answers | gcp | Vertex AI | Australia required; model endpoints unverified | Proposed | Implementation needed |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| source-sync | Source synchronization worker | gcp | Google Cloud Run | australia-southeast1 (proposed) | Proposed | Implementation needed |
| sync-schedule | Incremental sync and reconciliation schedule | gcp | Cloud Scheduler | australia-southeast1 (proposed) | Proposed | Implementation needed |
| integration-secrets | Source integration secrets | gcp | Secret Manager | Australia-only replication proposed; unverified | Proposed | Implementation needed |
| audit-logs | Access decisions and sync evidence | gcp | Cloud Logging | Australian log location proposed; unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Internal staff** (internal-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app.
- **Company sign-in boundary** (assistant-access): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: internal-users.
- **Assistant and access enforcement** (assistant-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-access.
- **Documents, retrieval and change state** (retrieval-store): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Embeddings and grounded answers** (model-runtime): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Source synchronization worker** (source-sync): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: sync-schedule.
- **Incremental sync and reconciliation schedule** (sync-schedule): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Source integration secrets** (integration-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Access decisions and sync evidence** (audit-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.

### Engineering work remaining

- Company sign-in boundary: Implementation needed.
- Assistant and access enforcement: Implementation needed.
- Documents, retrieval and change state: Implementation needed.
- Embeddings and grounded answers: Implementation needed.
- Source synchronization worker: Implementation needed.
- Incremental sync and reconciliation schedule: Implementation needed.
- Source integration secrets: Implementation needed.
- Access decisions and sync evidence: Implementation needed.
- Wire internal-users → assistant-access: implement data flow, access policy and acceptance test.
- Wire assistant-access → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → internal-users: implement data flow, access policy and acceptance test.
- Wire assistant-app → retrieval-store: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → model-runtime: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → retrieval-store: implement data flow, access policy and acceptance test.
- Wire source-sync → model-runtime: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire assistant-app → integration-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → integration-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → audit-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → audit-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Internal staff | Company sign-in boundary | HTTPS browser session; company sign-in | Internal |
| Company sign-in boundary | Assistant and access enforcement | Protected HTTPS; verified individual identity | Confidential |
| Assistant and access enforcement | Internal staff | Protected session: buffered cited answer after final checks, or safe abstention | Confidential |
| Assistant and access enforcement | Documents, retrieval and change state | Private PostgreSQL/TLS: bounded candidates, provenance and revision checks | Confidential |
| Assistant and access enforcement | Existing SharePoint | Native HTTPS: effective user access, existence and revision before model use and | Confidential |
| Assistant and access enforcement | Existing Confluence | Native HTTPS: effective user access, existence and revision before model use and | Confidential |
| Assistant and access enforcement | Embeddings and grounded answers | IAM-authenticated Australian endpoints required: query embedding and authorized- | Confidential |
| Source synchronization worker | Existing SharePoint | Read-only native API: content changes plus independent permission/group reconcil | Confidential |
| Source synchronization worker | Existing Confluence | Read-only native API: versions, restrictions, group changes, deletions and recon | Confidential |
| Source synchronization worker | Documents, retrieval and change state | Transactional revisions, permission metadata, tombstones and independent checkpo | Confidential |
| Source synchronization worker | Embeddings and grounded answers | IAM-authenticated Australian embedding endpoint required for staged document rev | Confidential |
| Incremental sync and reconciliation schedule | Source synchronization worker | Authenticated Cloud Run Jobs execution API; incremental and full reconciliation | Confidential |
| Assistant and access enforcement | Source integration secrets | Workload identity: read only required integration secrets | Confidential |
| Source synchronization worker | Source integration secrets | Workload identity: read only connector-specific secrets | Confidential |
| Assistant and access enforcement | Access decisions and sync evidence | Redacted access decisions and provenance to explicitly located Australian log st | Confidential |
| Source synchronization worker | Access decisions and sync evidence | Content/permission freshness, retries, reconciliation and failure events; no doc | Confidential |

## 5. Security controls

- **Internal staff** — Existing people using a proposed browser interface. Outside provisioning scope; each request must carry a verified individual identity. No shared end-user identity. User locations and browser delivery boundaries remain unconfirmed; Australian cloud placement does not establish where users access answers.
- **Company sign-in boundary** — Proposed Identity-Aware Proxy protects the assistant using company sign-in. Existing identity provider and compatible federation path must be established; no identity provider is assumed. Restrict Cloud Run ingress to the intended protected path and validate signed identity assertions server-side. Sign-in alone does not grant document access. Identity-Aware Proxy is not assigned a regional data-residency guarantee by this drawing; authentication, routing and identity/control-plane metadata handling require separate qualification. The protected Cloud Run path and any required ingress infrastructure remain implementation work.
- **Source integration secrets** — Proposed Secret Manager holds necessary source connector credentials and federation configuration, with workload-specific access and rotation. Use workload identities for Google Cloud access instead of exported keys. User-delegated authorization flow must be implemented separately with protected token handling; no credentials or identity identifiers are supplied in the diagram. Propose explicitly restricted Australian secret replication rather than assuming automatic replication meets residency. Exact regional-secret or replication configuration, metadata handling and compatibility require qualification. No persistent end-user token store is assumed.
- Requirement: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access. (must)
- Requirement: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure. (must)
- Requirement: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure. | security | not measurable yet | Open |
| Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access. (must, open)
- Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open. (must, open)
- The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.”, “Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 8 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Company sign-in boundary | Checked requests | needs requests_per_month | price needed | — | — |
| Documents, retrieval and change state | Index storage | needs data_gb | price needed | — | — |
| Embeddings and grounded answers | Endpoint hours | 730 hours | price needed | — | — |
| Existing SharePoint | Storage | needs data_gb | price needed | — | — |
| Existing Confluence | Storage | needs data_gb | price needed | — | — |
| Source synchronization worker | Data processed | needs data_gb | price needed | — | — |
| Incremental sync and reconciliation schedule | Data processed | needs data_gb | price needed | — | — |
| Source integration secrets | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Internal staff, Assistant and access enforcement, Access decisions and sync evidence.

**Estimate gaps:**

- Company sign-in boundary / Checked requests: input needed (requests_per_month).
- Documents, retrieval and change state / Index storage: input needed (data_gb).
- Embeddings and grounded answers / Endpoint hours: price needed.
- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Source synchronization worker / Data processed: input needed (data_gb).
- Incremental sync and reconciliation schedule / Data processed: input needed (data_gb).
- Source integration secrets / Checked requests: input needed (requests_per_month).
- Internal staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Assistant and access enforcement: no cost lines; add charges or an explicit zero-cost line with a reason.
- Access decisions and sync evidence: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff access: Company sign-in boundary.
4. Provision answering: Assistant and access enforcement, Embeddings and grounded answers.
5. Provision knowledge state: Documents, retrieval and change state.
6. Provision knowledge updates: Source synchronization worker, Incremental sync and reconciliation schedule.
7. Provision operations: Source integration secrets, Access decisions and sync evidence.
8. Connect existing systems: Internal staff, Existing SharePoint, Existing Confluence; test failure behaviour.
9. Run the acceptance checks (success measures and requirements) in staging; record results.
10. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing; explain service/model residency gaps.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Company sign-in boundary: needs requests_per_month _(estimate)_
- Documents, retrieval and change state: needs data_gb _(estimate)_
- Embeddings and grounded answers: needs a unit price with a source _(estimate)_
- Existing SharePoint: needs data_gb _(estimate)_
- Existing Confluence: needs data_gb _(estimate)_
- Source synchronization worker: needs data_gb _(estimate)_
- Incremental sync and reconciliation schedule: needs data_gb _(estimate)_
- Source integration secrets: needs requests_per_month _(estimate)_
