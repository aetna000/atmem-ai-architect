# Delivery handoff

Snapshot dee17f7c-a843-4a42-b02b-8d1c368281aa · design r3 · generated 2026-11-09T17:44:19.817Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Company sign-in boundary / Checked requests: input needed (requests_per_month).
- Documents, retrieval and change state / Index storage: input needed (data_gb).
- Embeddings and grounded answers / Endpoint hours: price needed.
- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Source synchronization worker / Data processed: input needed (data_gb).
- Incremental sync and reconciliation schedule / Data processed: input needed (data_gb).
- Source integration secrets / Checked requests: input needed (requests_per_month).
- Internal staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Assistant and access enforcement: no cost lines; add charges or an explicit zero-cost line with a reason.
- Access decisions and sync evidence: no cost lines; add charges or an explicit zero-cost line with a reason.
- Company sign-in boundary: Implementation needed.
- Assistant and access enforcement: Implementation needed.
- Documents, retrieval and change state: Implementation needed.
- Embeddings and grounded answers: Implementation needed.
- Source synchronization worker: Implementation needed.
- Incremental sync and reconciliation schedule: Implementation needed.
- Source integration secrets: Implementation needed.
- Access decisions and sync evidence: Implementation needed.
- Wire internal-users → assistant-access: implement data flow, access policy and acceptance test.
- Wire assistant-access → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → internal-users: implement data flow, access policy and acceptance test.
- Wire assistant-app → retrieval-store: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → model-runtime: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → retrieval-store: implement data flow, access policy and acceptance test.
- Wire source-sync → model-runtime: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire assistant-app → integration-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → integration-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → audit-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → audit-logs: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
