Snapshot dee17f7c-a843-4a42-b02b-8d1c368281aa · design r3 · generated 2026-11-09T17:44:19.817Z

# Permission-aware knowledge assistant — solution specification

## Problem and intended outcome

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access. (must, open); target: acceptance target needed; linked blocks: internal-users, assistant-access, assistant-app, sharepoint, confluence, model-runtime

Design explanation: Copied permissions can become stale; enforcing source-backed authorization before model use and response release reduces disclosure risk. Native API behavior and concurrent revocation races require explicit testing.

Basis: User: “People should get cited answers only from documents they can access.”
- [REQ-005] Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open. (must, open); target: acceptance target needed; linked blocks: source-sync, sync-schedule, retrieval-store, assistant-app, sharepoint, confluence

Design explanation: Out-of-order updates, missed deletions and restored indexes can expose obsolete content. Proposed revision gating and reconciliation keep incomplete or stale copies out of answers while synchronization recovers.

Basis: User: “Permission revocation, edits and deletion must propagate.”
- [REQ-006] When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure. (must, open); target: acceptance target needed; linked blocks: assistant-app, source-sync, retrieval-store, sharepoint, confluence, audit-logs

Design explanation: A last successful crawl does not prove current access during an outage. Proposed source isolation lets healthy sources remain useful without treating stale authorization as permission.

Basis: User: “An outage in one source should not leak stale restricted content.”
- [REQ-007] Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval. (must, open); target: acceptance target needed; linked blocks: assistant-app, retrieval-store, model-runtime, source-sync, audit-logs, sharepoint, confluence, assistant-access, integration-secrets

Design explanation: Australian application hosting alone cannot guarantee Australian model processing or storage of derived data; endpoint, backup and logging defaults could cross the required boundary.

Basis: “Australia for content, indexes and processing; explain service/model residency gaps.” Relevant components include assistant-app, retrieval-store, model-runtime and source-sync.
- [REQ-008] The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection. (must, open); target: acceptance target needed; linked blocks: source-sync, retrieval-store, assistant-app

Design explanation: The stated corpus rules out a small demonstration collection; bounded retrieval and resumable indexing must work across the full corpus without assuming document count determines storage or traffic.

Basis: “Ten thousand company documents.” The retrieval-store and source-sync components own indexing and recovery.

## How the system works

The current design contains 11 components and 16 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Internal staff → Company sign-in boundary

HTTPS browser session; company sign-in

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Company sign-in boundary → Assistant and access enforcement

Protected HTTPS; verified individual identity

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Assistant and access enforcement → Internal staff

Protected session: buffered cited answer after final checks, or safe abstention

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Assistant and access enforcement → Documents, retrieval and change state

Private PostgreSQL/TLS: bounded candidates, provenance and revision checks

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Assistant and access enforcement → Existing SharePoint

Native HTTPS: effective user access, existence and revision before model use and

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Assistant and access enforcement → Existing Confluence

Native HTTPS: effective user access, existence and revision before model use and

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Assistant and access enforcement → Embeddings and grounded answers

IAM-authenticated Australian endpoints required: query embedding and authorized-

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Source synchronization worker → Existing SharePoint

Read-only native API: content changes plus independent permission/group reconcil

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Source synchronization worker → Existing Confluence

Read-only native API: versions, restrictions, group changes, deletions and recon

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Source synchronization worker → Documents, retrieval and change state

Transactional revisions, permission metadata, tombstones and independent checkpo

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Source synchronization worker → Embeddings and grounded answers

IAM-authenticated Australian embedding endpoint required for staged document rev

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Incremental sync and reconciliation schedule → Source synchronization worker

Authenticated Cloud Run Jobs execution API; incremental and full reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Assistant and access enforcement → Source integration secrets

Workload identity: read only required integration secrets

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Source synchronization worker → Source integration secrets

Workload identity: read only connector-specific secrets

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 15: Assistant and access enforcement → Access decisions and sync evidence

Redacted access decisions and provenance to explicitly located Australian log st

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 16: Source synchronization worker → Access decisions and sync evidence

Content/permission freshness, retries, reconciliation and failure events; no doc

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Internal staff

Approval workflow · tools · region: Existing user locations · classification: Internal

Existing people using a proposed browser interface. Outside provisioning scope; each request must carry a verified individual identity. No shared end-user identity. User locations and browser delivery boundaries remain unconfirmed; Australian cloud placement does not establish where users access answers.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Assistant and access enforcement → Internal staff: Protected session: buffered cited answer after final checks, or safe abstention

Outputs: Internal staff → Company sign-in boundary: HTTPS browser session; company sign-in

Requirement traceability: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Company sign-in boundary

Identity-Aware Proxy · gcp · region: Identity/control-plane residency unresolved · classification: Internal

Proposed Identity-Aware Proxy protects the assistant using company sign-in. Existing identity provider and compatible federation path must be established; no identity provider is assumed. Restrict Cloud Run ingress to the intended protected path and validate signed identity assertions server-side. Sign-in alone does not grant document access. Identity-Aware Proxy is not assigned a regional data-residency guarantee by this drawing; authentication, routing and identity/control-plane metadata handling require separate qualification. The protected Cloud Run path and any required ingress infrastructure remain implementation work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Internal staff → Company sign-in boundary: HTTPS browser session; company sign-in

Outputs: Company sign-in boundary → Assistant and access enforcement: Protected HTTPS; verified individual identity

Requirement traceability: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Assistant and access enforcement

Google Cloud Run · gcp · region: australia-southeast1 (proposed) · classification: Confidential

Proposed Cloud Run service owns browser UI, question API, retrieval, source authorization and cited responses. Initial scope proposal is read-only assistance without source edits or autonomous actions. Map verified users to source identities without assuming matching email addresses. Fetch bounded candidates internally, then independently check effective user access, document existence and current content revision through native source APIs before sending passages to Vertex AI. Permission, inherited restriction and group-membership changes can occur without a content revision: an unchanged revision or copied ACL never proves current access. Do not cache positive authorization decisions initially. Buffer the answer and repeat effective-access, existence and revision checks for every supporting document before release; discard and regenerate from remaining eligible evidence or abstain after any invalidation. Exclude affected-source content when its checks fail, while allowing independently authorized healthy-source answers with a coverage warning. Fail closed for unknown identities, unavailable authorization, stale revisions and deleted documents; never substitute connector credentials. No shared answer cache or retained conversation history initially; do not log prompts, passages or answers. Source text cannot grant tool permissions. Sydney runtime is proposed; only qualified Australian model endpoints may receive content. Native APIs may have propagation delays and cannot provide an atomic transaction spanning authorization and answer delivery; document and test this limitation rather than promising instantaneous revocation. Native code, ingress controls and security tests remain required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Company sign-in boundary → Assistant and access enforcement: Protected HTTPS; verified individual identity

Outputs: Assistant and access enforcement → Internal staff: Protected session: buffered cited answer after final checks, or safe abstention; Assistant and access enforcement → Documents, retrieval and change state: Private PostgreSQL/TLS: bounded candidates, provenance and revision checks; Assistant and access enforcement → Existing SharePoint: Native HTTPS: effective user access, existence and revision before model use and; Assistant and access enforcement → Existing Confluence: Native HTTPS: effective user access, existence and revision before model use and; Assistant and access enforcement → Embeddings and grounded answers: IAM-authenticated Australian endpoints required: query embedding and authorized-; Assistant and access enforcement → Source integration secrets: Workload identity: read only required integration secrets; Assistant and access enforcement → Access decisions and sync evidence: Redacted access decisions and provenance to explicitly located Australian log st

Requirement traceability: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.; REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Documents, retrieval and change state

Cloud SQL for PostgreSQL · gcp · region: australia-southeast1 (proposed) · classification: Confidential

Proposed Cloud SQL for PostgreSQL with pgvector stores normalized passages, embeddings, source IDs, content revisions, ACL metadata, tombstones and independent source checkpoints for an initial 10,000-document corpus. Document count alone does not establish bytes, passage count, query load or instance sizing. Keyword/vector candidates carry explicit source/version provenance; copied ACLs only narrow candidates and never replace live authorization. Track authorization freshness separately from content revisions; do not assume vendors expose a complete permission-version token. Atomically activate complete document revisions, make tombstones immediately ineligible and remove superseded text and vectors through tracked cleanup. Separate application read privileges from synchronization writes and restrict network access. Propose regional multi-zone availability in Sydney, subject to service qualification; this does not provide region-wide disaster recovery. Require Australian placement for replicas, backups, recovery logs and temporary exports; backup retention and deletion policy remain unresolved. Restore into quarantine and reconcile content and permissions against sources before enabling retrieval. Extension compatibility, capacity and recovery behavior require validation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Assistant and access enforcement → Documents, retrieval and change state: Private PostgreSQL/TLS: bounded candidates, provenance and revision checks; Source synchronization worker → Documents, retrieval and change state: Transactional revisions, permission metadata, tombstones and independent checkpo

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.; REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Embeddings and grounded answers

Vertex AI · gcp · region: Australia required; model endpoints unverified · classification: Confidential

Proposed Vertex AI service provides embedding and generative model APIs. The assistant supplies only currently authorized passages and requests document/version citations; abstain when evidence is insufficient. The synchronization worker embeds newly staged content. Both embedding and generation must have independently qualified Australian processing endpoints and data-handling terms; placing Cloud Run in Sydney does not establish model processing residency. Exact models, model versions, regional availability, quotas, prompt retention, abuse-monitoring handling and endpoint guarantees remain unverified. No global endpoint, cross-region routing or overseas fallback is assumed. If no suitable Australian model configuration meets the requirement, preserve the residency requirement and resolve the model implementation gap before enabling inference. Model output does not enforce permissions.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Assistant and access enforcement → Embeddings and grounded answers: IAM-authenticated Australian endpoints required: query embedding and authorized-; Source synchronization worker → Embeddings and grounded answers: IAM-authenticated Australian embedding endpoint required for staged document rev

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing SharePoint

Microsoft SharePoint · tools · region: Existing source location; unconfirmed · classification: Confidential

Existing authoritative documents and permissions; outside provisioning scope. Native Microsoft Graph/SharePoint integration must establish change tracking, deletions, inherited permissions, group membership and user-delegated access checks. Permissions and membership can change independently of content revisions; content change tracking alone is insufficient. Connector read access is not evidence of an end user's access. Tenant configuration, API coverage, propagation behavior and effective authorization semantics require qualification. Existing content hosting, API processing locations and delegated-token handling remain unconfirmed; Google Cloud placement does not relocate or establish residency for SharePoint.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Assistant and access enforcement → Existing SharePoint: Native HTTPS: effective user access, existence and revision before model use and; Source synchronization worker → Existing SharePoint: Read-only native API: content changes plus independent permission/group reconcil

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Existing Confluence

Atlassian Confluence · tools · region: Existing source location; unconfirmed · classification: Confidential

Existing authoritative pages and permissions; outside provisioning scope. Native connector must qualify the actual Confluence edition and APIs for content versions, deletion, space/page restrictions, inherited access and group changes. Restrictions and membership can change without page-version changes. User-context permission checks must reflect actual effective access; broad connector credentials cannot substitute. Vendor compatibility, authorization consistency and propagation behavior remain unverified. Existing hosting, API processing locations and delegated-token handling require residency evidence; the assistant's Australian placement does not establish Confluence residency.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Assistant and access enforcement → Existing Confluence: Native HTTPS: effective user access, existence and revision before model use and; Source synchronization worker → Existing Confluence: Read-only native API: versions, restrictions, group changes, deletions and recon

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Source synchronization worker

Google Cloud Run · gcp · region: australia-southeast1 (proposed) · classification: Confidential

Separate proposed Cloud Run Job owns native SharePoint and Confluence connector modules, normalization and incremental indexing for 10,000 documents. Keep independent checkpoints, leases and recovery state per source, and separate content-change progress from permission/membership reconciliation where vendor APIs permit. Do not assume a content delta feed reports every authorization change. Use bounded retries with backoff, idempotent source-ID/revision writes, staged updates, deletion tombstones and periodic full reconciliation. Permission-only changes must invalidate copied access metadata even when text and embeddings are unchanged. Do not advance checkpoints after partial failure or interpret incomplete listings as deletion. Track freshness and quarantine incomplete revisions. Read-only source scopes, connector secrets, API limits and permission coverage require implementation. Extracted text, metadata and embeddings reside in Cloud SQL; no extra document bucket is assumed. Propose Sydney execution with Australian temporary processing and qualified Australian embedding endpoints. Sync frequency does not replace request-time source authorization.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Incremental sync and reconciliation schedule → Source synchronization worker: Authenticated Cloud Run Jobs execution API; incremental and full reconciliation

Outputs: Source synchronization worker → Existing SharePoint: Read-only native API: content changes plus independent permission/group reconcil; Source synchronization worker → Existing Confluence: Read-only native API: versions, restrictions, group changes, deletions and recon; Source synchronization worker → Documents, retrieval and change state: Transactional revisions, permission metadata, tombstones and independent checkpo; Source synchronization worker → Embeddings and grounded answers: IAM-authenticated Australian embedding endpoint required for staged document rev; Source synchronization worker → Source integration secrets: Workload identity: read only connector-specific secrets; Source synchronization worker → Access decisions and sync evidence: Content/permission freshness, retries, reconciliation and failure events; no doc

Requirement traceability: REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.; REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Incremental sync and reconciliation schedule

Cloud Scheduler · gcp · region: australia-southeast1 (proposed) · classification: Internal

Proposed Cloud Scheduler invokes Cloud Run Jobs through an authenticated execution API. Routine schedule is configurable; business freshness targets remain open. Worker leases prevent overlapping runs from corrupting checkpoints. Scheduled retries and reconciliation recover missed content and permission changes; live user authorization remains required independently of synchronization frequency. Propose Sydney scheduling subject to qualification, with identifiers rather than document content in execution payloads. Regional execution does not by itself establish control-plane metadata residency.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Incremental sync and reconciliation schedule → Source synchronization worker: Authenticated Cloud Run Jobs execution API; incremental and full reconciliation

Requirement traceability: REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Source integration secrets

Secret Manager · gcp · region: Australia-only replication proposed; unverified · classification: Confidential

Proposed Secret Manager holds necessary source connector credentials and federation configuration, with workload-specific access and rotation. Use workload identities for Google Cloud access instead of exported keys. User-delegated authorization flow must be implemented separately with protected token handling; no credentials or identity identifiers are supplied in the diagram. Propose explicitly restricted Australian secret replication rather than assuming automatic replication meets residency. Exact regional-secret or replication configuration, metadata handling and compatibility require qualification. No persistent end-user token store is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Assistant and access enforcement → Source integration secrets: Workload identity: read only required integration secrets; Source synchronization worker → Source integration secrets: Workload identity: read only connector-specific secrets

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Access decisions and sync evidence

Cloud Logging · gcp · region: Australian log location proposed; unverified · classification: Confidential

Proposed Cloud Logging receives restricted structured events for authorization decisions, source/version references, sync lag, independent permission reconciliation, checkpoints, failures and correlation IDs. Exclude document text, prompts, answers and authentication tokens; identifiers themselves remain sensitive. Restrict log readers and propose explicitly located Australian log buckets. Verify application logs, platform audit logs, default sinks, diagnostic exports and metadata handling individually; an Australian runtime does not establish log residency. Retention, alert routing and operational ownership remain open. Logs support investigation and do not prove correct permission enforcement.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Assistant and access enforcement → Access decisions and sync evidence: Redacted access decisions and provenance to explicitly located Australian log st; Source synchronization worker → Access decisions and sync evidence: Content/permission freshness, retries, reconciliation and failure events; no doc

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Internal staff<br/>Tools & data"]
  n1["Company sign-in boundary<br/>Google Cloud"]
  n2["Assistant and access enforcement<br/>Google Cloud"]
  n3["Documents, retrieval and change state<br/>Google Cloud"]
  n4["Embeddings and grounded answers<br/>Google Cloud"]
  n5["Existing SharePoint<br/>Tools & data"]
  n6["Existing Confluence<br/>Tools & data"]
  n7["Source synchronization worker<br/>Google Cloud"]
  n8["Incremental sync and reconciliation schedule<br/>Google Cloud"]
  n9["Source integration secrets<br/>Google Cloud"]
  n10["Access decisions and sync evidence<br/>Google Cloud"]
  n0 -->|HTTPS browser session; company sign-in| n1
  n1 -->|Protected HTTPS; verified individual identity| n2
  n2 -->|Protected session: buffered cited answer after final checks, or safe abstention| n0
  n2 -->|Private PostgreSQL/TLS: bounded candidates, provenance and revision checks| n3
  n2 -->|Native HTTPS: effective user access, existence and revision before model use and| n5
  n2 -->|Native HTTPS: effective user access, existence and revision before model use and| n6
  n2 -->|IAM-authenticated Australian endpoints required: query embedding and authorized-| n4
  n7 -->|Read-only native API: content changes plus independent permission/group reconcil| n5
  n7 -->|Read-only native API: versions, restrictions, group changes, deletions and recon| n6
  n7 -->|Transactional revisions, permission metadata, tombstones and independent checkpo| n3
  n7 -->|IAM-authenticated Australian embedding endpoint required for staged document rev| n4
  n8 -->|Authenticated Cloud Run Jobs execution API; incremental and full reconciliation| n7
  n2 -->|Workload identity: read only required integration secrets| n9
  n7 -->|Workload identity: read only connector-specific secrets| n9
  n2 -->|Redacted access decisions and provenance to explicitly located Australian log st| n10
  n7 -->|Content/permission freshness, retries, reconciliation and failure events; no doc| n10
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| internal-users | Internal staff | tools | Approval workflow | Existing user locations | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| assistant-access | Company sign-in boundary | gcp | Identity-Aware Proxy | Identity/control-plane residency unresolved | Proposed | Implementation needed |
| assistant-app | Assistant and access enforcement | gcp | Google Cloud Run | australia-southeast1 (proposed) | Proposed | Implementation needed |
| retrieval-store | Documents, retrieval and change state | gcp | Cloud SQL for PostgreSQL | australia-southeast1 (proposed) | Proposed | Implementation needed |
| model-runtime | Embeddings and grounded answers | gcp | Vertex AI | Australia required; model endpoints unverified | Proposed | Implementation needed |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| source-sync | Source synchronization worker | gcp | Google Cloud Run | australia-southeast1 (proposed) | Proposed | Implementation needed |
| sync-schedule | Incremental sync and reconciliation schedule | gcp | Cloud Scheduler | australia-southeast1 (proposed) | Proposed | Implementation needed |
| integration-secrets | Source integration secrets | gcp | Secret Manager | Australia-only replication proposed; unverified | Proposed | Implementation needed |
| audit-logs | Access decisions and sync evidence | gcp | Cloud Logging | Australian log location proposed; unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Internal staff** (internal-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app.
- **Company sign-in boundary** (assistant-access): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: internal-users.
- **Assistant and access enforcement** (assistant-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-access.
- **Documents, retrieval and change state** (retrieval-store): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Embeddings and grounded answers** (model-runtime): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Source synchronization worker** (source-sync): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: sync-schedule.
- **Incremental sync and reconciliation schedule** (sync-schedule): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Source integration secrets** (integration-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Access decisions and sync evidence** (audit-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.

### Engineering work remaining

- Company sign-in boundary: Implementation needed.
- Assistant and access enforcement: Implementation needed.
- Documents, retrieval and change state: Implementation needed.
- Embeddings and grounded answers: Implementation needed.
- Source synchronization worker: Implementation needed.
- Incremental sync and reconciliation schedule: Implementation needed.
- Source integration secrets: Implementation needed.
- Access decisions and sync evidence: Implementation needed.
- Wire internal-users → assistant-access: implement data flow, access policy and acceptance test.
- Wire assistant-access → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → internal-users: implement data flow, access policy and acceptance test.
- Wire assistant-app → retrieval-store: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → model-runtime: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → retrieval-store: implement data flow, access policy and acceptance test.
- Wire source-sync → model-runtime: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire assistant-app → integration-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → integration-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → audit-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → audit-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing; explain service/model residency gaps.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
