# Implementation Spec Kit

Snapshot dee17f7c-a843-4a42-b02b-8d1c368281aa · design r3 · generated 2026-11-09T17:44:19.817Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

7 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: gcp
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Internal staff (internal-users): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing user locations.
- Company sign-in boundary (assistant-access): Implementation needed; gcp, Identity/control-plane residency unresolved.
- Assistant and access enforcement (assistant-app): Implementation needed; gcp, australia-southeast1 (proposed).
- Documents, retrieval and change state (retrieval-store): Implementation needed; gcp, australia-southeast1 (proposed).
- Embeddings and grounded answers (model-runtime): Implementation needed; gcp, Australia required; model endpoints unverified.
- Existing SharePoint (sharepoint): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing source location; unconfirmed.
- Existing Confluence (confluence): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing source location; unconfirmed.
- Source synchronization worker (source-sync): Implementation needed; gcp, australia-southeast1 (proposed).
- Incremental sync and reconciliation schedule (sync-schedule): Implementation needed; gcp, australia-southeast1 (proposed).
- Source integration secrets (integration-secrets): Implementation needed; gcp, Australia-only replication proposed; unverified.
- Access decisions and sync evidence (audit-logs): Implementation needed; gcp, Australian log location proposed; unverified.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
