# Component and interface contracts

Snapshot dee17f7c-a843-4a42-b02b-8d1c368281aa · design r3 · generated 2026-11-09T17:44:19.817Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component internal-users: Internal staff

- Responsibility: Existing people using a proposed browser interface. Outside provisioning scope; each request must carry a verified individual identity. No shared end-user identity. User locations and browser delivery boundaries remain unconfirmed; Australian cloud placement does not establish where users access answers.
- Service: Approval workflow
- Provider / placement: tools / Existing user locations
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e7465726e616c2d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component assistant-access: Company sign-in boundary

- Responsibility: Proposed Identity-Aware Proxy protects the assistant using company sign-in. Existing identity provider and compatible federation path must be established; no identity provider is assumed. Restrict Cloud Run ingress to the intended protected path and validate signed identity assertions server-side. Sign-in alone does not grant document access. Identity-Aware Proxy is not assigned a regional data-residency guarantee by this drawing; authentication, routing and identity/control-plane metadata handling require separate qualification. The protected Cloud Run path and any required ingress infrastructure remain implementation work.
- Service: Identity-Aware Proxy
- Provider / placement: gcp / Identity/control-plane residency unresolved
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d616363657373
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component assistant-app: Assistant and access enforcement

- Responsibility: Proposed Cloud Run service owns browser UI, question API, retrieval, source authorization and cited responses. Initial scope proposal is read-only assistance without source edits or autonomous actions. Map verified users to source identities without assuming matching email addresses. Fetch bounded candidates internally, then independently check effective user access, document existence and current content revision through native source APIs before sending passages to Vertex AI. Permission, inherited restriction and group-membership changes can occur without a content revision: an unchanged revision or copied ACL never proves current access. Do not cache positive authorization decisions initially. Buffer the answer and repeat effective-access, existence and revision checks for every supporting document before release; discard and regenerate from remaining eligible evidence or abstain after any invalidation. Exclude affected-source content when its checks fail, while allowing independently authorized healthy-source answers with a coverage warning. Fail closed for unknown identities, unavailable authorization, stale revisions and deleted documents; never substitute connector credentials. No shared answer cache or retained conversation history initially; do not log prompts, passages or answers. Source text cannot grant tool permissions. Sydney runtime is proposed; only qualified Australian model endpoints may receive content. Native APIs may have propagation delays and cannot provide an atomic transaction spanning authorization and answer delivery; document and test this limitation rather than promising instantaneous revocation. Native code, ingress controls and security tests remain required.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component retrieval-store: Documents, retrieval and change state

- Responsibility: Proposed Cloud SQL for PostgreSQL with pgvector stores normalized passages, embeddings, source IDs, content revisions, ACL metadata, tombstones and independent source checkpoints for an initial 10,000-document corpus. Document count alone does not establish bytes, passage count, query load or instance sizing. Keyword/vector candidates carry explicit source/version provenance; copied ACLs only narrow candidates and never replace live authorization. Track authorization freshness separately from content revisions; do not assume vendors expose a complete permission-version token. Atomically activate complete document revisions, make tombstones immediately ineligible and remove superseded text and vectors through tracked cleanup. Separate application read privileges from synchronization writes and restrict network access. Propose regional multi-zone availability in Sydney, subject to service qualification; this does not provide region-wide disaster recovery. Require Australian placement for replicas, backups, recovery logs and temporary exports; backup retention and deletion policy remain unresolved. Restore into quarantine and reconcile content and permissions against sources before enabling retrieval. Extension compatibility, capacity and recovery behavior require validation.
- Service: Cloud SQL for PostgreSQL
- Provider / placement: gcp / australia-southeast1 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-72657472696576616c2d73746f7265
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component model-runtime: Embeddings and grounded answers

- Responsibility: Proposed Vertex AI service provides embedding and generative model APIs. The assistant supplies only currently authorized passages and requests document/version citations; abstain when evidence is insufficient. The synchronization worker embeds newly staged content. Both embedding and generation must have independently qualified Australian processing endpoints and data-handling terms; placing Cloud Run in Sydney does not establish model processing residency. Exact models, model versions, regional availability, quotas, prompt retention, abuse-monitoring handling and endpoint guarantees remain unverified. No global endpoint, cross-region routing or overseas fallback is assumed. If no suitable Australian model configuration meets the requirement, preserve the residency requirement and resolve the model implementation gap before enabling inference. Model output does not enforce permissions.
- Service: Vertex AI
- Provider / placement: gcp / Australia required; model endpoints unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6d6f64656c2d72756e74696d65
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component sharepoint: Existing SharePoint

- Responsibility: Existing authoritative documents and permissions; outside provisioning scope. Native Microsoft Graph/SharePoint integration must establish change tracking, deletions, inherited permissions, group membership and user-delegated access checks. Permissions and membership can change independently of content revisions; content change tracking alone is insufficient. Connector read access is not evidence of an end user's access. Tenant configuration, API coverage, propagation behavior and effective authorization semantics require qualification. Existing content hosting, API processing locations and delegated-token handling remain unconfirmed; Google Cloud placement does not relocate or establish residency for SharePoint.
- Service: Microsoft SharePoint
- Provider / placement: tools / Existing source location; unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7368617265706f696e74
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component confluence: Existing Confluence

- Responsibility: Existing authoritative pages and permissions; outside provisioning scope. Native connector must qualify the actual Confluence edition and APIs for content versions, deletion, space/page restrictions, inherited access and group changes. Restrictions and membership can change without page-version changes. User-context permission checks must reflect actual effective access; broad connector credentials cannot substitute. Vendor compatibility, authorization consistency and propagation behavior remain unverified. Existing hosting, API processing locations and delegated-token handling require residency evidence; the assistant's Australian placement does not establish Confluence residency.
- Service: Atlassian Confluence
- Provider / placement: tools / Existing source location; unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-636f6e666c75656e6365
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component source-sync: Source synchronization worker

- Responsibility: Separate proposed Cloud Run Job owns native SharePoint and Confluence connector modules, normalization and incremental indexing for 10,000 documents. Keep independent checkpoints, leases and recovery state per source, and separate content-change progress from permission/membership reconciliation where vendor APIs permit. Do not assume a content delta feed reports every authorization change. Use bounded retries with backoff, idempotent source-ID/revision writes, staged updates, deletion tombstones and periodic full reconciliation. Permission-only changes must invalidate copied access metadata even when text and embeddings are unchanged. Do not advance checkpoints after partial failure or interpret incomplete listings as deletion. Track freshness and quarantine incomplete revisions. Read-only source scopes, connector secrets, API limits and permission coverage require implementation. Extracted text, metadata and embeddings reside in Cloud SQL; no extra document bucket is assumed. Propose Sydney execution with Australian temporary processing and qualified Australian embedding endpoints. Sync frequency does not replace request-time source authorization.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736f757263652d73796e63
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component sync-schedule: Incremental sync and reconciliation schedule

- Responsibility: Proposed Cloud Scheduler invokes Cloud Run Jobs through an authenticated execution API. Routine schedule is configurable; business freshness targets remain open. Worker leases prevent overlapping runs from corrupting checkpoints. Scheduled retries and reconciliation recover missed content and permission changes; live user authorization remains required independently of synchronization frequency. Propose Sydney scheduling subject to qualification, with identifiers rather than document content in execution payloads. Regional execution does not by itself establish control-plane metadata residency.
- Service: Cloud Scheduler
- Provider / placement: gcp / australia-southeast1 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73796e632d7363686564756c65
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component integration-secrets: Source integration secrets

- Responsibility: Proposed Secret Manager holds necessary source connector credentials and federation configuration, with workload-specific access and rotation. Use workload identities for Google Cloud access instead of exported keys. User-delegated authorization flow must be implemented separately with protected token handling; no credentials or identity identifiers are supplied in the diagram. Propose explicitly restricted Australian secret replication rather than assuming automatic replication meets residency. Exact regional-secret or replication configuration, metadata handling and compatibility require qualification. No persistent end-user token store is assumed.
- Service: Secret Manager
- Provider / placement: gcp / Australia-only replication proposed; unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e746567726174696f6e2d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component audit-logs: Access decisions and sync evidence

- Responsibility: Proposed Cloud Logging receives restricted structured events for authorization decisions, source/version references, sync lag, independent permission reconciliation, checkpoints, failures and correlation IDs. Exclude document text, prompts, answers and authentication tokens; identifiers themselves remain sensitive. Restrict log readers and propose explicitly located Australian log buckets. Verify application logs, platform audit logs, default sinks, diagnostic exports and metadata handling individually; an Australian runtime does not establish log residency. Retention, alert routing and operational ownership remain open. Logs support investigation and do not prove correct permission enforcement.
- Service: Cloud Logging
- Provider / placement: gcp / Australian log location proposed; unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-61756469742d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### users-access: internal-users → assistant-access

- Drawn payload/purpose: HTTPS browser session; company sign-in
- Contract task: TASK-CONTRACT-75736572732d616363657373
- Integration task: TASK-INTEGRATION-75736572732d616363657373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### access-app: assistant-access → assistant-app

- Drawn payload/purpose: Protected HTTPS; verified individual identity
- Contract task: TASK-CONTRACT-6163636573732d617070
- Integration task: TASK-INTEGRATION-6163636573732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-response: assistant-app → internal-users

- Drawn payload/purpose: Protected session: buffered cited answer after final checks, or safe abstention
- Contract task: TASK-CONTRACT-6170702d726573706f6e7365
- Integration task: TASK-INTEGRATION-6170702d726573706f6e7365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-retrieval: assistant-app → retrieval-store

- Drawn payload/purpose: Private PostgreSQL/TLS: bounded candidates, provenance and revision checks
- Contract task: TASK-CONTRACT-6170702d72657472696576616c
- Integration task: TASK-INTEGRATION-6170702d72657472696576616c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-sharepoint-check: assistant-app → sharepoint

- Drawn payload/purpose: Native HTTPS: effective user access, existence and revision before model use and
- Contract task: TASK-CONTRACT-6170702d7368617265706f696e742d636865636b
- Integration task: TASK-INTEGRATION-6170702d7368617265706f696e742d636865636b
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-confluence-check: assistant-app → confluence

- Drawn payload/purpose: Native HTTPS: effective user access, existence and revision before model use and
- Contract task: TASK-CONTRACT-6170702d636f6e666c75656e63652d636865636b
- Integration task: TASK-INTEGRATION-6170702d636f6e666c75656e63652d636865636b
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-model: assistant-app → model-runtime

- Drawn payload/purpose: IAM-authenticated Australian endpoints required: query embedding and authorized-
- Contract task: TASK-CONTRACT-6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-sharepoint: source-sync → sharepoint

- Drawn payload/purpose: Read-only native API: content changes plus independent permission/group reconcil
- Contract task: TASK-CONTRACT-73796e632d7368617265706f696e74
- Integration task: TASK-INTEGRATION-73796e632d7368617265706f696e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-confluence: source-sync → confluence

- Drawn payload/purpose: Read-only native API: versions, restrictions, group changes, deletions and recon
- Contract task: TASK-CONTRACT-73796e632d636f6e666c75656e6365
- Integration task: TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-store: source-sync → retrieval-store

- Drawn payload/purpose: Transactional revisions, permission metadata, tombstones and independent checkpo
- Contract task: TASK-CONTRACT-73796e632d73746f7265
- Integration task: TASK-INTEGRATION-73796e632d73746f7265
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-model: source-sync → model-runtime

- Drawn payload/purpose: IAM-authenticated Australian embedding endpoint required for staged document rev
- Contract task: TASK-CONTRACT-73796e632d6d6f64656c
- Integration task: TASK-INTEGRATION-73796e632d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### schedule-sync: sync-schedule → source-sync

- Drawn payload/purpose: Authenticated Cloud Run Jobs execution API; incremental and full reconciliation
- Contract task: TASK-CONTRACT-7363686564756c652d73796e63
- Integration task: TASK-INTEGRATION-7363686564756c652d73796e63
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: assistant-app → integration-secrets

- Drawn payload/purpose: Workload identity: read only required integration secrets
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-secrets: source-sync → integration-secrets

- Drawn payload/purpose: Workload identity: read only connector-specific secrets
- Contract task: TASK-CONTRACT-73796e632d73656372657473
- Integration task: TASK-INTEGRATION-73796e632d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-audit: assistant-app → audit-logs

- Drawn payload/purpose: Redacted access decisions and provenance to explicitly located Australian log st
- Contract task: TASK-CONTRACT-6170702d6175646974
- Integration task: TASK-INTEGRATION-6170702d6175646974
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-audit: source-sync → audit-logs

- Drawn payload/purpose: Content/permission freshness, retries, reconciliation and failure events; no doc
- Contract task: TASK-CONTRACT-73796e632d6175646974
- Integration task: TASK-INTEGRATION-73796e632d6175646974
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
