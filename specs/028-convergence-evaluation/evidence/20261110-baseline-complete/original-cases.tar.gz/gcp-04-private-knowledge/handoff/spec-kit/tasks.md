# Detailed implementation tasks

Snapshot dee17f7c-a843-4a42-b02b-8d1c368281aa · design r3 · generated 2026-11-09T17:44:19.817Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-75736572732d616363657373 — Define Internal staff → Company sign-in boundary

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: internal-users, assistant-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-access: HTTPS browser session; company sign-in. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-access
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6163636573732d617070 — Define Company sign-in boundary → Assistant and access enforcement

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-access, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection access-app: Protected HTTPS; verified individual identity. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge access-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d726573706f6e7365 — Define Assistant and access enforcement → Internal staff

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, internal-users
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-response: Protected session: buffered cited answer after final checks, or safe abstention. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-response
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d72657472696576616c — Define Assistant and access enforcement → Documents, retrieval and change state

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-retrieval: Private PostgreSQL/TLS: bounded candidates, provenance and revision checks. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-retrieval
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d7368617265706f696e742d636865636b — Define Assistant and access enforcement → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-sharepoint-check: Native HTTPS: effective user access, existence and revision before model use and. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-sharepoint-check
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d636f6e666c75656e63652d636865636b — Define Assistant and access enforcement → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-confluence-check: Native HTTPS: effective user access, existence and revision before model use and. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-confluence-check
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6d6f64656c — Define Assistant and access enforcement → Embeddings and grounded answers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-model: IAM-authenticated Australian endpoints required: query embedding and authorized-. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d7368617265706f696e74 — Define Source synchronization worker → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-sharepoint: Read-only native API: content changes plus independent permission/group reconcil. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-sharepoint
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d636f6e666c75656e6365 — Define Source synchronization worker → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-confluence: Read-only native API: versions, restrictions, group changes, deletions and recon. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-confluence
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d73746f7265 — Define Source synchronization worker → Documents, retrieval and change state

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-store: Transactional revisions, permission metadata, tombstones and independent checkpo. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-store
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d6d6f64656c — Define Source synchronization worker → Embeddings and grounded answers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-model: IAM-authenticated Australian embedding endpoint required for staged document rev. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7363686564756c652d73796e63 — Define Incremental sync and reconciliation schedule → Source synchronization worker

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: sync-schedule, source-sync
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection schedule-sync: Authenticated Cloud Run Jobs execution API; incremental and full reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge schedule-sync
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d73656372657473 — Define Assistant and access enforcement → Source integration secrets

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-secrets: Workload identity: read only required integration secrets. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d73656372657473 — Define Source synchronization worker → Source integration secrets

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-secrets: Workload identity: read only connector-specific secrets. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6175646974 — Define Assistant and access enforcement → Access decisions and sync evidence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-audit: Redacted access decisions and provenance to explicitly located Australian log st. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-audit
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d6175646974 — Define Source synchronization worker → Access decisions and sync evidence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-audit: Content/permission freshness, retries, reconciliation and failure events; no doc. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-audit
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-696e7465726e616c2d7573657273 — Integrate existing Internal staff

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d616363657373, TASK-CONTRACT-6170702d726573706f6e7365
- Components: internal-users
- Generated files: No implementation files generated yet
- Requirements: ai-source-authorization

### Implementation steps

1. Responsibility from the board: Existing people using a proposed browser interface. Outside provisioning scope; each request must carry a verified individual identity. No shared end-user identity. User locations and browser delivery boundaries remain unconfirmed; Australian cloud placement does not establish where users access answers.
2. Verify Approval workflow on tools in Existing user locations; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component internal-users
- Application/configuration and tests for Internal staff

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d616363657373 — Implement Company sign-in boundary

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d616363657373, TASK-CONTRACT-6163636573732d617070
- Components: assistant-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-authorization, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Identity-Aware Proxy protects the assistant using company sign-in. Existing identity provider and compatible federation path must be established; no identity provider is assumed. Restrict Cloud Run ingress to the intended protected path and validate signed identity assertions server-side. Sign-in alone does not grant document access. Identity-Aware Proxy is not assigned a regional data-residency guarantee by this drawing; authentication, routing and identity/control-plane metadata handling require separate qualification. The protected Cloud Run path and any required ingress infrastructure remain implementation work.
2. Verify Identity-Aware Proxy on gcp in Identity/control-plane residency unresolved; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Identity-Aware Proxy; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-access
- Application/configuration and tests for Company sign-in boundary

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d617070 — Implement Assistant and access enforcement

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6163636573732d617070, TASK-CONTRACT-6170702d726573706f6e7365, TASK-CONTRACT-6170702d72657472696576616c, TASK-CONTRACT-6170702d7368617265706f696e742d636865636b, TASK-CONTRACT-6170702d636f6e666c75656e63652d636865636b, TASK-CONTRACT-6170702d6d6f64656c, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-6170702d6175646974
- Components: assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-authorization, ai-change-propagation, ai-source-outage-isolation, ai-australian-residency, ai-corpus-coverage

### Implementation steps

1. Responsibility from the board: Proposed Cloud Run service owns browser UI, question API, retrieval, source authorization and cited responses. Initial scope proposal is read-only assistance without source edits or autonomous actions. Map verified users to source identities without assuming matching email addresses. Fetch bounded candidates internally, then independently check effective user access, document existence and current content revision through native source APIs before sending passages to Vertex AI. Permission, inherited restriction and group-membership changes can occur without a content revision: an unchanged revision or copied ACL never proves current access. Do not cache positive authorization decisions initially. Buffer the answer and repeat effective-access, existence and revision checks for every supporting document before release; discard and regenerate from remaining eligible evidence or abstain after any invalidation. Exclude affected-source content when its checks fail, while allowing independently authorized healthy-source answers with a coverage warning. Fail closed for unknown identities, unavailable authorization, stale revisions and deleted documents; never substitute connector credentials. No shared answer cache or retained conversation history initially; do not log prompts, passages or answers. Source text cannot grant tool permissions. Sydney runtime is proposed; only qualified Australian model endpoints may receive content. Native APIs may have propagation delays and cannot provide an atomic transaction spanning authorization and answer delivery; document and test this limitation rather than promising instantaneous revocation. Native code, ingress controls and security tests remain required.
2. Verify Google Cloud Run on gcp in australia-southeast1 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Run; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.; REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-app
- Application/configuration and tests for Assistant and access enforcement

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-72657472696576616c2d73746f7265 — Implement Documents, retrieval and change state

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d72657472696576616c, TASK-CONTRACT-73796e632d73746f7265
- Components: retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-change-propagation, ai-source-outage-isolation, ai-australian-residency, ai-corpus-coverage

### Implementation steps

1. Responsibility from the board: Proposed Cloud SQL for PostgreSQL with pgvector stores normalized passages, embeddings, source IDs, content revisions, ACL metadata, tombstones and independent source checkpoints for an initial 10,000-document corpus. Document count alone does not establish bytes, passage count, query load or instance sizing. Keyword/vector candidates carry explicit source/version provenance; copied ACLs only narrow candidates and never replace live authorization. Track authorization freshness separately from content revisions; do not assume vendors expose a complete permission-version token. Atomically activate complete document revisions, make tombstones immediately ineligible and remove superseded text and vectors through tracked cleanup. Separate application read privileges from synchronization writes and restrict network access. Propose regional multi-zone availability in Sydney, subject to service qualification; this does not provide region-wide disaster recovery. Require Australian placement for replicas, backups, recovery logs and temporary exports; backup retention and deletion policy remain unresolved. Restore into quarantine and reconcile content and permissions against sources before enabling retrieval. Extension compatibility, capacity and recovery behavior require validation.
2. Verify Cloud SQL for PostgreSQL on gcp in australia-southeast1 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Cloud SQL for PostgreSQL; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.; REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component retrieval-store
- Application/configuration and tests for Documents, retrieval and change state

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6d6f64656c2d72756e74696d65 — Implement Embeddings and grounded answers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6d6f64656c, TASK-CONTRACT-73796e632d6d6f64656c
- Components: model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-authorization, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Vertex AI service provides embedding and generative model APIs. The assistant supplies only currently authorized passages and requests document/version citations; abstain when evidence is insufficient. The synchronization worker embeds newly staged content. Both embedding and generation must have independently qualified Australian processing endpoints and data-handling terms; placing Cloud Run in Sydney does not establish model processing residency. Exact models, model versions, regional availability, quotas, prompt retention, abuse-monitoring handling and endpoint guarantees remain unverified. No global endpoint, cross-region routing or overseas fallback is assumed. If no suitable Australian model configuration meets the requirement, preserve the residency requirement and resolve the model implementation gap before enabling inference. Model output does not enforce permissions.
2. Verify Vertex AI on gcp in Australia required; model endpoints unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Vertex AI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component model-runtime
- Application/configuration and tests for Embeddings and grounded answers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7368617265706f696e74 — Integrate existing Existing SharePoint

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d7368617265706f696e742d636865636b, TASK-CONTRACT-73796e632d7368617265706f696e74
- Components: sharepoint
- Generated files: No implementation files generated yet
- Requirements: ai-source-authorization, ai-change-propagation, ai-source-outage-isolation, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Existing authoritative documents and permissions; outside provisioning scope. Native Microsoft Graph/SharePoint integration must establish change tracking, deletions, inherited permissions, group membership and user-delegated access checks. Permissions and membership can change independently of content revisions; content change tracking alone is insufficient. Connector read access is not evidence of an end user's access. Tenant configuration, API coverage, propagation behavior and effective authorization semantics require qualification. Existing content hosting, API processing locations and delegated-token handling remain unconfirmed; Google Cloud placement does not relocate or establish residency for SharePoint.
2. Verify Microsoft SharePoint on tools in Existing source location; unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sharepoint
- Application/configuration and tests for Existing SharePoint

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e666c75656e6365 — Integrate existing Existing Confluence

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d636f6e666c75656e63652d636865636b, TASK-CONTRACT-73796e632d636f6e666c75656e6365
- Components: confluence
- Generated files: No implementation files generated yet
- Requirements: ai-source-authorization, ai-change-propagation, ai-source-outage-isolation, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Existing authoritative pages and permissions; outside provisioning scope. Native connector must qualify the actual Confluence edition and APIs for content versions, deletion, space/page restrictions, inherited access and group changes. Restrictions and membership can change without page-version changes. User-context permission checks must reflect actual effective access; broad connector credentials cannot substitute. Vendor compatibility, authorization consistency and propagation behavior remain unverified. Existing hosting, API processing locations and delegated-token handling require residency evidence; the assistant's Australian placement does not establish Confluence residency.
2. Verify Atlassian Confluence on tools in Existing source location; unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.; REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component confluence
- Application/configuration and tests for Existing Confluence

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-736f757263652d73796e63 — Implement Source synchronization worker

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-CONTRACT-73796e632d73746f7265, TASK-CONTRACT-73796e632d6d6f64656c, TASK-CONTRACT-7363686564756c652d73796e63, TASK-CONTRACT-73796e632d73656372657473, TASK-CONTRACT-73796e632d6175646974
- Components: source-sync
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-change-propagation, ai-source-outage-isolation, ai-australian-residency, ai-corpus-coverage

### Implementation steps

1. Responsibility from the board: Separate proposed Cloud Run Job owns native SharePoint and Confluence connector modules, normalization and incremental indexing for 10,000 documents. Keep independent checkpoints, leases and recovery state per source, and separate content-change progress from permission/membership reconciliation where vendor APIs permit. Do not assume a content delta feed reports every authorization change. Use bounded retries with backoff, idempotent source-ID/revision writes, staged updates, deletion tombstones and periodic full reconciliation. Permission-only changes must invalidate copied access metadata even when text and embeddings are unchanged. Do not advance checkpoints after partial failure or interpret incomplete listings as deletion. Track freshness and quarantine incomplete revisions. Read-only source scopes, connector secrets, API limits and permission coverage require implementation. Extracted text, metadata and embeddings reside in Cloud SQL; no extra document bucket is assumed. Propose Sydney execution with Australian temporary processing and qualified Australian embedding endpoints. Sync frequency does not replace request-time source authorization.
2. Verify Google Cloud Run on gcp in australia-southeast1 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Run; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.; REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component source-sync
- Application/configuration and tests for Source synchronization worker

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73796e632d7363686564756c65 — Implement Incremental sync and reconciliation schedule

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7363686564756c652d73796e63
- Components: sync-schedule
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-change-propagation

### Implementation steps

1. Responsibility from the board: Proposed Cloud Scheduler invokes Cloud Run Jobs through an authenticated execution API. Routine schedule is configurable; business freshness targets remain open. Worker leases prevent overlapping runs from corrupting checkpoints. Scheduled retries and reconciliation recover missed content and permission changes; live user authorization remains required independently of synchronization frequency. Propose Sydney scheduling subject to qualification, with identifiers rather than document content in execution payloads. Regional execution does not by itself establish control-plane metadata residency.
2. Verify Cloud Scheduler on gcp in australia-southeast1 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Cloud Scheduler; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sync-schedule
- Application/configuration and tests for Incremental sync and reconciliation schedule

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e746567726174696f6e2d73656372657473 — Implement Source integration secrets

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-73796e632d73656372657473
- Components: integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Secret Manager holds necessary source connector credentials and federation configuration, with workload-specific access and rotation. Use workload identities for Google Cloud access instead of exported keys. User-delegated authorization flow must be implemented separately with protected token handling; no credentials or identity identifiers are supplied in the diagram. Propose explicitly restricted Australian secret replication rather than assuming automatic replication meets residency. Exact regional-secret or replication configuration, metadata handling and compatibility require qualification. No persistent end-user token store is assumed.
2. Verify Secret Manager on gcp in Australia-only replication proposed; unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Secret Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component integration-secrets
- Application/configuration and tests for Source integration secrets

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-61756469742d6c6f6773 — Implement Access decisions and sync evidence

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6175646974, TASK-CONTRACT-73796e632d6175646974
- Components: audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-outage-isolation, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Cloud Logging receives restricted structured events for authorization decisions, source/version references, sync lag, independent permission reconciliation, checkpoints, failures and correlation IDs. Exclude document text, prompts, answers and authentication tokens; identifiers themselves remain sensitive. Restrict log readers and propose explicitly located Australian log buckets. Verify application logs, platform audit logs, default sinks, diagnostic exports and metadata handling individually; an Australian runtime does not establish log residency. Retention, alert routing and operational ownership remain open. Logs support investigation and do not prove correct permission enforcement.
2. Verify Cloud Logging on gcp in Australian log location proposed; unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Cloud Logging; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.; REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component audit-logs
- Application/configuration and tests for Access decisions and sync evidence

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-75736572732d616363657373 — Wire Internal staff to Company sign-in boundary

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d616363657373, TASK-RESOURCE-696e7465726e616c2d7573657273, TASK-RESOURCE-617373697374616e742d616363657373
- Components: internal-users, assistant-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-access carrying HTTPS browser session; company sign-in, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-access
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6163636573732d617070 — Wire Company sign-in boundary to Assistant and access enforcement

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6163636573732d617070, TASK-RESOURCE-617373697374616e742d616363657373, TASK-RESOURCE-617373697374616e742d617070
- Components: assistant-access, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge access-app carrying Protected HTTPS; verified individual identity, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation access-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d726573706f6e7365 — Wire Assistant and access enforcement to Internal staff

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d726573706f6e7365, TASK-RESOURCE-696e7465726e616c2d7573657273, TASK-RESOURCE-617373697374616e742d617070
- Components: assistant-app, internal-users
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-response carrying Protected session: buffered cited answer after final checks, or safe abstention, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-response
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d72657472696576616c — Wire Assistant and access enforcement to Documents, retrieval and change state

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d72657472696576616c, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265
- Components: assistant-app, retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-retrieval carrying Private PostgreSQL/TLS: bounded candidates, provenance and revision checks, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-retrieval
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d7368617265706f696e742d636865636b — Wire Assistant and access enforcement to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d7368617265706f696e742d636865636b, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-7368617265706f696e74
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-sharepoint-check carrying Native HTTPS: effective user access, existence and revision before model use and, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-sharepoint-check
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d636f6e666c75656e63652d636865636b — Wire Assistant and access enforcement to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d636f6e666c75656e63652d636865636b, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-636f6e666c75656e6365
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-confluence-check carrying Native HTTPS: effective user access, existence and revision before model use and, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-confluence-check
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6d6f64656c — Wire Assistant and access enforcement to Embeddings and grounded answers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6d6f64656c, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-6d6f64656c2d72756e74696d65
- Components: assistant-app, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-model carrying IAM-authenticated Australian endpoints required: query embedding and authorized-, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d7368617265706f696e74 — Wire Source synchronization worker to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-sharepoint carrying Read-only native API: content changes plus independent permission/group reconcil, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-sharepoint
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d636f6e666c75656e6365 — Wire Source synchronization worker to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-confluence carrying Read-only native API: versions, restrictions, group changes, deletions and recon, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-confluence
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d73746f7265 — Wire Source synchronization worker to Documents, retrieval and change state

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d73746f7265, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-store carrying Transactional revisions, permission metadata, tombstones and independent checkpo, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-store
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d6d6f64656c — Wire Source synchronization worker to Embeddings and grounded answers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d6d6f64656c, TASK-RESOURCE-6d6f64656c2d72756e74696d65, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-model carrying IAM-authenticated Australian embedding endpoint required for staged document rev, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7363686564756c652d73796e63 — Wire Incremental sync and reconciliation schedule to Source synchronization worker

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7363686564756c652d73796e63, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65
- Components: sync-schedule, source-sync
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge schedule-sync carrying Authenticated Cloud Run Jobs execution API; incremental and full reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation schedule-sync
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d73656372657473 — Wire Assistant and access enforcement to Source integration secrets

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d73656372657473, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-696e746567726174696f6e2d73656372657473
- Components: assistant-app, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-secrets carrying Workload identity: read only required integration secrets, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d73656372657473 — Wire Source synchronization worker to Source integration secrets

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d73656372657473, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-696e746567726174696f6e2d73656372657473
- Components: source-sync, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-secrets carrying Workload identity: read only connector-specific secrets, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6175646974 — Wire Assistant and access enforcement to Access decisions and sync evidence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6175646974, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-61756469742d6c6f6773
- Components: assistant-app, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-audit carrying Redacted access decisions and provenance to explicitly located Australian log st, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-audit
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d6175646974 — Wire Source synchronization worker to Access decisions and sync evidence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d6175646974, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-61756469742d6c6f6773
- Components: source-sync, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-audit carrying Content/permission freshness, retries, reconciliation and failure events; no doc, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-audit
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-75736572732d616363657373 — Verify live Internal staff → Company sign-in boundary

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d616363657373
- Components: internal-users, assistant-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-access with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-access

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6163636573732d617070 — Verify live Company sign-in boundary → Assistant and access enforcement

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6163636573732d617070
- Components: assistant-access, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge access-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence access-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d726573706f6e7365 — Verify live Assistant and access enforcement → Internal staff

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d726573706f6e7365
- Components: assistant-app, internal-users
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-response with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-response

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d72657472696576616c — Verify live Assistant and access enforcement → Documents, retrieval and change state

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d72657472696576616c
- Components: assistant-app, retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-retrieval with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-retrieval

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b — Verify live Assistant and access enforcement → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d7368617265706f696e742d636865636b
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-sharepoint-check with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-sharepoint-check

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b — Verify live Assistant and access enforcement → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d636f6e666c75656e63652d636865636b
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-confluence-check with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-confluence-check

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6d6f64656c — Verify live Assistant and access enforcement → Embeddings and grounded answers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6d6f64656c
- Components: assistant-app, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74 — Verify live Source synchronization worker → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d7368617265706f696e74
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-sharepoint with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-sharepoint

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365 — Verify live Source synchronization worker → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-confluence with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-confluence

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d73746f7265 — Verify live Source synchronization worker → Documents, retrieval and change state

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d73746f7265
- Components: source-sync, retrieval-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-store with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-store

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d6d6f64656c — Verify live Source synchronization worker → Embeddings and grounded answers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d6d6f64656c
- Components: source-sync, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7363686564756c652d73796e63 — Verify live Incremental sync and reconciliation schedule → Source synchronization worker

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7363686564756c652d73796e63
- Components: sync-schedule, source-sync
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge schedule-sync with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence schedule-sync

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d73656372657473 — Verify live Assistant and access enforcement → Source integration secrets

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d73656372657473
- Components: assistant-app, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d73656372657473 — Verify live Source synchronization worker → Source integration secrets

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d73656372657473
- Components: source-sync, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6175646974 — Verify live Assistant and access enforcement → Access decisions and sync evidence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6175646974
- Components: assistant-app, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-audit with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-audit

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d6175646974 — Verify live Source synchronization worker → Access decisions and sync evidence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d6175646974
- Components: source-sync, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-audit with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-audit

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3534333964343536 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-5439d456

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d617574686f72697a6174696f6e — Verify REQ-004: The assistant must bind each request to a verified user and enforce effective source permissions on all supporting documents before model use and again before releasing a cited answer. Unknown identity, denied access or an unverifiable authorization result must exclude the affected content; connector privileges must never substitute for user access.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e7465726e616c2d7573657273, TASK-RESOURCE-617373697374616e742d616363657373, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-6d6f64656c2d72756e74696d65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-INTEGRATION-LIVE-75736572732d616363657373, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974
- Components: internal-users, assistant-access, assistant-app, sharepoint, confluence, model-runtime
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-authorization

### Implementation steps

1. Basis: User: “People should get cited answers only from documents they can access.”; rationale: Copied permissions can become stale; enforcing source-backed authorization before model use and response release reduces disclosure risk. Native API behavior and concurrent revocation races require explicit testing.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6368616e67652d70726f7061676174696f6e — Verify REQ-005: Synchronization must propagate permission changes, edits and deletions using revision-aware, idempotent updates and independent source checkpoints. The assistant must exclude deleted documents and revision-mismatched copies; retries, reconciliation and restore procedures must preserve that exclusion. Business propagation-time and retention targets remain open.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d73746f7265, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974, TASK-INTEGRATION-LIVE-73796e632d6175646974
- Components: source-sync, sync-schedule, retrieval-store, assistant-app, sharepoint, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-change-propagation

### Implementation steps

1. Basis: User: “Permission revocation, edits and deletion must propagate.”; rationale: Out-of-order updates, missed deletions and restored indexes can expose obsolete content. Proposed revision gating and reconciliation keep incomplete or stale copies out of answers while synchronization recovers.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6f75746167652d69736f6c6174696f6e — Verify REQ-006: When a source cannot confirm current user access and document revision, the assistant must withhold that source's affected content and any answer depending on it. Independently authorized healthy-source content may remain available with a clear coverage warning. Acceptance tests must cover source outages, authorization timeouts, revocation, deletion, retries and recovery without stale-content disclosure.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-61756469742d6c6f6773, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d73746f7265, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974, TASK-INTEGRATION-LIVE-73796e632d6175646974
- Components: assistant-app, source-sync, retrieval-store, sharepoint, confluence, audit-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-outage-isolation

### Implementation steps

1. Basis: User: “An outage in one source should not leak stale restricted content.”; rationale: A last successful crawl does not prove current access during an outage. Proposed source isolation lets healthy sources remain useful without treating stale authorization as permission.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379 — Verify REQ-007: Document content, derived passages, indexes, embeddings and AI processing must remain in Australia, including content-bearing temporary files, replicas, backups and diagnostics. Qualify embedding and generation endpoints independently and prohibit global or overseas fallback. Record existing-source residency, identity/control-plane metadata and service-specific exceptions as unresolved evidence gaps; proposed Sydney placement is not region approval.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d616363657373, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-6d6f64656c2d72756e74696d65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-696e746567726174696f6e2d73656372657473, TASK-RESOURCE-61756469742d6c6f6773, TASK-INTEGRATION-LIVE-75736572732d616363657373, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d73746f7265, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974, TASK-INTEGRATION-LIVE-73796e632d6175646974
- Components: assistant-app, retrieval-store, model-runtime, source-sync, audit-logs, sharepoint, confluence, assistant-access, integration-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-australian-residency

### Implementation steps

1. Basis: “Australia for content, indexes and processing; explain service/model residency gaps.” Relevant components include assistant-app, retrieval-store, model-runtime and source-sync.; rationale: Australian application hosting alone cannot guarantee Australian model processing or storage of derived data; endpoint, backup and logging defaults could cross the required boundary.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d636f727075732d636f766572616765 — Verify REQ-008: The assistant must support indexing and permission-aware retrieval across the initial 10,000-document corpus, preserving source identity and revision provenance and supporting resumable reconciliation after partial failure. Document sizes, passage counts, request load and latency targets remain to be established before capacity selection.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-736f757263652d73796e63, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d73746f7265, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974, TASK-INTEGRATION-LIVE-73796e632d6175646974
- Components: source-sync, retrieval-store, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-corpus-coverage

### Implementation steps

1. Basis: “Ten thousand company documents.” The retrieval-store and source-sync components own indexing and recovery.; rationale: The stated corpus rules out a small demonstration collection; bounded retrieval and resumable indexing must work across the full corpus without assuming document count determines storage or traffic.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-696e7465726e616c2d7573657273, TASK-RESOURCE-617373697374616e742d616363657373, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-6d6f64656c2d72756e74696d65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-RESOURCE-696e746567726174696f6e2d73656372657473, TASK-RESOURCE-61756469742d6c6f6773, TASK-INTEGRATION-75736572732d616363657373, TASK-INTEGRATION-6163636573732d617070, TASK-INTEGRATION-6170702d726573706f6e7365, TASK-INTEGRATION-6170702d72657472696576616c, TASK-INTEGRATION-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-6170702d6d6f64656c, TASK-INTEGRATION-73796e632d7368617265706f696e74, TASK-INTEGRATION-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-73796e632d73746f7265, TASK-INTEGRATION-73796e632d6d6f64656c, TASK-INTEGRATION-7363686564756c652d73796e63, TASK-INTEGRATION-6170702d73656372657473, TASK-INTEGRATION-73796e632d73656372657473, TASK-INTEGRATION-6170702d6175646974, TASK-INTEGRATION-73796e632d6175646974
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-696e7465726e616c2d7573657273, TASK-RESOURCE-617373697374616e742d616363657373, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72657472696576616c2d73746f7265, TASK-RESOURCE-6d6f64656c2d72756e74696d65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-RESOURCE-696e746567726174696f6e2d73656372657473, TASK-RESOURCE-61756469742d6c6f6773, TASK-INTEGRATION-LIVE-75736572732d616363657373, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d73746f7265, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974, TASK-INTEGRATION-LIVE-73796e632d6175646974
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3534333964343536, TASK-ACCEPTANCE-61692d736f757263652d617574686f72697a6174696f6e, TASK-ACCEPTANCE-61692d6368616e67652d70726f7061676174696f6e, TASK-ACCEPTANCE-61692d736f757263652d6f75746167652d69736f6c6174696f6e, TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379, TASK-ACCEPTANCE-61692d636f727075732d636f766572616765, TASK-INTEGRATION-LIVE-75736572732d616363657373, TASK-INTEGRATION-LIVE-6163636573732d617070, TASK-INTEGRATION-LIVE-6170702d726573706f6e7365, TASK-INTEGRATION-LIVE-6170702d72657472696576616c, TASK-INTEGRATION-LIVE-6170702d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-6170702d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-6170702d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d73746f7265, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-6170702d6175646974, TASK-INTEGRATION-LIVE-73796e632d6175646974
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
