# Delivery handoff

Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Application sign-in and roles / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: input needed (data_gb).
- Invoice state and approval ledger / Storage: input needed (data_gb).
- Extraction and approved-delivery queues / Data processed: input needed (data_gb).
- Invoice field extraction / Endpoint hours: price needed.
- Accounting credentials / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Extraction and accounting workers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Workflow monitoring and recovery alerts: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: Implementation needed.
- Application sign-in and roles: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice state and approval ledger: Implementation needed.
- Extraction and approved-delivery queues: Implementation needed.
- Extraction and accounting workers: Implementation needed.
- Invoice field extraction: Implementation needed.
- Workflow monitoring and recovery alerts: Implementation needed.
- Accounting credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-broker: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-worker: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
