Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

# Asynchronous document intake — deployment document

Generated 2026-11-09 17:18 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 9 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** Twenty signed-in staff and three reviewers; ordinary uploaders cannot approve. The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.
- **How good, fast and safe:** —
- **Cloud preference:** Azure
- **Budget and timeline:** —

## 3. Architecture

**Upload and review**

- Uploaders and reviewers (Tools & data, existing) — Existing people using browsers, outside provisioning scope: twenty signed-in staff and three reviewers, with membership overlap unspecified. Uploaders submit PDFs and view permitted records; ordinary uploaders cannot approve. Designated reviewers inspect source documents, correct extracted fields and approve a specific revision. User directory and operating owner remain unconfirmed.
- Invoice upload and review application (Azure, sketch) — Proposed Azure App Service deployment hosting browser UI and server API. Authenticates staff and enforces uploader/reviewer permissions server-side on every operation; ordinary uploaders cannot approve, including through direct API requests. Validates PDFs, assigns stable intake IDs and streams files to private storage. Presents permitted source PDFs, field confidence, corrections and review status. Approval atomically records the authorized reviewer, timestamp and immutable payload revision plus an outbox entry; edits invalidate approval. Uses managed identity for supported Azure access. Application, hosting dependencies, authorization and deployment modules require engineering, including denial tests for uploader approval attempts.
- Application sign-in and roles (Azure, sketch) — Proposed Microsoft Entra ID application registration and uploader/reviewer app roles for twenty signed-in staff and three reviewers; no existing tenant or company sign-in is assumed. Existing directory alignment and tenant inputs remain open. Reviewer privileges require explicit assignment; ordinary uploader membership grants no approval permission. Application validates tokens and authorizes each operation and document access; browser controls alone are insufficient. Directory integration, role assignment administration and authorization tests require implementation.

**Durable records**

- Private invoice PDFs (Azure, sketch) — Private Azure Blob Storage for original PDFs with immutable object references per intake record. No anonymous access; application and worker receive scoped managed-identity permissions. Users access permitted PDFs through the application. Proposed content hashes flag identical uploads, without claiming to identify every duplicate business invoice. Lifecycle, retention and recovery policy await business constraints. This application-mediated storage path requires integration work and is not the standalone operator storage contract.
- Invoice state and approval ledger (Azure, sketch) — Azure SQL Database stores intake keys, document references, extracted fields, confidence, corrections, approval revisions, delivery attempts and accounting IDs. Unique constraints and conditional state transitions prevent duplicate intake and concurrent approval/submission. Transactions write workflow changes and outbox entries together. Durable review records are the review queue; broker messages are not the source of approval truth. Approved snapshots are immutable and retain reviewer identity and timestamp. Records of unknown accounting outcomes remain pending reconciliation. Backup, retention and restoration procedures require implementation and agreed targets.

**Background processing**

- Extraction and approved-delivery queues (Azure, sketch) — One Azure Service Bus namespace with separate extraction and accounting-delivery queues and their dead-letter subqueues. Messages carry stable job IDs and revision references, not raw invoice contents. Outbox publishing is retryable; consumers must tolerate redelivery even if broker duplicate detection is enabled. Bounded delivery attempts, lock renewal, dead-letter inspection and controlled replay require application implementation. Approval is verified against SQL state before an accounting call.
- Extraction and accounting workers (Azure, sketch) — One Azure Functions application owns outbox dispatch, asynchronous extraction and approved accounting delivery. Extraction reads the exact stored PDF, submits and polls Document Intelligence, maps supplier/date/total/currency and durably records results or reviewable errors. Accounting delivery verifies the authorized approval and exact revision, reserves work atomically and submits a stable external reference. Retries use bounded backoff; ambiguous accounting outcomes require reconciliation rather than blind resubmission. Proposed modules share one deployment initially. Administrator supplies the external accounting endpoint as configuration and credentials through Key Vault; worker reads only required secrets through managed identity and fails closed when configuration or credentials are unavailable. Required Functions storage, runtime logging, rotation handling and all worker code remain implementation tasks; credentials must never appear in the graph or telemetry.
- Invoice field extraction (Azure, sketch) — Azure AI Document Intelligence with the prebuilt invoice model is proposed for PDF field extraction. Worker maps supplier, invoice date, total and currency into the review schema, preserving missing values and confidence rather than inventing data. All results require human approval. Model/API version, regional processing availability, supported currencies and representative-document accuracy need verification. PDF content is untrusted input. No managed extraction integration is currently generated.

**Accounting integration**

- Existing accounting API (Tools & data, existing) — Client's existing accounting API, retained outside provisioning scope and not recreated, imported or modified. An administrator will supply its endpoint and credentials through deployment configuration and the proposed secret-management process. Receives only approved invoice revisions. Authentication mechanism, request schema, idempotency-key support, unique external reference enforcement and reference lookup remain unverified. Integration must test the case where accounting commits but the response is lost; duplicate-free recovery cannot be claimed without a suitable API contract or reconciliation process.
- Accounting credentials (Azure, sketch) — Proposed Azure Key Vault holds administrator-supplied accounting credentials. An authorized administrator loads and rotates secrets through a separate administrative process; no secret values belong in the diagram, source code or Terraform state. Grant the worker managed identity read access only to required secrets, without secret-management privileges. Endpoint configuration stays separate from credentials. Provisioning, scoped access, secret loading instructions, rotation behavior and denied-access tests require engineering; the accounting authentication mechanism remains unverified.

**Operations**

- Workflow monitoring and recovery alerts (Azure, sketch) — Azure Monitor collects correlated application and worker telemetry and alerts on dead-letter messages, stalled extraction, outbox backlog and unresolved accounting submissions. Avoid raw PDF contents, invoice fields and credentials in telemetry. Alert recipients, operating ownership, log retention and recovery objectives remain open. Instrumentation, alert rules and replay/reconciliation runbooks require implementation; this node does not prove monitoring works.

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice upload and review application<br/>Azure"]
  n2["Application sign-in and roles<br/>Azure"]
  n3["Private invoice PDFs<br/>Azure"]
  n4["Invoice state and approval ledger<br/>Azure"]
  n5["Extraction and approved-delivery queues<br/>Azure"]
  n6["Extraction and accounting workers<br/>Azure"]
  n7["Invoice field extraction<br/>Azure"]
  n8["Existing accounting API<br/>Tools & data"]
  n9["Workflow monitoring and recovery alerts<br/>Azure"]
  n10["Accounting credentials<br/>Azure"]
  n0 -->|HTTPS: signed-in uploads and review; only reviewers may approve| n1
  n1 -->|OpenID Connect sign-in; server validates identity and uploader/reviewer roles| n2
  n1 -->|Managed identity: private PDF upload and authorized reads| n3
  n1 -->|SQL transactions: intake, review, authorized approval and outbox| n4
  n6 -->|Claim outbox/jobs; persist extraction, approval checks and delivery state| n4
  n6 -->|Managed identity: publish durable outbox jobs over AMQP/TLS| n5
  n5 -->|Service Bus triggers: locked delivery, retry and dead-letter recovery| n6
  n6 -->|Managed identity: read exact stored PDF reference| n3
  n6 -->|HTTPS: submit PDF, persist operation ID and poll extraction| n7
  n6 -->|Authenticated HTTPS: approved payload and stable reference; reconcile uncertain | n8
  n1 -->|Correlated request, authorization and approval telemetry| n9
  n6 -->|Job failures, backlog and reconciliation telemetry| n9
  n5 -->|Queue age and dead-letter metrics for recovery alerts| n9
  n6 -->|Managed identity over HTTPS: read scoped accounting credentials| n10
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Approval workflow | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-app | Invoice upload and review application | azure | Azure App Service | To be selected | Proposed | Implementation needed |
| invoice-identity | Application sign-in and roles | azure | Microsoft Entra ID | To be selected | Proposed | Implementation needed |
| invoice-documents | Private invoice PDFs | azure | Azure Blob Storage | To be selected | Proposed | Implementation needed |
| invoice-state | Invoice state and approval ledger | azure | Azure SQL Database | To be selected | Proposed | Implementation needed |
| invoice-broker | Extraction and approved-delivery queues | azure | Azure Service Bus | To be selected | Proposed | Implementation needed |
| invoice-worker | Extraction and accounting workers | azure | Azure Functions | To be selected | Proposed | Implementation needed |
| invoice-extraction | Invoice field extraction | azure | Azure AI Document Intelligence | To be selected | Proposed | Implementation needed |
| invoice-accounting | Existing accounting API | tools | Existing accounting API | Existing location — unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| invoice-monitoring | Workflow monitoring and recovery alerts | azure | Azure Monitor | To be selected | Proposed | Implementation needed |
| invoice-secrets | Accounting credentials | azure | Azure Key Vault | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Invoice upload and review application** (invoice-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users.
- **Application sign-in and roles** (invoice-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Private invoice PDFs** (invoice-documents): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Invoice state and approval ledger** (invoice-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Extraction and approved-delivery queues** (invoice-broker): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Extraction and accounting workers** (invoice-worker): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-broker.
- **Invoice field extraction** (invoice-extraction): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Existing accounting API** (invoice-accounting): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Workflow monitoring and recovery alerts** (invoice-monitoring): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker, invoice-broker.
- **Accounting credentials** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.

### Engineering work remaining

- Invoice upload and review application: Implementation needed.
- Application sign-in and roles: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice state and approval ledger: Implementation needed.
- Extraction and approved-delivery queues: Implementation needed.
- Extraction and accounting workers: Implementation needed.
- Invoice field extraction: Implementation needed.
- Workflow monitoring and recovery alerts: Implementation needed.
- Accounting credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-broker: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-worker: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Uploaders and reviewers | Invoice upload and review application | HTTPS: signed-in uploads and review; only reviewers may approve | Confidential |
| Invoice upload and review application | Application sign-in and roles | OpenID Connect sign-in; server validates identity and uploader/reviewer roles | Confidential |
| Invoice upload and review application | Private invoice PDFs | Managed identity: private PDF upload and authorized reads | Confidential |
| Invoice upload and review application | Invoice state and approval ledger | SQL transactions: intake, review, authorized approval and outbox | Confidential |
| Extraction and accounting workers | Invoice state and approval ledger | Claim outbox/jobs; persist extraction, approval checks and delivery state | Confidential |
| Extraction and accounting workers | Extraction and approved-delivery queues | Managed identity: publish durable outbox jobs over AMQP/TLS | Confidential |
| Extraction and approved-delivery queues | Extraction and accounting workers | Service Bus triggers: locked delivery, retry and dead-letter recovery | Confidential |
| Extraction and accounting workers | Private invoice PDFs | Managed identity: read exact stored PDF reference | Confidential |
| Extraction and accounting workers | Invoice field extraction | HTTPS: submit PDF, persist operation ID and poll extraction | Confidential |
| Extraction and accounting workers | Existing accounting API | Authenticated HTTPS: approved payload and stable reference; reconcile uncertain  | Confidential |
| Invoice upload and review application | Workflow monitoring and recovery alerts | Correlated request, authorization and approval telemetry | Confidential |
| Extraction and accounting workers | Workflow monitoring and recovery alerts | Job failures, backlog and reconciliation telemetry | Confidential |
| Extraction and approved-delivery queues | Workflow monitoring and recovery alerts | Queue age and dead-letter metrics for recovery alerts | Confidential |
| Extraction and accounting workers | Accounting credentials | Managed identity over HTTPS: read scoped accounting credentials | Confidential |

## 5. Security controls

- **Uploaders and reviewers** — Existing people using browsers, outside provisioning scope: twenty signed-in staff and three reviewers, with membership overlap unspecified. Uploaders submit PDFs and view permitted records; ordinary uploaders cannot approve. Designated reviewers inspect source documents, correct extracted fields and approve a specific revision. User directory and operating owner remain unconfirmed.
- **Application sign-in and roles** — Proposed Microsoft Entra ID application registration and uploader/reviewer app roles for twenty signed-in staff and three reviewers; no existing tenant or company sign-in is assumed. Existing directory alignment and tenant inputs remain open. Reviewer privileges require explicit assignment; ordinary uploader membership grants no approval permission. Application validates tokens and authorizes each operation and document access; browser controls alone are insufficient. Directory integration, role assignment administration and authorization tests require implementation.
- **Accounting credentials** — Proposed Azure Key Vault holds administrator-supplied accounting credentials. An authorized administrator loads and rotates secrets through a separate administrative process; no secret values belong in the diagram, source code or Terraform state. Grant the worker managed identity read access only to required secrets, without secret-management privileges. Endpoint configuration stays separate from credentials. Provisioning, scoped access, secret loading instructions, rotation behavior and denied-access tests require engineering; the accounting authentication mechanism remains unverified.
- Requirement: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes. (must)
- Requirement: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior. (must)
- Open finding SEC-002: Sensitive data is involved but where it must be stored is not stated.

## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior. | security | not measurable yet | Open |

**Functional**

- For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures. (must, open)
- Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes. (must, open)
- Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Security & controls**

- [major] Sensitive data is involved but where it must be stored is not stated. Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks. _(AtMem AI Architect rule SEC-002 v1.0.0)_

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 9 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Application sign-in and roles | Checked requests | needs requests_per_month | price needed | — | — |
| Private invoice PDFs | Storage | needs data_gb | price needed | — | — |
| Invoice state and approval ledger | Storage | needs data_gb | price needed | — | — |
| Extraction and approved-delivery queues | Data processed | needs data_gb | price needed | — | — |
| Invoice field extraction | Endpoint hours | 730 hours | price needed | — | — |
| Accounting credentials | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Uploaders and reviewers, Invoice upload and review application, Extraction and accounting workers, Existing accounting API, Workflow monitoring and recovery alerts.

**Estimate gaps:**

- Application sign-in and roles / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: input needed (data_gb).
- Invoice state and approval ledger / Storage: input needed (data_gb).
- Extraction and approved-delivery queues / Data processed: input needed (data_gb).
- Invoice field extraction / Endpoint hours: price needed.
- Accounting credentials / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice upload and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Extraction and accounting workers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Workflow monitoring and recovery alerts: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision upload and review: Invoice upload and review application, Application sign-in and roles.
4. Provision durable records: Private invoice PDFs, Invoice state and approval ledger.
5. Provision background processing: Extraction and approved-delivery queues, Extraction and accounting workers, Invoice field extraction.
6. Provision accounting integration: Accounting credentials.
7. Provision operations: Workflow monitoring and recovery alerts.
8. Connect existing systems: Uploaders and reviewers, Existing accounting API; test failure behaviour.
9. Run the acceptance checks (success measures and requirements) in staging; record results.
10. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Application sign-in and roles: needs requests_per_month _(estimate)_
- Private invoice PDFs: needs data_gb _(estimate)_
- Invoice state and approval ledger: needs data_gb _(estimate)_
- Extraction and approved-delivery queues: needs data_gb _(estimate)_
- Invoice field extraction: needs a unit price with a source _(estimate)_
- Accounting credentials: needs requests_per_month _(estimate)_
