# Implementation Spec Kit

Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

7 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: azure

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Uploaders and reviewers (invoice-users): External browser — no infrastructure to provision; connection behavior still requires validation; tools, To be selected.
- Invoice upload and review application (invoice-app): Implementation needed; azure, To be selected.
- Application sign-in and roles (invoice-identity): Implementation needed; azure, To be selected.
- Private invoice PDFs (invoice-documents): Implementation needed; azure, To be selected.
- Invoice state and approval ledger (invoice-state): Implementation needed; azure, To be selected.
- Extraction and approved-delivery queues (invoice-broker): Implementation needed; azure, To be selected.
- Extraction and accounting workers (invoice-worker): Implementation needed; azure, To be selected.
- Invoice field extraction (invoice-extraction): Implementation needed; azure, To be selected.
- Existing accounting API (invoice-accounting): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — unconfirmed.
- Workflow monitoring and recovery alerts (invoice-monitoring): Implementation needed; azure, To be selected.
- Accounting credentials (invoice-secrets): Implementation needed; azure, To be selected.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
