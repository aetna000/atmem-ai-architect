# Component and interface contracts

Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component invoice-users: Uploaders and reviewers

- Responsibility: Existing people using browsers, outside provisioning scope: twenty signed-in staff and three reviewers, with membership overlap unspecified. Uploaders submit PDFs and view permitted records; ordinary uploaders cannot approve. Designated reviewers inspect source documents, correct extracted fields and approve a specific revision. User directory and operating owner remain unconfirmed.
- Service: Approval workflow
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component invoice-app: Invoice upload and review application

- Responsibility: Proposed Azure App Service deployment hosting browser UI and server API. Authenticates staff and enforces uploader/reviewer permissions server-side on every operation; ordinary uploaders cannot approve, including through direct API requests. Validates PDFs, assigns stable intake IDs and streams files to private storage. Presents permitted source PDFs, field confidence, corrections and review status. Approval atomically records the authorized reviewer, timestamp and immutable payload revision plus an outbox entry; edits invalidate approval. Uses managed identity for supported Azure access. Application, hosting dependencies, authorization and deployment modules require engineering, including denial tests for uploader approval attempts.
- Service: Azure App Service
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-identity: Application sign-in and roles

- Responsibility: Proposed Microsoft Entra ID application registration and uploader/reviewer app roles for twenty signed-in staff and three reviewers; no existing tenant or company sign-in is assumed. Existing directory alignment and tenant inputs remain open. Reviewer privileges require explicit assignment; ordinary uploader membership grants no approval permission. Application validates tokens and authorizes each operation and document access; browser controls alone are insufficient. Directory integration, role assignment administration and authorization tests require implementation.
- Service: Microsoft Entra ID
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-documents: Private invoice PDFs

- Responsibility: Private Azure Blob Storage for original PDFs with immutable object references per intake record. No anonymous access; application and worker receive scoped managed-identity permissions. Users access permitted PDFs through the application. Proposed content hashes flag identical uploads, without claiming to identify every duplicate business invoice. Lifecycle, retention and recovery policy await business constraints. This application-mediated storage path requires integration work and is not the standalone operator storage contract.
- Service: Azure Blob Storage
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d646f63756d656e7473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-state: Invoice state and approval ledger

- Responsibility: Azure SQL Database stores intake keys, document references, extracted fields, confidence, corrections, approval revisions, delivery attempts and accounting IDs. Unique constraints and conditional state transitions prevent duplicate intake and concurrent approval/submission. Transactions write workflow changes and outbox entries together. Durable review records are the review queue; broker messages are not the source of approval truth. Approved snapshots are immutable and retain reviewer identity and timestamp. Records of unknown accounting outcomes remain pending reconciliation. Backup, retention and restoration procedures require implementation and agreed targets.
- Service: Azure SQL Database
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-broker: Extraction and approved-delivery queues

- Responsibility: One Azure Service Bus namespace with separate extraction and accounting-delivery queues and their dead-letter subqueues. Messages carry stable job IDs and revision references, not raw invoice contents. Outbox publishing is retryable; consumers must tolerate redelivery even if broker duplicate detection is enabled. Bounded delivery attempts, lock renewal, dead-letter inspection and controlled replay require application implementation. Approval is verified against SQL state before an accounting call.
- Service: Azure Service Bus
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d62726f6b6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-worker: Extraction and accounting workers

- Responsibility: One Azure Functions application owns outbox dispatch, asynchronous extraction and approved accounting delivery. Extraction reads the exact stored PDF, submits and polls Document Intelligence, maps supplier/date/total/currency and durably records results or reviewable errors. Accounting delivery verifies the authorized approval and exact revision, reserves work atomically and submits a stable external reference. Retries use bounded backoff; ambiguous accounting outcomes require reconciliation rather than blind resubmission. Proposed modules share one deployment initially. Administrator supplies the external accounting endpoint as configuration and credentials through Key Vault; worker reads only required secrets through managed identity and fails closed when configuration or credentials are unavailable. Required Functions storage, runtime logging, rotation handling and all worker code remain implementation tasks; credentials must never appear in the graph or telemetry.
- Service: Azure Functions
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d776f726b6572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-extraction: Invoice field extraction

- Responsibility: Azure AI Document Intelligence with the prebuilt invoice model is proposed for PDF field extraction. Worker maps supplier, invoice date, total and currency into the review schema, preserving missing values and confidence rather than inventing data. All results require human approval. Model/API version, regional processing availability, supported currencies and representative-document accuracy need verification. PDF content is untrusted input. No managed extraction integration is currently generated.
- Service: Azure AI Document Intelligence
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d65787472616374696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-accounting: Existing accounting API

- Responsibility: Client's existing accounting API, retained outside provisioning scope and not recreated, imported or modified. An administrator will supply its endpoint and credentials through deployment configuration and the proposed secret-management process. Receives only approved invoice revisions. Authentication mechanism, request schema, idempotency-key support, unique external reference enforcement and reference lookup remain unverified. Integration must test the case where accounting commits but the response is lost; duplicate-free recovery cannot be claimed without a suitable API contract or reconciliation process.
- Service: Existing accounting API
- Provider / placement: tools / Existing location — unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d6163636f756e74696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component invoice-monitoring: Workflow monitoring and recovery alerts

- Responsibility: Azure Monitor collects correlated application and worker telemetry and alerts on dead-letter messages, stalled extraction, outbox backlog and unresolved accounting submissions. Avoid raw PDF contents, invoice fields and credentials in telemetry. Alert recipients, operating ownership, log retention and recovery objectives remain open. Instrumentation, alert rules and replay/reconciliation runbooks require implementation; this node does not prove monitoring works.
- Service: Azure Monitor
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-secrets: Accounting credentials

- Responsibility: Proposed Azure Key Vault holds administrator-supplied accounting credentials. An authorized administrator loads and rotates secrets through a separate administrative process; no secret values belong in the diagram, source code or Terraform state. Grant the worker managed identity read access only to required secrets, without secret-management privileges. Endpoint configuration stays separate from credentials. Provisioning, scoped access, secret loading instructions, rotation behavior and denied-access tests require engineering; the accounting authentication mechanism remains unverified.
- Service: Azure Key Vault
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### users-app: invoice-users → invoice-app

- Drawn payload/purpose: HTTPS: signed-in uploads and review; only reviewers may approve
- Contract task: TASK-CONTRACT-75736572732d617070
- Integration task: TASK-INTEGRATION-75736572732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: invoice-app → invoice-identity

- Drawn payload/purpose: OpenID Connect sign-in; server validates identity and uploader/reviewer roles
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-documents: invoice-app → invoice-documents

- Drawn payload/purpose: Managed identity: private PDF upload and authorized reads
- Contract task: TASK-CONTRACT-6170702d646f63756d656e7473
- Integration task: TASK-INTEGRATION-6170702d646f63756d656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-state: invoice-app → invoice-state

- Drawn payload/purpose: SQL transactions: intake, review, authorized approval and outbox
- Contract task: TASK-CONTRACT-6170702d7374617465
- Integration task: TASK-INTEGRATION-6170702d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-state: invoice-worker → invoice-state

- Drawn payload/purpose: Claim outbox/jobs; persist extraction, approval checks and delivery state
- Contract task: TASK-CONTRACT-776f726b65722d7374617465
- Integration task: TASK-INTEGRATION-776f726b65722d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-publish: invoice-worker → invoice-broker

- Drawn payload/purpose: Managed identity: publish durable outbox jobs over AMQP/TLS
- Contract task: TASK-CONTRACT-776f726b65722d7075626c697368
- Integration task: TASK-INTEGRATION-776f726b65722d7075626c697368
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### broker-worker: invoice-broker → invoice-worker

- Drawn payload/purpose: Service Bus triggers: locked delivery, retry and dead-letter recovery
- Contract task: TASK-CONTRACT-62726f6b65722d776f726b6572
- Integration task: TASK-INTEGRATION-62726f6b65722d776f726b6572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-documents: invoice-worker → invoice-documents

- Drawn payload/purpose: Managed identity: read exact stored PDF reference
- Contract task: TASK-CONTRACT-776f726b65722d646f63756d656e7473
- Integration task: TASK-INTEGRATION-776f726b65722d646f63756d656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-extraction: invoice-worker → invoice-extraction

- Drawn payload/purpose: HTTPS: submit PDF, persist operation ID and poll extraction
- Contract task: TASK-CONTRACT-776f726b65722d65787472616374696f6e
- Integration task: TASK-INTEGRATION-776f726b65722d65787472616374696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-accounting: invoice-worker → invoice-accounting

- Drawn payload/purpose: Authenticated HTTPS: approved payload and stable reference; reconcile uncertain 
- Contract task: TASK-CONTRACT-776f726b65722d6163636f756e74696e67
- Integration task: TASK-INTEGRATION-776f726b65722d6163636f756e74696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-monitoring: invoice-app → invoice-monitoring

- Drawn payload/purpose: Correlated request, authorization and approval telemetry
- Contract task: TASK-CONTRACT-6170702d6d6f6e69746f72696e67
- Integration task: TASK-INTEGRATION-6170702d6d6f6e69746f72696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-monitoring: invoice-worker → invoice-monitoring

- Drawn payload/purpose: Job failures, backlog and reconciliation telemetry
- Contract task: TASK-CONTRACT-776f726b65722d6d6f6e69746f72696e67
- Integration task: TASK-INTEGRATION-776f726b65722d6d6f6e69746f72696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### broker-monitoring: invoice-broker → invoice-monitoring

- Drawn payload/purpose: Queue age and dead-letter metrics for recovery alerts
- Contract task: TASK-CONTRACT-62726f6b65722d6d6f6e69746f72696e67
- Integration task: TASK-INTEGRATION-62726f6b65722d6d6f6e69746f72696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### worker-secrets: invoice-worker → invoice-secrets

- Drawn payload/purpose: Managed identity over HTTPS: read scoped accounting credentials
- Contract task: TASK-CONTRACT-776f726b65722d73656372657473
- Integration task: TASK-INTEGRATION-776f726b65722d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
