# Questions and assumptions to resolve

Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

- [ai-invoice-extraction] Confirm REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.
- [ai-invoice-approval] Confirm REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.
- [ai-invoice-idempotency] Confirm REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.
- [ai-invoice-accounting-boundary] Confirm REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.
- [acceptance-ai-invoice-extraction] Agree a measurable acceptance check for REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.
- [acceptance-ai-invoice-approval] Agree a measurable acceptance check for REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.
- [acceptance-ai-invoice-idempotency] Agree a measurable acceptance check for REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.
- [acceptance-ai-invoice-accounting-boundary] Agree a measurable acceptance check for REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d696e766f6963652d617070726f76616c] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d696e766f6963652d65787472616374696f6e] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d696e766f6963652d6964656d706f74656e6379] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
