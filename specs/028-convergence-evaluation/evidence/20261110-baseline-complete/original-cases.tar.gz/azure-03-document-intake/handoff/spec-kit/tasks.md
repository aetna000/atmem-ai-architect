# Detailed implementation tasks

Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-75736572732d617070 — Define Uploaders and reviewers → Invoice upload and review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-app: HTTPS: signed-in uploads and review; only reviewers may approve. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6964656e74697479 — Define Invoice upload and review application → Application sign-in and roles

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-identity: OpenID Connect sign-in; server validates identity and uploader/reviewer roles. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-identity
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d646f63756d656e7473 — Define Invoice upload and review application → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-documents: Managed identity: private PDF upload and authorized reads. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-documents
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d7374617465 — Define Invoice upload and review application → Invoice state and approval ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-state: SQL transactions: intake, review, authorized approval and outbox. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d7374617465 — Define Extraction and accounting workers → Invoice state and approval ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-state: Claim outbox/jobs; persist extraction, approval checks and delivery state. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d7075626c697368 — Define Extraction and accounting workers → Extraction and approved-delivery queues

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-broker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-publish: Managed identity: publish durable outbox jobs over AMQP/TLS. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-publish
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-62726f6b65722d776f726b6572 — Define Extraction and approved-delivery queues → Extraction and accounting workers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-broker, invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection broker-worker: Service Bus triggers: locked delivery, retry and dead-letter recovery. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge broker-worker
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d646f63756d656e7473 — Define Extraction and accounting workers → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-documents: Managed identity: read exact stored PDF reference. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-documents
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d65787472616374696f6e — Define Extraction and accounting workers → Invoice field extraction

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-extraction
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-extraction: HTTPS: submit PDF, persist operation ID and poll extraction. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-extraction
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d6163636f756e74696e67 — Define Extraction and accounting workers → Existing accounting API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-accounting
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-accounting: Authenticated HTTPS: approved payload and stable reference; reconcile uncertain . Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-accounting
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6d6f6e69746f72696e67 — Define Invoice upload and review application → Workflow monitoring and recovery alerts

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-monitoring: Correlated request, authorization and approval telemetry. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-monitoring
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d6d6f6e69746f72696e67 — Define Extraction and accounting workers → Workflow monitoring and recovery alerts

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-monitoring: Job failures, backlog and reconciliation telemetry. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-monitoring
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-62726f6b65722d6d6f6e69746f72696e67 — Define Extraction and approved-delivery queues → Workflow monitoring and recovery alerts

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-broker, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection broker-monitoring: Queue age and dead-letter metrics for recovery alerts. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge broker-monitoring
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-776f726b65722d73656372657473 — Define Extraction and accounting workers → Accounting credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection worker-secrets: Managed identity over HTTPS: read scoped accounting credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge worker-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-696e766f6963652d7573657273 — Integrate existing Uploaders and reviewers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d617070
- Components: invoice-users
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing people using browsers, outside provisioning scope: twenty signed-in staff and three reviewers, with membership overlap unspecified. Uploaders submit PDFs and view permitted records; ordinary uploaders cannot approve. Designated reviewers inspect source documents, correct extracted fields and approve a specific revision. User directory and operating owner remain unconfirmed.
2. Verify Approval workflow on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-users
- Application/configuration and tests for Uploaders and reviewers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d617070 — Implement Invoice upload and review application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d617070, TASK-CONTRACT-6170702d6964656e74697479, TASK-CONTRACT-6170702d646f63756d656e7473, TASK-CONTRACT-6170702d7374617465, TASK-CONTRACT-6170702d6d6f6e69746f72696e67
- Components: invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Proposed Azure App Service deployment hosting browser UI and server API. Authenticates staff and enforces uploader/reviewer permissions server-side on every operation; ordinary uploaders cannot approve, including through direct API requests. Validates PDFs, assigns stable intake IDs and streams files to private storage. Presents permitted source PDFs, field confidence, corrections and review status. Approval atomically records the authorized reviewer, timestamp and immutable payload revision plus an outbox entry; edits invalidate approval. Uses managed identity for supported Azure access. Application, hosting dependencies, authorization and deployment modules require engineering, including denial tests for uploader approval attempts.
2. Verify Azure App Service on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure App Service; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.; REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-app
- Application/configuration and tests for Invoice upload and review application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6964656e74697479 — Implement Application sign-in and roles

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6964656e74697479
- Components: invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Proposed Microsoft Entra ID application registration and uploader/reviewer app roles for twenty signed-in staff and three reviewers; no existing tenant or company sign-in is assumed. Existing directory alignment and tenant inputs remain open. Reviewer privileges require explicit assignment; ordinary uploader membership grants no approval permission. Application validates tokens and authorizes each operation and document access; browser controls alone are insufficient. Directory integration, role assignment administration and authorization tests require implementation.
2. Verify Microsoft Entra ID on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Microsoft Entra ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-identity
- Application/configuration and tests for Application sign-in and roles

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d646f63756d656e7473 — Implement Private invoice PDFs

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d646f63756d656e7473, TASK-CONTRACT-776f726b65722d646f63756d656e7473
- Components: invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Responsibility from the board: Private Azure Blob Storage for original PDFs with immutable object references per intake record. No anonymous access; application and worker receive scoped managed-identity permissions. Users access permitted PDFs through the application. Proposed content hashes flag identical uploads, without claiming to identify every duplicate business invoice. Lifecycle, retention and recovery policy await business constraints. This application-mediated storage path requires integration work and is not the standalone operator storage contract.
2. Verify Azure Blob Storage on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Blob Storage; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-documents
- Application/configuration and tests for Private invoice PDFs

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d7374617465 — Implement Invoice state and approval ledger

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d7374617465, TASK-CONTRACT-776f726b65722d7374617465
- Components: invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-approval, ai-invoice-idempotency

### Implementation steps

1. Responsibility from the board: Azure SQL Database stores intake keys, document references, extracted fields, confidence, corrections, approval revisions, delivery attempts and accounting IDs. Unique constraints and conditional state transitions prevent duplicate intake and concurrent approval/submission. Transactions write workflow changes and outbox entries together. Durable review records are the review queue; broker messages are not the source of approval truth. Approved snapshots are immutable and retain reviewer identity and timestamp. Records of unknown accounting outcomes remain pending reconciliation. Backup, retention and restoration procedures require implementation and agreed targets.
2. Verify Azure SQL Database on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure SQL Database; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.; REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.; REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-state
- Application/configuration and tests for Invoice state and approval ledger

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d62726f6b6572 — Implement Extraction and approved-delivery queues

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d7075626c697368, TASK-CONTRACT-62726f6b65722d776f726b6572, TASK-CONTRACT-62726f6b65722d6d6f6e69746f72696e67
- Components: invoice-broker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-idempotency

### Implementation steps

1. Responsibility from the board: One Azure Service Bus namespace with separate extraction and accounting-delivery queues and their dead-letter subqueues. Messages carry stable job IDs and revision references, not raw invoice contents. Outbox publishing is retryable; consumers must tolerate redelivery even if broker duplicate detection is enabled. Bounded delivery attempts, lock renewal, dead-letter inspection and controlled replay require application implementation. Approval is verified against SQL state before an accounting call.
2. Verify Azure Service Bus on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Service Bus; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-broker
- Application/configuration and tests for Extraction and approved-delivery queues

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d776f726b6572 — Implement Extraction and accounting workers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d7374617465, TASK-CONTRACT-776f726b65722d7075626c697368, TASK-CONTRACT-62726f6b65722d776f726b6572, TASK-CONTRACT-776f726b65722d646f63756d656e7473, TASK-CONTRACT-776f726b65722d65787472616374696f6e, TASK-CONTRACT-776f726b65722d6163636f756e74696e67, TASK-CONTRACT-776f726b65722d6d6f6e69746f72696e67, TASK-CONTRACT-776f726b65722d73656372657473
- Components: invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-approval, ai-invoice-idempotency, ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: One Azure Functions application owns outbox dispatch, asynchronous extraction and approved accounting delivery. Extraction reads the exact stored PDF, submits and polls Document Intelligence, maps supplier/date/total/currency and durably records results or reviewable errors. Accounting delivery verifies the authorized approval and exact revision, reserves work atomically and submits a stable external reference. Retries use bounded backoff; ambiguous accounting outcomes require reconciliation rather than blind resubmission. Proposed modules share one deployment initially. Administrator supplies the external accounting endpoint as configuration and credentials through Key Vault; worker reads only required secrets through managed identity and fails closed when configuration or credentials are unavailable. Required Functions storage, runtime logging, rotation handling and all worker code remain implementation tasks; credentials must never appear in the graph or telemetry.
2. Verify Azure Functions on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Functions; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.; REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.; REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-worker
- Application/configuration and tests for Extraction and accounting workers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d65787472616374696f6e — Implement Invoice field extraction

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d65787472616374696f6e
- Components: invoice-extraction
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Responsibility from the board: Azure AI Document Intelligence with the prebuilt invoice model is proposed for PDF field extraction. Worker maps supplier, invoice date, total and currency into the review schema, preserving missing values and confidence rather than inventing data. All results require human approval. Model/API version, regional processing availability, supported currencies and representative-document accuracy need verification. PDF content is untrusted input. No managed extraction integration is currently generated.
2. Verify Azure AI Document Intelligence on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure AI Document Intelligence; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-extraction
- Application/configuration and tests for Invoice field extraction

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6163636f756e74696e67 — Integrate existing Existing accounting API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d6163636f756e74696e67
- Components: invoice-accounting
- Generated files: No implementation files generated yet
- Requirements: ai-invoice-approval, ai-invoice-idempotency, ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Client's existing accounting API, retained outside provisioning scope and not recreated, imported or modified. An administrator will supply its endpoint and credentials through deployment configuration and the proposed secret-management process. Receives only approved invoice revisions. Authentication mechanism, request schema, idempotency-key support, unique external reference enforcement and reference lookup remain unverified. Integration must test the case where accounting commits but the response is lost; duplicate-free recovery cannot be claimed without a suitable API contract or reconciliation process.
2. Verify Existing accounting API on tools in Existing location — unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.; REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-accounting
- Application/configuration and tests for Existing accounting API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67 — Implement Workflow monitoring and recovery alerts

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6d6f6e69746f72696e67, TASK-CONTRACT-776f726b65722d6d6f6e69746f72696e67, TASK-CONTRACT-62726f6b65722d6d6f6e69746f72696e67
- Components: invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Azure Monitor collects correlated application and worker telemetry and alerts on dead-letter messages, stalled extraction, outbox backlog and unresolved accounting submissions. Avoid raw PDF contents, invoice fields and credentials in telemetry. Alert recipients, operating ownership, log retention and recovery objectives remain open. Instrumentation, alert rules and replay/reconciliation runbooks require implementation; this node does not prove monitoring works.
2. Verify Azure Monitor on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Monitor; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-monitoring
- Application/configuration and tests for Workflow monitoring and recovery alerts

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d73656372657473 — Implement Accounting credentials

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-776f726b65722d73656372657473
- Components: invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Proposed Azure Key Vault holds administrator-supplied accounting credentials. An authorized administrator loads and rotates secrets through a separate administrative process; no secret values belong in the diagram, source code or Terraform state. Grant the worker managed identity read access only to required secrets, without secret-management privileges. Endpoint configuration stays separate from credentials. Provisioning, scoped access, secret loading instructions, rotation behavior and denied-access tests require engineering; the accounting authentication mechanism remains unverified.
2. Verify Azure Key Vault on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Key Vault; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-secrets
- Application/configuration and tests for Accounting credentials

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-75736572732d617070 — Wire Uploaders and reviewers to Invoice upload and review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d617070, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-app carrying HTTPS: signed-in uploads and review; only reviewers may approve, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6964656e74697479 — Wire Invoice upload and review application to Application sign-in and roles

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6964656e74697479, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-identity carrying OpenID Connect sign-in; server validates identity and uploader/reviewer roles, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-identity
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d646f63756d656e7473 — Wire Invoice upload and review application to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d646f63756d656e7473
- Components: invoice-app, invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-documents carrying Managed identity: private PDF upload and authorized reads, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-documents
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d7374617465 — Wire Invoice upload and review application to Invoice state and approval ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d7374617465, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d7374617465
- Components: invoice-app, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-state carrying SQL transactions: intake, review, authorized approval and outbox, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d7374617465 — Wire Extraction and accounting workers to Invoice state and approval ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d7374617465, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d776f726b6572
- Components: invoice-worker, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-state carrying Claim outbox/jobs; persist extraction, approval checks and delivery state, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d7075626c697368 — Wire Extraction and accounting workers to Extraction and approved-delivery queues

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d7075626c697368, TASK-RESOURCE-696e766f6963652d62726f6b6572, TASK-RESOURCE-696e766f6963652d776f726b6572
- Components: invoice-worker, invoice-broker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-publish carrying Managed identity: publish durable outbox jobs over AMQP/TLS, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-publish
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-62726f6b65722d776f726b6572 — Wire Extraction and approved-delivery queues to Extraction and accounting workers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f6b65722d776f726b6572, TASK-RESOURCE-696e766f6963652d62726f6b6572, TASK-RESOURCE-696e766f6963652d776f726b6572
- Components: invoice-broker, invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge broker-worker carrying Service Bus triggers: locked delivery, retry and dead-letter recovery, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation broker-worker
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d646f63756d656e7473 — Wire Extraction and accounting workers to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d776f726b6572
- Components: invoice-worker, invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-documents carrying Managed identity: read exact stored PDF reference, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-documents
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d65787472616374696f6e — Wire Extraction and accounting workers to Invoice field extraction

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d65787472616374696f6e
- Components: invoice-worker, invoice-extraction
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-extraction carrying HTTPS: submit PDF, persist operation ID and poll extraction, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-extraction
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d6163636f756e74696e67 — Wire Extraction and accounting workers to Existing accounting API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67
- Components: invoice-worker, invoice-accounting
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-accounting carrying Authenticated HTTPS: approved payload and stable reference; reconcile uncertain , using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-accounting
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6d6f6e69746f72696e67 — Wire Invoice upload and review application to Workflow monitoring and recovery alerts

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6d6f6e69746f72696e67, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67
- Components: invoice-app, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-monitoring carrying Correlated request, authorization and approval telemetry, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-monitoring
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d6d6f6e69746f72696e67 — Wire Extraction and accounting workers to Workflow monitoring and recovery alerts

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d6d6f6e69746f72696e67, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67
- Components: invoice-worker, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-monitoring carrying Job failures, backlog and reconciliation telemetry, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-monitoring
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-62726f6b65722d6d6f6e69746f72696e67 — Wire Extraction and approved-delivery queues to Workflow monitoring and recovery alerts

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f6b65722d6d6f6e69746f72696e67, TASK-RESOURCE-696e766f6963652d62726f6b6572, TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67
- Components: invoice-broker, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge broker-monitoring carrying Queue age and dead-letter metrics for recovery alerts, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation broker-monitoring
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-776f726b65722d73656372657473 — Wire Extraction and accounting workers to Accounting credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-776f726b65722d73656372657473, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d73656372657473
- Components: invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge worker-secrets carrying Managed identity over HTTPS: read scoped accounting credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation worker-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-75736572732d617070 — Verify live Uploaders and reviewers → Invoice upload and review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d617070
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6964656e74697479 — Verify live Invoice upload and review application → Application sign-in and roles

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6964656e74697479
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-identity with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-identity

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d646f63756d656e7473 — Verify live Invoice upload and review application → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d646f63756d656e7473
- Components: invoice-app, invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-documents with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-documents

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d7374617465 — Verify live Invoice upload and review application → Invoice state and approval ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d7374617465
- Components: invoice-app, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d7374617465 — Verify live Extraction and accounting workers → Invoice state and approval ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d7374617465
- Components: invoice-worker, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368 — Verify live Extraction and accounting workers → Extraction and approved-delivery queues

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d7075626c697368
- Components: invoice-worker, invoice-broker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-publish with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-publish

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572 — Verify live Extraction and approved-delivery queues → Extraction and accounting workers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f6b65722d776f726b6572
- Components: invoice-broker, invoice-worker
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge broker-worker with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence broker-worker

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473 — Verify live Extraction and accounting workers → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d646f63756d656e7473
- Components: invoice-worker, invoice-documents
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-documents with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-documents

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e — Verify live Extraction and accounting workers → Invoice field extraction

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d65787472616374696f6e
- Components: invoice-worker, invoice-extraction
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-extraction with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-extraction

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67 — Verify live Extraction and accounting workers → Existing accounting API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d6163636f756e74696e67
- Components: invoice-worker, invoice-accounting
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-accounting with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-accounting

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6d6f6e69746f72696e67 — Verify live Invoice upload and review application → Workflow monitoring and recovery alerts

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6d6f6e69746f72696e67
- Components: invoice-app, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-monitoring with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-monitoring

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67 — Verify live Extraction and accounting workers → Workflow monitoring and recovery alerts

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d6d6f6e69746f72696e67
- Components: invoice-worker, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-monitoring with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-monitoring

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-62726f6b65722d6d6f6e69746f72696e67 — Verify live Extraction and approved-delivery queues → Workflow monitoring and recovery alerts

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f6b65722d6d6f6e69746f72696e67
- Components: invoice-broker, invoice-monitoring
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge broker-monitoring with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence broker-monitoring

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-776f726b65722d73656372657473 — Verify live Extraction and accounting workers → Accounting credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-776f726b65722d73656372657473
- Components: invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge worker-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence worker-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e — Verify REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d65787472616374696f6e, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368, TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473
- Components: invoice-app, invoice-documents, invoice-worker, invoice-extraction, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.”; rationale: Makes extraction useful while ensuring missing or uncertain values remain visible for human correction.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c — Verify REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368, TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473
- Components: invoice-app, invoice-identity, invoice-state, invoice-worker, invoice-accounting
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Basis: “A reviewer approves a result before it is sent to our existing accounting API.”; rationale: Prevents unapproved or subsequently edited results from reaching accounting; revision binding and audit records are proposed enforcement details.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379 — Verify REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d62726f6b6572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368, TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-62726f6b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473
- Components: invoice-state, invoice-broker, invoice-worker, invoice-accounting
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-idempotency

### Implementation steps

1. Basis: “Delivery can repeat; retries must not create duplicate invoices.”; rationale: Broker redelivery, concurrent workers and lost accounting responses can create duplicates. Local deduplication alone cannot guarantee duplicate-free external submission; the accounting contract needs confirmation.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279 — Verify REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368, TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473
- Components: invoice-accounting, invoice-worker, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-accounting-boundary

### Implementation steps

1. Basis: “An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.” Supports invoice-accounting, invoice-worker and proposed invoice-secrets.; rationale: Proposed credential control prevents accounting secrets from reaching browsers, exports or logs and limits credential exposure to the delivery runtime.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d62726f6b6572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-INTEGRATION-75736572732d617070, TASK-INTEGRATION-6170702d6964656e74697479, TASK-INTEGRATION-6170702d646f63756d656e7473, TASK-INTEGRATION-6170702d7374617465, TASK-INTEGRATION-776f726b65722d7374617465, TASK-INTEGRATION-776f726b65722d7075626c697368, TASK-INTEGRATION-62726f6b65722d776f726b6572, TASK-INTEGRATION-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-6170702d6d6f6e69746f72696e67, TASK-INTEGRATION-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-62726f6b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-776f726b65722d73656372657473
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d646f63756d656e7473, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d62726f6b6572, TASK-RESOURCE-696e766f6963652d776f726b6572, TASK-RESOURCE-696e766f6963652d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d6d6f6e69746f72696e67, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368, TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-62726f6b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e, TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c, TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379, TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d646f63756d656e7473, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7374617465, TASK-INTEGRATION-LIVE-776f726b65722d7075626c697368, TASK-INTEGRATION-LIVE-62726f6b65722d776f726b6572, TASK-INTEGRATION-LIVE-776f726b65722d646f63756d656e7473, TASK-INTEGRATION-LIVE-776f726b65722d65787472616374696f6e, TASK-INTEGRATION-LIVE-776f726b65722d6163636f756e74696e67, TASK-INTEGRATION-LIVE-6170702d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-62726f6b65722d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-776f726b65722d73656372657473
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
