# Infrastructure implementation required

Requested providers: azure. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Invoice upload and review application: Implementation needed.
- Application sign-in and roles: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice state and approval ledger: Implementation needed.
- Extraction and approved-delivery queues: Implementation needed.
- Extraction and accounting workers: Implementation needed.
- Invoice field extraction: Implementation needed.
- Workflow monitoring and recovery alerts: Implementation needed.
- Accounting credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-broker: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-worker: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
