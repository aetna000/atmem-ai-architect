Snapshot b5664303-c4d4-43ef-a35d-95ce934e2039 · design r3 · generated 2026-11-09T17:18:18.213Z

# Asynchronous document intake — solution specification

## Problem and intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-documents, invoice-worker, invoice-extraction, invoice-state

Design explanation: Makes extraction useful while ensuring missing or uncertain values remain visible for human correction.

Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.”
- [REQ-004] Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-identity, invoice-state, invoice-worker, invoice-accounting

Design explanation: Prevents unapproved or subsequently edited results from reaching accounting; revision binding and audit records are proposed enforcement details.

Basis: “A reviewer approves a result before it is sent to our existing accounting API.”
- [REQ-005] Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract. (must, open); target: acceptance target needed; linked blocks: invoice-state, invoice-broker, invoice-worker, invoice-accounting

Design explanation: Broker redelivery, concurrent workers and lost accounting responses can create duplicates. Local deduplication alone cannot guarantee duplicate-free external submission; the accounting contract needs confirmation.

Basis: “Delivery can repeat; retries must not create duplicate invoices.”
- [REQ-006] Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior. (must, open); target: acceptance target needed; linked blocks: invoice-accounting, invoice-worker, invoice-secrets

Design explanation: Proposed credential control prevents accounting secrets from reaching browsers, exports or logs and limits credential exposure to the delivery runtime.

Basis: “An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.” Supports invoice-accounting, invoice-worker and proposed invoice-secrets.

## How the system works

The current design contains 11 components and 14 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Uploaders and reviewers → Invoice upload and review application

HTTPS: signed-in uploads and review; only reviewers may approve

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Invoice upload and review application → Application sign-in and roles

OpenID Connect sign-in; server validates identity and uploader/reviewer roles

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Invoice upload and review application → Private invoice PDFs

Managed identity: private PDF upload and authorized reads

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Invoice upload and review application → Invoice state and approval ledger

SQL transactions: intake, review, authorized approval and outbox

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Extraction and accounting workers → Invoice state and approval ledger

Claim outbox/jobs; persist extraction, approval checks and delivery state

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Extraction and accounting workers → Extraction and approved-delivery queues

Managed identity: publish durable outbox jobs over AMQP/TLS

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Extraction and approved-delivery queues → Extraction and accounting workers

Service Bus triggers: locked delivery, retry and dead-letter recovery

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Extraction and accounting workers → Private invoice PDFs

Managed identity: read exact stored PDF reference

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Extraction and accounting workers → Invoice field extraction

HTTPS: submit PDF, persist operation ID and poll extraction

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Extraction and accounting workers → Existing accounting API

Authenticated HTTPS: approved payload and stable reference; reconcile uncertain 

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Invoice upload and review application → Workflow monitoring and recovery alerts

Correlated request, authorization and approval telemetry

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Extraction and accounting workers → Workflow monitoring and recovery alerts

Job failures, backlog and reconciliation telemetry

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Extraction and approved-delivery queues → Workflow monitoring and recovery alerts

Queue age and dead-letter metrics for recovery alerts

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Extraction and accounting workers → Accounting credentials

Managed identity over HTTPS: read scoped accounting credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Uploaders and reviewers

Approval workflow · tools · region: To be selected · classification: Confidential

Existing people using browsers, outside provisioning scope: twenty signed-in staff and three reviewers, with membership overlap unspecified. Uploaders submit PDFs and view permitted records; ordinary uploaders cannot approve. Designated reviewers inspect source documents, correct extracted fields and approve a specific revision. User directory and operating owner remain unconfirmed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Uploaders and reviewers → Invoice upload and review application: HTTPS: signed-in uploads and review; only reviewers may approve

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Invoice upload and review application

Azure App Service · azure · region: To be selected · classification: Confidential

Proposed Azure App Service deployment hosting browser UI and server API. Authenticates staff and enforces uploader/reviewer permissions server-side on every operation; ordinary uploaders cannot approve, including through direct API requests. Validates PDFs, assigns stable intake IDs and streams files to private storage. Presents permitted source PDFs, field confidence, corrections and review status. Approval atomically records the authorized reviewer, timestamp and immutable payload revision plus an outbox entry; edits invalidate approval. Uses managed identity for supported Azure access. Application, hosting dependencies, authorization and deployment modules require engineering, including denial tests for uploader approval attempts.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Uploaders and reviewers → Invoice upload and review application: HTTPS: signed-in uploads and review; only reviewers may approve

Outputs: Invoice upload and review application → Application sign-in and roles: OpenID Connect sign-in; server validates identity and uploader/reviewer roles; Invoice upload and review application → Private invoice PDFs: Managed identity: private PDF upload and authorized reads; Invoice upload and review application → Invoice state and approval ledger: SQL transactions: intake, review, authorized approval and outbox; Invoice upload and review application → Workflow monitoring and recovery alerts: Correlated request, authorization and approval telemetry

Requirement traceability: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.; REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Application sign-in and roles

Microsoft Entra ID · azure · region: To be selected · classification: Internal

Proposed Microsoft Entra ID application registration and uploader/reviewer app roles for twenty signed-in staff and three reviewers; no existing tenant or company sign-in is assumed. Existing directory alignment and tenant inputs remain open. Reviewer privileges require explicit assignment; ordinary uploader membership grants no approval permission. Application validates tokens and authorizes each operation and document access; browser controls alone are insufficient. Directory integration, role assignment administration and authorization tests require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Application sign-in and roles: OpenID Connect sign-in; server validates identity and uploader/reviewer roles

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Private invoice PDFs

Azure Blob Storage · azure · region: To be selected · classification: Confidential

Private Azure Blob Storage for original PDFs with immutable object references per intake record. No anonymous access; application and worker receive scoped managed-identity permissions. Users access permitted PDFs through the application. Proposed content hashes flag identical uploads, without claiming to identify every duplicate business invoice. Lifecycle, retention and recovery policy await business constraints. This application-mediated storage path requires integration work and is not the standalone operator storage contract.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Private invoice PDFs: Managed identity: private PDF upload and authorized reads; Extraction and accounting workers → Private invoice PDFs: Managed identity: read exact stored PDF reference

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Invoice state and approval ledger

Azure SQL Database · azure · region: To be selected · classification: Confidential

Azure SQL Database stores intake keys, document references, extracted fields, confidence, corrections, approval revisions, delivery attempts and accounting IDs. Unique constraints and conditional state transitions prevent duplicate intake and concurrent approval/submission. Transactions write workflow changes and outbox entries together. Durable review records are the review queue; broker messages are not the source of approval truth. Approved snapshots are immutable and retain reviewer identity and timestamp. Records of unknown accounting outcomes remain pending reconciliation. Backup, retention and restoration procedures require implementation and agreed targets.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Invoice state and approval ledger: SQL transactions: intake, review, authorized approval and outbox; Extraction and accounting workers → Invoice state and approval ledger: Claim outbox/jobs; persist extraction, approval checks and delivery state

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.; REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.; REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Extraction and approved-delivery queues

Azure Service Bus · azure · region: To be selected · classification: Confidential

One Azure Service Bus namespace with separate extraction and accounting-delivery queues and their dead-letter subqueues. Messages carry stable job IDs and revision references, not raw invoice contents. Outbox publishing is retryable; consumers must tolerate redelivery even if broker duplicate detection is enabled. Bounded delivery attempts, lock renewal, dead-letter inspection and controlled replay require application implementation. Approval is verified against SQL state before an accounting call.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and accounting workers → Extraction and approved-delivery queues: Managed identity: publish durable outbox jobs over AMQP/TLS

Outputs: Extraction and approved-delivery queues → Extraction and accounting workers: Service Bus triggers: locked delivery, retry and dead-letter recovery; Extraction and approved-delivery queues → Workflow monitoring and recovery alerts: Queue age and dead-letter metrics for recovery alerts

Requirement traceability: REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Extraction and accounting workers

Azure Functions · azure · region: To be selected · classification: Confidential

One Azure Functions application owns outbox dispatch, asynchronous extraction and approved accounting delivery. Extraction reads the exact stored PDF, submits and polls Document Intelligence, maps supplier/date/total/currency and durably records results or reviewable errors. Accounting delivery verifies the authorized approval and exact revision, reserves work atomically and submits a stable external reference. Retries use bounded backoff; ambiguous accounting outcomes require reconciliation rather than blind resubmission. Proposed modules share one deployment initially. Administrator supplies the external accounting endpoint as configuration and credentials through Key Vault; worker reads only required secrets through managed identity and fails closed when configuration or credentials are unavailable. Required Functions storage, runtime logging, rotation handling and all worker code remain implementation tasks; credentials must never appear in the graph or telemetry.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and approved-delivery queues → Extraction and accounting workers: Service Bus triggers: locked delivery, retry and dead-letter recovery

Outputs: Extraction and accounting workers → Invoice state and approval ledger: Claim outbox/jobs; persist extraction, approval checks and delivery state; Extraction and accounting workers → Extraction and approved-delivery queues: Managed identity: publish durable outbox jobs over AMQP/TLS; Extraction and accounting workers → Private invoice PDFs: Managed identity: read exact stored PDF reference; Extraction and accounting workers → Invoice field extraction: HTTPS: submit PDF, persist operation ID and poll extraction; Extraction and accounting workers → Existing accounting API: Authenticated HTTPS: approved payload and stable reference; reconcile uncertain ; Extraction and accounting workers → Workflow monitoring and recovery alerts: Job failures, backlog and reconciliation telemetry; Extraction and accounting workers → Accounting credentials: Managed identity over HTTPS: read scoped accounting credentials

Requirement traceability: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.; REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.; REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Invoice field extraction

Azure AI Document Intelligence · azure · region: To be selected · classification: Confidential

Azure AI Document Intelligence with the prebuilt invoice model is proposed for PDF field extraction. Worker maps supplier, invoice date, total and currency into the review schema, preserving missing values and confidence rather than inventing data. All results require human approval. Model/API version, regional processing availability, supported currencies and representative-document accuracy need verification. PDF content is untrusted input. No managed extraction integration is currently generated.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and accounting workers → Invoice field extraction: HTTPS: submit PDF, persist operation ID and poll extraction

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: For each accepted PDF invoice, retain its source document and present supplier, invoice date, total and currency for review, explicitly marking missing values and extraction failures.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing accounting API

Existing accounting API · tools · region: Existing location — unconfirmed · classification: Confidential

Client's existing accounting API, retained outside provisioning scope and not recreated, imported or modified. An administrator will supply its endpoint and credentials through deployment configuration and the proposed secret-management process. Receives only approved invoice revisions. Authentication mechanism, request schema, idempotency-key support, unique external reference enforcement and reference lookup remain unverified. Integration must test the case where accounting commits but the response is lost; duplicate-free recovery cannot be claimed without a suitable API contract or reconciliation process.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Extraction and accounting workers → Existing accounting API: Authenticated HTTPS: approved payload and stable reference; reconcile uncertain 

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Submit an invoice to accounting only after an authorized reviewer approves its exact field revision; retain approval evidence and require fresh approval following changes.; REQ-005: Repeated deliveries and concurrent retries must produce one logical invoice and no duplicate accounting creation. Use durable intake keys and atomic transitions; reconcile ambiguous external outcomes before resubmission using an agreed accounting reference/idempotency contract.; REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Workflow monitoring and recovery alerts

Azure Monitor · azure · region: To be selected · classification: Confidential

Azure Monitor collects correlated application and worker telemetry and alerts on dead-letter messages, stalled extraction, outbox backlog and unresolved accounting submissions. Avoid raw PDF contents, invoice fields and credentials in telemetry. Alert recipients, operating ownership, log retention and recovery objectives remain open. Instrumentation, alert rules and replay/reconciliation runbooks require implementation; this node does not prove monitoring works.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice upload and review application → Workflow monitoring and recovery alerts: Correlated request, authorization and approval telemetry; Extraction and accounting workers → Workflow monitoring and recovery alerts: Job failures, backlog and reconciliation telemetry; Extraction and approved-delivery queues → Workflow monitoring and recovery alerts: Queue age and dead-letter metrics for recovery alerts

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Accounting credentials

Azure Key Vault · azure · region: To be selected · classification: Confidential

Proposed Azure Key Vault holds administrator-supplied accounting credentials. An authorized administrator loads and rotates secrets through a separate administrative process; no secret values belong in the diagram, source code or Terraform state. Grant the worker managed identity read access only to required secrets, without secret-management privileges. Endpoint configuration stays separate from credentials. Provisioning, scoped access, secret loading instructions, rotation behavior and denied-access tests require engineering; the accounting authentication mechanism remains unverified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Extraction and accounting workers → Accounting credentials: Managed identity over HTTPS: read scoped accounting credentials

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Integrate with the existing accounting API without provisioning or modifying that system. Accept its endpoint as administrator-supplied configuration and credentials through a protected secret-loading process. Permit only the delivery worker to read required credentials; exclude secret values from browser responses, project exports and telemetry. Document credential rotation and verify denied access and missing-credential behavior.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice upload and review application<br/>Azure"]
  n2["Application sign-in and roles<br/>Azure"]
  n3["Private invoice PDFs<br/>Azure"]
  n4["Invoice state and approval ledger<br/>Azure"]
  n5["Extraction and approved-delivery queues<br/>Azure"]
  n6["Extraction and accounting workers<br/>Azure"]
  n7["Invoice field extraction<br/>Azure"]
  n8["Existing accounting API<br/>Tools & data"]
  n9["Workflow monitoring and recovery alerts<br/>Azure"]
  n10["Accounting credentials<br/>Azure"]
  n0 -->|HTTPS: signed-in uploads and review; only reviewers may approve| n1
  n1 -->|OpenID Connect sign-in; server validates identity and uploader/reviewer roles| n2
  n1 -->|Managed identity: private PDF upload and authorized reads| n3
  n1 -->|SQL transactions: intake, review, authorized approval and outbox| n4
  n6 -->|Claim outbox/jobs; persist extraction, approval checks and delivery state| n4
  n6 -->|Managed identity: publish durable outbox jobs over AMQP/TLS| n5
  n5 -->|Service Bus triggers: locked delivery, retry and dead-letter recovery| n6
  n6 -->|Managed identity: read exact stored PDF reference| n3
  n6 -->|HTTPS: submit PDF, persist operation ID and poll extraction| n7
  n6 -->|Authenticated HTTPS: approved payload and stable reference; reconcile uncertain | n8
  n1 -->|Correlated request, authorization and approval telemetry| n9
  n6 -->|Job failures, backlog and reconciliation telemetry| n9
  n5 -->|Queue age and dead-letter metrics for recovery alerts| n9
  n6 -->|Managed identity over HTTPS: read scoped accounting credentials| n10
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Approval workflow | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-app | Invoice upload and review application | azure | Azure App Service | To be selected | Proposed | Implementation needed |
| invoice-identity | Application sign-in and roles | azure | Microsoft Entra ID | To be selected | Proposed | Implementation needed |
| invoice-documents | Private invoice PDFs | azure | Azure Blob Storage | To be selected | Proposed | Implementation needed |
| invoice-state | Invoice state and approval ledger | azure | Azure SQL Database | To be selected | Proposed | Implementation needed |
| invoice-broker | Extraction and approved-delivery queues | azure | Azure Service Bus | To be selected | Proposed | Implementation needed |
| invoice-worker | Extraction and accounting workers | azure | Azure Functions | To be selected | Proposed | Implementation needed |
| invoice-extraction | Invoice field extraction | azure | Azure AI Document Intelligence | To be selected | Proposed | Implementation needed |
| invoice-accounting | Existing accounting API | tools | Existing accounting API | Existing location — unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| invoice-monitoring | Workflow monitoring and recovery alerts | azure | Azure Monitor | To be selected | Proposed | Implementation needed |
| invoice-secrets | Accounting credentials | azure | Azure Key Vault | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Invoice upload and review application** (invoice-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users.
- **Application sign-in and roles** (invoice-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Private invoice PDFs** (invoice-documents): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Invoice state and approval ledger** (invoice-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker.
- **Extraction and approved-delivery queues** (invoice-broker): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Extraction and accounting workers** (invoice-worker): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-broker.
- **Invoice field extraction** (invoice-extraction): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Existing accounting API** (invoice-accounting): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.
- **Workflow monitoring and recovery alerts** (invoice-monitoring): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app, invoice-worker, invoice-broker.
- **Accounting credentials** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-worker.

### Engineering work remaining

- Invoice upload and review application: Implementation needed.
- Application sign-in and roles: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Invoice state and approval ledger: Implementation needed.
- Extraction and approved-delivery queues: Implementation needed.
- Extraction and accounting workers: Implementation needed.
- Invoice field extraction: Implementation needed.
- Workflow monitoring and recovery alerts: Implementation needed.
- Accounting credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-broker: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-worker: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-documents: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-extraction: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-accounting: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-broker → invoice-monitoring: implement data flow, access policy and acceptance test.
- Wire invoice-worker → invoice-secrets: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
