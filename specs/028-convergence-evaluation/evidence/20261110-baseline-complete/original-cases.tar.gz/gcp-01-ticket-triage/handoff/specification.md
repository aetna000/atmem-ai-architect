Snapshot 5146ebcb-0c5f-45a1-9a9a-dcaab63db778 · design r3 · generated 2026-11-09T17:31:39.473Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly. (must, open); target: acceptance target needed; linked blocks: team-browser, triage-app, triage-model

Design explanation: Defines the complete first-version outcome without introducing ticket-system integration or autonomous actions.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass. (must, open); target: acceptance target needed; linked blocks: team-access, triage-app

Design explanation: Proposed access boundary prevents an internal tool from exposing ticket processing to unauthorized users.

Basis: User requests a “small internal tool”; team-access and triage-app implement the proposed boundary.
- [REQ-004] Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint. (should, open); target: acceptance target needed; linked blocks: triage-app, triage-model, triage-logs

Design explanation: Proposed minimization reduces unnecessary copies of potentially sensitive support tickets; country and provider data-handling requirements remain open.

Basis: The pasted support-ticket workflow requires transient processing; persistent history was not requested.
- [REQ-005] Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected. (must, open); target: acceptance target needed; linked blocks: team-browser, triage-app

Design explanation: Enforcing the limit before inference bounds processing and prevents unsupported payloads reaching the model; decimal KB is an explicit proposed interpretation.

Basis: “We paste synthetic or redacted text, up to 20 KB per ticket.”
- [REQ-006] Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference. (must, open); target: acceptance target needed; linked blocks: team-access, triage-app, triage-model, triage-logs

Design explanation: Regional application hosting alone does not establish model, identity or logging residency; silent overseas fallback could violate the requested boundary.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”

## How the system works

The current design contains 5 components and 5 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team member → Team-only access

HTTPS: sign in and submit synthetic/redacted ticket

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Team-only access → Ticket review web app

Authorized HTTPS request; verify proxy routing and bypass protection

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Ticket review web app → Ticket analysis model

Regional Vertex AI API: transient ticket → structured suggestions; no global fal

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Ticket review web app → Team member

Protected HTTPS: suggestions for human review; Cache-Control: no-store

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Ticket review web app → Operational logs

Sanitized operational metadata only; proposed Australian log routing

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team member

Approval workflow · tools · region: Australia — user location · classification: Confidential

Existing team member in Australia using a browser to paste synthetic or redacted ticket text and review suggested summary, topic and urgency. External client, outside provisioning scope. Proposed interface clears ticket text after processing and does not use browser storage or content analytics; user-managed clipboard and device behavior remain outside application control.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Ticket review web app → Team member: Protected HTTPS: suggestions for human review; Cache-Control: no-store

Outputs: Team member → Team-only access: HTTPS: sign in and submit synthetic/redacted ticket

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly.; REQ-005: Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Team-only access

Identity-Aware Proxy · gcp · region: Global identity boundary — residency unresolved · classification: Confidential

Proposed Identity-Aware Proxy protection allowing approved team identities only, with direct Cloud Run endpoint bypass prevented. Existing company sign-in compatibility and protection configuration require implementation and verification. Identity, proxy routing and associated metadata may have global handling: Australian-only routing is not established and any overseas handling must be flagged before use. Never put ticket content in URLs or identity attributes.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team member → Team-only access: HTTPS: sign in and submit synthetic/redacted ticket

Outputs: Team-only access → Ticket review web app: Authorized HTTPS request; verify proxy routing and bypass protection

Requirement traceability: REQ-003: Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass.; REQ-006: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Ticket review web app

Google Cloud Run · gcp · region: australia-southeast1 · classification: Confidential

Proposed single Cloud Run deployment serving the interface and server-side triage endpoint. Accept synthetic or redacted ticket text; enforce a proposed 20,000-byte UTF-8 text limit server-side and reject oversized input before inference. Return validated summary, topic and suggested urgency marked for human review. Treat tickets as untrusted data. Keep ticket content only for processing, with no history, persistence, request-body tracing or content logs; clear application references on completion and failure, disable browser response caching and clear submitted text. Use a dedicated least-privilege model-invocation identity with no email or customer-system credentials. Bound inference and return explicit errors rather than fabricate results. Proposed Sydney placement is subject to validation; no automatic overseas fallback. Code, infrastructure, access enforcement and tests remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team-only access → Ticket review web app: Authorized HTTPS request; verify proxy routing and bypass protection

Outputs: Ticket review web app → Ticket analysis model: Regional Vertex AI API: transient ticket → structured suggestions; no global fal; Ticket review web app → Team member: Protected HTTPS: suggestions for human review; Cache-Control: no-store; Ticket review web app → Operational logs: Sanitized operational metadata only; proposed Australian log routing

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly.; REQ-003: Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass.; REQ-004: Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint.; REQ-005: Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected.; REQ-006: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Ticket analysis model

Vertex AI · gcp · region: australia-southeast1 · classification: Confidential

Proposed Gemini inference through a regional Vertex AI endpoint to return bounded structured summary, topic and urgency. No tools or business-system actions. Sydney is a candidate only: verify a suitable model's regional availability, processing boundary, provider-side retention including abuse monitoring or caching, quotas and compatibility before use. Application deletion alone does not establish provider non-retention. Do not silently select a global endpoint or overseas fallback; flag any overseas handling and obtain a decision before enabling it. Evaluate approved synthetic/redacted tickets for missed urgent cases and resistance to misleading instructions. No quality, residency or retention claim has been verified.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket review web app → Ticket analysis model: Regional Vertex AI API: transient ticket → structured suggestions; no global fal

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly.; REQ-004: Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint.; REQ-006: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Operational logs

Cloud Logging · gcp · region: australia-southeast1 · classification: Internal

Proposed Cloud Logging configuration storing only request identifiers, latency, usage and sanitized failures. Exclude ticket text, prompts and generated suggestions from application logs, traces and exception payloads. Propose an Australian regional log bucket in Sydney; verify default log buckets, routing, audit records, exports and metadata handling for overseas paths. Metadata retention and access remain implementation decisions; no ticket-content retention is permitted. Configure an operational failure alert and document its owner. Infrastructure and tests remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket review web app → Operational logs: Sanitized operational metadata only; proposed Australian log routing

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint.; REQ-006: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Team-only access<br/>Google Cloud"]
  n2["Ticket review web app<br/>Google Cloud"]
  n3["Ticket analysis model<br/>Google Cloud"]
  n4["Operational logs<br/>Google Cloud"]
  n0 -->|HTTPS: sign in and submit synthetic/redacted ticket| n1
  n1 -->|Authorized HTTPS request; verify proxy routing and bypass protection| n2
  n2 -->|Regional Vertex AI API: transient ticket → structured suggestions; no global fal| n3
  n2 -->|Protected HTTPS: suggestions for human review; Cache-Control: no-store| n0
  n2 -->|Sanitized operational metadata only; proposed Australian log routing| n4
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team member | tools | Approval workflow | Australia — user location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| team-access | Team-only access | gcp | Identity-Aware Proxy | Global identity boundary — residency unresolved | Proposed | Implementation needed |
| triage-app | Ticket review web app | gcp | Google Cloud Run | australia-southeast1 | Proposed | Implementation needed |
| triage-model | Ticket analysis model | gcp | Vertex AI | australia-southeast1 | Proposed | Implementation needed |
| triage-logs | Operational logs | gcp | Cloud Logging | australia-southeast1 | Proposed | Implementation needed |

### Resources and cost dimensions

- **Team member** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Team-only access** (team-access): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-browser.
- **Ticket review web app** (triage-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-access.
- **Ticket analysis model** (triage-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Operational logs** (triage-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.

### Engineering work remaining

- Team-only access: Implementation needed.
- Ticket review web app: Implementation needed.
- Ticket analysis model: Implementation needed.
- Operational logs: Implementation needed.
- Wire team-browser → team-access: implement data flow, access policy and acceptance test.
- Wire team-access → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.
- Wire triage-app → team-browser: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
