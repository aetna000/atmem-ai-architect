Snapshot 5146ebcb-0c5f-45a1-9a9a-dcaab63db778 · design r3 · generated 2026-11-09T17:31:39.473Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 17:31 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Google Cloud
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** We paste synthetic or redacted text, up to 20 KB per ticket. Do not retain ticket text after processing. Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**Team access**

- Team member (Tools & data, existing, sketch) — Existing team member in Australia using a browser to paste synthetic or redacted ticket text and review suggested summary, topic and urgency. External client, outside provisioning scope. Proposed interface clears ticket text after processing and does not use browser storage or content analytics; user-managed clipboard and device behavior remain outside application control.
- Team-only access (Google Cloud, sketch) — Proposed Identity-Aware Proxy protection allowing approved team identities only, with direct Cloud Run endpoint bypass prevented. Existing company sign-in compatibility and protection configuration require implementation and verification. Identity, proxy routing and associated metadata may have global handling: Australian-only routing is not established and any overseas handling must be flagged before use. Never put ticket content in URLs or identity attributes.

**Ticket triage**

- Ticket review web app (Google Cloud, sketch) — Proposed single Cloud Run deployment serving the interface and server-side triage endpoint. Accept synthetic or redacted ticket text; enforce a proposed 20,000-byte UTF-8 text limit server-side and reject oversized input before inference. Return validated summary, topic and suggested urgency marked for human review. Treat tickets as untrusted data. Keep ticket content only for processing, with no history, persistence, request-body tracing or content logs; clear application references on completion and failure, disable browser response caching and clear submitted text. Use a dedicated least-privilege model-invocation identity with no email or customer-system credentials. Bound inference and return explicit errors rather than fabricate results. Proposed Sydney placement is subject to validation; no automatic overseas fallback. Code, infrastructure, access enforcement and tests remain engineering work.
- Ticket analysis model (Google Cloud, sketch) — Proposed Gemini inference through a regional Vertex AI endpoint to return bounded structured summary, topic and urgency. No tools or business-system actions. Sydney is a candidate only: verify a suitable model's regional availability, processing boundary, provider-side retention including abuse monitoring or caching, quotas and compatibility before use. Application deletion alone does not establish provider non-retention. Do not silently select a global endpoint or overseas fallback; flag any overseas handling and obtain a decision before enabling it. Evaluate approved synthetic/redacted tickets for missed urgent cases and resistance to misleading instructions. No quality, residency or retention claim has been verified.

**Operations**

- Operational logs (Google Cloud, sketch) — Proposed Cloud Logging configuration storing only request identifiers, latency, usage and sanitized failures. Exclude ticket text, prompts and generated suggestions from application logs, traces and exception payloads. Propose an Australian regional log bucket in Sydney; verify default log buckets, routing, audit records, exports and metadata handling for overseas paths. Metadata retention and access remain implementation decisions; no ticket-content retention is permitted. Configure an operational failure alert and document its owner. Infrastructure and tests remain engineering work.

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Team-only access<br/>Google Cloud"]
  n2["Ticket review web app<br/>Google Cloud"]
  n3["Ticket analysis model<br/>Google Cloud"]
  n4["Operational logs<br/>Google Cloud"]
  n0 -->|HTTPS: sign in and submit synthetic/redacted ticket| n1
  n1 -->|Authorized HTTPS request; verify proxy routing and bypass protection| n2
  n2 -->|Regional Vertex AI API: transient ticket → structured suggestions; no global fal| n3
  n2 -->|Protected HTTPS: suggestions for human review; Cache-Control: no-store| n0
  n2 -->|Sanitized operational metadata only; proposed Australian log routing| n4
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-browser | Team member | tools | Approval workflow | Australia — user location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| team-access | Team-only access | gcp | Identity-Aware Proxy | Global identity boundary — residency unresolved | Proposed | Implementation needed |
| triage-app | Ticket review web app | gcp | Google Cloud Run | australia-southeast1 | Proposed | Implementation needed |
| triage-model | Ticket analysis model | gcp | Vertex AI | australia-southeast1 | Proposed | Implementation needed |
| triage-logs | Operational logs | gcp | Cloud Logging | australia-southeast1 | Proposed | Implementation needed |

### Resources and cost dimensions

- **Team member** (team-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Team-only access** (team-access): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-browser.
- **Ticket review web app** (triage-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-access.
- **Ticket analysis model** (triage-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Operational logs** (triage-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.

### Engineering work remaining

- Team-only access: Implementation needed.
- Ticket review web app: Implementation needed.
- Ticket analysis model: Implementation needed.
- Operational logs: Implementation needed.
- Wire team-browser → team-access: implement data flow, access policy and acceptance test.
- Wire team-access → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.
- Wire triage-app → team-browser: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team member | Team-only access | HTTPS: sign in and submit synthetic/redacted ticket | Confidential |
| Team-only access | Ticket review web app | Authorized HTTPS request; verify proxy routing and bypass protection | Confidential |
| Ticket review web app | Ticket analysis model | Regional Vertex AI API: transient ticket → structured suggestions; no global fal | Confidential |
| Ticket review web app | Team member | Protected HTTPS: suggestions for human review; Cache-Control: no-store | Confidential |
| Ticket review web app | Operational logs | Sanitized operational metadata only; proposed Australian log routing | Confidential |

## 5. Security controls

- **Team member** — Existing team member in Australia using a browser to paste synthetic or redacted ticket text and review suggested summary, topic and urgency. External client, outside provisioning scope. Proposed interface clears ticket text after processing and does not use browser storage or content analytics; user-managed clipboard and device behavior remain outside application control.
- **Team-only access** — Proposed Identity-Aware Proxy protection allowing approved team identities only, with direct Cloud Run endpoint bypass prevented. Existing company sign-in compatibility and protection configuration require implementation and verification. Identity, proxy routing and associated metadata may have global handling: Australian-only routing is not established and any overseas handling must be flagged before use. Never put ticket content in URLs or identity attributes.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass. (must)
- Requirement: Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint. (should)
- Requirement: Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected. (must)
- Requirement: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass. | security | not measurable yet | Open |
| Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint. | compliance | not measurable yet | Open |
| Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference. | compliance | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly. (must, open)
- Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 3 quality requirements have no measurable target. Add a metric and target to: “Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass.”, “Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint.”, “Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 5 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Team-only access | Checked requests | needs requests_per_month | price needed | — | — |
| Ticket analysis model | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team member, Ticket review web app, Operational logs.

**Estimate gaps:**

- Team-only access / Checked requests: input needed (requests_per_month).
- Ticket analysis model / Endpoint hours: price needed.
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket review web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational logs: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision team access: Team-only access.
4. Provision ticket triage: Ticket review web app, Ticket analysis model.
5. Provision operations: Operational logs.
6. Connect existing systems: Team member; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Team-only access: needs requests_per_month _(estimate)_
- Ticket analysis model: needs a unit price with a source _(estimate)_
