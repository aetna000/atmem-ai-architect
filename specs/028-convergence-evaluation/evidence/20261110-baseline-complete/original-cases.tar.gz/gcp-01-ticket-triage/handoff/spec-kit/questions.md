# Questions and assumptions to resolve

Snapshot 5146ebcb-0c5f-45a1-9a9a-dcaab63db778 · design r3 · generated 2026-11-09T17:31:39.473Z

- [ai-triage-outcome] Confirm REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly.
- [ai-team-access] Confirm REQ-003: Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass.
- [ai-ticket-data-minimization] Confirm REQ-004: Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint.
- [ai-ticket-input-bound] Confirm REQ-005: Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected.
- [ai-australian-processing] Confirm REQ-006: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.
- [acceptance-req-f986cdc9] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-triage-outcome] Agree a measurable acceptance check for REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency together for a person to review; identify suggestions as AI-generated and surface processing failures explicitly.
- [acceptance-ai-team-access] Agree a measurable acceptance check for REQ-003: Proposed: permit only approved authenticated team members to submit tickets and view their returned suggestions, with server-side authorization and protection against direct-endpoint bypass.
- [acceptance-ai-ticket-data-minimization] Agree a measurable acceptance check for REQ-004: Proposed: do not persist ticket history or include ticket text and generated suggestions in application logs; select processing and logging locations after the user confirms the data-country constraint.
- [acceptance-ai-ticket-input-bound] Agree a measurable acceptance check for REQ-005: Accept synthetic or redacted ticket text only and enforce the ticket-size limit server-side before inference; proposed interpretation is 20 KB = 20,000 UTF-8 bytes, with oversized input explicitly rejected.
- [acceptance-ai-australian-processing] Agree a measurable acceptance check for REQ-006: Use Australian regional services where supported and identify any ticket, identity or operational-data path leaving Australia. Proposed safeguard: keep overseas model fallback disabled pending an explicit decision; verify model availability and processing boundaries before enabling inference.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d6175737472616c69616e2d70726f63657373696e67] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7465616d2d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d646174612d6d696e696d697a6174696f6e] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d696e7075742d626f756e64] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d6f7574636f6d65] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
