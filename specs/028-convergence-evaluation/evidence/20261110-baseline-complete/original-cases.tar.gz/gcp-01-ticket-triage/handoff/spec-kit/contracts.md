# Component and interface contracts

Snapshot 5146ebcb-0c5f-45a1-9a9a-dcaab63db778 · design r3 · generated 2026-11-09T17:31:39.473Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-browser: Team member

- Responsibility: Existing team member in Australia using a browser to paste synthetic or redacted ticket text and review suggested summary, topic and urgency. External client, outside provisioning scope. Proposed interface clears ticket text after processing and does not use browser storage or content analytics; user-managed clipboard and device behavior remain outside application control.
- Service: Approval workflow
- Provider / placement: tools / Australia — user location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component team-access: Team-only access

- Responsibility: Proposed Identity-Aware Proxy protection allowing approved team identities only, with direct Cloud Run endpoint bypass prevented. Existing company sign-in compatibility and protection configuration require implementation and verification. Identity, proxy routing and associated metadata may have global handling: Australian-only routing is not established and any overseas handling must be flagged before use. Never put ticket content in URLs or identity attributes.
- Service: Identity-Aware Proxy
- Provider / placement: gcp / Global identity boundary — residency unresolved
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7465616d2d616363657373
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-app: Ticket review web app

- Responsibility: Proposed single Cloud Run deployment serving the interface and server-side triage endpoint. Accept synthetic or redacted ticket text; enforce a proposed 20,000-byte UTF-8 text limit server-side and reject oversized input before inference. Return validated summary, topic and suggested urgency marked for human review. Treat tickets as untrusted data. Keep ticket content only for processing, with no history, persistence, request-body tracing or content logs; clear application references on completion and failure, disable browser response caching and clear submitted text. Use a dedicated least-privilege model-invocation identity with no email or customer-system credentials. Bound inference and return explicit errors rather than fabricate results. Proposed Sydney placement is subject to validation; no automatic overseas fallback. Code, infrastructure, access enforcement and tests remain engineering work.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-model: Ticket analysis model

- Responsibility: Proposed Gemini inference through a regional Vertex AI endpoint to return bounded structured summary, topic and urgency. No tools or business-system actions. Sydney is a candidate only: verify a suitable model's regional availability, processing boundary, provider-side retention including abuse monitoring or caching, quotas and compatibility before use. Application deletion alone does not establish provider non-retention. Do not silently select a global endpoint or overseas fallback; flag any overseas handling and obtain a decision before enabling it. Evaluate approved synthetic/redacted tickets for missed urgent cases and resistance to misleading instructions. No quality, residency or retention claim has been verified.
- Service: Vertex AI
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-logs: Operational logs

- Responsibility: Proposed Cloud Logging configuration storing only request identifiers, latency, usage and sanitized failures. Exclude ticket text, prompts and generated suggestions from application logs, traces and exception payloads. Propose an Australian regional log bucket in Sydney; verify default log buckets, routing, audit records, exports and metadata handling for overseas paths. Metadata retention and access remain implementation decisions; no ticket-content retention is permitted. Configure an operational failure alert and document its owner. Infrastructure and tests remain engineering work.
- Service: Cloud Logging
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-access: team-browser → team-access

- Drawn payload/purpose: HTTPS: sign in and submit synthetic/redacted ticket
- Contract task: TASK-CONTRACT-62726f777365722d616363657373
- Integration task: TASK-INTEGRATION-62726f777365722d616363657373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### access-app: team-access → triage-app

- Drawn payload/purpose: Authorized HTTPS request; verify proxy routing and bypass protection
- Contract task: TASK-CONTRACT-6163636573732d617070
- Integration task: TASK-INTEGRATION-6163636573732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-model: triage-app → triage-model

- Drawn payload/purpose: Regional Vertex AI API: transient ticket → structured suggestions; no global fal
- Contract task: TASK-CONTRACT-6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-review-response: triage-app → team-browser

- Drawn payload/purpose: Protected HTTPS: suggestions for human review; Cache-Control: no-store
- Contract task: TASK-CONTRACT-6170702d7265766965772d726573706f6e7365
- Integration task: TASK-INTEGRATION-6170702d7265766965772d726573706f6e7365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-logs: triage-app → triage-logs

- Drawn payload/purpose: Sanitized operational metadata only; proposed Australian log routing
- Contract task: TASK-CONTRACT-6170702d6c6f6773
- Integration task: TASK-INTEGRATION-6170702d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
