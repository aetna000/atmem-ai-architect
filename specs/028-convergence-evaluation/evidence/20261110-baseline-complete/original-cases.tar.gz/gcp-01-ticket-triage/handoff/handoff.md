# Delivery handoff

Snapshot 5146ebcb-0c5f-45a1-9a9a-dcaab63db778 · design r3 · generated 2026-11-09T17:31:39.473Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Team-only access / Checked requests: input needed (requests_per_month).
- Ticket analysis model / Endpoint hours: price needed.
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket review web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational logs: no cost lines; add charges or an explicit zero-cost line with a reason.
- Team-only access: Implementation needed.
- Ticket review web app: Implementation needed.
- Ticket analysis model: Implementation needed.
- Operational logs: Implementation needed.
- Wire team-browser → team-access: implement data flow, access policy and acceptance test.
- Wire team-access → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.
- Wire triage-app → team-browser: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-logs: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
