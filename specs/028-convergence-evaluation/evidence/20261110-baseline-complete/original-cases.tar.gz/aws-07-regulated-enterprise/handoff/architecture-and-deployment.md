Snapshot 73f80183-2191-419a-9770-04f8c323dbbd · design r1 · generated 2026-11-09T17:09:30.636Z

# Resilient regulated knowledge platform — deployment document

Generated 2026-11-09 17:09 UTC from design revision r1 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Architect a regulated enterprise AI assistant spanning two existing document systems and an internal service API. It needs permission-aware retrieval, human-approved actions, data residency, dependable recovery and an operational handoff. Include ingestion, identity, application, data and model paths; do not reduce it to storage. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** not estimated
- **Review:** 0 open findings (0 blockers)
- **Current decisions:** 0

## 2. Scope and context

- **What you want to build:** Architect a regulated enterprise AI assistant spanning two existing document systems and an internal service API. It needs permission-aware retrieval, human-approved actions, data residency, dependable recovery and an operational handoff. Include ingestion, identity, application, data and model paths; do not reduce it to storage. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** AWS
- **Budget and timeline:** —

## 3. Architecture

_No components yet._

```mermaid
flowchart LR
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|


### Resources and cost dimensions



### Engineering work remaining

- No resources in the design yet.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

_None recorded._

## 5. Security controls

- _No guardrail or approval components in the design._



## 6. Requirements

**Non-functional**

_None recorded._

**Functional**

_None recorded._

**Success measures**

_No success measures defined._


## 7. Review findings

_No findings._

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

_No costed components._

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected.

**Estimate gaps:**

No worksheet gaps detected; validate dimensions, quotations and assumptions before treating this as a full estimate.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Run the acceptance checks (success measures and requirements) in staging; record results.
4. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

_No decisions recorded yet._

## 11. Assumptions

_None recorded._


## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
