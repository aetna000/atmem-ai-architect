# Component and interface contracts

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-visitors: Public website visitors

- Responsibility: Existing human visitors using a browser, outside provisioning scope. Submit questions and receive cited answers or an explicit uncertainty response. No visitor account proposed. Public source material does not imply visitor questions contain no personal information.
- Service: Approval workflow
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d76697369746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-editors: Article editors

- Responsibility: Existing people responsible for the public help articles, outside provisioning scope. Supply twenty public UTF-8 files under 30 KB each, with titles and canonical public article URLs for citations. Proposed protected workflow previews validated content before publishing and supports replacement and removal. Editor identities are required destination inputs, not invented accounts.
- Service: Approval workflow
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component faq-app: FAQ website and answer service

- Responsibility: Proposed new Google Cloud Run service serves the public website, question API and protected editorial API in one deployment. Sydney placement is proposed, not approved or verified. Editorial file intake validates UTF-8 and the agreed file-size boundary, rejects invalid uploads explicitly, previews content, and requires title and canonical public URL before publication. The precise byte interpretation of 30 KB is an implementation assumption to document. Original files need not be retained separately; validated article text is stored in Firestore. Editorial mutations validate Google-issued identity tokens and a server-side editor allowlist on every request; public routes cannot mutate articles. Reads only published approved articles and ranks passages with application-owned keyword retrieval. Sends selected passages as untrusted evidence, with no private-source credentials, arbitrary URL fetching or model tools. Validates article IDs, citations and current publication revisions before returning an answer; returns uncertainty for insufficient evidence and a clear unavailable response on dependency failure. Uses bounded requests, rate and instance limits, model timeouts and retry limits, plus a dedicated least-privilege service account. Does not persist visitor conversations or log raw questions by default. Owns application code, file workflow, revision checks, representative grounding/retrieval/prompt-injection tests and release/rollback procedures. No supplied application artifact or typed Cloud Run generator contract is established; application, identity flow, infrastructure and integrations require implementation.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-articles: Approved public article catalogue

- Responsibility: Proposed Cloud Firestore database holds validated text from the twenty public UTF-8 files under 30 KB each: stable article ID, title, canonical public URL, text, publication state and revision. Sydney regional placement is proposed, subject to verification and acceptance. Stores editorial authorization metadata separately from public article content. Server-only access through the application service account; browsers have no direct database access. Atomic publication and removal update a catalogue revision; retrieval excludes unpublished or removed records and the application rechecks revisions before returning cited answers. Updates and removals do not depend on a separate vector index. Recovery must not silently republish removed articles. Database rules, transactions, retention, recovery and integration tests require implementation. Backup locations and ancillary data handling require review before claiming Australian residency; no cross-region recovery is assumed.
- Service: Cloud Firestore
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d61727469636c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-model: Grounded answer generation

- Responsibility: Proposed Vertex AI managed Gemini model access, called only by the application service account. Receives the question and selected approved public passages with citation IDs; instructed to answer only from supplied evidence and abstain otherwise. No private retrieval, web grounding or tool execution is proposed. Australia is preferred, but no specific model or inference region has been selected or verified. Verify model availability, regional processing guarantees, retention, logging, quotas and contractual data handling before selection. A regional application or endpoint name alone does not prove all model data stays in Australia. Do not silently use a global endpoint, overseas processing or cross-region fallback; return an unavailable response if the approved model path fails. Model instructions alone do not prove grounding: application validation and representative answer, refusal and prompt-injection tests are required. No dedicated model training or endpoint deployment is assumed. Model integration and infrastructure support remain engineering work.
- Service: Vertex AI
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### faq-visitors-app: faq-visitors → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or uncertainty
- Contract task: TASK-CONTRACT-6661712d76697369746f72732d617070
- Integration task: TASK-INTEGRATION-6661712d76697369746f72732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editors-app: faq-editors → faq-app

- Drawn payload/purpose: HTTPS + verified editor identity: upload, preview, publish, update, remove
- Contract task: TASK-CONTRACT-6661712d656469746f72732d617070
- Integration task: TASK-INTEGRATION-6661712d656469746f72732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-articles: faq-app → faq-articles

- Drawn payload/purpose: Firestore API + service identity: articles and revision transactions
- Contract task: TASK-CONTRACT-6661712d6170702d61727469636c6573
- Integration task: TASK-INTEGRATION-6661712d6170702d61727469636c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-model: faq-app → faq-model

- Drawn payload/purpose: Vertex AI API + service identity: passages → draft answer
- Contract task: TASK-CONTRACT-6661712d6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
