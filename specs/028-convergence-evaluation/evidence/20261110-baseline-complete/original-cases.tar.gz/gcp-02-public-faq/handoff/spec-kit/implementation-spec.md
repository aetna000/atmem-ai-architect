# Implementation Spec Kit

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

8 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: gcp

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Public website visitors (faq-visitors): External browser — no infrastructure to provision; connection behavior still requires validation; tools, To be selected.
- Article editors (faq-editors): Existing — reference/import plan needed; tools, To be selected.
- FAQ website and answer service (faq-app): Implementation needed; gcp, australia-southeast1.
- Approved public article catalogue (faq-articles): Implementation needed; gcp, australia-southeast1.
- Grounded answer generation (faq-model): Implementation needed; gcp, To be selected.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### decision-data.country — priority 1

The data country and processing boundary is not independently confirmed.

Action: Record an explicit data.country decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d61727469636c652d6c6966656379636c65 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### requirement-proposed-61692d67726f756e6465642d616e7377657273 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273

### requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379 — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379

### requirement-proposed-61692d7075626c69632d66696c652d696e74616b65 — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e74616b65

### requirement-proposed-61692d7075626c69632d736f757263652d626f756e64617279 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279

### placement-6661712d6d6f64656c — priority 2

Grounded answer generation: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6661712d6d6f64656c

### review-52454c2d3030313a6661712d6d6f64656c — priority 2

No monitoring for model quality or drift.

Action: Add a monitoring block (quality, drift, cost) and decide who is alerted.

Tasks: TASK-SECURITY-DESIGN, TASK-SECURITY

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

5 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d61727469636c652d6c6966656379636c65 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### acceptance-61692d67726f756e6465642d616e7377657273 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273

### acceptance-61692d6c6f636174696f6e2d7472616e73706172656e6379 — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379

### acceptance-61692d7075626c69632d66696c652d696e74616b65 — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e74616b65

### acceptance-61692d7075626c69632d736f757263652d626f756e64617279 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279

### acceptance-7265712d6265343661353230 — priority 2

REQ-001: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-7265712d6265343661353230

### traceability-7265712d6265343661353230 — priority 2

REQ-001 has no component links.

Action: Map the requirement to relevant components or record why it is project-wide; do not guess the mapping.

Tasks: TASK-ACCEPTANCE-7265712d6265343661353230

### implementation-6661712d617070 — priority 2

FAQ website and answer service: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d617070

### implementation-6661712d61727469636c6573 — priority 2

Approved public article catalogue: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d61727469636c6573

### implementation-6661712d6d6f64656c — priority 2

Grounded answer generation: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d6d6f64656c

### existing-6661712d656469746f7273 — priority 2

Article editors: existing-system contract and access are unverified.

Action: Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.

Tasks: TASK-RESOURCE-6661712d656469746f7273

### existing-6661712d76697369746f7273 — priority 2

Public website visitors: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-6661712d76697369746f7273


# Component and interface contracts

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-visitors: Public website visitors

- Responsibility: Existing human visitors using a browser, outside provisioning scope. Submit questions and receive cited answers or an explicit uncertainty response. No visitor account proposed. Public source material does not imply visitor questions contain no personal information.
- Service: Approval workflow
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d76697369746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-editors: Article editors

- Responsibility: Existing people responsible for the public help articles, outside provisioning scope. Supply twenty public UTF-8 files under 30 KB each, with titles and canonical public article URLs for citations. Proposed protected workflow previews validated content before publishing and supports replacement and removal. Editor identities are required destination inputs, not invented accounts.
- Service: Approval workflow
- Provider / placement: tools / To be selected
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component faq-app: FAQ website and answer service

- Responsibility: Proposed new Google Cloud Run service serves the public website, question API and protected editorial API in one deployment. Sydney placement is proposed, not approved or verified. Editorial file intake validates UTF-8 and the agreed file-size boundary, rejects invalid uploads explicitly, previews content, and requires title and canonical public URL before publication. The precise byte interpretation of 30 KB is an implementation assumption to document. Original files need not be retained separately; validated article text is stored in Firestore. Editorial mutations validate Google-issued identity tokens and a server-side editor allowlist on every request; public routes cannot mutate articles. Reads only published approved articles and ranks passages with application-owned keyword retrieval. Sends selected passages as untrusted evidence, with no private-source credentials, arbitrary URL fetching or model tools. Validates article IDs, citations and current publication revisions before returning an answer; returns uncertainty for insufficient evidence and a clear unavailable response on dependency failure. Uses bounded requests, rate and instance limits, model timeouts and retry limits, plus a dedicated least-privilege service account. Does not persist visitor conversations or log raw questions by default. Owns application code, file workflow, revision checks, representative grounding/retrieval/prompt-injection tests and release/rollback procedures. No supplied application artifact or typed Cloud Run generator contract is established; application, identity flow, infrastructure and integrations require implementation.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-articles: Approved public article catalogue

- Responsibility: Proposed Cloud Firestore database holds validated text from the twenty public UTF-8 files under 30 KB each: stable article ID, title, canonical public URL, text, publication state and revision. Sydney regional placement is proposed, subject to verification and acceptance. Stores editorial authorization metadata separately from public article content. Server-only access through the application service account; browsers have no direct database access. Atomic publication and removal update a catalogue revision; retrieval excludes unpublished or removed records and the application rechecks revisions before returning cited answers. Updates and removals do not depend on a separate vector index. Recovery must not silently republish removed articles. Database rules, transactions, retention, recovery and integration tests require implementation. Backup locations and ancillary data handling require review before claiming Australian residency; no cross-region recovery is assumed.
- Service: Cloud Firestore
- Provider / placement: gcp / australia-southeast1
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d61727469636c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-model: Grounded answer generation

- Responsibility: Proposed Vertex AI managed Gemini model access, called only by the application service account. Receives the question and selected approved public passages with citation IDs; instructed to answer only from supplied evidence and abstain otherwise. No private retrieval, web grounding or tool execution is proposed. Australia is preferred, but no specific model or inference region has been selected or verified. Verify model availability, regional processing guarantees, retention, logging, quotas and contractual data handling before selection. A regional application or endpoint name alone does not prove all model data stays in Australia. Do not silently use a global endpoint, overseas processing or cross-region fallback; return an unavailable response if the approved model path fails. Model instructions alone do not prove grounding: application validation and representative answer, refusal and prompt-injection tests are required. No dedicated model training or endpoint deployment is assumed. Model integration and infrastructure support remain engineering work.
- Service: Vertex AI
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### faq-visitors-app: faq-visitors → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or uncertainty
- Contract task: TASK-CONTRACT-6661712d76697369746f72732d617070
- Integration task: TASK-INTEGRATION-6661712d76697369746f72732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editors-app: faq-editors → faq-app

- Drawn payload/purpose: HTTPS + verified editor identity: upload, preview, publish, update, remove
- Contract task: TASK-CONTRACT-6661712d656469746f72732d617070
- Integration task: TASK-INTEGRATION-6661712d656469746f72732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-articles: faq-app → faq-articles

- Drawn payload/purpose: Firestore API + service identity: articles and revision transactions
- Contract task: TASK-CONTRACT-6661712d6170702d61727469636c6573
- Integration task: TASK-INTEGRATION-6661712d6170702d61727469636c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-model: faq-app → faq-model

- Drawn payload/purpose: Vertex AI API + service identity: passages → draft answer
- Contract task: TASK-CONTRACT-6661712d6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d76697369746f72732d617070 — Define Public website visitors → FAQ website and answer service

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-visitors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-visitors-app: HTTPS question → cited answer or uncertainty. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-visitors-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d656469746f72732d617070 — Define Article editors → FAQ website and answer service

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-editors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-editors-app: HTTPS + verified editor identity: upload, preview, publish, update, remove. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-editors-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d61727469636c6573 — Define FAQ website and answer service → Approved public article catalogue

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-articles: Firestore API + service identity: articles and revision transactions. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-articles
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d6d6f64656c — Define FAQ website and answer service → Grounded answer generation

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-model: Vertex AI API + service identity: passages → draft answer. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d76697369746f7273 — Integrate existing Public website visitors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d76697369746f72732d617070
- Components: faq-visitors
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing human visitors using a browser, outside provisioning scope. Submit questions and receive cited answers or an explicit uncertainty response. No visitor account proposed. Public source material does not imply visitor questions contain no personal information.
2. Verify Approval workflow on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-visitors
- Application/configuration and tests for Public website visitors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d656469746f7273 — Integrate existing Article editors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d656469746f72732d617070
- Components: faq-editors
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-article-lifecycle, ai-public-file-intake

### Implementation steps

1. Responsibility from the board: Existing people responsible for the public help articles, outside provisioning scope. Supply twenty public UTF-8 files under 30 KB each, with titles and canonical public article URLs for citations. Proposed protected workflow previews validated content before publishing and supports replacement and removal. Editor identities are required destination inputs, not invented accounts.
2. Verify Approval workflow on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.; REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-editors
- Application/configuration and tests for Article editors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Implement FAQ website and answer service

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d76697369746f72732d617070, TASK-CONTRACT-6661712d656469746f72732d617070, TASK-CONTRACT-6661712d6170702d61727469636c6573, TASK-CONTRACT-6661712d6170702d6d6f64656c
- Components: faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-article-lifecycle, ai-public-source-boundary, ai-public-file-intake, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed new Google Cloud Run service serves the public website, question API and protected editorial API in one deployment. Sydney placement is proposed, not approved or verified. Editorial file intake validates UTF-8 and the agreed file-size boundary, rejects invalid uploads explicitly, previews content, and requires title and canonical public URL before publication. The precise byte interpretation of 30 KB is an implementation assumption to document. Original files need not be retained separately; validated article text is stored in Firestore. Editorial mutations validate Google-issued identity tokens and a server-side editor allowlist on every request; public routes cannot mutate articles. Reads only published approved articles and ranks passages with application-owned keyword retrieval. Sends selected passages as untrusted evidence, with no private-source credentials, arbitrary URL fetching or model tools. Validates article IDs, citations and current publication revisions before returning an answer; returns uncertainty for insufficient evidence and a clear unavailable response on dependency failure. Uses bounded requests, rate and instance limits, model timeouts and retry limits, plus a dedicated least-privilege service account. Does not persist visitor conversations or log raw questions by default. Owns application code, file workflow, revision checks, representative grounding/retrieval/prompt-injection tests and release/rollback procedures. No supplied application artifact or typed Cloud Run generator contract is established; application, identity flow, infrastructure and integrations require implementation.
2. Verify Google Cloud Run on gcp in australia-southeast1; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Run; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.; REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.; REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.; REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.; REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for FAQ website and answer service

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d61727469636c6573 — Implement Approved public article catalogue

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170702d61727469636c6573
- Components: faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-article-lifecycle, ai-public-source-boundary, ai-public-file-intake, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed Cloud Firestore database holds validated text from the twenty public UTF-8 files under 30 KB each: stable article ID, title, canonical public URL, text, publication state and revision. Sydney regional placement is proposed, subject to verification and acceptance. Stores editorial authorization metadata separately from public article content. Server-only access through the application service account; browsers have no direct database access. Atomic publication and removal update a catalogue revision; retrieval excludes unpublished or removed records and the application rechecks revisions before returning cited answers. Updates and removals do not depend on a separate vector index. Recovery must not silently republish removed articles. Database rules, transactions, retention, recovery and integration tests require implementation. Backup locations and ancillary data handling require review before claiming Australian residency; no cross-region recovery is assumed.
2. Verify Cloud Firestore on gcp in australia-southeast1; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Cloud Firestore; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.; REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.; REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.; REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.; REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-articles
- Application/configuration and tests for Approved public article catalogue

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d6d6f64656c — Implement Grounded answer generation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170702d6d6f64656c
- Components: faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed Vertex AI managed Gemini model access, called only by the application service account. Receives the question and selected approved public passages with citation IDs; instructed to answer only from supplied evidence and abstain otherwise. No private retrieval, web grounding or tool execution is proposed. Australia is preferred, but no specific model or inference region has been selected or verified. Verify model availability, regional processing guarantees, retention, logging, quotas and contractual data handling before selection. A regional application or endpoint name alone does not prove all model data stays in Australia. Do not silently use a global endpoint, overseas processing or cross-region fallback; return an unavailable response if the approved model path fails. Model instructions alone do not prove grounding: application validation and representative answer, refusal and prompt-injection tests are required. No dedicated model training or endpoint deployment is assumed. Model integration and infrastructure support remain engineering work.
2. Verify Vertex AI on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Vertex AI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.; REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.; REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-model
- Application/configuration and tests for Grounded answer generation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d76697369746f72732d617070 — Wire Public website visitors to FAQ website and answer service

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d76697369746f72732d617070, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070
- Components: faq-visitors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-visitors-app carrying HTTPS question → cited answer or uncertainty, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-visitors-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d656469746f72732d617070 — Wire Article editors to FAQ website and answer service

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d656469746f72732d617070, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d617070
- Components: faq-editors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-editors-app carrying HTTPS + verified editor identity: upload, preview, publish, update, remove, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-editors-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d61727469636c6573 — Wire FAQ website and answer service to Approved public article catalogue

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d61727469636c6573, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573
- Components: faq-app, faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-articles carrying Firestore API + service identity: articles and revision transactions, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-articles
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d6d6f64656c — Wire FAQ website and answer service to Grounded answer generation

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d6d6f64656c, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d6d6f64656c
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-model carrying Vertex AI API + service identity: passages → draft answer, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070 — Verify live Public website visitors → FAQ website and answer service

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d76697369746f72732d617070
- Components: faq-visitors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-visitors-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-visitors-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070 — Verify live Article editors → FAQ website and answer service

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d656469746f72732d617070
- Components: faq-editors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-editors-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-editors-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573 — Verify live FAQ website and answer service → Approved public article catalogue

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d61727469636c6573
- Components: faq-app, faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-articles with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-articles

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c — Verify live FAQ website and answer service → Grounded answer generation

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d6265343661353230 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-be46a520

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273 — Verify REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-app, faq-articles, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers

### Implementation steps

1. Basis: “answers questions from our twenty public help articles” and “says when it does not know.”; rationale: Proposed acceptance boundary prevents plausible model output from being presented as supported article guidance.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65 — Verify REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-editors, faq-app, faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-article-lifecycle

### Implementation steps

1. Basis: “We need to update and remove articles.”; rationale: Proposed server-side publication and revision checks prevent stale or removed material from remaining eligible for new answers.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279 — Verify REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-app, faq-articles, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-source-boundary

### Implementation steps

1. Basis: “It must not answer from private sources.”; rationale: A public endpoint must not gain private-source access through retrieval, supplied URLs or article instructions; this requires permissions and application tests.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e74616b65 — Verify REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-editors, faq-app, faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-file-intake

### Implementation steps

1. Basis: “Twenty public UTF-8 help articles under 30 KB each, supplied as files.” Existing faq-editors, faq-app and faq-articles responsibilities.; rationale: File validation and protected publication prevent malformed or unapproved content from entering the public answer catalogue; the workflow remains a proposed implementation.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379 — Verify REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-app, faq-articles, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-location-transparency

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.”; rationale: Australian storage placement does not establish Australian inference or ancillary data handling; explicit verification prevents the preference becoming an unsupported residency claim.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-6661712d76697369746f72732d617070, TASK-INTEGRATION-6661712d656469746f72732d617070, TASK-INTEGRATION-6661712d6170702d61727469636c6573, TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d6265343661353230, TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273, TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65, TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279, TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e74616b65, TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379, TASK-INTEGRATION-LIVE-6661712d76697369746f72732d617070, TASK-INTEGRATION-LIVE-6661712d656469746f72732d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-001 (req-be46a520) → TASK-ACCEPTANCE-7265712d6265343661353230; Recorded from user discussion
- REQ-004 (ai-grounded-answers) → TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273; Proposed; needs confirmation
- REQ-005 (ai-article-lifecycle) → TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65; Proposed; needs confirmation
- REQ-006 (ai-public-source-boundary) → TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279; Proposed; needs confirmation
- REQ-007 (ai-public-file-intake) → TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e74616b65; Proposed; needs confirmation
- REQ-008 (ai-location-transparency) → TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379; Proposed; needs confirmation
