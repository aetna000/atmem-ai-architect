# Questions and assumptions to resolve

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

- [ai-grounded-answers] Confirm REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.
- [ai-article-lifecycle] Confirm REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.
- [ai-public-source-boundary] Confirm REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.
- [ai-public-file-intake] Confirm REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.
- [ai-location-transparency] Confirm REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.
- [acceptance-req-be46a520] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-grounded-answers] Agree a measurable acceptance check for REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.
- [acceptance-ai-article-lifecycle] Agree a measurable acceptance check for REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.
- [acceptance-ai-public-source-boundary] Agree a measurable acceptance check for REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.
- [acceptance-ai-public-file-intake] Agree a measurable acceptance check for REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.
- [acceptance-ai-location-transparency] Agree a measurable acceptance check for REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d61727469636c652d6c6966656379636c65] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d616e7377657273] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d66696c652d696e74616b65] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d736f757263652d626f756e64617279] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
