Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

# Cited public FAQ — deployment document

Generated 2026-11-09 17:34 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Google Cloud
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. Australia is preferred; make model/data-location limitations explicit.
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**Public experience**

- Public website visitors (Tools & data, existing, sketch) — Existing human visitors using a browser, outside provisioning scope. Submit questions and receive cited answers or an explicit uncertainty response. No visitor account proposed. Public source material does not imply visitor questions contain no personal information.
- FAQ website and answer service (Google Cloud, sketch) — Proposed new Google Cloud Run service serves the public website, question API and protected editorial API in one deployment. Sydney placement is proposed, not approved or verified. Editorial file intake validates UTF-8 and the agreed file-size boundary, rejects invalid uploads explicitly, previews content, and requires title and canonical public URL before publication. The precise byte interpretation of 30 KB is an implementation assumption to document. Original files need not be retained separately; validated article text is stored in Firestore. Editorial mutations validate Google-issued identity tokens and a server-side editor allowlist on every request; public routes cannot mutate articles. Reads only published approved articles and ranks passages with application-owned keyword retrieval. Sends selected passages as untrusted evidence, with no private-source credentials, arbitrary URL fetching or model tools. Validates article IDs, citations and current publication revisions before returning an answer; returns uncertainty for insufficient evidence and a clear unavailable response on dependency failure. Uses bounded requests, rate and instance limits, model timeouts and retry limits, plus a dedicated least-privilege service account. Does not persist visitor conversations or log raw questions by default. Owns application code, file workflow, revision checks, representative grounding/retrieval/prompt-injection tests and release/rollback procedures. No supplied application artifact or typed Cloud Run generator contract is established; application, identity flow, infrastructure and integrations require implementation.

**Article management**

- Article editors (Tools & data, existing, sketch) — Existing people responsible for the public help articles, outside provisioning scope. Supply twenty public UTF-8 files under 30 KB each, with titles and canonical public article URLs for citations. Proposed protected workflow previews validated content before publishing and supports replacement and removal. Editor identities are required destination inputs, not invented accounts.
- Approved public article catalogue (Google Cloud, sketch) — Proposed Cloud Firestore database holds validated text from the twenty public UTF-8 files under 30 KB each: stable article ID, title, canonical public URL, text, publication state and revision. Sydney regional placement is proposed, subject to verification and acceptance. Stores editorial authorization metadata separately from public article content. Server-only access through the application service account; browsers have no direct database access. Atomic publication and removal update a catalogue revision; retrieval excludes unpublished or removed records and the application rechecks revisions before returning cited answers. Updates and removals do not depend on a separate vector index. Recovery must not silently republish removed articles. Database rules, transactions, retention, recovery and integration tests require implementation. Backup locations and ancillary data handling require review before claiming Australian residency; no cross-region recovery is assumed.

**Answer generation**

- Grounded answer generation (Google Cloud, sketch) — Proposed Vertex AI managed Gemini model access, called only by the application service account. Receives the question and selected approved public passages with citation IDs; instructed to answer only from supplied evidence and abstain otherwise. No private retrieval, web grounding or tool execution is proposed. Australia is preferred, but no specific model or inference region has been selected or verified. Verify model availability, regional processing guarantees, retention, logging, quotas and contractual data handling before selection. A regional application or endpoint name alone does not prove all model data stays in Australia. Do not silently use a global endpoint, overseas processing or cross-region fallback; return an unavailable response if the approved model path fails. Model instructions alone do not prove grounding: application validation and representative answer, refusal and prompt-injection tests are required. No dedicated model training or endpoint deployment is assumed. Model integration and infrastructure support remain engineering work.

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Article editors<br/>Tools & data"]
  n2["FAQ website and answer service<br/>Google Cloud"]
  n3["Approved public article catalogue<br/>Google Cloud"]
  n4["Grounded answer generation<br/>Google Cloud"]
  n0 -->|HTTPS question → cited answer or uncertainty| n2
  n1 -->|HTTPS + verified editor identity: upload, preview, publish, update, remove| n2
  n2 -->|Firestore API + service identity: articles and revision transactions| n3
  n2 -->|Vertex AI API + service identity: passages → draft answer| n4
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitors | Public website visitors | tools | Approval workflow | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-editors | Article editors | tools | Approval workflow | To be selected | Existing | Existing — reference/import plan needed |
| faq-app | FAQ website and answer service | gcp | Google Cloud Run | australia-southeast1 | Proposed | Implementation needed |
| faq-articles | Approved public article catalogue | gcp | Cloud Firestore | australia-southeast1 | Proposed | Implementation needed |
| faq-model | Grounded answer generation | gcp | Vertex AI | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Public website visitors** (faq-visitors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Article editors** (faq-editors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **FAQ website and answer service** (faq-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-visitors, faq-editors.
- **Approved public article catalogue** (faq-articles): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.
- **Grounded answer generation** (faq-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.

### Engineering work remaining

- Article editors: Existing — reference/import plan needed.
- FAQ website and answer service: Implementation needed.
- Approved public article catalogue: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Public website visitors | FAQ website and answer service | HTTPS question → cited answer or uncertainty | Internal |
| Article editors | FAQ website and answer service | HTTPS + verified editor identity: upload, preview, publish, update, remove | Internal |
| FAQ website and answer service | Approved public article catalogue | Firestore API + service identity: articles and revision transactions | Internal |
| FAQ website and answer service | Grounded answer generation | Vertex AI API + service identity: passages → draft answer | Internal |

## 5. Security controls

- **Public website visitors** — Existing human visitors using a browser, outside provisioning scope. Submit questions and receive cited answers or an explicit uncertainty response. No visitor account proposed. Public source material does not imply visitor questions contain no personal information.
- **Article editors** — Existing people responsible for the public help articles, outside provisioning scope. Supply twenty public UTF-8 files under 30 KB each, with titles and canonical public article URLs for citations. Proposed protected workflow previews validated content before publishing and supports replacement and removal. Editor identities are required destination inputs, not invented accounts.
- Requirement: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary. (must)
- Requirement: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary. | security | not measurable yet | Open |
| The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions. (must, open)
- Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles. (must, open)
- The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.”, “The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 5 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Approved public article catalogue | Storage | needs data_gb | price needed | — | — |
| Grounded answer generation | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Public website visitors, Article editors, FAQ website and answer service.

**Estimate gaps:**

- Approved public article catalogue / Storage: input needed (data_gb).
- Grounded answer generation / Endpoint hours: price needed.
- Public website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Article editors: no cost lines; add charges or an explicit zero-cost line with a reason.
- FAQ website and answer service: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public experience: FAQ website and answer service.
4. Provision article management: Approved public article catalogue.
5. Provision answer generation: Grounded answer generation.
6. Connect existing systems: Public website visitors, Article editors; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Approved public article catalogue: needs data_gb _(estimate)_
- Grounded answer generation: needs a unit price with a source _(estimate)_
