# Infrastructure implementation required

Requested providers: gcp. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Article editors: Existing — reference/import plan needed.
- FAQ website and answer service: Implementation needed.
- Approved public article catalogue: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
