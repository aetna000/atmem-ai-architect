Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions. (must, open); target: acceptance target needed; linked blocks: faq-app, faq-articles, faq-model

Design explanation: Proposed acceptance boundary prevents plausible model output from being presented as supported article guidance.

Basis: “answers questions from our twenty public help articles” and “says when it does not know.”
- [REQ-005] Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles. (must, open); target: acceptance target needed; linked blocks: faq-editors, faq-app, faq-articles

Design explanation: Proposed server-side publication and revision checks prevent stale or removed material from remaining eligible for new answers.

Basis: “We need to update and remove articles.”
- [REQ-006] The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary. (must, open); target: acceptance target needed; linked blocks: faq-app, faq-articles, faq-model

Design explanation: A public endpoint must not gain private-source access through retrieval, supplied URLs or article instructions; this requires permissions and application tests.

Basis: “It must not answer from private sources.”
- [REQ-007] The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks. (must, open); target: acceptance target needed; linked blocks: faq-editors, faq-app, faq-articles

Design explanation: File validation and protected publication prevent malformed or unapproved content from entering the public answer catalogue; the workflow remains a proposed implementation.

Basis: “Twenty public UTF-8 help articles under 30 KB each, supplied as files.” Existing faq-editors, faq-app and faq-articles responsibilities.
- [REQ-008] The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision. (should, open); target: acceptance target needed; linked blocks: faq-app, faq-articles, faq-model

Design explanation: Australian storage placement does not establish Australian inference or ancillary data handling; explicit verification prevents the preference becoming an unsupported residency claim.

Basis: “Australia is preferred; make model/data-location limitations explicit.”

## How the system works

The current design contains 5 components and 4 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Public website visitors → FAQ website and answer service

HTTPS question → cited answer or uncertainty

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Article editors → FAQ website and answer service

HTTPS + verified editor identity: upload, preview, publish, update, remove

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: FAQ website and answer service → Approved public article catalogue

Firestore API + service identity: articles and revision transactions

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: FAQ website and answer service → Grounded answer generation

Vertex AI API + service identity: passages → draft answer

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Public website visitors

Approval workflow · tools · region: To be selected · classification: Public

Existing human visitors using a browser, outside provisioning scope. Submit questions and receive cited answers or an explicit uncertainty response. No visitor account proposed. Public source material does not imply visitor questions contain no personal information.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Public website visitors → FAQ website and answer service: HTTPS question → cited answer or uncertainty

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Article editors

Approval workflow · tools · region: To be selected · classification: Internal

Existing people responsible for the public help articles, outside provisioning scope. Supply twenty public UTF-8 files under 30 KB each, with titles and canonical public article URLs for citations. Proposed protected workflow previews validated content before publishing and supports replacement and removal. Editor identities are required destination inputs, not invented accounts.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Article editors → FAQ website and answer service: HTTPS + verified editor identity: upload, preview, publish, update, remove

Requirement traceability: REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.; REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### FAQ website and answer service

Google Cloud Run · gcp · region: australia-southeast1 · classification: Internal

Proposed new Google Cloud Run service serves the public website, question API and protected editorial API in one deployment. Sydney placement is proposed, not approved or verified. Editorial file intake validates UTF-8 and the agreed file-size boundary, rejects invalid uploads explicitly, previews content, and requires title and canonical public URL before publication. The precise byte interpretation of 30 KB is an implementation assumption to document. Original files need not be retained separately; validated article text is stored in Firestore. Editorial mutations validate Google-issued identity tokens and a server-side editor allowlist on every request; public routes cannot mutate articles. Reads only published approved articles and ranks passages with application-owned keyword retrieval. Sends selected passages as untrusted evidence, with no private-source credentials, arbitrary URL fetching or model tools. Validates article IDs, citations and current publication revisions before returning an answer; returns uncertainty for insufficient evidence and a clear unavailable response on dependency failure. Uses bounded requests, rate and instance limits, model timeouts and retry limits, plus a dedicated least-privilege service account. Does not persist visitor conversations or log raw questions by default. Owns application code, file workflow, revision checks, representative grounding/retrieval/prompt-injection tests and release/rollback procedures. No supplied application artifact or typed Cloud Run generator contract is established; application, identity flow, infrastructure and integrations require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public website visitors → FAQ website and answer service: HTTPS question → cited answer or uncertainty; Article editors → FAQ website and answer service: HTTPS + verified editor identity: upload, preview, publish, update, remove

Outputs: FAQ website and answer service → Approved public article catalogue: Firestore API + service identity: articles and revision transactions; FAQ website and answer service → Grounded answer generation: Vertex AI API + service identity: passages → draft answer

Requirement traceability: REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.; REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.; REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.; REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.; REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Approved public article catalogue

Cloud Firestore · gcp · region: australia-southeast1 · classification: Internal

Proposed Cloud Firestore database holds validated text from the twenty public UTF-8 files under 30 KB each: stable article ID, title, canonical public URL, text, publication state and revision. Sydney regional placement is proposed, subject to verification and acceptance. Stores editorial authorization metadata separately from public article content. Server-only access through the application service account; browsers have no direct database access. Atomic publication and removal update a catalogue revision; retrieval excludes unpublished or removed records and the application rechecks revisions before returning cited answers. Updates and removals do not depend on a separate vector index. Recovery must not silently republish removed articles. Database rules, transactions, retention, recovery and integration tests require implementation. Backup locations and ancillary data handling require review before claiming Australian residency; no cross-region recovery is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: FAQ website and answer service → Approved public article catalogue: Firestore API + service identity: articles and revision transactions

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.; REQ-005: Authorized editors shall be able to publish, replace and remove articles; new questions shall use current published revisions, and answers shall recheck publication state before returning citations. Public visitors shall not be able to change articles.; REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.; REQ-007: The editorial workflow shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and size, and explicitly reject invalid files before publication. Proposed publication requires an authorized editor, preview, title and canonical public citation URL; replacement and removal shall preserve stable article identity and revision checks.; REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Grounded answer generation

Vertex AI · gcp · region: To be selected · classification: Public

Proposed Vertex AI managed Gemini model access, called only by the application service account. Receives the question and selected approved public passages with citation IDs; instructed to answer only from supplied evidence and abstain otherwise. No private retrieval, web grounding or tool execution is proposed. Australia is preferred, but no specific model or inference region has been selected or verified. Verify model availability, regional processing guarantees, retention, logging, quotas and contractual data handling before selection. A regional application or endpoint name alone does not prove all model data stays in Australia. Do not silently use a global endpoint, overseas processing or cross-region fallback; return an unavailable response if the approved model path fails. Model instructions alone do not prove grounding: application validation and representative answer, refusal and prompt-injection tests are required. No dedicated model training or endpoint deployment is assumed. Model integration and infrastructure support remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: FAQ website and answer service → Grounded answer generation: Vertex AI API + service identity: passages → draft answer

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The public assistant shall answer article questions using approved published article evidence and explicitly state when that evidence does not support an answer; acceptance testing shall include supported, unsupported and misleading questions.; REQ-006: The answer path shall retrieve only the approved public article catalogue, possess no private-source access, and prevent user or article instructions from enabling arbitrary retrieval or tools. Acceptance tests shall exercise attempts to cross this boundary.; REQ-008: The design should prefer Australian application hosting, article storage and AI processing. Before implementation approval, document the selected services' model availability, processing locations, retention, logging and backup limitations. Australian residency shall not be claimed without evidence; any proposed overseas processing or global routing shall be presented for a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Article editors<br/>Tools & data"]
  n2["FAQ website and answer service<br/>Google Cloud"]
  n3["Approved public article catalogue<br/>Google Cloud"]
  n4["Grounded answer generation<br/>Google Cloud"]
  n0 -->|HTTPS question → cited answer or uncertainty| n2
  n1 -->|HTTPS + verified editor identity: upload, preview, publish, update, remove| n2
  n2 -->|Firestore API + service identity: articles and revision transactions| n3
  n2 -->|Vertex AI API + service identity: passages → draft answer| n4
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitors | Public website visitors | tools | Approval workflow | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-editors | Article editors | tools | Approval workflow | To be selected | Existing | Existing — reference/import plan needed |
| faq-app | FAQ website and answer service | gcp | Google Cloud Run | australia-southeast1 | Proposed | Implementation needed |
| faq-articles | Approved public article catalogue | gcp | Cloud Firestore | australia-southeast1 | Proposed | Implementation needed |
| faq-model | Grounded answer generation | gcp | Vertex AI | To be selected | Proposed | Implementation needed |

### Resources and cost dimensions

- **Public website visitors** (faq-visitors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Article editors** (faq-editors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **FAQ website and answer service** (faq-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-visitors, faq-editors.
- **Approved public article catalogue** (faq-articles): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.
- **Grounded answer generation** (faq-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.

### Engineering work remaining

- Article editors: Existing — reference/import plan needed.
- FAQ website and answer service: Implementation needed.
- Approved public article catalogue: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
