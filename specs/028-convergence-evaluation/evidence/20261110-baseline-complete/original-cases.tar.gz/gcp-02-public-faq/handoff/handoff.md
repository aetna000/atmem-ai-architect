# Delivery handoff

Snapshot b758e367-1500-4b71-8934-fa7e517a2a61 · design r3 · generated 2026-11-09T17:34:09.828Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Approved public article catalogue / Storage: input needed (data_gb).
- Grounded answer generation / Endpoint hours: price needed.
- Public website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Article editors: no cost lines; add charges or an explicit zero-cost line with a reason.
- FAQ website and answer service: no cost lines; add charges or an explicit zero-cost line with a reason.
- Article editors: Existing — reference/import plan needed.
- FAQ website and answer service: Implementation needed.
- Approved public article catalogue: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
