# Delivery handoff

Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Company sign-in integration / Checked requests: input needed (requests_per_month).
- Source synchronization / Data processed: input needed (data_gb).
- Document and permission state / Storage: input needed (data_gb).
- Searchable document copies / Index storage: input needed (data_gb).
- Answer and embedding models / Endpoint hours: price needed.
- Connector credential protection / Checked requests: input needed (requests_per_month).
- Staff browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Internal assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational evidence and alerts: no cost lines; add charges or an explicit zero-cost line with a reason.
- Company sign-in integration: Implementation needed.
- Internal assistant: Implementation needed.
- Source synchronization: Implementation needed.
- Document and permission state: Implementation needed.
- Searchable document copies: Implementation needed.
- Answer and embedding models: Implementation needed.
- Connector credential protection: Implementation needed.
- Operational evidence and alerts: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → company-sign-in: implement data flow, access policy and acceptance test.
- Wire source-ingestion → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-ingestion → confluence: implement data flow, access policy and acceptance test.
- Wire source-ingestion → authorization-state: implement data flow, access policy and acceptance test.
- Wire source-ingestion → document-search: implement data flow, access policy and acceptance test.
- Wire source-ingestion → language-models: implement data flow, access policy and acceptance test.
- Wire assistant-app → document-search: implement data flow, access policy and acceptance test.
- Wire assistant-app → authorization-state: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → language-models: implement data flow, access policy and acceptance test.
- Wire source-ingestion → connector-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire source-ingestion → operations-logs: implement data flow, access policy and acceptance test.
- Wire assistant-app → operations-logs: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
