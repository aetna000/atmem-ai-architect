# Start here — Permission-aware knowledge assistant

Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

Give this ZIP to a coding agent with this instruction:

> Read AGENTS.md and spec-kit/plan.md. Review the specification, design and implementation tasks. Explain the first actionable task and ask about the highest-impact missing decision. Then implement approved scope, maintaining task progress and test evidence. Do not treat this handoff as permission to deploy.

## Reading order

1. AGENTS.md
2. specification.md or specification.pdf
3. diagram.svg or diagram.pdf, then resource-schedule.json
4. spec-kit/readiness.md, plan.md, contracts.md and questions.md
5. spec-kit/tasks.md or tasks.json
6. terraform/ and estimate.json

project.atmem-ai-architect.json is the editable source snapshot. PDFs/images are review formats. The receiving agent needs the destination repository, runtime decisions and appropriate access; unknowns are listed rather than invented.
