Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

# Permission-aware knowledge assistant — deployment document

Generated 2026-11-09 17:22 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** Ten thousand company documents. Source permissions are authoritative; content and authorization can change independently. Australia for content, indexes and processing; explain service/model residency gaps.
- **Cloud preference:** Azure
- **Budget and timeline:** —

## 3. Architecture

**Staff access**

- Staff browser (Tools & data, existing, sketch) — Existing staff client outside provisioning scope. Uses the proposed internal browser application and company sign-in. User population and company identity configuration remain unconfirmed. Browser locations and downloaded answer handling are not established by the Australian server placement.
- Company sign-in integration (Azure, sketch) — Proposed Microsoft Entra ID application registration and sign-in integration, not a new company directory. Existing tenant and federation arrangements require confirmation. Validate issuer, audience and sessions server-side; map immutable subjects to source identities. Signing in never grants document access by itself; unknown mappings deny access. Tenant identity metadata and service processing geography require separate review; an Australian application region does not establish Entra residency.

**Existing knowledge**

- Existing SharePoint (Tools & data, existing) — Existing authoritative source of documents, versions and permissions, outside provisioning scope. Native Microsoft Graph integration must implement change tracking, deletion detection and current source-side user access checks. Content and permissions can change independently: content change tracking alone is insufficient to track authorization. Tenant consent, delegated access, group changes and permission inheritance require qualification. Existing tenant content geography remains unverified; placing the assistant in Australia does not relocate SharePoint.
- Existing Confluence (Tools & data, existing) — Existing authoritative source of pages, revisions and permissions, outside provisioning scope. Cloud versus Data Center edition and hosting geography remain unconfirmed. Native integration must independently reconcile content revisions, restrictions, inherited permissions, group membership, identities and deletions, and qualify source-side mapped-user access checks. Unchanged page content is never evidence of unchanged authorization. No vendor compatibility or Australian source residency is assumed.

**Answering**

- Internal assistant (Azure, sketch) — Proposed Azure App Service deployment owning browser UI, backend authorization and cited responses over 10,000 source documents. Retrieve candidate metadata first; never expose unauthorized titles, snippets or counts. Check current source-side user access, authoritative lifecycle state and content revision before loading text into the model. Track content revision and authorization generation separately; cached permission snapshots cannot replace current source checks. Recheck dependencies before releasing a complete answer; do not stream unvalidated answer text. Discard or regenerate on changed access, revision or quarantine. Exclude unavailable sources, answer from independently authorized remaining evidence or abstain. No shared answer cache, persistent conversation history or action tools are proposed. Retrieved text is untrusted; validate citation provenance. Managed identity accesses Azure dependencies. Australia East is a proposed primary region only; qualify application temporary storage, diagnostics and recovery locations. No overseas fallback. Cross-vendor checks are not atomic: define the authorization observation point and test in-flight revocation races without promising instantaneous revocation.
- Searchable document copies (Azure, sketch) — Proposed Azure AI Search service holding derived chunks, embeddings, source references, content revisions and separate permission generations for hybrid keyword/vector retrieval across 10,000 source documents. Document count does not determine index capacity; chunk count and embedding dimensions remain engineering sizing inputs. Application security filters narrow candidates but never establish current access. Metadata-only candidate retrieval precedes source authorization and text fetch. Only ingestion writes and only the backend queries; no browser index access. Versioned rebuilds and controlled cutover preserve lifecycle fences. Deletion lag cannot override quarantine. Australia East is a proposed candidate; SKU, vector capability, capacity, semantic enrichment if later added, diagnostic locations and recovery copies require residency qualification. No external enrichment or overseas index replica is proposed.
- Answer and embedding models (Azure, sketch) — Proposed Azure OpenAI resource with separately configured generation and embedding deployments. Both document/query embeddings and answer generation must process content in Australia. Australia East is only a candidate; no model, regional deployment type, quota or entitlement is selected or verified. Verify generation and embedding availability separately, together with processing geography, service retention and abuse-monitoring handling. An Australian resource address alone is insufficient evidence; do not silently select Global or Data Zone deployment types or overseas fallback. If no compliant model combination is available, retain the Australian boundary and report the blocked model implementation. Use only backend-authorized text, return structured source identifiers and abstain without sufficient evidence; application validates citations against supplied chunks. No model behavior has been tested.

**Knowledge synchronization**

- Source synchronization (Azure, sketch) — Proposed dedicated Azure Functions app containing independent SharePoint and Confluence adapters with durable checkpoints, schedules and bounded retries. Synchronize a 10,000-document corpus; byte volume and change rates remain unknown. Track content revisions and permission generations independently, including permission-only and group-membership changes. Combine supported change signals with periodic reconciliation; do not assume content events cover authorization. Extract text, request embeddings and write revision-tagged chunks. Persist revocation/deletion quarantine before asynchronous index cleanup. Conditional writes reject stale content and permission replays. Recover from checkpoints and recheck current source state; failed records remain quarantined. Native APIs, extraction and inherited permission handling require engineering and qualification. Australia East is proposed; Functions host/checkpoint storage, temporary extraction files and backups must also be qualified for Australian residency. Required host storage is an owned deployment dependency to implement in the resource schedule, not an existing verified resource.
- Document and permission state (Azure, sketch) — Proposed Azure Cosmos DB account for source-qualified document IDs, independent content revisions and permission generations, deletion tombstones, identity mappings, checkpoints and quarantine. Application lifecycle authority never replaces current source authorization. Strong consistency and a single Australian primary region are proposed, subject to configuration qualification. Missing state or read failure denies affected content. Serving chunks must match active content and authorization fences. Conditional updates prevent one lifecycle stream from rolling back the other; reconciliation detects partial writes. Retain tombstones until stale replay and index copies cannot resurrect content; retention and recovery targets remain open. Australia East is a candidate only; backup location, restore behavior and all replication destinations require verification. No overseas replicas or automatic overseas failover.

**Operations**

- Connector credential protection (Azure, sketch) — Proposed Azure Key Vault for connector certificates or secrets only where managed or delegated identity cannot replace them. Separate scoped access for ingestion and serving identities, credential rotation and no interactive client access. No credentials in the project or logs. Vendor credential and consent mechanisms remain connector engineering work. Australia East is a candidate only; verify service replication, recovery and diagnostic geography rather than assuming the selected vault region proves every location.
- Operational evidence and alerts (Azure, sketch) — Proposed Azure Monitor Logs workspace recording structured authorization outcomes, separate content/permission synchronization lag, source outages, quarantine, model failures and recovery evidence. Exclude document text, prompts, answers, secrets and tokens by default; protect sensitive identifiers. Measure permission-only changes separately from content updates. Alerts and an owned response runbook are required before production; retention, recipients and operational ownership remain open. Propose Australian workspace and diagnostic storage, subject to service-specific verification; this is an engineering proposal rather than a user-confirmed logs policy. No overseas telemetry export. Logs are operational evidence, not proof of permission enforcement.

```mermaid
flowchart LR
  n0["Staff browser<br/>Tools & data"]
  n1["Existing SharePoint<br/>Tools & data"]
  n2["Existing Confluence<br/>Tools & data"]
  n3["Company sign-in integration<br/>Azure"]
  n4["Internal assistant<br/>Azure"]
  n5["Source synchronization<br/>Azure"]
  n6["Document and permission state<br/>Azure"]
  n7["Searchable document copies<br/>Azure"]
  n8["Answer and embedding models<br/>Azure"]
  n9["Connector credential protection<br/>Azure"]
  n10["Operational evidence and alerts<br/>Azure"]
  n0 -->|HTTPS questions; authorized cited answers returned| n4
  n4 -->|OpenID Connect sign-in; server-side token validation| n3
  n5 -->|Microsoft Graph HTTPS: independent content and permission reconciliation| n1
  n5 -->|Native Confluence HTTPS API: independent page and permission reconciliation| n2
  n5 -->|Managed identity: separate content/permission fences, tombstones and checkpoints| n6
  n5 -->|Managed identity: revision-tagged chunks, permission generations and deletion re| n7
  n5 -->|Managed identity HTTPS: document embeddings; Australian processing required| n8
  n4 -->|Managed identity: filtered candidate metadata, then authorized chunk fetch| n7
  n4 -->|Strong reads: identity, quarantine and independent content/permission fences| n6
  n4 -->|Current source-side user access and revision checks; deny on uncertainty| n1
  n4 -->|Current mapped-user access and revision checks; deny on uncertainty| n2
  n4 -->|Managed identity HTTPS: query embeddings and authorized generation in Australia| n8
  n5 -->|Managed identity: scoped connector credential retrieval| n9
  n4 -->|Managed identity: scoped source-check credential retrieval| n9
  n5 -->|Redacted content/permission lag, quarantine, outage and recovery telemetry| n10
  n4 -->|Redacted authorization, citation and failure telemetry| n10
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Staff browser | tools | Web browser | Existing user locations | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| company-sign-in | Company sign-in integration | azure | Microsoft Entra ID | Tenant geography to be confirmed | Proposed | Implementation needed |
| assistant-app | Internal assistant | azure | Azure App Service | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| source-ingestion | Source synchronization | azure | Azure Functions | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| authorization-state | Document and permission state | azure | Azure Cosmos DB | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| document-search | Searchable document copies | azure | Azure AI Search | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| language-models | Answer and embedding models | azure | Azure OpenAI | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| connector-secrets | Connector credential protection | azure | Azure Key Vault | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| operations-logs | Operational evidence and alerts | azure | Azure Monitor Logs | australiaeast (proposed; unverified) | Proposed | Implementation needed |

### Resources and cost dimensions

- **Staff browser** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Company sign-in integration** (company-sign-in): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app.
- **Internal assistant** (assistant-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser.
- **Source synchronization** (source-ingestion): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Document and permission state** (authorization-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Searchable document copies** (document-search): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Answer and embedding models** (language-models): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Connector credential protection** (connector-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Operational evidence and alerts** (operations-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.

### Engineering work remaining

- Company sign-in integration: Implementation needed.
- Internal assistant: Implementation needed.
- Source synchronization: Implementation needed.
- Document and permission state: Implementation needed.
- Searchable document copies: Implementation needed.
- Answer and embedding models: Implementation needed.
- Connector credential protection: Implementation needed.
- Operational evidence and alerts: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → company-sign-in: implement data flow, access policy and acceptance test.
- Wire source-ingestion → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-ingestion → confluence: implement data flow, access policy and acceptance test.
- Wire source-ingestion → authorization-state: implement data flow, access policy and acceptance test.
- Wire source-ingestion → document-search: implement data flow, access policy and acceptance test.
- Wire source-ingestion → language-models: implement data flow, access policy and acceptance test.
- Wire assistant-app → document-search: implement data flow, access policy and acceptance test.
- Wire assistant-app → authorization-state: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → language-models: implement data flow, access policy and acceptance test.
- Wire source-ingestion → connector-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire source-ingestion → operations-logs: implement data flow, access policy and acceptance test.
- Wire assistant-app → operations-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Staff browser | Internal assistant | HTTPS questions; authorized cited answers returned | Confidential |
| Internal assistant | Company sign-in integration | OpenID Connect sign-in; server-side token validation | Confidential |
| Source synchronization | Existing SharePoint | Microsoft Graph HTTPS: independent content and permission reconciliation | Confidential |
| Source synchronization | Existing Confluence | Native Confluence HTTPS API: independent page and permission reconciliation | Confidential |
| Source synchronization | Document and permission state | Managed identity: separate content/permission fences, tombstones and checkpoints | Confidential |
| Source synchronization | Searchable document copies | Managed identity: revision-tagged chunks, permission generations and deletion re | Confidential |
| Source synchronization | Answer and embedding models | Managed identity HTTPS: document embeddings; Australian processing required | Confidential |
| Internal assistant | Searchable document copies | Managed identity: filtered candidate metadata, then authorized chunk fetch | Confidential |
| Internal assistant | Document and permission state | Strong reads: identity, quarantine and independent content/permission fences | Confidential |
| Internal assistant | Existing SharePoint | Current source-side user access and revision checks; deny on uncertainty | Confidential |
| Internal assistant | Existing Confluence | Current mapped-user access and revision checks; deny on uncertainty | Confidential |
| Internal assistant | Answer and embedding models | Managed identity HTTPS: query embeddings and authorized generation in Australia | Confidential |
| Source synchronization | Connector credential protection | Managed identity: scoped connector credential retrieval | Confidential |
| Internal assistant | Connector credential protection | Managed identity: scoped source-check credential retrieval | Confidential |
| Source synchronization | Operational evidence and alerts | Redacted content/permission lag, quarantine, outage and recovery telemetry | Confidential |
| Internal assistant | Operational evidence and alerts | Redacted authorization, citation and failure telemetry | Confidential |

## 5. Security controls

- **Staff browser** — Existing staff client outside provisioning scope. Uses the proposed internal browser application and company sign-in. User population and company identity configuration remain unconfirmed. Browser locations and downloaded answer handling are not established by the Australian server placement.
- **Company sign-in integration** — Proposed Microsoft Entra ID application registration and sign-in integration, not a new company directory. Existing tenant and federation arrangements require confirmation. Validate issuer, audience and sessions server-side; map immutable subjects to source identities. Signing in never grants document access by itself; unknown mappings deny access. Tenant identity metadata and service processing geography require separate review; an Australian application region does not establish Entra residency.
- **Connector credential protection** — Proposed Azure Key Vault for connector certificates or secrets only where managed or delegated identity cannot replace them. Separate scoped access for ingestion and serving identities, credential rotation and no interactive client access. No credentials in the project or logs. Vendor credential and consent mechanisms remain connector engineering work. Australia East is a candidate only; verify service replication, recovery and diagnostic geography rather than assuming the selected vault region proves every location.
- Requirement: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks. (must)
- Requirement: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain. (must)
- Requirement: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain. | security | not measurable yet | Open |
| Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback. | compliance | not measurable yet | Open |
| Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified. | scalability | supported_source_documents >= 10000documents | Open |

**Functional**

- Every answer shows its sources (should, open)
- The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks. (must, open)
- The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.”, “Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 9 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Existing SharePoint | Storage | needs data_gb | price needed | — | — |
| Existing Confluence | Storage | needs data_gb | price needed | — | — |
| Company sign-in integration | Checked requests | needs requests_per_month | price needed | — | — |
| Source synchronization | Data processed | needs data_gb | price needed | — | — |
| Document and permission state | Storage | needs data_gb | price needed | — | — |
| Searchable document copies | Index storage | needs data_gb | price needed | — | — |
| Answer and embedding models | Endpoint hours | 730 hours | price needed | — | — |
| Connector credential protection | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Staff browser, Internal assistant, Operational evidence and alerts.

**Estimate gaps:**

- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Company sign-in integration / Checked requests: input needed (requests_per_month).
- Source synchronization / Data processed: input needed (data_gb).
- Document and permission state / Storage: input needed (data_gb).
- Searchable document copies / Index storage: input needed (data_gb).
- Answer and embedding models / Endpoint hours: price needed.
- Connector credential protection / Checked requests: input needed (requests_per_month).
- Staff browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Internal assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Operational evidence and alerts: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff access: Company sign-in integration.
4. Provision knowledge synchronization: Source synchronization, Document and permission state.
5. Provision answering: Internal assistant, Searchable document copies, Answer and embedding models.
6. Provision operations: Connector credential protection, Operational evidence and alerts.
7. Connect existing systems: Staff browser, Existing SharePoint, Existing Confluence; test failure behaviour.
8. Run the acceptance checks (success measures and requirements) in staging; record results.
9. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing; explain service/model residency gaps.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Existing SharePoint: needs data_gb _(estimate)_
- Existing Confluence: needs data_gb _(estimate)_
- Company sign-in integration: needs requests_per_month _(estimate)_
- Source synchronization: needs data_gb _(estimate)_
- Document and permission state: needs data_gb _(estimate)_
- Searchable document copies: needs data_gb _(estimate)_
- Answer and embedding models: needs a unit price with a source _(estimate)_
- Connector credential protection: needs requests_per_month _(estimate)_
