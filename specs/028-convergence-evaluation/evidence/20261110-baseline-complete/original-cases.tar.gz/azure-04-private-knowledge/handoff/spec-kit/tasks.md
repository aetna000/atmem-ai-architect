# Detailed implementation tasks

Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-73746166662d746f2d617373697374616e74 — Define Staff browser → Internal assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: staff-browser, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection staff-to-assistant: HTTPS questions; authorized cited answers returned. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge staff-to-assistant
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d7369676e2d696e — Define Internal assistant → Company sign-in integration

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, company-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-sign-in: OpenID Connect sign-in; server-side token validation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-sign-in
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7368617265706f696e742d73796e63 — Define Source synchronization → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sharepoint-sync: Microsoft Graph HTTPS: independent content and permission reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sharepoint-sync
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-636f6e666c75656e63652d73796e63 — Define Source synchronization → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection confluence-sync: Native Confluence HTTPS API: independent page and permission reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge confluence-sync
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-696e67657374696f6e2d7374617465 — Define Source synchronization → Document and permission state

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection ingestion-state: Managed identity: separate content/permission fences, tombstones and checkpoints. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge ingestion-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-696e67657374696f6e2d696e646578 — Define Source synchronization → Searchable document copies

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection ingestion-index: Managed identity: revision-tagged chunks, permission generations and deletion re. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge ingestion-index
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-696e67657374696f6e2d656d62656464696e6773 — Define Source synchronization → Answer and embedding models

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection ingestion-embeddings: Managed identity HTTPS: document embeddings; Australian processing required. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge ingestion-embeddings
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d736561726368 — Define Internal assistant → Searchable document copies

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-search: Managed identity: filtered candidate metadata, then authorized chunk fetch. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-search
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d7374617465 — Define Internal assistant → Document and permission state

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-state: Strong reads: identity, quarantine and independent content/permission fences. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d7368617265706f696e742d616363657373 — Define Internal assistant → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-sharepoint-access: Current source-side user access and revision checks; deny on uncertainty. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-sharepoint-access
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d616363657373 — Define Internal assistant → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-confluence-access: Current mapped-user access and revision checks; deny on uncertainty. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-confluence-access
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d67656e65726174696f6e — Define Internal assistant → Answer and embedding models

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-generation: Managed identity HTTPS: query embeddings and authorized generation in Australia. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-generation
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-696e67657374696f6e2d7661756c74 — Define Source synchronization → Connector credential protection

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection ingestion-vault: Managed identity: scoped connector credential retrieval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge ingestion-vault
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d7661756c74 — Define Internal assistant → Connector credential protection

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-vault: Managed identity: scoped source-check credential retrieval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-vault
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-696e67657374696f6e2d74656c656d65747279 — Define Source synchronization → Operational evidence and alerts

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-ingestion, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection ingestion-telemetry: Redacted content/permission lag, quarantine, outage and recovery telemetry. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge ingestion-telemetry
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d74656c656d65747279 — Define Internal assistant → Operational evidence and alerts

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-telemetry: Redacted authorization, citation and failure telemetry. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-telemetry
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-73746166662d62726f77736572 — Integrate existing Staff browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d746f2d617373697374616e74
- Components: staff-browser
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing staff client outside provisioning scope. Uses the proposed internal browser application and company sign-in. User population and company identity configuration remain unconfirmed. Browser locations and downloaded answer handling are not established by the Australian server placement.
2. Verify Web browser on tools in Existing user locations; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-browser
- Application/configuration and tests for Staff browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7368617265706f696e74 — Integrate existing Existing SharePoint

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7368617265706f696e742d73796e63, TASK-CONTRACT-617373697374616e742d7368617265706f696e742d616363657373
- Components: sharepoint
- Generated files: No implementation files generated yet
- Requirements: ai-current-source-authorization, ai-source-outage-isolation, ai-document-corpus-scale

### Implementation steps

1. Responsibility from the board: Existing authoritative source of documents, versions and permissions, outside provisioning scope. Native Microsoft Graph integration must implement change tracking, deletion detection and current source-side user access checks. Content and permissions can change independently: content change tracking alone is insufficient to track authorization. Tenant consent, delegated access, group changes and permission inheritance require qualification. Existing tenant content geography remains unverified; placing the assistant in Australia does not relocate SharePoint.
2. Verify Microsoft SharePoint on tools in Existing source location; unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sharepoint
- Application/configuration and tests for Existing SharePoint

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e666c75656e6365 — Integrate existing Existing Confluence

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-636f6e666c75656e63652d73796e63, TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d616363657373
- Components: confluence
- Generated files: No implementation files generated yet
- Requirements: ai-current-source-authorization, ai-source-outage-isolation, ai-document-corpus-scale

### Implementation steps

1. Responsibility from the board: Existing authoritative source of pages, revisions and permissions, outside provisioning scope. Cloud versus Data Center edition and hosting geography remain unconfirmed. Native integration must independently reconcile content revisions, restrictions, inherited permissions, group membership, identities and deletions, and qualify source-side mapped-user access checks. Unchanged page content is never evidence of unchanged authorization. No vendor compatibility or Australian source residency is assumed.
2. Verify Atlassian Confluence on tools in Existing source location; unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component confluence
- Application/configuration and tests for Existing Confluence

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6d70616e792d7369676e2d696e — Implement Company sign-in integration

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-617373697374616e742d7369676e2d696e
- Components: company-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-authorization

### Implementation steps

1. Responsibility from the board: Proposed Microsoft Entra ID application registration and sign-in integration, not a new company directory. Existing tenant and federation arrangements require confirmation. Validate issuer, audience and sessions server-side; map immutable subjects to source identities. Signing in never grants document access by itself; unknown mappings deny access. Tenant identity metadata and service processing geography require separate review; an Australian application region does not establish Entra residency.
2. Verify Microsoft Entra ID on azure in Tenant geography to be confirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Microsoft Entra ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component company-sign-in
- Application/configuration and tests for Company sign-in integration

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d617070 — Implement Internal assistant

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d746f2d617373697374616e74, TASK-CONTRACT-617373697374616e742d7369676e2d696e, TASK-CONTRACT-617373697374616e742d736561726368, TASK-CONTRACT-617373697374616e742d7374617465, TASK-CONTRACT-617373697374616e742d7368617265706f696e742d616363657373, TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-CONTRACT-617373697374616e742d67656e65726174696f6e, TASK-CONTRACT-617373697374616e742d7661756c74, TASK-CONTRACT-617373697374616e742d74656c656d65747279
- Components: assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-authorization, ai-source-lifecycle-propagation, ai-source-outage-isolation, ai-australian-data-processing, ai-document-corpus-scale

### Implementation steps

1. Responsibility from the board: Proposed Azure App Service deployment owning browser UI, backend authorization and cited responses over 10,000 source documents. Retrieve candidate metadata first; never expose unauthorized titles, snippets or counts. Check current source-side user access, authoritative lifecycle state and content revision before loading text into the model. Track content revision and authorization generation separately; cached permission snapshots cannot replace current source checks. Recheck dependencies before releasing a complete answer; do not stream unvalidated answer text. Discard or regenerate on changed access, revision or quarantine. Exclude unavailable sources, answer from independently authorized remaining evidence or abstain. No shared answer cache, persistent conversation history or action tools are proposed. Retrieved text is untrusted; validate citation provenance. Managed identity accesses Azure dependencies. Australia East is a proposed primary region only; qualify application temporary storage, diagnostics and recovery locations. No overseas fallback. Cross-vendor checks are not atomic: define the authorization observation point and test in-flight revocation races without promising instantaneous revocation.
2. Verify Azure App Service on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure App Service; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-app
- Application/configuration and tests for Internal assistant

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-736f757263652d696e67657374696f6e — Implement Source synchronization

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7368617265706f696e742d73796e63, TASK-CONTRACT-636f6e666c75656e63652d73796e63, TASK-CONTRACT-696e67657374696f6e2d7374617465, TASK-CONTRACT-696e67657374696f6e2d696e646578, TASK-CONTRACT-696e67657374696f6e2d656d62656464696e6773, TASK-CONTRACT-696e67657374696f6e2d7661756c74, TASK-CONTRACT-696e67657374696f6e2d74656c656d65747279
- Components: source-ingestion
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-lifecycle-propagation, ai-australian-data-processing, ai-document-corpus-scale

### Implementation steps

1. Responsibility from the board: Proposed dedicated Azure Functions app containing independent SharePoint and Confluence adapters with durable checkpoints, schedules and bounded retries. Synchronize a 10,000-document corpus; byte volume and change rates remain unknown. Track content revisions and permission generations independently, including permission-only and group-membership changes. Combine supported change signals with periodic reconciliation; do not assume content events cover authorization. Extract text, request embeddings and write revision-tagged chunks. Persist revocation/deletion quarantine before asynchronous index cleanup. Conditional writes reject stale content and permission replays. Recover from checkpoints and recheck current source state; failed records remain quarantined. Native APIs, extraction and inherited permission handling require engineering and qualification. Australia East is proposed; Functions host/checkpoint storage, temporary extraction files and backups must also be qualified for Australian residency. Required host storage is an owned deployment dependency to implement in the resource schedule, not an existing verified resource.
2. Verify Azure Functions on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Functions; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component source-ingestion
- Application/configuration and tests for Source synchronization

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465 — Implement Document and permission state

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-696e67657374696f6e2d7374617465, TASK-CONTRACT-617373697374616e742d7374617465
- Components: authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-authorization, ai-source-lifecycle-propagation, ai-source-outage-isolation, ai-australian-data-processing, ai-document-corpus-scale

### Implementation steps

1. Responsibility from the board: Proposed Azure Cosmos DB account for source-qualified document IDs, independent content revisions and permission generations, deletion tombstones, identity mappings, checkpoints and quarantine. Application lifecycle authority never replaces current source authorization. Strong consistency and a single Australian primary region are proposed, subject to configuration qualification. Missing state or read failure denies affected content. Serving chunks must match active content and authorization fences. Conditional updates prevent one lifecycle stream from rolling back the other; reconciliation detects partial writes. Retain tombstones until stale replay and index copies cannot resurrect content; retention and recovery targets remain open. Australia East is a candidate only; backup location, restore behavior and all replication destinations require verification. No overseas replicas or automatic overseas failover.
2. Verify Azure Cosmos DB on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Cosmos DB; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component authorization-state
- Application/configuration and tests for Document and permission state

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-646f63756d656e742d736561726368 — Implement Searchable document copies

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-696e67657374696f6e2d696e646578, TASK-CONTRACT-617373697374616e742d736561726368
- Components: document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-authorization, ai-source-lifecycle-propagation, ai-australian-data-processing, ai-document-corpus-scale

### Implementation steps

1. Responsibility from the board: Proposed Azure AI Search service holding derived chunks, embeddings, source references, content revisions and separate permission generations for hybrid keyword/vector retrieval across 10,000 source documents. Document count does not determine index capacity; chunk count and embedding dimensions remain engineering sizing inputs. Application security filters narrow candidates but never establish current access. Metadata-only candidate retrieval precedes source authorization and text fetch. Only ingestion writes and only the backend queries; no browser index access. Versioned rebuilds and controlled cutover preserve lifecycle fences. Deletion lag cannot override quarantine. Australia East is a proposed candidate; SKU, vector capability, capacity, semantic enrichment if later added, diagnostic locations and recovery copies require residency qualification. No external enrichment or overseas index replica is proposed.
2. Verify Azure AI Search on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure AI Search; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component document-search
- Application/configuration and tests for Searchable document copies

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6c616e67756167652d6d6f64656c73 — Implement Answer and embedding models

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-696e67657374696f6e2d656d62656464696e6773, TASK-CONTRACT-617373697374616e742d67656e65726174696f6e
- Components: language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-australian-data-processing

### Implementation steps

1. Responsibility from the board: Proposed Azure OpenAI resource with separately configured generation and embedding deployments. Both document/query embeddings and answer generation must process content in Australia. Australia East is only a candidate; no model, regional deployment type, quota or entitlement is selected or verified. Verify generation and embedding availability separately, together with processing geography, service retention and abuse-monitoring handling. An Australian resource address alone is insufficient evidence; do not silently select Global or Data Zone deployment types or overseas fallback. If no compliant model combination is available, retain the Australian boundary and report the blocked model implementation. Use only backend-authorized text, return structured source identifiers and abstain without sufficient evidence; application validates citations against supplied chunks. No model behavior has been tested.
2. Verify Azure OpenAI on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure OpenAI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component language-models
- Application/configuration and tests for Answer and embedding models

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e6e6563746f722d73656372657473 — Implement Connector credential protection

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-696e67657374696f6e2d7661756c74, TASK-CONTRACT-617373697374616e742d7661756c74
- Components: connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Azure Key Vault for connector certificates or secrets only where managed or delegated identity cannot replace them. Separate scoped access for ingestion and serving identities, credential rotation and no interactive client access. No credentials in the project or logs. Vendor credential and consent mechanisms remain connector engineering work. Australia East is a candidate only; verify service replication, recovery and diagnostic geography rather than assuming the selected vault region proves every location.
2. Verify Azure Key Vault on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Key Vault; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component connector-secrets
- Application/configuration and tests for Connector credential protection

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6f7065726174696f6e732d6c6f6773 — Implement Operational evidence and alerts

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-696e67657374696f6e2d74656c656d65747279, TASK-CONTRACT-617373697374616e742d74656c656d65747279
- Components: operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-outage-isolation

### Implementation steps

1. Responsibility from the board: Proposed Azure Monitor Logs workspace recording structured authorization outcomes, separate content/permission synchronization lag, source outages, quarantine, model failures and recovery evidence. Exclude document text, prompts, answers, secrets and tokens by default; protect sensitive identifiers. Measure permission-only changes separately from content updates. Alerts and an owned response runbook are required before production; retention, recipients and operational ownership remain open. Propose Australian workspace and diagnostic storage, subject to service-specific verification; this is an engineering proposal rather than a user-confirmed logs policy. No overseas telemetry export. Logs are operational evidence, not proof of permission enforcement.
2. Verify Azure Monitor Logs on azure in australiaeast (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Monitor Logs; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component operations-logs
- Application/configuration and tests for Operational evidence and alerts

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-73746166662d746f2d617373697374616e74 — Wire Staff browser to Internal assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73746166662d746f2d617373697374616e74, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-617373697374616e742d617070
- Components: staff-browser, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge staff-to-assistant carrying HTTPS questions; authorized cited answers returned, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation staff-to-assistant
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d7369676e2d696e — Wire Internal assistant to Company sign-in integration

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d7369676e2d696e, TASK-RESOURCE-636f6d70616e792d7369676e2d696e, TASK-RESOURCE-617373697374616e742d617070
- Components: assistant-app, company-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-sign-in carrying OpenID Connect sign-in; server-side token validation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-sign-in
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7368617265706f696e742d73796e63 — Wire Source synchronization to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7368617265706f696e742d73796e63, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-736f757263652d696e67657374696f6e
- Components: source-ingestion, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sharepoint-sync carrying Microsoft Graph HTTPS: independent content and permission reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sharepoint-sync
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-636f6e666c75656e63652d73796e63 — Wire Source synchronization to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-636f6e666c75656e63652d73796e63, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d696e67657374696f6e
- Components: source-ingestion, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge confluence-sync carrying Native Confluence HTTPS API: independent page and permission reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation confluence-sync
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-696e67657374696f6e2d7374617465 — Wire Source synchronization to Document and permission state

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-696e67657374696f6e2d7374617465, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465
- Components: source-ingestion, authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge ingestion-state carrying Managed identity: separate content/permission fences, tombstones and checkpoints, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation ingestion-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-696e67657374696f6e2d696e646578 — Wire Source synchronization to Searchable document copies

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-696e67657374696f6e2d696e646578, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-646f63756d656e742d736561726368
- Components: source-ingestion, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge ingestion-index carrying Managed identity: revision-tagged chunks, permission generations and deletion re, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation ingestion-index
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-696e67657374696f6e2d656d62656464696e6773 — Wire Source synchronization to Answer and embedding models

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-696e67657374696f6e2d656d62656464696e6773, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-6c616e67756167652d6d6f64656c73
- Components: source-ingestion, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge ingestion-embeddings carrying Managed identity HTTPS: document embeddings; Australian processing required, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation ingestion-embeddings
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d736561726368 — Wire Internal assistant to Searchable document copies

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d736561726368, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-646f63756d656e742d736561726368
- Components: assistant-app, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-search carrying Managed identity: filtered candidate metadata, then authorized chunk fetch, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-search
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d7374617465 — Wire Internal assistant to Document and permission state

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d7374617465, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465
- Components: assistant-app, authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-state carrying Strong reads: identity, quarantine and independent content/permission fences, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d616363657373 — Wire Internal assistant to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d7368617265706f696e742d616363657373, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-617373697374616e742d617070
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-sharepoint-access carrying Current source-side user access and revision checks; deny on uncertainty, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-sharepoint-access
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d616363657373 — Wire Internal assistant to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-617373697374616e742d617070
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-confluence-access carrying Current mapped-user access and revision checks; deny on uncertainty, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-confluence-access
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d67656e65726174696f6e — Wire Internal assistant to Answer and embedding models

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d67656e65726174696f6e, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-6c616e67756167652d6d6f64656c73
- Components: assistant-app, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-generation carrying Managed identity HTTPS: query embeddings and authorized generation in Australia, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-generation
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-696e67657374696f6e2d7661756c74 — Wire Source synchronization to Connector credential protection

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-696e67657374696f6e2d7661756c74, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Components: source-ingestion, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge ingestion-vault carrying Managed identity: scoped connector credential retrieval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation ingestion-vault
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d7661756c74 — Wire Internal assistant to Connector credential protection

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d7661756c74, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Components: assistant-app, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-vault carrying Managed identity: scoped source-check credential retrieval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-vault
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-696e67657374696f6e2d74656c656d65747279 — Wire Source synchronization to Operational evidence and alerts

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-696e67657374696f6e2d74656c656d65747279, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-6f7065726174696f6e732d6c6f6773
- Components: source-ingestion, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge ingestion-telemetry carrying Redacted content/permission lag, quarantine, outage and recovery telemetry, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation ingestion-telemetry
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d74656c656d65747279 — Wire Internal assistant to Operational evidence and alerts

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d74656c656d65747279, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-6f7065726174696f6e732d6c6f6773
- Components: assistant-app, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-telemetry carrying Redacted authorization, citation and failure telemetry, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-telemetry
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74 — Verify live Staff browser → Internal assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73746166662d746f2d617373697374616e74
- Components: staff-browser, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge staff-to-assistant with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence staff-to-assistant

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e — Verify live Internal assistant → Company sign-in integration

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d7369676e2d696e
- Components: assistant-app, company-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-sign-in with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-sign-in

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63 — Verify live Source synchronization → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7368617265706f696e742d73796e63
- Components: source-ingestion, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sharepoint-sync with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sharepoint-sync

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63 — Verify live Source synchronization → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-636f6e666c75656e63652d73796e63
- Components: source-ingestion, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge confluence-sync with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence confluence-sync

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465 — Verify live Source synchronization → Document and permission state

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-696e67657374696f6e2d7374617465
- Components: source-ingestion, authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge ingestion-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence ingestion-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578 — Verify live Source synchronization → Searchable document copies

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-696e67657374696f6e2d696e646578
- Components: source-ingestion, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge ingestion-index with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence ingestion-index

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-696e67657374696f6e2d656d62656464696e6773 — Verify live Source synchronization → Answer and embedding models

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-696e67657374696f6e2d656d62656464696e6773
- Components: source-ingestion, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge ingestion-embeddings with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence ingestion-embeddings

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d736561726368 — Verify live Internal assistant → Searchable document copies

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d736561726368
- Components: assistant-app, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-search with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-search

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d7374617465 — Verify live Internal assistant → Document and permission state

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d7374617465
- Components: assistant-app, authorization-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373 — Verify live Internal assistant → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d616363657373
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-sharepoint-access with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-sharepoint-access

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373 — Verify live Internal assistant → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d616363657373
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-confluence-access with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-confluence-access

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e — Verify live Internal assistant → Answer and embedding models

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d67656e65726174696f6e
- Components: assistant-app, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-generation with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-generation

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-696e67657374696f6e2d7661756c74 — Verify live Source synchronization → Connector credential protection

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-696e67657374696f6e2d7661756c74
- Components: source-ingestion, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge ingestion-vault with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence ingestion-vault

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74 — Verify live Internal assistant → Connector credential protection

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d7661756c74
- Components: assistant-app, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-vault with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-vault

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279 — Verify live Source synchronization → Operational evidence and alerts

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-696e67657374696f6e2d74656c656d65747279
- Components: source-ingestion, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge ingestion-telemetry with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence ingestion-telemetry

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279 — Verify live Internal assistant → Operational evidence and alerts

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d74656c656d65747279
- Components: assistant-app, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-telemetry with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-telemetry

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3864353938393361 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-8d59893a

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d617574686f72697a6174696f6e — Verify REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-636f6d70616e792d7369676e2d696e, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-646f63756d656e742d736561726368, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: assistant-app, company-sign-in, sharepoint, confluence, authorization-state, document-search
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-authorization

### Implementation steps

1. Basis: “People should get cited answers only from documents they can access.”; rationale: Search copies and cached permission lists can outlive a revocation. Proposed enforcement checks current source authorization before model use and answer release; unresolved checks must deny access.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6c6966656379636c652d70726f7061676174696f6e — Verify REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-646f63756d656e742d736561726368, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578, TASK-INTEGRATION-LIVE-696e67657374696f6e2d656d62656464696e6773, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7661756c74, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: source-ingestion, authorization-state, document-search, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-lifecycle-propagation

### Implementation steps

1. Basis: “Permission revocation, edits and deletion must propagate.”; rationale: Out-of-order updates and delayed index deletion can restore obsolete or restricted material. Proposed version fences, quarantine and reconciliation prevent stale index entries from becoming eligible; propagation timing remains open.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6f75746167652d69736f6c6174696f6e — Verify REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-6f7065726174696f6e732d6c6f6773, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: assistant-app, sharepoint, confluence, authorization-state, operations-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-outage-isolation

### Implementation steps

1. Basis: “An outage in one source should not leak stale restricted content.”; rationale: A source outage removes the ability to establish current permissions. Proposed behavior sacrifices answers involving that source while preserving answers supported entirely by other confirmed sources.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6175737472616c69616e2d646174612d70726f63657373696e67 — Verify REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-646f63756d656e742d736561726368, TASK-RESOURCE-6c616e67756167652d6d6f64656c73, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578, TASK-INTEGRATION-LIVE-696e67657374696f6e2d656d62656464696e6773, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7661756c74, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: assistant-app, source-ingestion, authorization-state, document-search, language-models
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-australian-data-processing

### Implementation steps

1. Basis: “Australia for content, indexes and processing; explain service/model residency gaps.” Australian backup and temporary-copy coverage is a proposed interpretation of that boundary.; rationale: Prevents an Australian resource location from concealing overseas inference, embeddings, recovery copies or temporary processing; deployment choices need evidence before use.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d646f63756d656e742d636f727075732d7363616c65 — Verify REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-646f63756d656e742d736561726368, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578, TASK-INTEGRATION-LIVE-696e67657374696f6e2d656d62656464696e6773, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7661756c74, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: sharepoint, confluence, source-ingestion, authorization-state, document-search, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-document-corpus-scale

### Implementation steps

1. Basis: “Ten thousand company documents.”; rationale: Preserves the actual corpus scope without treating document count as a storage or traffic estimate; qualification must include the complete corpus and permission diversity.
2. Implement a check for supported_source_documents >= 10000 documents; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-636f6d70616e792d7369676e2d696e, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-646f63756d656e742d736561726368, TASK-RESOURCE-6c616e67756167652d6d6f64656c73, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-6f7065726174696f6e732d6c6f6773, TASK-INTEGRATION-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-7368617265706f696e742d73796e63, TASK-INTEGRATION-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-696e67657374696f6e2d7374617465, TASK-INTEGRATION-696e67657374696f6e2d696e646578, TASK-INTEGRATION-696e67657374696f6e2d656d62656464696e6773, TASK-INTEGRATION-617373697374616e742d736561726368, TASK-INTEGRATION-617373697374616e742d7374617465, TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-696e67657374696f6e2d7661756c74, TASK-INTEGRATION-617373697374616e742d7661756c74, TASK-INTEGRATION-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-617373697374616e742d74656c656d65747279
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-636f6d70616e792d7369676e2d696e, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-736f757263652d696e67657374696f6e, TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465, TASK-RESOURCE-646f63756d656e742d736561726368, TASK-RESOURCE-6c616e67756167652d6d6f64656c73, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-6f7065726174696f6e732d6c6f6773, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578, TASK-INTEGRATION-LIVE-696e67657374696f6e2d656d62656464696e6773, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7661756c74, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3864353938393361, TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d617574686f72697a6174696f6e, TASK-ACCEPTANCE-61692d736f757263652d6c6966656379636c652d70726f7061676174696f6e, TASK-ACCEPTANCE-61692d736f757263652d6f75746167652d69736f6c6174696f6e, TASK-ACCEPTANCE-61692d6175737472616c69616e2d646174612d70726f63657373696e67, TASK-ACCEPTANCE-61692d646f63756d656e742d636f727075732d7363616c65, TASK-INTEGRATION-LIVE-73746166662d746f2d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d7369676e2d696e, TASK-INTEGRATION-LIVE-7368617265706f696e742d73796e63, TASK-INTEGRATION-LIVE-636f6e666c75656e63652d73796e63, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7374617465, TASK-INTEGRATION-LIVE-696e67657374696f6e2d696e646578, TASK-INTEGRATION-LIVE-696e67657374696f6e2d656d62656464696e6773, TASK-INTEGRATION-LIVE-617373697374616e742d736561726368, TASK-INTEGRATION-LIVE-617373697374616e742d7374617465, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d616363657373, TASK-INTEGRATION-LIVE-617373697374616e742d67656e65726174696f6e, TASK-INTEGRATION-LIVE-696e67657374696f6e2d7661756c74, TASK-INTEGRATION-LIVE-617373697374616e742d7661756c74, TASK-INTEGRATION-LIVE-696e67657374696f6e2d74656c656d65747279, TASK-INTEGRATION-LIVE-617373697374616e742d74656c656d65747279
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
