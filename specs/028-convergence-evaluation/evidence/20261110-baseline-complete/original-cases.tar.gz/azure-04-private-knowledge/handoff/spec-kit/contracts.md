# Component and interface contracts

Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component staff-browser: Staff browser

- Responsibility: Existing staff client outside provisioning scope. Uses the proposed internal browser application and company sign-in. User population and company identity configuration remain unconfirmed. Browser locations and downloaded answer handling are not established by the Australian server placement.
- Service: Web browser
- Provider / placement: tools / Existing user locations
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-73746166662d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component sharepoint: Existing SharePoint

- Responsibility: Existing authoritative source of documents, versions and permissions, outside provisioning scope. Native Microsoft Graph integration must implement change tracking, deletion detection and current source-side user access checks. Content and permissions can change independently: content change tracking alone is insufficient to track authorization. Tenant consent, delegated access, group changes and permission inheritance require qualification. Existing tenant content geography remains unverified; placing the assistant in Australia does not relocate SharePoint.
- Service: Microsoft SharePoint
- Provider / placement: tools / Existing source location; unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7368617265706f696e74
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component confluence: Existing Confluence

- Responsibility: Existing authoritative source of pages, revisions and permissions, outside provisioning scope. Cloud versus Data Center edition and hosting geography remain unconfirmed. Native integration must independently reconcile content revisions, restrictions, inherited permissions, group membership, identities and deletions, and qualify source-side mapped-user access checks. Unchanged page content is never evidence of unchanged authorization. No vendor compatibility or Australian source residency is assumed.
- Service: Atlassian Confluence
- Provider / placement: tools / Existing source location; unconfirmed
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-636f6e666c75656e6365
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component company-sign-in: Company sign-in integration

- Responsibility: Proposed Microsoft Entra ID application registration and sign-in integration, not a new company directory. Existing tenant and federation arrangements require confirmation. Validate issuer, audience and sessions server-side; map immutable subjects to source identities. Signing in never grants document access by itself; unknown mappings deny access. Tenant identity metadata and service processing geography require separate review; an Australian application region does not establish Entra residency.
- Service: Microsoft Entra ID
- Provider / placement: azure / Tenant geography to be confirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f6d70616e792d7369676e2d696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component assistant-app: Internal assistant

- Responsibility: Proposed Azure App Service deployment owning browser UI, backend authorization and cited responses over 10,000 source documents. Retrieve candidate metadata first; never expose unauthorized titles, snippets or counts. Check current source-side user access, authoritative lifecycle state and content revision before loading text into the model. Track content revision and authorization generation separately; cached permission snapshots cannot replace current source checks. Recheck dependencies before releasing a complete answer; do not stream unvalidated answer text. Discard or regenerate on changed access, revision or quarantine. Exclude unavailable sources, answer from independently authorized remaining evidence or abstain. No shared answer cache, persistent conversation history or action tools are proposed. Retrieved text is untrusted; validate citation provenance. Managed identity accesses Azure dependencies. Australia East is a proposed primary region only; qualify application temporary storage, diagnostics and recovery locations. No overseas fallback. Cross-vendor checks are not atomic: define the authorization observation point and test in-flight revocation races without promising instantaneous revocation.
- Service: Azure App Service
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component source-ingestion: Source synchronization

- Responsibility: Proposed dedicated Azure Functions app containing independent SharePoint and Confluence adapters with durable checkpoints, schedules and bounded retries. Synchronize a 10,000-document corpus; byte volume and change rates remain unknown. Track content revisions and permission generations independently, including permission-only and group-membership changes. Combine supported change signals with periodic reconciliation; do not assume content events cover authorization. Extract text, request embeddings and write revision-tagged chunks. Persist revocation/deletion quarantine before asynchronous index cleanup. Conditional writes reject stale content and permission replays. Recover from checkpoints and recheck current source state; failed records remain quarantined. Native APIs, extraction and inherited permission handling require engineering and qualification. Australia East is proposed; Functions host/checkpoint storage, temporary extraction files and backups must also be qualified for Australian residency. Required host storage is an owned deployment dependency to implement in the resource schedule, not an existing verified resource.
- Service: Azure Functions
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736f757263652d696e67657374696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component authorization-state: Document and permission state

- Responsibility: Proposed Azure Cosmos DB account for source-qualified document IDs, independent content revisions and permission generations, deletion tombstones, identity mappings, checkpoints and quarantine. Application lifecycle authority never replaces current source authorization. Strong consistency and a single Australian primary region are proposed, subject to configuration qualification. Missing state or read failure denies affected content. Serving chunks must match active content and authorization fences. Conditional updates prevent one lifecycle stream from rolling back the other; reconciliation detects partial writes. Retain tombstones until stale replay and index copies cannot resurrect content; retention and recovery targets remain open. Australia East is a candidate only; backup location, restore behavior and all replication destinations require verification. No overseas replicas or automatic overseas failover.
- Service: Azure Cosmos DB
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617574686f72697a6174696f6e2d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component document-search: Searchable document copies

- Responsibility: Proposed Azure AI Search service holding derived chunks, embeddings, source references, content revisions and separate permission generations for hybrid keyword/vector retrieval across 10,000 source documents. Document count does not determine index capacity; chunk count and embedding dimensions remain engineering sizing inputs. Application security filters narrow candidates but never establish current access. Metadata-only candidate retrieval precedes source authorization and text fetch. Only ingestion writes and only the backend queries; no browser index access. Versioned rebuilds and controlled cutover preserve lifecycle fences. Deletion lag cannot override quarantine. Australia East is a proposed candidate; SKU, vector capability, capacity, semantic enrichment if later added, diagnostic locations and recovery copies require residency qualification. No external enrichment or overseas index replica is proposed.
- Service: Azure AI Search
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-646f63756d656e742d736561726368
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component language-models: Answer and embedding models

- Responsibility: Proposed Azure OpenAI resource with separately configured generation and embedding deployments. Both document/query embeddings and answer generation must process content in Australia. Australia East is only a candidate; no model, regional deployment type, quota or entitlement is selected or verified. Verify generation and embedding availability separately, together with processing geography, service retention and abuse-monitoring handling. An Australian resource address alone is insufficient evidence; do not silently select Global or Data Zone deployment types or overseas fallback. If no compliant model combination is available, retain the Australian boundary and report the blocked model implementation. Use only backend-authorized text, return structured source identifiers and abstain without sufficient evidence; application validates citations against supplied chunks. No model behavior has been tested.
- Service: Azure OpenAI
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6c616e67756167652d6d6f64656c73
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component connector-secrets: Connector credential protection

- Responsibility: Proposed Azure Key Vault for connector certificates or secrets only where managed or delegated identity cannot replace them. Separate scoped access for ingestion and serving identities, credential rotation and no interactive client access. No credentials in the project or logs. Vendor credential and consent mechanisms remain connector engineering work. Australia East is a candidate only; verify service replication, recovery and diagnostic geography rather than assuming the selected vault region proves every location.
- Service: Azure Key Vault
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component operations-logs: Operational evidence and alerts

- Responsibility: Proposed Azure Monitor Logs workspace recording structured authorization outcomes, separate content/permission synchronization lag, source outages, quarantine, model failures and recovery evidence. Exclude document text, prompts, answers, secrets and tokens by default; protect sensitive identifiers. Measure permission-only changes separately from content updates. Alerts and an owned response runbook are required before production; retention, recipients and operational ownership remain open. Propose Australian workspace and diagnostic storage, subject to service-specific verification; this is an engineering proposal rather than a user-confirmed logs policy. No overseas telemetry export. Logs are operational evidence, not proof of permission enforcement.
- Service: Azure Monitor Logs
- Provider / placement: azure / australiaeast (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7065726174696f6e732d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### staff-to-assistant: staff-browser → assistant-app

- Drawn payload/purpose: HTTPS questions; authorized cited answers returned
- Contract task: TASK-CONTRACT-73746166662d746f2d617373697374616e74
- Integration task: TASK-INTEGRATION-73746166662d746f2d617373697374616e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-sign-in: assistant-app → company-sign-in

- Drawn payload/purpose: OpenID Connect sign-in; server-side token validation
- Contract task: TASK-CONTRACT-617373697374616e742d7369676e2d696e
- Integration task: TASK-INTEGRATION-617373697374616e742d7369676e2d696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sharepoint-sync: source-ingestion → sharepoint

- Drawn payload/purpose: Microsoft Graph HTTPS: independent content and permission reconciliation
- Contract task: TASK-CONTRACT-7368617265706f696e742d73796e63
- Integration task: TASK-INTEGRATION-7368617265706f696e742d73796e63
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### confluence-sync: source-ingestion → confluence

- Drawn payload/purpose: Native Confluence HTTPS API: independent page and permission reconciliation
- Contract task: TASK-CONTRACT-636f6e666c75656e63652d73796e63
- Integration task: TASK-INTEGRATION-636f6e666c75656e63652d73796e63
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### ingestion-state: source-ingestion → authorization-state

- Drawn payload/purpose: Managed identity: separate content/permission fences, tombstones and checkpoints
- Contract task: TASK-CONTRACT-696e67657374696f6e2d7374617465
- Integration task: TASK-INTEGRATION-696e67657374696f6e2d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### ingestion-index: source-ingestion → document-search

- Drawn payload/purpose: Managed identity: revision-tagged chunks, permission generations and deletion re
- Contract task: TASK-CONTRACT-696e67657374696f6e2d696e646578
- Integration task: TASK-INTEGRATION-696e67657374696f6e2d696e646578
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### ingestion-embeddings: source-ingestion → language-models

- Drawn payload/purpose: Managed identity HTTPS: document embeddings; Australian processing required
- Contract task: TASK-CONTRACT-696e67657374696f6e2d656d62656464696e6773
- Integration task: TASK-INTEGRATION-696e67657374696f6e2d656d62656464696e6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-search: assistant-app → document-search

- Drawn payload/purpose: Managed identity: filtered candidate metadata, then authorized chunk fetch
- Contract task: TASK-CONTRACT-617373697374616e742d736561726368
- Integration task: TASK-INTEGRATION-617373697374616e742d736561726368
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-state: assistant-app → authorization-state

- Drawn payload/purpose: Strong reads: identity, quarantine and independent content/permission fences
- Contract task: TASK-CONTRACT-617373697374616e742d7374617465
- Integration task: TASK-INTEGRATION-617373697374616e742d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-sharepoint-access: assistant-app → sharepoint

- Drawn payload/purpose: Current source-side user access and revision checks; deny on uncertainty
- Contract task: TASK-CONTRACT-617373697374616e742d7368617265706f696e742d616363657373
- Integration task: TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d616363657373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-confluence-access: assistant-app → confluence

- Drawn payload/purpose: Current mapped-user access and revision checks; deny on uncertainty
- Contract task: TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d616363657373
- Integration task: TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d616363657373
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-generation: assistant-app → language-models

- Drawn payload/purpose: Managed identity HTTPS: query embeddings and authorized generation in Australia
- Contract task: TASK-CONTRACT-617373697374616e742d67656e65726174696f6e
- Integration task: TASK-INTEGRATION-617373697374616e742d67656e65726174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### ingestion-vault: source-ingestion → connector-secrets

- Drawn payload/purpose: Managed identity: scoped connector credential retrieval
- Contract task: TASK-CONTRACT-696e67657374696f6e2d7661756c74
- Integration task: TASK-INTEGRATION-696e67657374696f6e2d7661756c74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-vault: assistant-app → connector-secrets

- Drawn payload/purpose: Managed identity: scoped source-check credential retrieval
- Contract task: TASK-CONTRACT-617373697374616e742d7661756c74
- Integration task: TASK-INTEGRATION-617373697374616e742d7661756c74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### ingestion-telemetry: source-ingestion → operations-logs

- Drawn payload/purpose: Redacted content/permission lag, quarantine, outage and recovery telemetry
- Contract task: TASK-CONTRACT-696e67657374696f6e2d74656c656d65747279
- Integration task: TASK-INTEGRATION-696e67657374696f6e2d74656c656d65747279
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-telemetry: assistant-app → operations-logs

- Drawn payload/purpose: Redacted authorization, citation and failure telemetry
- Contract task: TASK-CONTRACT-617373697374616e742d74656c656d65747279
- Integration task: TASK-INTEGRATION-617373697374616e742d74656c656d65747279
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
