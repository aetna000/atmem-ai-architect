# Questions and assumptions to resolve

Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

- [ai-current-source-authorization] Confirm REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.
- [ai-source-lifecycle-propagation] Confirm REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.
- [ai-source-outage-isolation] Confirm REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.
- [ai-australian-data-processing] Confirm REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.
- [ai-document-corpus-scale] Confirm REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.
- [acceptance-req-8d59893a] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-current-source-authorization] Agree a measurable acceptance check for REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.
- [acceptance-ai-source-lifecycle-propagation] Agree a measurable acceptance check for REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.
- [acceptance-ai-source-outage-isolation] Agree a measurable acceptance check for REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.
- [acceptance-ai-australian-data-processing] Agree a measurable acceptance check for REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d6175737472616c69616e2d646174612d70726f63657373696e67] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d63757272656e742d736f757263652d617574686f72697a6174696f6e] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d646f63756d656e742d636f727075732d7363616c65] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d736f757263652d6c6966656379636c652d70726f7061676174696f6e] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d736f757263652d6f75746167652d69736f6c6174696f6e] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
