# Infrastructure implementation required

Requested providers: azure. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Company sign-in integration: Implementation needed.
- Internal assistant: Implementation needed.
- Source synchronization: Implementation needed.
- Document and permission state: Implementation needed.
- Searchable document copies: Implementation needed.
- Answer and embedding models: Implementation needed.
- Connector credential protection: Implementation needed.
- Operational evidence and alerts: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → company-sign-in: implement data flow, access policy and acceptance test.
- Wire source-ingestion → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-ingestion → confluence: implement data flow, access policy and acceptance test.
- Wire source-ingestion → authorization-state: implement data flow, access policy and acceptance test.
- Wire source-ingestion → document-search: implement data flow, access policy and acceptance test.
- Wire source-ingestion → language-models: implement data flow, access policy and acceptance test.
- Wire assistant-app → document-search: implement data flow, access policy and acceptance test.
- Wire assistant-app → authorization-state: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → language-models: implement data flow, access policy and acceptance test.
- Wire source-ingestion → connector-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire source-ingestion → operations-logs: implement data flow, access policy and acceptance test.
- Wire assistant-app → operations-logs: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
