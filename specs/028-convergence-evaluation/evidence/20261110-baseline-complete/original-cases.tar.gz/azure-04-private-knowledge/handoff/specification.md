Snapshot 1383303a-60b7-4840-bfa4-b891a9caf6c3 · design r3 · generated 2026-11-09T17:22:44.367Z

# Permission-aware knowledge assistant — solution specification

## Problem and intended outcome

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks. (must, open); target: acceptance target needed; linked blocks: assistant-app, company-sign-in, sharepoint, confluence, authorization-state, document-search

Design explanation: Search copies and cached permission lists can outlive a revocation. Proposed enforcement checks current source authorization before model use and answer release; unresolved checks must deny access.

Basis: “People should get cited answers only from documents they can access.”
- [REQ-005] The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed. (must, open); target: acceptance target needed; linked blocks: source-ingestion, authorization-state, document-search, assistant-app

Design explanation: Out-of-order updates and delayed index deletion can restore obsolete or restricted material. Proposed version fences, quarantine and reconciliation prevent stale index entries from becoming eligible; propagation timing remains open.

Basis: “Permission revocation, edits and deletion must propagate.”
- [REQ-006] When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain. (must, open); target: acceptance target needed; linked blocks: assistant-app, sharepoint, confluence, authorization-state, operations-logs

Design explanation: A source outage removes the ability to establish current permissions. Proposed behavior sacrifices answers involving that source while preserving answers supported entirely by other confirmed sources.

Basis: “An outage in one source should not leak stale restricted content.”
- [REQ-007] Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback. (must, open); target: acceptance target needed; linked blocks: assistant-app, source-ingestion, authorization-state, document-search, language-models

Design explanation: Prevents an Australian resource location from concealing overseas inference, embeddings, recovery copies or temporary processing; deployment choices need evidence before use.

Basis: “Australia for content, indexes and processing; explain service/model residency gaps.” Australian backup and temporary-copy coverage is a proposed interpretation of that boundary.
- [REQ-008] Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified. (must, open); target: supported_source_documents >= 10000documents; linked blocks: sharepoint, confluence, source-ingestion, authorization-state, document-search, assistant-app

Design explanation: Preserves the actual corpus scope without treating document count as a storage or traffic estimate; qualification must include the complete corpus and permission diversity.

Basis: “Ten thousand company documents.”

## How the system works

The current design contains 11 components and 16 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Staff browser → Internal assistant

HTTPS questions; authorized cited answers returned

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Internal assistant → Company sign-in integration

OpenID Connect sign-in; server-side token validation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Source synchronization → Existing SharePoint

Microsoft Graph HTTPS: independent content and permission reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Source synchronization → Existing Confluence

Native Confluence HTTPS API: independent page and permission reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Source synchronization → Document and permission state

Managed identity: separate content/permission fences, tombstones and checkpoints

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Source synchronization → Searchable document copies

Managed identity: revision-tagged chunks, permission generations and deletion re

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Source synchronization → Answer and embedding models

Managed identity HTTPS: document embeddings; Australian processing required

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Internal assistant → Searchable document copies

Managed identity: filtered candidate metadata, then authorized chunk fetch

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Internal assistant → Document and permission state

Strong reads: identity, quarantine and independent content/permission fences

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Internal assistant → Existing SharePoint

Current source-side user access and revision checks; deny on uncertainty

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Internal assistant → Existing Confluence

Current mapped-user access and revision checks; deny on uncertainty

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Internal assistant → Answer and embedding models

Managed identity HTTPS: query embeddings and authorized generation in Australia

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Source synchronization → Connector credential protection

Managed identity: scoped connector credential retrieval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Internal assistant → Connector credential protection

Managed identity: scoped source-check credential retrieval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 15: Source synchronization → Operational evidence and alerts

Redacted content/permission lag, quarantine, outage and recovery telemetry

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 16: Internal assistant → Operational evidence and alerts

Redacted authorization, citation and failure telemetry

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Staff browser

Web browser · tools · region: Existing user locations · classification: Internal

Existing staff client outside provisioning scope. Uses the proposed internal browser application and company sign-in. User population and company identity configuration remain unconfirmed. Browser locations and downloaded answer handling are not established by the Australian server placement.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Staff browser → Internal assistant: HTTPS questions; authorized cited answers returned

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Existing SharePoint

Microsoft SharePoint · tools · region: Existing source location; unconfirmed · classification: Confidential

Existing authoritative source of documents, versions and permissions, outside provisioning scope. Native Microsoft Graph integration must implement change tracking, deletion detection and current source-side user access checks. Content and permissions can change independently: content change tracking alone is insufficient to track authorization. Tenant consent, delegated access, group changes and permission inheritance require qualification. Existing tenant content geography remains unverified; placing the assistant in Australia does not relocate SharePoint.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Source synchronization → Existing SharePoint: Microsoft Graph HTTPS: independent content and permission reconciliation; Internal assistant → Existing SharePoint: Current source-side user access and revision checks; deny on uncertainty

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Existing Confluence

Atlassian Confluence · tools · region: Existing source location; unconfirmed · classification: Confidential

Existing authoritative source of pages, revisions and permissions, outside provisioning scope. Cloud versus Data Center edition and hosting geography remain unconfirmed. Native integration must independently reconcile content revisions, restrictions, inherited permissions, group membership, identities and deletions, and qualify source-side mapped-user access checks. Unchanged page content is never evidence of unchanged authorization. No vendor compatibility or Australian source residency is assumed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Source synchronization → Existing Confluence: Native Confluence HTTPS API: independent page and permission reconciliation; Internal assistant → Existing Confluence: Current mapped-user access and revision checks; deny on uncertainty

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Company sign-in integration

Microsoft Entra ID · azure · region: Tenant geography to be confirmed · classification: Confidential

Proposed Microsoft Entra ID application registration and sign-in integration, not a new company directory. Existing tenant and federation arrangements require confirmation. Validate issuer, audience and sessions server-side; map immutable subjects to source identities. Signing in never grants document access by itself; unknown mappings deny access. Tenant identity metadata and service processing geography require separate review; an Australian application region does not establish Entra residency.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Internal assistant → Company sign-in integration: OpenID Connect sign-in; server-side token validation

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Internal assistant

Azure App Service · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed Azure App Service deployment owning browser UI, backend authorization and cited responses over 10,000 source documents. Retrieve candidate metadata first; never expose unauthorized titles, snippets or counts. Check current source-side user access, authoritative lifecycle state and content revision before loading text into the model. Track content revision and authorization generation separately; cached permission snapshots cannot replace current source checks. Recheck dependencies before releasing a complete answer; do not stream unvalidated answer text. Discard or regenerate on changed access, revision or quarantine. Exclude unavailable sources, answer from independently authorized remaining evidence or abstain. No shared answer cache, persistent conversation history or action tools are proposed. Retrieved text is untrusted; validate citation provenance. Managed identity accesses Azure dependencies. Australia East is a proposed primary region only; qualify application temporary storage, diagnostics and recovery locations. No overseas fallback. Cross-vendor checks are not atomic: define the authorization observation point and test in-flight revocation races without promising instantaneous revocation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff browser → Internal assistant: HTTPS questions; authorized cited answers returned

Outputs: Internal assistant → Company sign-in integration: OpenID Connect sign-in; server-side token validation; Internal assistant → Searchable document copies: Managed identity: filtered candidate metadata, then authorized chunk fetch; Internal assistant → Document and permission state: Strong reads: identity, quarantine and independent content/permission fences; Internal assistant → Existing SharePoint: Current source-side user access and revision checks; deny on uncertainty; Internal assistant → Existing Confluence: Current mapped-user access and revision checks; deny on uncertainty; Internal assistant → Answer and embedding models: Managed identity HTTPS: query embeddings and authorized generation in Australia; Internal assistant → Connector credential protection: Managed identity: scoped source-check credential retrieval; Internal assistant → Operational evidence and alerts: Redacted authorization, citation and failure telemetry

Requirement traceability: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Source synchronization

Azure Functions · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed dedicated Azure Functions app containing independent SharePoint and Confluence adapters with durable checkpoints, schedules and bounded retries. Synchronize a 10,000-document corpus; byte volume and change rates remain unknown. Track content revisions and permission generations independently, including permission-only and group-membership changes. Combine supported change signals with periodic reconciliation; do not assume content events cover authorization. Extract text, request embeddings and write revision-tagged chunks. Persist revocation/deletion quarantine before asynchronous index cleanup. Conditional writes reject stale content and permission replays. Recover from checkpoints and recheck current source state; failed records remain quarantined. Native APIs, extraction and inherited permission handling require engineering and qualification. Australia East is proposed; Functions host/checkpoint storage, temporary extraction files and backups must also be qualified for Australian residency. Required host storage is an owned deployment dependency to implement in the resource schedule, not an existing verified resource.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Source synchronization → Existing SharePoint: Microsoft Graph HTTPS: independent content and permission reconciliation; Source synchronization → Existing Confluence: Native Confluence HTTPS API: independent page and permission reconciliation; Source synchronization → Document and permission state: Managed identity: separate content/permission fences, tombstones and checkpoints; Source synchronization → Searchable document copies: Managed identity: revision-tagged chunks, permission generations and deletion re; Source synchronization → Answer and embedding models: Managed identity HTTPS: document embeddings; Australian processing required; Source synchronization → Connector credential protection: Managed identity: scoped connector credential retrieval; Source synchronization → Operational evidence and alerts: Redacted content/permission lag, quarantine, outage and recovery telemetry

Requirement traceability: REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Document and permission state

Azure Cosmos DB · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed Azure Cosmos DB account for source-qualified document IDs, independent content revisions and permission generations, deletion tombstones, identity mappings, checkpoints and quarantine. Application lifecycle authority never replaces current source authorization. Strong consistency and a single Australian primary region are proposed, subject to configuration qualification. Missing state or read failure denies affected content. Serving chunks must match active content and authorization fences. Conditional updates prevent one lifecycle stream from rolling back the other; reconciliation detects partial writes. Retain tombstones until stale replay and index copies cannot resurrect content; retention and recovery targets remain open. Australia East is a candidate only; backup location, restore behavior and all replication destinations require verification. No overseas replicas or automatic overseas failover.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Source synchronization → Document and permission state: Managed identity: separate content/permission fences, tombstones and checkpoints; Internal assistant → Document and permission state: Strong reads: identity, quarantine and independent content/permission fences

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Searchable document copies

Azure AI Search · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed Azure AI Search service holding derived chunks, embeddings, source references, content revisions and separate permission generations for hybrid keyword/vector retrieval across 10,000 source documents. Document count does not determine index capacity; chunk count and embedding dimensions remain engineering sizing inputs. Application security filters narrow candidates but never establish current access. Metadata-only candidate retrieval precedes source authorization and text fetch. Only ingestion writes and only the backend queries; no browser index access. Versioned rebuilds and controlled cutover preserve lifecycle fences. Deletion lag cannot override quarantine. Australia East is a proposed candidate; SKU, vector capability, capacity, semantic enrichment if later added, diagnostic locations and recovery copies require residency qualification. No external enrichment or overseas index replica is proposed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Source synchronization → Searchable document copies: Managed identity: revision-tagged chunks, permission generations and deletion re; Internal assistant → Searchable document copies: Managed identity: filtered candidate metadata, then authorized chunk fetch

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant must restrict retrieved text, model context, citations and returned answers to documents currently accessible to the authenticated user, denying unknown identity mappings or inconclusive authorization checks.; REQ-005: The system must propagate permission changes, edits and deletions into serving eligibility and derived search data, reject stale replays and prevent obsolete revisions from supporting an answer; end-to-end propagation targets remain to be agreed.; REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.; REQ-008: Support ingestion, reconciliation and permission-aware cited retrieval across 10,000 source documents distributed between SharePoint and Confluence. Document sizes, extracted chunk count, change frequency, concurrency and latency targets remain unspecified.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Answer and embedding models

Azure OpenAI · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed Azure OpenAI resource with separately configured generation and embedding deployments. Both document/query embeddings and answer generation must process content in Australia. Australia East is only a candidate; no model, regional deployment type, quota or entitlement is selected or verified. Verify generation and embedding availability separately, together with processing geography, service retention and abuse-monitoring handling. An Australian resource address alone is insufficient evidence; do not silently select Global or Data Zone deployment types or overseas fallback. If no compliant model combination is available, retain the Australian boundary and report the blocked model implementation. Use only backend-authorized text, return structured source identifiers and abstain without sufficient evidence; application validates citations against supplied chunks. No model behavior has been tested.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Source synchronization → Answer and embedding models: Managed identity HTTPS: document embeddings; Australian processing required; Internal assistant → Answer and embedding models: Managed identity HTTPS: query embeddings and authorized generation in Australia

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-007: Keep assistant-held document content, derived indexes and embeddings, and content processing in Australia. Proposed coverage includes temporary copies and backups. Qualify generation and embedding deployments separately, document source and identity residency gaps, and prohibit automatic overseas fallback.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Connector credential protection

Azure Key Vault · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed Azure Key Vault for connector certificates or secrets only where managed or delegated identity cannot replace them. Separate scoped access for ingestion and serving identities, credential rotation and no interactive client access. No credentials in the project or logs. Vendor credential and consent mechanisms remain connector engineering work. Australia East is a candidate only; verify service replication, recovery and diagnostic geography rather than assuming the selected vault region proves every location.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Source synchronization → Connector credential protection: Managed identity: scoped connector credential retrieval; Internal assistant → Connector credential protection: Managed identity: scoped source-check credential retrieval

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Operational evidence and alerts

Azure Monitor Logs · azure · region: australiaeast (proposed; unverified) · classification: Confidential

Proposed Azure Monitor Logs workspace recording structured authorization outcomes, separate content/permission synchronization lag, source outages, quarantine, model failures and recovery evidence. Exclude document text, prompts, answers, secrets and tokens by default; protect sensitive identifiers. Measure permission-only changes separately from content updates. Alerts and an owned response runbook are required before production; retention, recipients and operational ownership remain open. Propose Australian workspace and diagnostic storage, subject to service-specific verification; this is an engineering proposal rather than a user-confirmed logs policy. No overseas telemetry export. Logs are operational evidence, not proof of permission enforcement.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Source synchronization → Operational evidence and alerts: Redacted content/permission lag, quarantine, outage and recovery telemetry; Internal assistant → Operational evidence and alerts: Redacted authorization, citation and failure telemetry

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: When a source cannot confirm current user access and document revision, the assistant must exclude its content from model context and responses, including in-flight answers; it may answer from independently authorized available sources or abstain.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Staff browser<br/>Tools & data"]
  n1["Existing SharePoint<br/>Tools & data"]
  n2["Existing Confluence<br/>Tools & data"]
  n3["Company sign-in integration<br/>Azure"]
  n4["Internal assistant<br/>Azure"]
  n5["Source synchronization<br/>Azure"]
  n6["Document and permission state<br/>Azure"]
  n7["Searchable document copies<br/>Azure"]
  n8["Answer and embedding models<br/>Azure"]
  n9["Connector credential protection<br/>Azure"]
  n10["Operational evidence and alerts<br/>Azure"]
  n0 -->|HTTPS questions; authorized cited answers returned| n4
  n4 -->|OpenID Connect sign-in; server-side token validation| n3
  n5 -->|Microsoft Graph HTTPS: independent content and permission reconciliation| n1
  n5 -->|Native Confluence HTTPS API: independent page and permission reconciliation| n2
  n5 -->|Managed identity: separate content/permission fences, tombstones and checkpoints| n6
  n5 -->|Managed identity: revision-tagged chunks, permission generations and deletion re| n7
  n5 -->|Managed identity HTTPS: document embeddings; Australian processing required| n8
  n4 -->|Managed identity: filtered candidate metadata, then authorized chunk fetch| n7
  n4 -->|Strong reads: identity, quarantine and independent content/permission fences| n6
  n4 -->|Current source-side user access and revision checks; deny on uncertainty| n1
  n4 -->|Current mapped-user access and revision checks; deny on uncertainty| n2
  n4 -->|Managed identity HTTPS: query embeddings and authorized generation in Australia| n8
  n5 -->|Managed identity: scoped connector credential retrieval| n9
  n4 -->|Managed identity: scoped source-check credential retrieval| n9
  n5 -->|Redacted content/permission lag, quarantine, outage and recovery telemetry| n10
  n4 -->|Redacted authorization, citation and failure telemetry| n10
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Staff browser | tools | Web browser | Existing user locations | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing source location; unconfirmed | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| company-sign-in | Company sign-in integration | azure | Microsoft Entra ID | Tenant geography to be confirmed | Proposed | Implementation needed |
| assistant-app | Internal assistant | azure | Azure App Service | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| source-ingestion | Source synchronization | azure | Azure Functions | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| authorization-state | Document and permission state | azure | Azure Cosmos DB | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| document-search | Searchable document copies | azure | Azure AI Search | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| language-models | Answer and embedding models | azure | Azure OpenAI | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| connector-secrets | Connector credential protection | azure | Azure Key Vault | australiaeast (proposed; unverified) | Proposed | Implementation needed |
| operations-logs | Operational evidence and alerts | azure | Azure Monitor Logs | australiaeast (proposed; unverified) | Proposed | Implementation needed |

### Resources and cost dimensions

- **Staff browser** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Company sign-in integration** (company-sign-in): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app.
- **Internal assistant** (assistant-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser.
- **Source synchronization** (source-ingestion): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Document and permission state** (authorization-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Searchable document copies** (document-search): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Answer and embedding models** (language-models): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Connector credential protection** (connector-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.
- **Operational evidence and alerts** (operations-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-ingestion, assistant-app.

### Engineering work remaining

- Company sign-in integration: Implementation needed.
- Internal assistant: Implementation needed.
- Source synchronization: Implementation needed.
- Document and permission state: Implementation needed.
- Searchable document copies: Implementation needed.
- Answer and embedding models: Implementation needed.
- Connector credential protection: Implementation needed.
- Operational evidence and alerts: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire assistant-app → company-sign-in: implement data flow, access policy and acceptance test.
- Wire source-ingestion → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-ingestion → confluence: implement data flow, access policy and acceptance test.
- Wire source-ingestion → authorization-state: implement data flow, access policy and acceptance test.
- Wire source-ingestion → document-search: implement data flow, access policy and acceptance test.
- Wire source-ingestion → language-models: implement data flow, access policy and acceptance test.
- Wire assistant-app → document-search: implement data flow, access policy and acceptance test.
- Wire assistant-app → authorization-state: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → language-models: implement data flow, access policy and acceptance test.
- Wire source-ingestion → connector-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire source-ingestion → operations-logs: implement data flow, access policy and acceptance test.
- Wire assistant-app → operations-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing; explain service/model residency gaps.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
