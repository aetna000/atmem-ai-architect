Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

# Permission-aware knowledge assistant — solution specification

## Problem and intended outcome

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results. (must, open); target: acceptance target needed; linked blocks: assistant-app, staff-auth, sharepoint, confluence, answer-model

Design explanation: Copied permissions can become stale; checking source authority prevents cached access from exposing restricted material. Proposed enforcement must be tested against actual source permission semantics.

Basis: “People should get cited answers only from documents they can access.”
- [REQ-005] Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery. (must, open); target: acceptance target needed; linked blocks: source-sync, knowledge-catalog, assistant-app, sharepoint, confluence, operational-logs

Design explanation: An outage or incomplete synchronization must not allow old restricted content to remain answerable. Durable per-source recovery state prevents failed batches or restores from silently reactivating stale revisions.

Basis: “Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content.”
- [REQ-006] Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution. (should, open); target: acceptance target needed; linked blocks: staff-browser, assistant-app, answer-model, sharepoint, confluence

Design explanation: Clear scope keeps document content from granting action permissions and ensures users can trace answers to authorized evidence. Read-only browser delivery is a proposed boundary rather than confirmed policy.

Basis: “Build an internal assistant over our existing SharePoint and Confluence content.” and “People should get cited answers only from documents they can access.” Existing requirement req-75519d41 records source citations.
- [REQ-007] Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation. (must, open); target: acceptance target needed; linked blocks: assistant-app, sharepoint, confluence, source-sync, knowledge-catalog, answer-model, operational-logs

Design explanation: Prevents an Australian application from silently sending content to overseas inference, backups or telemetry. Service names and a candidate region do not prove compliance.

Basis: “Australia for content, indexes and processing; explain service/model residency gaps.”
- [REQ-008] The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open. (must, open); target: Supported collection size >= 10000documents; linked blocks: sharepoint, confluence, source-sync, knowledge-catalog, assistant-app

Design explanation: Establishes the known collection size while avoiding invented storage, concurrency or latency targets. Representative retrieval and synchronization tests must determine suitability.

Basis: “Ten thousand company documents.”

## How the system works

The current design contains 10 components and 14 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Internal staff browser → Private knowledge assistant

HTTPS question / complete answer after final authorization checks

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Internal staff browser → Staff sign-in

Proposed OIDC sign-in with PKCE; federation unverified

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Private knowledge assistant → Staff sign-in

Validate issuer, audience, token and staff identity

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Source synchronization → Existing SharePoint

Native API: content revisions and independent permission/deletion reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Source synchronization → Existing Confluence

Native API: page revisions and independent restriction/deletion reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Source synchronization → Revisioned knowledge catalog

TLS SQL: atomic revisions, permission observations, tombstones and checkpoints

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Private knowledge assistant → Revisioned knowledge catalog

TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Private knowledge assistant → Existing SharePoint

Live independent access + revision checks before inference and complete answer r

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Private knowledge assistant → Existing Confluence

Live independent access + revision checks before inference and complete answer r

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Private knowledge assistant → Grounded answer model

Authorized excerpts / grounded draft; Australian inference endpoint qualificatio

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Private knowledge assistant → Connector and runtime secrets

Workload identity: scoped runtime secret retrieval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Source synchronization → Connector and runtime secrets

Separate workload identity: scoped connector secret retrieval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Private knowledge assistant → Access and synchronization evidence

Redacted authorization, revision and failure metadata; Australian destination re

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Source synchronization → Access and synchronization evidence

Redacted source health, permission-change and reconciliation events

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Internal staff browser

Web browser · tools · region: Existing client location · classification: Internal

Existing staff client outside provisioning scope. Proposed browser channel for questions and cited answers; receives no database or model credentials. Proposed no persistent browser answer cache; previously delivered information cannot be recalled by later permission revocation. Staff location and browser data handling remain relevant to the Australian boundary.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Internal staff browser → Private knowledge assistant: HTTPS question / complete answer after final authorization checks; Internal staff browser → Staff sign-in: Proposed OIDC sign-in with PKCE; federation unverified

Requirement traceability: REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Private knowledge assistant

IBM Cloud Code Engine · ibm · region: Australia only; Sydney candidate, unverified · classification: Confidential

Proposed Code Engine application hosting browser interface and authenticated backend in Australia. Validates identity server-side and explicitly maps staff to source identities without assuming email equivalence. Retrieves candidates, then independently checks current source permissions and exact content revisions before sending excerpts to the model. Repeats both checks for every supporting document before releasing the complete cited answer. Unchanged text or revision never proves unchanged authorization. On denial, timeout, uncertainty, deletion or mismatch, discards the affected draft; any replacement answer is regenerated solely from freshly authorized evidence. No streaming of unvalidated drafts. Authorization checks establish point-in-time access, not an atomic transaction with external sources; qualification must document race limits. Treats source text as untrusted evidence and abstains without sufficient authorized evidence. No shared answer cache or persistent conversation memory initially. Separate least-privilege identity from synchronization. Australian runtime, network destinations, transient processing and telemetry require qualification. Application, federation, native connectors and infrastructure generation remain engineering work; no supplied-image contract is claimed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Internal staff browser → Private knowledge assistant: HTTPS question / complete answer after final authorization checks

Outputs: Private knowledge assistant → Staff sign-in: Validate issuer, audience, token and staff identity; Private knowledge assistant → Revisioned knowledge catalog: TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters; Private knowledge assistant → Existing SharePoint: Live independent access + revision checks before inference and complete answer r; Private knowledge assistant → Existing Confluence: Live independent access + revision checks before inference and complete answer r; Private knowledge assistant → Grounded answer model: Authorized excerpts / grounded draft; Australian inference endpoint qualificatio; Private knowledge assistant → Connector and runtime secrets: Workload identity: scoped runtime secret retrieval; Private knowledge assistant → Access and synchronization evidence: Redacted authorization, revision and failure metadata; Australian destination re

Requirement traceability: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Staff sign-in

IBM Cloud App ID · ibm · region: Australia required; service placement unverified · classification: Confidential

Proposed IBM Cloud App ID for staff authentication, subject to enterprise federation and Australian regional qualification. Does not grant source permissions. Existing company identity provider, subject mapping, identity metadata processing and token handling remain to be established. Do not create unrelated local staff accounts by default. Australian hosting for other services does not establish this service's residency or federation compatibility.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Internal staff browser → Staff sign-in: Proposed OIDC sign-in with PKCE; federation unverified; Private knowledge assistant → Staff sign-in: Validate issuer, audience, token and staff identity

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing SharePoint

Microsoft SharePoint · tools · region: Existing source; Australian residency unverified · classification: Confidential

Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Australian tenant content and processing residency require evidence; no relocation is implied. Native connector must qualify revisions, inherited permissions, groups, revocation, edits and deletion against the actual tenant. Authorization can change without a content revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content when checks fail. Native API semantics, permissions and tenant access remain unverified.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Source synchronization → Existing SharePoint: Native API: content revisions and independent permission/deletion reconciliation; Private knowledge assistant → Existing SharePoint: Live independent access + revision checks before inference and complete answer r

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Existing Confluence

Atlassian Confluence · tools · region: Existing source; Australian residency unverified · classification: Confidential

Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Deployment type and Australian content/processing residency remain unverified. Native connector must qualify page revisions, space/page restrictions, inheritance, groups, edits and deletion. Authorization can change without a page revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content on failed checks. No native compatibility is claimed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Source synchronization → Existing Confluence: Native API: page revisions and independent restriction/deletion reconciliation; Private knowledge assistant → Existing Confluence: Live independent access + revision checks before inference and complete answer r

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Source synchronization

IBM Cloud Code Engine · ibm · region: Australia only; Sydney candidate, unverified · classification: Confidential

Separate proposed scheduled Code Engine job with SharePoint and Confluence connector modules in one deployment, processing only in Australia. Bounded paginated incremental polling plus periodic full reconciliation covers 10,000 documents. Tracks immutable content revisions separately from permission observations and group/restriction changes; permission-only events cannot be skipped because text is unchanged. Uses source-specific checkpoints, deletion tombstones, transactional publication, idempotent retries and bounded backoff. Failed batches do not advance checkpoints. Source uncertainty blocks affected content; recovery requires reconciliation before re-enabling it. Cached ACLs never replace live authorization. No separate raw-file object store initially. Native API coverage, throttling, reconciliation scheduling and Australian processing require implementation and tests.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Source synchronization → Existing SharePoint: Native API: content revisions and independent permission/deletion reconciliation; Source synchronization → Existing Confluence: Native API: page revisions and independent restriction/deletion reconciliation; Source synchronization → Revisioned knowledge catalog: TLS SQL: atomic revisions, permission observations, tombstones and checkpoints; Source synchronization → Connector and runtime secrets: Separate workload identity: scoped connector secret retrieval; Source synchronization → Access and synchronization evidence: Redacted source health, permission-change and reconciliation events

Requirement traceability: REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Revisioned knowledge catalog

IBM Cloud Databases for PostgreSQL · ibm · region: Australia only; Sydney candidate, unverified · classification: Confidential

Proposed managed PostgreSQL instance for extracted text, full-text search, immutable content revisions, separate permission observations, source links, tombstones, source health and checkpoints. Starting retrieval design for 10,000 documents; document count alone proves neither storage needs nor search quality or latency. No assumed vector extension. Application has scoped reads; synchronization has scoped updates. Indexed ACLs are prefilters only. Proposed encrypted private service access and Australian-only primary storage, replicas, backups, restore processing and temporary exports; exact regional/plan support remains unverified. Purge and backup retention require a documented lifecycle without invented time targets. Restored content remains unavailable until source reconciliation and live authorization.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Source synchronization → Revisioned knowledge catalog: TLS SQL: atomic revisions, permission observations, tombstones and checkpoints; Private knowledge assistant → Revisioned knowledge catalog: TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Grounded answer model

IBM watsonx.ai Runtime · ibm · region: Australia required; model endpoint unverified · classification: Confidential

Proposed IBM watsonx.ai Runtime receiving only freshly authorized excerpts and the question. Model answers from supplied evidence with source identifiers or abstains; application checks citations and reauthorizes all supporting evidence before release. No tools or source credentials exposed. Exact model ID, Australian inference processing, endpoint routing, retention, abuse-monitoring copies, entitlement, quotas and availability remain unverified. An Australian application endpoint does not establish model residency. No overseas fallback is permitted. If no suitable managed model satisfies the boundary, inference remains blocked pending an explicitly engineered Australian-hosted alternative; no substitute deployment or support claim is made here.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Private knowledge assistant → Grounded answer model: Authorized excerpts / grounded draft; Australian inference endpoint qualificatio

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Connector and runtime secrets

IBM Cloud Secrets Manager · ibm · region: Australia required; service placement unverified · classification: Confidential

Proposed IBM Cloud Secrets Manager with separate least-privilege workload identities, scoped retrieval and credential rotation. No credentials in canvas, browser or prompts. Native delegated authorization, identity mapping and credential lifecycle remain engineering work; stored application credentials do not prove user access. Australian instance placement, replication, backup and operational access handling require qualification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Private knowledge assistant → Connector and runtime secrets: Workload identity: scoped runtime secret retrieval; Source synchronization → Connector and runtime secrets: Separate workload identity: scoped connector secret retrieval

Outputs: No outgoing connection is drawn.

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Access and synchronization evidence

IBM Cloud Logs · ibm · region: Australia required; service placement unverified · classification: Confidential

Proposed IBM Cloud Logs for structured authorization outcomes, content revision identifiers, permission-check timestamps, synchronization failures and correlation IDs. Exclude raw documents, prompts, answers, credentials and tokens by default. Alert on source uncertainty, reconciliation failure and authorization errors. Australian ingestion, storage, archives, processing and support access need service-specific qualification; do not export telemetry overseas by default. Retention and incident ownership remain open. Delivery, redaction and alert behavior require tests.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Private knowledge assistant → Access and synchronization evidence: Redacted authorization, revision and failure metadata; Australian destination re; Source synchronization → Access and synchronization evidence: Redacted source health, permission-change and reconciliation events

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Internal staff browser<br/>Tools & data"]
  n1["Private knowledge assistant<br/>IBM"]
  n2["Staff sign-in<br/>IBM"]
  n3["Existing SharePoint<br/>Tools & data"]
  n4["Existing Confluence<br/>Tools & data"]
  n5["Source synchronization<br/>IBM"]
  n6["Revisioned knowledge catalog<br/>IBM"]
  n7["Grounded answer model<br/>IBM"]
  n8["Connector and runtime secrets<br/>IBM"]
  n9["Access and synchronization evidence<br/>IBM"]
  n0 -->|HTTPS question / complete answer after final authorization checks| n1
  n0 -->|Proposed OIDC sign-in with PKCE; federation unverified| n2
  n1 -->|Validate issuer, audience, token and staff identity| n2
  n5 -->|Native API: content revisions and independent permission/deletion reconciliation| n3
  n5 -->|Native API: page revisions and independent restriction/deletion reconciliation| n4
  n5 -->|TLS SQL: atomic revisions, permission observations, tombstones and checkpoints| n6
  n1 -->|TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters| n6
  n1 -->|Live independent access + revision checks before inference and complete answer r| n3
  n1 -->|Live independent access + revision checks before inference and complete answer r| n4
  n1 -->|Authorized excerpts / grounded draft; Australian inference endpoint qualificatio| n7
  n1 -->|Workload identity: scoped runtime secret retrieval| n8
  n5 -->|Separate workload identity: scoped connector secret retrieval| n8
  n1 -->|Redacted authorization, revision and failure metadata; Australian destination re| n9
  n5 -->|Redacted source health, permission-change and reconciliation events| n9
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Internal staff browser | tools | Web browser | Existing client location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| assistant-app | Private knowledge assistant | ibm | IBM Cloud Code Engine | Australia only; Sydney candidate, unverified | Proposed | Implementation needed |
| staff-auth | Staff sign-in | ibm | IBM Cloud App ID | Australia required; service placement unverified | Proposed | Implementation needed |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing source; Australian residency unverified | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing source; Australian residency unverified | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| source-sync | Source synchronization | ibm | IBM Cloud Code Engine | Australia only; Sydney candidate, unverified | Proposed | Implementation needed |
| knowledge-catalog | Revisioned knowledge catalog | ibm | IBM Cloud Databases for PostgreSQL | Australia only; Sydney candidate, unverified | Proposed | Implementation needed |
| answer-model | Grounded answer model | ibm | IBM watsonx.ai Runtime | Australia required; model endpoint unverified | Proposed | Implementation needed |
| runtime-secrets | Connector and runtime secrets | ibm | IBM Cloud Secrets Manager | Australia required; service placement unverified | Proposed | Implementation needed |
| operational-logs | Access and synchronization evidence | ibm | IBM Cloud Logs | Australia required; service placement unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Internal staff browser** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Private knowledge assistant** (assistant-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser.
- **Staff sign-in** (staff-auth): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser, assistant-app.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-sync, assistant-app.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-sync, assistant-app.
- **Source synchronization** (source-sync): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Revisioned knowledge catalog** (knowledge-catalog): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-sync, assistant-app.
- **Grounded answer model** (answer-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app.
- **Connector and runtime secrets** (runtime-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Access and synchronization evidence** (operational-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.

### Engineering work remaining

- Private knowledge assistant: Implementation needed.
- Staff sign-in: Implementation needed.
- Source synchronization: Implementation needed.
- Revisioned knowledge catalog: Implementation needed.
- Grounded answer model: Implementation needed.
- Connector and runtime secrets: Implementation needed.
- Access and synchronization evidence: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire staff-browser → staff-auth: implement data flow, access policy and acceptance test.
- Wire assistant-app → staff-auth: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → answer-model: implement data flow, access policy and acceptance test.
- Wire assistant-app → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → operational-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing; explain service/model residency gaps.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
