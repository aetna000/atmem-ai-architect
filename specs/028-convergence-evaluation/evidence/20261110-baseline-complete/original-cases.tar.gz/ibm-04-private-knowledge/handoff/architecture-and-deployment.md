Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

# Permission-aware knowledge assistant — deployment document

Generated 2026-11-09 18:05 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** IBM
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** Ten thousand company documents. Source permissions are authoritative; content and authorization can change independently. Australia for content, indexes and processing; explain service/model residency gaps.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM
- **Budget and timeline:** —

## 3. Architecture

**Staff access**

- Internal staff browser (Tools & data, existing, sketch) — Existing staff client outside provisioning scope. Proposed browser channel for questions and cited answers; receives no database or model credentials. Proposed no persistent browser answer cache; previously delivered information cannot be recalled by later permission revocation. Staff location and browser data handling remain relevant to the Australian boundary.
- Staff sign-in (IBM, sketch) — Proposed IBM Cloud App ID for staff authentication, subject to enterprise federation and Australian regional qualification. Does not grant source permissions. Existing company identity provider, subject mapping, identity metadata processing and token handling remain to be established. Do not create unrelated local staff accounts by default. Australian hosting for other services does not establish this service's residency or federation compatibility.

**Answer delivery**

- Private knowledge assistant (IBM, sketch) — Proposed Code Engine application hosting browser interface and authenticated backend in Australia. Validates identity server-side and explicitly maps staff to source identities without assuming email equivalence. Retrieves candidates, then independently checks current source permissions and exact content revisions before sending excerpts to the model. Repeats both checks for every supporting document before releasing the complete cited answer. Unchanged text or revision never proves unchanged authorization. On denial, timeout, uncertainty, deletion or mismatch, discards the affected draft; any replacement answer is regenerated solely from freshly authorized evidence. No streaming of unvalidated drafts. Authorization checks establish point-in-time access, not an atomic transaction with external sources; qualification must document race limits. Treats source text as untrusted evidence and abstains without sufficient authorized evidence. No shared answer cache or persistent conversation memory initially. Separate least-privilege identity from synchronization. Australian runtime, network destinations, transient processing and telemetry require qualification. Application, federation, native connectors and infrastructure generation remain engineering work; no supplied-image contract is claimed.
- Grounded answer model (IBM, sketch) — Proposed IBM watsonx.ai Runtime receiving only freshly authorized excerpts and the question. Model answers from supplied evidence with source identifiers or abstains; application checks citations and reauthorizes all supporting evidence before release. No tools or source credentials exposed. Exact model ID, Australian inference processing, endpoint routing, retention, abuse-monitoring copies, entitlement, quotas and availability remain unverified. An Australian application endpoint does not establish model residency. No overseas fallback is permitted. If no suitable managed model satisfies the boundary, inference remains blocked pending an explicitly engineered Australian-hosted alternative; no substitute deployment or support claim is made here.

**Authoritative sources**

- Existing SharePoint (Tools & data, existing, sketch) — Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Australian tenant content and processing residency require evidence; no relocation is implied. Native connector must qualify revisions, inherited permissions, groups, revocation, edits and deletion against the actual tenant. Authorization can change without a content revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content when checks fail. Native API semantics, permissions and tenant access remain unverified.
- Existing Confluence (Tools & data, existing, sketch) — Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Deployment type and Australian content/processing residency remain unverified. Native connector must qualify page revisions, space/page restrictions, inheritance, groups, edits and deletion. Authorization can change without a page revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content on failed checks. No native compatibility is claimed.

**Content synchronization**

- Source synchronization (IBM, sketch) — Separate proposed scheduled Code Engine job with SharePoint and Confluence connector modules in one deployment, processing only in Australia. Bounded paginated incremental polling plus periodic full reconciliation covers 10,000 documents. Tracks immutable content revisions separately from permission observations and group/restriction changes; permission-only events cannot be skipped because text is unchanged. Uses source-specific checkpoints, deletion tombstones, transactional publication, idempotent retries and bounded backoff. Failed batches do not advance checkpoints. Source uncertainty blocks affected content; recovery requires reconciliation before re-enabling it. Cached ACLs never replace live authorization. No separate raw-file object store initially. Native API coverage, throttling, reconciliation scheduling and Australian processing require implementation and tests.

**Knowledge state**

- Revisioned knowledge catalog (IBM, sketch) — Proposed managed PostgreSQL instance for extracted text, full-text search, immutable content revisions, separate permission observations, source links, tombstones, source health and checkpoints. Starting retrieval design for 10,000 documents; document count alone proves neither storage needs nor search quality or latency. No assumed vector extension. Application has scoped reads; synchronization has scoped updates. Indexed ACLs are prefilters only. Proposed encrypted private service access and Australian-only primary storage, replicas, backups, restore processing and temporary exports; exact regional/plan support remains unverified. Purge and backup retention require a documented lifecycle without invented time targets. Restored content remains unavailable until source reconciliation and live authorization.

**Operations**

- Connector and runtime secrets (IBM, sketch) — Proposed IBM Cloud Secrets Manager with separate least-privilege workload identities, scoped retrieval and credential rotation. No credentials in canvas, browser or prompts. Native delegated authorization, identity mapping and credential lifecycle remain engineering work; stored application credentials do not prove user access. Australian instance placement, replication, backup and operational access handling require qualification.
- Access and synchronization evidence (IBM, sketch) — Proposed IBM Cloud Logs for structured authorization outcomes, content revision identifiers, permission-check timestamps, synchronization failures and correlation IDs. Exclude raw documents, prompts, answers, credentials and tokens by default. Alert on source uncertainty, reconciliation failure and authorization errors. Australian ingestion, storage, archives, processing and support access need service-specific qualification; do not export telemetry overseas by default. Retention and incident ownership remain open. Delivery, redaction and alert behavior require tests.

```mermaid
flowchart LR
  n0["Internal staff browser<br/>Tools & data"]
  n1["Private knowledge assistant<br/>IBM"]
  n2["Staff sign-in<br/>IBM"]
  n3["Existing SharePoint<br/>Tools & data"]
  n4["Existing Confluence<br/>Tools & data"]
  n5["Source synchronization<br/>IBM"]
  n6["Revisioned knowledge catalog<br/>IBM"]
  n7["Grounded answer model<br/>IBM"]
  n8["Connector and runtime secrets<br/>IBM"]
  n9["Access and synchronization evidence<br/>IBM"]
  n0 -->|HTTPS question / complete answer after final authorization checks| n1
  n0 -->|Proposed OIDC sign-in with PKCE; federation unverified| n2
  n1 -->|Validate issuer, audience, token and staff identity| n2
  n5 -->|Native API: content revisions and independent permission/deletion reconciliation| n3
  n5 -->|Native API: page revisions and independent restriction/deletion reconciliation| n4
  n5 -->|TLS SQL: atomic revisions, permission observations, tombstones and checkpoints| n6
  n1 -->|TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters| n6
  n1 -->|Live independent access + revision checks before inference and complete answer r| n3
  n1 -->|Live independent access + revision checks before inference and complete answer r| n4
  n1 -->|Authorized excerpts / grounded draft; Australian inference endpoint qualificatio| n7
  n1 -->|Workload identity: scoped runtime secret retrieval| n8
  n5 -->|Separate workload identity: scoped connector secret retrieval| n8
  n1 -->|Redacted authorization, revision and failure metadata; Australian destination re| n9
  n5 -->|Redacted source health, permission-change and reconciliation events| n9
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Internal staff browser | tools | Web browser | Existing client location | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| assistant-app | Private knowledge assistant | ibm | IBM Cloud Code Engine | Australia only; Sydney candidate, unverified | Proposed | Implementation needed |
| staff-auth | Staff sign-in | ibm | IBM Cloud App ID | Australia required; service placement unverified | Proposed | Implementation needed |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing source; Australian residency unverified | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing source; Australian residency unverified | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| source-sync | Source synchronization | ibm | IBM Cloud Code Engine | Australia only; Sydney candidate, unverified | Proposed | Implementation needed |
| knowledge-catalog | Revisioned knowledge catalog | ibm | IBM Cloud Databases for PostgreSQL | Australia only; Sydney candidate, unverified | Proposed | Implementation needed |
| answer-model | Grounded answer model | ibm | IBM watsonx.ai Runtime | Australia required; model endpoint unverified | Proposed | Implementation needed |
| runtime-secrets | Connector and runtime secrets | ibm | IBM Cloud Secrets Manager | Australia required; service placement unverified | Proposed | Implementation needed |
| operational-logs | Access and synchronization evidence | ibm | IBM Cloud Logs | Australia required; service placement unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Internal staff browser** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Private knowledge assistant** (assistant-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser.
- **Staff sign-in** (staff-auth): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser, assistant-app.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-sync, assistant-app.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-sync, assistant-app.
- **Source synchronization** (source-sync): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Revisioned knowledge catalog** (knowledge-catalog): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: source-sync, assistant-app.
- **Grounded answer model** (answer-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app.
- **Connector and runtime secrets** (runtime-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.
- **Access and synchronization evidence** (operational-logs): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-app, source-sync.

### Engineering work remaining

- Private knowledge assistant: Implementation needed.
- Staff sign-in: Implementation needed.
- Source synchronization: Implementation needed.
- Revisioned knowledge catalog: Implementation needed.
- Grounded answer model: Implementation needed.
- Connector and runtime secrets: Implementation needed.
- Access and synchronization evidence: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire staff-browser → staff-auth: implement data flow, access policy and acceptance test.
- Wire assistant-app → staff-auth: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → answer-model: implement data flow, access policy and acceptance test.
- Wire assistant-app → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → operational-logs: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Internal staff browser | Private knowledge assistant | HTTPS question / complete answer after final authorization checks | Confidential |
| Internal staff browser | Staff sign-in | Proposed OIDC sign-in with PKCE; federation unverified | Confidential |
| Private knowledge assistant | Staff sign-in | Validate issuer, audience, token and staff identity | Confidential |
| Source synchronization | Existing SharePoint | Native API: content revisions and independent permission/deletion reconciliation | Confidential |
| Source synchronization | Existing Confluence | Native API: page revisions and independent restriction/deletion reconciliation | Confidential |
| Source synchronization | Revisioned knowledge catalog | TLS SQL: atomic revisions, permission observations, tombstones and checkpoints | Confidential |
| Private knowledge assistant | Revisioned knowledge catalog | TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters | Confidential |
| Private knowledge assistant | Existing SharePoint | Live independent access + revision checks before inference and complete answer r | Confidential |
| Private knowledge assistant | Existing Confluence | Live independent access + revision checks before inference and complete answer r | Confidential |
| Private knowledge assistant | Grounded answer model | Authorized excerpts / grounded draft; Australian inference endpoint qualificatio | Confidential |
| Private knowledge assistant | Connector and runtime secrets | Workload identity: scoped runtime secret retrieval | Confidential |
| Source synchronization | Connector and runtime secrets | Separate workload identity: scoped connector secret retrieval | Confidential |
| Private knowledge assistant | Access and synchronization evidence | Redacted authorization, revision and failure metadata; Australian destination re | Confidential |
| Source synchronization | Access and synchronization evidence | Redacted source health, permission-change and reconciliation events | Confidential |

## 5. Security controls

- **Staff sign-in** — Proposed IBM Cloud App ID for staff authentication, subject to enterprise federation and Australian regional qualification. Does not grant source permissions. Existing company identity provider, subject mapping, identity metadata processing and token handling remain to be established. Do not create unrelated local staff accounts by default. Australian hosting for other services does not establish this service's residency or federation compatibility.
- **Connector and runtime secrets** — Proposed IBM Cloud Secrets Manager with separate least-privilege workload identities, scoped retrieval and credential rotation. No credentials in canvas, browser or prompts. Native delegated authorization, identity mapping and credential lifecycle remain engineering work; stored application credentials do not prove user access. Australian instance placement, replication, backup and operational access handling require qualification.
- Requirement: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results. (must)
- Requirement: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery. | reliability | not measurable yet | Open |
| Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation. | compliance | not measurable yet | Open |
| The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open. | scalability | Supported collection size >= 10000documents | Open |

**Functional**

- Every answer shows its sources (should, open)
- The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results. (must, open)
- Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution. (should, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.”, “Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 10 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Existing SharePoint | Storage | needs data_gb | price needed | — | — |
| Existing Confluence | Storage | needs data_gb | price needed | — | — |
| Source synchronization | Data processed | needs data_gb | price needed | — | — |
| Revisioned knowledge catalog | Index storage | needs data_gb | price needed | — | — |
| Grounded answer model | Endpoint hours | 730 hours | price needed | — | — |
| Connector and runtime secrets | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Internal staff browser, Private knowledge assistant, Access and synchronization evidence.

**Estimate gaps:**

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Source synchronization / Data processed: input needed (data_gb).
- Revisioned knowledge catalog / Index storage: input needed (data_gb).
- Grounded answer model / Endpoint hours: price needed.
- Connector and runtime secrets / Checked requests: input needed (requests_per_month).
- Internal staff browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Private knowledge assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Access and synchronization evidence: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff access: Staff sign-in.
4. Provision content synchronization: Source synchronization.
5. Provision answer delivery: Private knowledge assistant, Grounded answer model.
6. Provision knowledge state: Revisioned knowledge catalog.
7. Provision operations: Connector and runtime secrets, Access and synchronization evidence.
8. Connect existing systems: Internal staff browser, Existing SharePoint, Existing Confluence; test failure behaviour.
9. Run the acceptance checks (success measures and requirements) in staging; record results.
10. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing; explain service/model residency gaps.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- Staff sign-in: needs requests_per_month _(estimate)_
- Existing SharePoint: needs data_gb _(estimate)_
- Existing Confluence: needs data_gb _(estimate)_
- Source synchronization: needs data_gb _(estimate)_
- Revisioned knowledge catalog: needs data_gb _(estimate)_
- Grounded answer model: needs a unit price with a source _(estimate)_
- Connector and runtime secrets: needs requests_per_month _(estimate)_
