# Component and interface contracts

Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component staff-browser: Internal staff browser

- Responsibility: Existing staff client outside provisioning scope. Proposed browser channel for questions and cited answers; receives no database or model credentials. Proposed no persistent browser answer cache; previously delivered information cannot be recalled by later permission revocation. Staff location and browser data handling remain relevant to the Australian boundary.
- Service: Web browser
- Provider / placement: tools / Existing client location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-73746166662d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component assistant-app: Private knowledge assistant

- Responsibility: Proposed Code Engine application hosting browser interface and authenticated backend in Australia. Validates identity server-side and explicitly maps staff to source identities without assuming email equivalence. Retrieves candidates, then independently checks current source permissions and exact content revisions before sending excerpts to the model. Repeats both checks for every supporting document before releasing the complete cited answer. Unchanged text or revision never proves unchanged authorization. On denial, timeout, uncertainty, deletion or mismatch, discards the affected draft; any replacement answer is regenerated solely from freshly authorized evidence. No streaming of unvalidated drafts. Authorization checks establish point-in-time access, not an atomic transaction with external sources; qualification must document race limits. Treats source text as untrusted evidence and abstains without sufficient authorized evidence. No shared answer cache or persistent conversation memory initially. Separate least-privilege identity from synchronization. Australian runtime, network destinations, transient processing and telemetry require qualification. Application, federation, native connectors and infrastructure generation remain engineering work; no supplied-image contract is claimed.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia only; Sydney candidate, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component staff-auth: Staff sign-in

- Responsibility: Proposed IBM Cloud App ID for staff authentication, subject to enterprise federation and Australian regional qualification. Does not grant source permissions. Existing company identity provider, subject mapping, identity metadata processing and token handling remain to be established. Do not create unrelated local staff accounts by default. Australian hosting for other services does not establish this service's residency or federation compatibility.
- Service: IBM Cloud App ID
- Provider / placement: ibm / Australia required; service placement unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d61757468
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component sharepoint: Existing SharePoint

- Responsibility: Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Australian tenant content and processing residency require evidence; no relocation is implied. Native connector must qualify revisions, inherited permissions, groups, revocation, edits and deletion against the actual tenant. Authorization can change without a content revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content when checks fail. Native API semantics, permissions and tenant access remain unverified.
- Service: Microsoft SharePoint
- Provider / placement: tools / Existing source; Australian residency unverified
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7368617265706f696e74
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component confluence: Existing Confluence

- Responsibility: Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Deployment type and Australian content/processing residency remain unverified. Native connector must qualify page revisions, space/page restrictions, inheritance, groups, edits and deletion. Authorization can change without a page revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content on failed checks. No native compatibility is claimed.
- Service: Atlassian Confluence
- Provider / placement: tools / Existing source; Australian residency unverified
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-636f6e666c75656e6365
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component source-sync: Source synchronization

- Responsibility: Separate proposed scheduled Code Engine job with SharePoint and Confluence connector modules in one deployment, processing only in Australia. Bounded paginated incremental polling plus periodic full reconciliation covers 10,000 documents. Tracks immutable content revisions separately from permission observations and group/restriction changes; permission-only events cannot be skipped because text is unchanged. Uses source-specific checkpoints, deletion tombstones, transactional publication, idempotent retries and bounded backoff. Failed batches do not advance checkpoints. Source uncertainty blocks affected content; recovery requires reconciliation before re-enabling it. Cached ACLs never replace live authorization. No separate raw-file object store initially. Native API coverage, throttling, reconciliation scheduling and Australian processing require implementation and tests.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia only; Sydney candidate, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736f757263652d73796e63
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component knowledge-catalog: Revisioned knowledge catalog

- Responsibility: Proposed managed PostgreSQL instance for extracted text, full-text search, immutable content revisions, separate permission observations, source links, tombstones, source health and checkpoints. Starting retrieval design for 10,000 documents; document count alone proves neither storage needs nor search quality or latency. No assumed vector extension. Application has scoped reads; synchronization has scoped updates. Indexed ACLs are prefilters only. Proposed encrypted private service access and Australian-only primary storage, replicas, backups, restore processing and temporary exports; exact regional/plan support remains unverified. Purge and backup retention require a documented lifecycle without invented time targets. Restored content remains unavailable until source reconciliation and live authorization.
- Service: IBM Cloud Databases for PostgreSQL
- Provider / placement: ibm / Australia only; Sydney candidate, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component answer-model: Grounded answer model

- Responsibility: Proposed IBM watsonx.ai Runtime receiving only freshly authorized excerpts and the question. Model answers from supplied evidence with source identifiers or abstains; application checks citations and reauthorizes all supporting evidence before release. No tools or source credentials exposed. Exact model ID, Australian inference processing, endpoint routing, retention, abuse-monitoring copies, entitlement, quotas and availability remain unverified. An Australian application endpoint does not establish model residency. No overseas fallback is permitted. If no suitable managed model satisfies the boundary, inference remains blocked pending an explicitly engineered Australian-hosted alternative; no substitute deployment or support claim is made here.
- Service: IBM watsonx.ai Runtime
- Provider / placement: ibm / Australia required; model endpoint unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-616e737765722d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component runtime-secrets: Connector and runtime secrets

- Responsibility: Proposed IBM Cloud Secrets Manager with separate least-privilege workload identities, scoped retrieval and credential rotation. No credentials in canvas, browser or prompts. Native delegated authorization, identity mapping and credential lifecycle remain engineering work; stored application credentials do not prove user access. Australian instance placement, replication, backup and operational access handling require qualification.
- Service: IBM Cloud Secrets Manager
- Provider / placement: ibm / Australia required; service placement unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-72756e74696d652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component operational-logs: Access and synchronization evidence

- Responsibility: Proposed IBM Cloud Logs for structured authorization outcomes, content revision identifiers, permission-check timestamps, synchronization failures and correlation IDs. Exclude raw documents, prompts, answers, credentials and tokens by default. Alert on source uncertainty, reconciliation failure and authorization errors. Australian ingestion, storage, archives, processing and support access need service-specific qualification; do not export telemetry overseas by default. Retention and incident ownership remain open. Delivery, redaction and alert behavior require tests.
- Service: IBM Cloud Logs
- Provider / placement: ibm / Australia required; service placement unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-assistant: staff-browser → assistant-app

- Drawn payload/purpose: HTTPS question / complete answer after final authorization checks
- Contract task: TASK-CONTRACT-62726f777365722d617373697374616e74
- Integration task: TASK-INTEGRATION-62726f777365722d617373697374616e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### browser-signin: staff-browser → staff-auth

- Drawn payload/purpose: Proposed OIDC sign-in with PKCE; federation unverified
- Contract task: TASK-CONTRACT-62726f777365722d7369676e696e
- Integration task: TASK-INTEGRATION-62726f777365722d7369676e696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-auth: assistant-app → staff-auth

- Drawn payload/purpose: Validate issuer, audience, token and staff identity
- Contract task: TASK-CONTRACT-617373697374616e742d61757468
- Integration task: TASK-INTEGRATION-617373697374616e742d61757468
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-sharepoint: source-sync → sharepoint

- Drawn payload/purpose: Native API: content revisions and independent permission/deletion reconciliation
- Contract task: TASK-CONTRACT-73796e632d7368617265706f696e74
- Integration task: TASK-INTEGRATION-73796e632d7368617265706f696e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-confluence: source-sync → confluence

- Drawn payload/purpose: Native API: page revisions and independent restriction/deletion reconciliation
- Contract task: TASK-CONTRACT-73796e632d636f6e666c75656e6365
- Integration task: TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-catalog: source-sync → knowledge-catalog

- Drawn payload/purpose: TLS SQL: atomic revisions, permission observations, tombstones and checkpoints
- Contract task: TASK-CONTRACT-73796e632d636174616c6f67
- Integration task: TASK-INTEGRATION-73796e632d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-catalog: assistant-app → knowledge-catalog

- Drawn payload/purpose: TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters
- Contract task: TASK-CONTRACT-617373697374616e742d636174616c6f67
- Integration task: TASK-INTEGRATION-617373697374616e742d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-sharepoint-check: assistant-app → sharepoint

- Drawn payload/purpose: Live independent access + revision checks before inference and complete answer r
- Contract task: TASK-CONTRACT-617373697374616e742d7368617265706f696e742d636865636b
- Integration task: TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d636865636b
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-confluence-check: assistant-app → confluence

- Drawn payload/purpose: Live independent access + revision checks before inference and complete answer r
- Contract task: TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d636865636b
- Integration task: TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d636865636b
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-model: assistant-app → answer-model

- Drawn payload/purpose: Authorized excerpts / grounded draft; Australian inference endpoint qualificatio
- Contract task: TASK-CONTRACT-617373697374616e742d6d6f64656c
- Integration task: TASK-INTEGRATION-617373697374616e742d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-secrets: assistant-app → runtime-secrets

- Drawn payload/purpose: Workload identity: scoped runtime secret retrieval
- Contract task: TASK-CONTRACT-617373697374616e742d73656372657473
- Integration task: TASK-INTEGRATION-617373697374616e742d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-secrets: source-sync → runtime-secrets

- Drawn payload/purpose: Separate workload identity: scoped connector secret retrieval
- Contract task: TASK-CONTRACT-73796e632d73656372657473
- Integration task: TASK-INTEGRATION-73796e632d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-logs: assistant-app → operational-logs

- Drawn payload/purpose: Redacted authorization, revision and failure metadata; Australian destination re
- Contract task: TASK-CONTRACT-617373697374616e742d6c6f6773
- Integration task: TASK-INTEGRATION-617373697374616e742d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-logs: source-sync → operational-logs

- Drawn payload/purpose: Redacted source health, permission-change and reconciliation events
- Contract task: TASK-CONTRACT-73796e632d6c6f6773
- Integration task: TASK-INTEGRATION-73796e632d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
