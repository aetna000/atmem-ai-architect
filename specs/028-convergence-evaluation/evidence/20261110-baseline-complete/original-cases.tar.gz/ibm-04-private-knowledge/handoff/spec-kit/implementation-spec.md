# Implementation Spec Kit

Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

7 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: ibm
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Internal staff browser (staff-browser): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing client location.
- Private knowledge assistant (assistant-app): Implementation needed; ibm, Australia only; Sydney candidate, unverified.
- Staff sign-in (staff-auth): Implementation needed; ibm, Australia required; service placement unverified.
- Existing SharePoint (sharepoint): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing source; Australian residency unverified.
- Existing Confluence (confluence): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing source; Australian residency unverified.
- Source synchronization (source-sync): Implementation needed; ibm, Australia only; Sydney candidate, unverified.
- Revisioned knowledge catalog (knowledge-catalog): Implementation needed; ibm, Australia only; Sydney candidate, unverified.
- Grounded answer model (answer-model): Implementation needed; ibm, Australia required; model endpoint unverified.
- Connector and runtime secrets (runtime-secrets): Implementation needed; ibm, Australia required; service placement unverified.
- Access and synchronization evidence (operational-logs): Implementation needed; ibm, Australia required; service placement unverified.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d6175737472616c69616e2d7265736964656e6379 — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379

### requirement-proposed-61692d636f6c6c656374696f6e2d7363616c65 — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d636f6c6c656374696f6e2d7363616c65

### requirement-proposed-61692d63757272656e742d736f757263652d616363657373 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d616363657373

### requirement-proposed-61692d726561646f6e6c792d67726f756e6465642d73636f7065 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d726561646f6e6c792d67726f756e6465642d73636f7065

### requirement-proposed-61692d736f757263652d6368616e67652d7265636f76657279 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d7265636f76657279

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

10 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d6175737472616c69616e2d7265736964656e6379 — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379

### acceptance-61692d636f6c6c656374696f6e2d7363616c65 — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d636f6c6c656374696f6e2d7363616c65

### acceptance-61692d63757272656e742d736f757263652d616363657373 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d616363657373

### acceptance-61692d726561646f6e6c792d67726f756e6465642d73636f7065 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d726561646f6e6c792d67726f756e6465642d73636f7065

### acceptance-61692d736f757263652d6368616e67652d7265636f76657279 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d7265636f76657279

### acceptance-7265712d3735353139643431 — priority 2

REQ-001: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-7265712d3735353139643431

### traceability-7265712d3735353139643431 — priority 2

REQ-001 has no component links.

Action: Map the requirement to relevant components or record why it is project-wide; do not guess the mapping.

Tasks: TASK-ACCEPTANCE-7265712d3735353139643431

### implementation-616e737765722d6d6f64656c — priority 2

Grounded answer model: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-616e737765722d6d6f64656c

### implementation-617373697374616e742d617070 — priority 2

Private knowledge assistant: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-617373697374616e742d617070

### implementation-6b6e6f776c656467652d636174616c6f67 — priority 2

Revisioned knowledge catalog: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67

### implementation-6f7065726174696f6e616c2d6c6f6773 — priority 2

Access and synchronization evidence: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773

### implementation-72756e74696d652d73656372657473 — priority 2

Connector and runtime secrets: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-72756e74696d652d73656372657473

### implementation-736f757263652d73796e63 — priority 2

Source synchronization: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-736f757263652d73796e63

### implementation-73746166662d61757468 — priority 2

Staff sign-in: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-73746166662d61757468

### existing-636f6e666c75656e6365 — priority 2

Existing Confluence: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-636f6e666c75656e6365

### existing-7368617265706f696e74 — priority 2

Existing SharePoint: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-7368617265706f696e74

### existing-73746166662d62726f77736572 — priority 2

Internal staff browser: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-73746166662d62726f77736572


# Component and interface contracts

Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component staff-browser: Internal staff browser

- Responsibility: Existing staff client outside provisioning scope. Proposed browser channel for questions and cited answers; receives no database or model credentials. Proposed no persistent browser answer cache; previously delivered information cannot be recalled by later permission revocation. Staff location and browser data handling remain relevant to the Australian boundary.
- Service: Web browser
- Provider / placement: tools / Existing client location
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-73746166662d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component assistant-app: Private knowledge assistant

- Responsibility: Proposed Code Engine application hosting browser interface and authenticated backend in Australia. Validates identity server-side and explicitly maps staff to source identities without assuming email equivalence. Retrieves candidates, then independently checks current source permissions and exact content revisions before sending excerpts to the model. Repeats both checks for every supporting document before releasing the complete cited answer. Unchanged text or revision never proves unchanged authorization. On denial, timeout, uncertainty, deletion or mismatch, discards the affected draft; any replacement answer is regenerated solely from freshly authorized evidence. No streaming of unvalidated drafts. Authorization checks establish point-in-time access, not an atomic transaction with external sources; qualification must document race limits. Treats source text as untrusted evidence and abstains without sufficient authorized evidence. No shared answer cache or persistent conversation memory initially. Separate least-privilege identity from synchronization. Australian runtime, network destinations, transient processing and telemetry require qualification. Application, federation, native connectors and infrastructure generation remain engineering work; no supplied-image contract is claimed.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia only; Sydney candidate, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component staff-auth: Staff sign-in

- Responsibility: Proposed IBM Cloud App ID for staff authentication, subject to enterprise federation and Australian regional qualification. Does not grant source permissions. Existing company identity provider, subject mapping, identity metadata processing and token handling remain to be established. Do not create unrelated local staff accounts by default. Australian hosting for other services does not establish this service's residency or federation compatibility.
- Service: IBM Cloud App ID
- Provider / placement: ibm / Australia required; service placement unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d61757468
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component sharepoint: Existing SharePoint

- Responsibility: Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Australian tenant content and processing residency require evidence; no relocation is implied. Native connector must qualify revisions, inherited permissions, groups, revocation, edits and deletion against the actual tenant. Authorization can change without a content revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content when checks fail. Native API semantics, permissions and tenant access remain unverified.
- Service: Microsoft SharePoint
- Provider / placement: tools / Existing source; Australian residency unverified
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7368617265706f696e74
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component confluence: Existing Confluence

- Responsibility: Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Deployment type and Australian content/processing residency remain unverified. Native connector must qualify page revisions, space/page restrictions, inheritance, groups, edits and deletion. Authorization can change without a page revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content on failed checks. No native compatibility is claimed.
- Service: Atlassian Confluence
- Provider / placement: tools / Existing source; Australian residency unverified
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-636f6e666c75656e6365
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component source-sync: Source synchronization

- Responsibility: Separate proposed scheduled Code Engine job with SharePoint and Confluence connector modules in one deployment, processing only in Australia. Bounded paginated incremental polling plus periodic full reconciliation covers 10,000 documents. Tracks immutable content revisions separately from permission observations and group/restriction changes; permission-only events cannot be skipped because text is unchanged. Uses source-specific checkpoints, deletion tombstones, transactional publication, idempotent retries and bounded backoff. Failed batches do not advance checkpoints. Source uncertainty blocks affected content; recovery requires reconciliation before re-enabling it. Cached ACLs never replace live authorization. No separate raw-file object store initially. Native API coverage, throttling, reconciliation scheduling and Australian processing require implementation and tests.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia only; Sydney candidate, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736f757263652d73796e63
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component knowledge-catalog: Revisioned knowledge catalog

- Responsibility: Proposed managed PostgreSQL instance for extracted text, full-text search, immutable content revisions, separate permission observations, source links, tombstones, source health and checkpoints. Starting retrieval design for 10,000 documents; document count alone proves neither storage needs nor search quality or latency. No assumed vector extension. Application has scoped reads; synchronization has scoped updates. Indexed ACLs are prefilters only. Proposed encrypted private service access and Australian-only primary storage, replicas, backups, restore processing and temporary exports; exact regional/plan support remains unverified. Purge and backup retention require a documented lifecycle without invented time targets. Restored content remains unavailable until source reconciliation and live authorization.
- Service: IBM Cloud Databases for PostgreSQL
- Provider / placement: ibm / Australia only; Sydney candidate, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component answer-model: Grounded answer model

- Responsibility: Proposed IBM watsonx.ai Runtime receiving only freshly authorized excerpts and the question. Model answers from supplied evidence with source identifiers or abstains; application checks citations and reauthorizes all supporting evidence before release. No tools or source credentials exposed. Exact model ID, Australian inference processing, endpoint routing, retention, abuse-monitoring copies, entitlement, quotas and availability remain unverified. An Australian application endpoint does not establish model residency. No overseas fallback is permitted. If no suitable managed model satisfies the boundary, inference remains blocked pending an explicitly engineered Australian-hosted alternative; no substitute deployment or support claim is made here.
- Service: IBM watsonx.ai Runtime
- Provider / placement: ibm / Australia required; model endpoint unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-616e737765722d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component runtime-secrets: Connector and runtime secrets

- Responsibility: Proposed IBM Cloud Secrets Manager with separate least-privilege workload identities, scoped retrieval and credential rotation. No credentials in canvas, browser or prompts. Native delegated authorization, identity mapping and credential lifecycle remain engineering work; stored application credentials do not prove user access. Australian instance placement, replication, backup and operational access handling require qualification.
- Service: IBM Cloud Secrets Manager
- Provider / placement: ibm / Australia required; service placement unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-72756e74696d652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component operational-logs: Access and synchronization evidence

- Responsibility: Proposed IBM Cloud Logs for structured authorization outcomes, content revision identifiers, permission-check timestamps, synchronization failures and correlation IDs. Exclude raw documents, prompts, answers, credentials and tokens by default. Alert on source uncertainty, reconciliation failure and authorization errors. Australian ingestion, storage, archives, processing and support access need service-specific qualification; do not export telemetry overseas by default. Retention and incident ownership remain open. Delivery, redaction and alert behavior require tests.
- Service: IBM Cloud Logs
- Provider / placement: ibm / Australia required; service placement unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-assistant: staff-browser → assistant-app

- Drawn payload/purpose: HTTPS question / complete answer after final authorization checks
- Contract task: TASK-CONTRACT-62726f777365722d617373697374616e74
- Integration task: TASK-INTEGRATION-62726f777365722d617373697374616e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### browser-signin: staff-browser → staff-auth

- Drawn payload/purpose: Proposed OIDC sign-in with PKCE; federation unverified
- Contract task: TASK-CONTRACT-62726f777365722d7369676e696e
- Integration task: TASK-INTEGRATION-62726f777365722d7369676e696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-auth: assistant-app → staff-auth

- Drawn payload/purpose: Validate issuer, audience, token and staff identity
- Contract task: TASK-CONTRACT-617373697374616e742d61757468
- Integration task: TASK-INTEGRATION-617373697374616e742d61757468
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-sharepoint: source-sync → sharepoint

- Drawn payload/purpose: Native API: content revisions and independent permission/deletion reconciliation
- Contract task: TASK-CONTRACT-73796e632d7368617265706f696e74
- Integration task: TASK-INTEGRATION-73796e632d7368617265706f696e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-confluence: source-sync → confluence

- Drawn payload/purpose: Native API: page revisions and independent restriction/deletion reconciliation
- Contract task: TASK-CONTRACT-73796e632d636f6e666c75656e6365
- Integration task: TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-catalog: source-sync → knowledge-catalog

- Drawn payload/purpose: TLS SQL: atomic revisions, permission observations, tombstones and checkpoints
- Contract task: TASK-CONTRACT-73796e632d636174616c6f67
- Integration task: TASK-INTEGRATION-73796e632d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-catalog: assistant-app → knowledge-catalog

- Drawn payload/purpose: TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters
- Contract task: TASK-CONTRACT-617373697374616e742d636174616c6f67
- Integration task: TASK-INTEGRATION-617373697374616e742d636174616c6f67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-sharepoint-check: assistant-app → sharepoint

- Drawn payload/purpose: Live independent access + revision checks before inference and complete answer r
- Contract task: TASK-CONTRACT-617373697374616e742d7368617265706f696e742d636865636b
- Integration task: TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d636865636b
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-confluence-check: assistant-app → confluence

- Drawn payload/purpose: Live independent access + revision checks before inference and complete answer r
- Contract task: TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d636865636b
- Integration task: TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d636865636b
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-model: assistant-app → answer-model

- Drawn payload/purpose: Authorized excerpts / grounded draft; Australian inference endpoint qualificatio
- Contract task: TASK-CONTRACT-617373697374616e742d6d6f64656c
- Integration task: TASK-INTEGRATION-617373697374616e742d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-secrets: assistant-app → runtime-secrets

- Drawn payload/purpose: Workload identity: scoped runtime secret retrieval
- Contract task: TASK-CONTRACT-617373697374616e742d73656372657473
- Integration task: TASK-INTEGRATION-617373697374616e742d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-secrets: source-sync → runtime-secrets

- Drawn payload/purpose: Separate workload identity: scoped connector secret retrieval
- Contract task: TASK-CONTRACT-73796e632d73656372657473
- Integration task: TASK-INTEGRATION-73796e632d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### assistant-logs: assistant-app → operational-logs

- Drawn payload/purpose: Redacted authorization, revision and failure metadata; Australian destination re
- Contract task: TASK-CONTRACT-617373697374616e742d6c6f6773
- Integration task: TASK-INTEGRATION-617373697374616e742d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-logs: source-sync → operational-logs

- Drawn payload/purpose: Redacted source health, permission-change and reconciliation events
- Contract task: TASK-CONTRACT-73796e632d6c6f6773
- Integration task: TASK-INTEGRATION-73796e632d6c6f6773
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-62726f777365722d617373697374616e74 — Define Internal staff browser → Private knowledge assistant

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: staff-browser, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection browser-assistant: HTTPS question / complete answer after final authorization checks. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge browser-assistant
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-62726f777365722d7369676e696e — Define Internal staff browser → Staff sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: staff-browser, staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection browser-signin: Proposed OIDC sign-in with PKCE; federation unverified. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge browser-signin
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d61757468 — Define Private knowledge assistant → Staff sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-auth: Validate issuer, audience, token and staff identity. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-auth
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d7368617265706f696e74 — Define Source synchronization → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-sharepoint: Native API: content revisions and independent permission/deletion reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-sharepoint
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d636f6e666c75656e6365 — Define Source synchronization → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-confluence: Native API: page revisions and independent restriction/deletion reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-confluence
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d636174616c6f67 — Define Source synchronization → Revisioned knowledge catalog

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-catalog: TLS SQL: atomic revisions, permission observations, tombstones and checkpoints. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d636174616c6f67 — Define Private knowledge assistant → Revisioned knowledge catalog

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-catalog: TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d7368617265706f696e742d636865636b — Define Private knowledge assistant → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-sharepoint-check: Live independent access + revision checks before inference and complete answer r. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-sharepoint-check
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d636865636b — Define Private knowledge assistant → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-confluence-check: Live independent access + revision checks before inference and complete answer r. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-confluence-check
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d6d6f64656c — Define Private knowledge assistant → Grounded answer model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, answer-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-model: Authorized excerpts / grounded draft; Australian inference endpoint qualificatio. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d73656372657473 — Define Private knowledge assistant → Connector and runtime secrets

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-secrets: Workload identity: scoped runtime secret retrieval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d73656372657473 — Define Source synchronization → Connector and runtime secrets

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-secrets: Separate workload identity: scoped connector secret retrieval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-617373697374616e742d6c6f6773 — Define Private knowledge assistant → Access and synchronization evidence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-app, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection assistant-logs: Redacted authorization, revision and failure metadata; Australian destination re. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge assistant-logs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d6c6f6773 — Define Source synchronization → Access and synchronization evidence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-logs: Redacted source health, permission-change and reconciliation events. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-logs
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-73746166662d62726f77736572 — Integrate existing Internal staff browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d617373697374616e74, TASK-CONTRACT-62726f777365722d7369676e696e
- Components: staff-browser
- Generated files: No implementation files generated yet
- Requirements: ai-readonly-grounded-scope

### Implementation steps

1. Responsibility from the board: Existing staff client outside provisioning scope. Proposed browser channel for questions and cited answers; receives no database or model credentials. Proposed no persistent browser answer cache; previously delivered information cannot be recalled by later permission revocation. Staff location and browser data handling remain relevant to the Australian boundary.
2. Verify Web browser on tools in Existing client location; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-browser
- Application/configuration and tests for Internal staff browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d617070 — Implement Private knowledge assistant

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d617373697374616e74, TASK-CONTRACT-617373697374616e742d61757468, TASK-CONTRACT-617373697374616e742d636174616c6f67, TASK-CONTRACT-617373697374616e742d7368617265706f696e742d636865636b, TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-CONTRACT-617373697374616e742d6d6f64656c, TASK-CONTRACT-617373697374616e742d73656372657473, TASK-CONTRACT-617373697374616e742d6c6f6773
- Components: assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-access, ai-source-change-recovery, ai-readonly-grounded-scope, ai-australian-residency, ai-collection-scale

### Implementation steps

1. Responsibility from the board: Proposed Code Engine application hosting browser interface and authenticated backend in Australia. Validates identity server-side and explicitly maps staff to source identities without assuming email equivalence. Retrieves candidates, then independently checks current source permissions and exact content revisions before sending excerpts to the model. Repeats both checks for every supporting document before releasing the complete cited answer. Unchanged text or revision never proves unchanged authorization. On denial, timeout, uncertainty, deletion or mismatch, discards the affected draft; any replacement answer is regenerated solely from freshly authorized evidence. No streaming of unvalidated drafts. Authorization checks establish point-in-time access, not an atomic transaction with external sources; qualification must document race limits. Treats source text as untrusted evidence and abstains without sufficient authorized evidence. No shared answer cache or persistent conversation memory initially. Separate least-privilege identity from synchronization. Australian runtime, network destinations, transient processing and telemetry require qualification. Application, federation, native connectors and infrastructure generation remain engineering work; no supplied-image contract is claimed.
2. Verify IBM Cloud Code Engine on ibm in Australia only; Sydney candidate, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-app
- Application/configuration and tests for Private knowledge assistant

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73746166662d61757468 — Implement Staff sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d7369676e696e, TASK-CONTRACT-617373697374616e742d61757468
- Components: staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-access

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud App ID for staff authentication, subject to enterprise federation and Australian regional qualification. Does not grant source permissions. Existing company identity provider, subject mapping, identity metadata processing and token handling remain to be established. Do not create unrelated local staff accounts by default. Australian hosting for other services does not establish this service's residency or federation compatibility.
2. Verify IBM Cloud App ID on ibm in Australia required; service placement unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud App ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-auth
- Application/configuration and tests for Staff sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7368617265706f696e74 — Integrate existing Existing SharePoint

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-CONTRACT-617373697374616e742d7368617265706f696e742d636865636b
- Components: sharepoint
- Generated files: No implementation files generated yet
- Requirements: ai-current-source-access, ai-source-change-recovery, ai-readonly-grounded-scope, ai-australian-residency, ai-collection-scale

### Implementation steps

1. Responsibility from the board: Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Australian tenant content and processing residency require evidence; no relocation is implied. Native connector must qualify revisions, inherited permissions, groups, revocation, edits and deletion against the actual tenant. Authorization can change without a content revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content when checks fail. Native API semantics, permissions and tenant access remain unverified.
2. Verify Microsoft SharePoint on tools in Existing source; Australian residency unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sharepoint
- Application/configuration and tests for Existing SharePoint

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e666c75656e6365 — Integrate existing Existing Confluence

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d636865636b
- Components: confluence
- Generated files: No implementation files generated yet
- Requirements: ai-current-source-access, ai-source-change-recovery, ai-readonly-grounded-scope, ai-australian-residency, ai-collection-scale

### Implementation steps

1. Responsibility from the board: Existing authoritative content and permission source, outside provisioning scope; part of the combined 10,000-document collection. Deployment type and Australian content/processing residency remain unverified. Native connector must qualify page revisions, space/page restrictions, inheritance, groups, edits and deletion. Authorization can change without a page revision. Live user-context permission and revision checks are required before model use and answer release. Deny affected content on failed checks. No native compatibility is claimed.
2. Verify Atlassian Confluence on tools in Existing source; Australian residency unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component confluence
- Application/configuration and tests for Existing Confluence

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-736f757263652d73796e63 — Implement Source synchronization

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-CONTRACT-73796e632d636174616c6f67, TASK-CONTRACT-73796e632d73656372657473, TASK-CONTRACT-73796e632d6c6f6773
- Components: source-sync
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-change-recovery, ai-australian-residency, ai-collection-scale

### Implementation steps

1. Responsibility from the board: Separate proposed scheduled Code Engine job with SharePoint and Confluence connector modules in one deployment, processing only in Australia. Bounded paginated incremental polling plus periodic full reconciliation covers 10,000 documents. Tracks immutable content revisions separately from permission observations and group/restriction changes; permission-only events cannot be skipped because text is unchanged. Uses source-specific checkpoints, deletion tombstones, transactional publication, idempotent retries and bounded backoff. Failed batches do not advance checkpoints. Source uncertainty blocks affected content; recovery requires reconciliation before re-enabling it. Cached ACLs never replace live authorization. No separate raw-file object store initially. Native API coverage, throttling, reconciliation scheduling and Australian processing require implementation and tests.
2. Verify IBM Cloud Code Engine on ibm in Australia only; Sydney candidate, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component source-sync
- Application/configuration and tests for Source synchronization

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67 — Implement Revisioned knowledge catalog

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73796e632d636174616c6f67, TASK-CONTRACT-617373697374616e742d636174616c6f67
- Components: knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-change-recovery, ai-australian-residency, ai-collection-scale

### Implementation steps

1. Responsibility from the board: Proposed managed PostgreSQL instance for extracted text, full-text search, immutable content revisions, separate permission observations, source links, tombstones, source health and checkpoints. Starting retrieval design for 10,000 documents; document count alone proves neither storage needs nor search quality or latency. No assumed vector extension. Application has scoped reads; synchronization has scoped updates. Indexed ACLs are prefilters only. Proposed encrypted private service access and Australian-only primary storage, replicas, backups, restore processing and temporary exports; exact regional/plan support remains unverified. Purge and backup retention require a documented lifecycle without invented time targets. Restored content remains unavailable until source reconciliation and live authorization.
2. Verify IBM Cloud Databases for PostgreSQL on ibm in Australia only; Sydney candidate, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Databases for PostgreSQL; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.; REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component knowledge-catalog
- Application/configuration and tests for Revisioned knowledge catalog

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-616e737765722d6d6f64656c — Implement Grounded answer model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-617373697374616e742d6d6f64656c
- Components: answer-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-access, ai-readonly-grounded-scope, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed IBM watsonx.ai Runtime receiving only freshly authorized excerpts and the question. Model answers from supplied evidence with source identifiers or abstains; application checks citations and reauthorizes all supporting evidence before release. No tools or source credentials exposed. Exact model ID, Australian inference processing, endpoint routing, retention, abuse-monitoring copies, entitlement, quotas and availability remain unverified. An Australian application endpoint does not establish model residency. No overseas fallback is permitted. If no suitable managed model satisfies the boundary, inference remains blocked pending an explicitly engineered Australian-hosted alternative; no substitute deployment or support claim is made here.
2. Verify IBM watsonx.ai Runtime on ibm in Australia required; model endpoint unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM watsonx.ai Runtime; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.; REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component answer-model
- Application/configuration and tests for Grounded answer model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-72756e74696d652d73656372657473 — Implement Connector and runtime secrets

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-617373697374616e742d73656372657473, TASK-CONTRACT-73796e632d73656372657473
- Components: runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Secrets Manager with separate least-privilege workload identities, scoped retrieval and credential rotation. No credentials in canvas, browser or prompts. Native delegated authorization, identity mapping and credential lifecycle remain engineering work; stored application credentials do not prove user access. Australian instance placement, replication, backup and operational access handling require qualification.
2. Verify IBM Cloud Secrets Manager on ibm in Australia required; service placement unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Secrets Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component runtime-secrets
- Application/configuration and tests for Connector and runtime secrets

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773 — Implement Access and synchronization evidence

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-617373697374616e742d6c6f6773, TASK-CONTRACT-73796e632d6c6f6773
- Components: operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-change-recovery, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Logs for structured authorization outcomes, content revision identifiers, permission-check timestamps, synchronization failures and correlation IDs. Exclude raw documents, prompts, answers, credentials and tokens by default. Alert on source uncertainty, reconciliation failure and authorization errors. Australian ingestion, storage, archives, processing and support access need service-specific qualification; do not export telemetry overseas by default. Retention and incident ownership remain open. Delivery, redaction and alert behavior require tests.
2. Verify IBM Cloud Logs on ibm in Australia required; service placement unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Logs; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.; REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component operational-logs
- Application/configuration and tests for Access and synchronization evidence

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-62726f777365722d617373697374616e74 — Wire Internal staff browser to Private knowledge assistant

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f777365722d617373697374616e74, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-617373697374616e742d617070
- Components: staff-browser, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge browser-assistant carrying HTTPS question / complete answer after final authorization checks, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation browser-assistant
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-62726f777365722d7369676e696e — Wire Internal staff browser to Staff sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f777365722d7369676e696e, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-73746166662d61757468
- Components: staff-browser, staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge browser-signin carrying Proposed OIDC sign-in with PKCE; federation unverified, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation browser-signin
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d61757468 — Wire Private knowledge assistant to Staff sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d61757468, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-73746166662d61757468
- Components: assistant-app, staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-auth carrying Validate issuer, audience, token and staff identity, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-auth
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d7368617265706f696e74 — Wire Source synchronization to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-sharepoint carrying Native API: content revisions and independent permission/deletion reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-sharepoint
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d636f6e666c75656e6365 — Wire Source synchronization to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-confluence carrying Native API: page revisions and independent restriction/deletion reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-confluence
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d636174616c6f67 — Wire Source synchronization to Revisioned knowledge catalog

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d636174616c6f67, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67
- Components: source-sync, knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-catalog carrying TLS SQL: atomic revisions, permission observations, tombstones and checkpoints, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d636174616c6f67 — Wire Private knowledge assistant to Revisioned knowledge catalog

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d636174616c6f67, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67
- Components: assistant-app, knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-catalog carrying TLS SQL: full-text candidates, revisions and source health; ACLs are prefilters, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d636865636b — Wire Private knowledge assistant to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d7368617265706f696e742d636865636b, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-7368617265706f696e74
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-sharepoint-check carrying Live independent access + revision checks before inference and complete answer r, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-sharepoint-check
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d636865636b — Wire Private knowledge assistant to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-636f6e666c75656e6365
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-confluence-check carrying Live independent access + revision checks before inference and complete answer r, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-confluence-check
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d6d6f64656c — Wire Private knowledge assistant to Grounded answer model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d6d6f64656c, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-616e737765722d6d6f64656c
- Components: assistant-app, answer-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-model carrying Authorized excerpts / grounded draft; Australian inference endpoint qualificatio, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d73656372657473 — Wire Private knowledge assistant to Connector and runtime secrets

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d73656372657473, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-72756e74696d652d73656372657473
- Components: assistant-app, runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-secrets carrying Workload identity: scoped runtime secret retrieval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d73656372657473 — Wire Source synchronization to Connector and runtime secrets

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d73656372657473, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-72756e74696d652d73656372657473
- Components: source-sync, runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-secrets carrying Separate workload identity: scoped connector secret retrieval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-617373697374616e742d6c6f6773 — Wire Private knowledge assistant to Access and synchronization evidence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-617373697374616e742d6c6f6773, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Components: assistant-app, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge assistant-logs carrying Redacted authorization, revision and failure metadata; Australian destination re, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation assistant-logs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d6c6f6773 — Wire Source synchronization to Access and synchronization evidence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d6c6f6773, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773
- Components: source-sync, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-logs carrying Redacted source health, permission-change and reconciliation events, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-logs
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74 — Verify live Internal staff browser → Private knowledge assistant

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f777365722d617373697374616e74
- Components: staff-browser, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge browser-assistant with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence browser-assistant

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-62726f777365722d7369676e696e — Verify live Internal staff browser → Staff sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f777365722d7369676e696e
- Components: staff-browser, staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge browser-signin with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence browser-signin

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d61757468 — Verify live Private knowledge assistant → Staff sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d61757468
- Components: assistant-app, staff-auth
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-auth with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-auth

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74 — Verify live Source synchronization → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d7368617265706f696e74
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-sharepoint with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-sharepoint

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365 — Verify live Source synchronization → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-confluence with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-confluence

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d636174616c6f67 — Verify live Source synchronization → Revisioned knowledge catalog

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d636174616c6f67
- Components: source-sync, knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67 — Verify live Private knowledge assistant → Revisioned knowledge catalog

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d636174616c6f67
- Components: assistant-app, knowledge-catalog
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b — Verify live Private knowledge assistant → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d636865636b
- Components: assistant-app, sharepoint
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-sharepoint-check with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-sharepoint-check

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b — Verify live Private knowledge assistant → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d636865636b
- Components: assistant-app, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-confluence-check with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-confluence-check

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c — Verify live Private knowledge assistant → Grounded answer model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d6d6f64656c
- Components: assistant-app, answer-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473 — Verify live Private knowledge assistant → Connector and runtime secrets

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d73656372657473
- Components: assistant-app, runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d73656372657473 — Verify live Source synchronization → Connector and runtime secrets

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d73656372657473
- Components: source-sync, runtime-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773 — Verify live Private knowledge assistant → Access and synchronization evidence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-617373697374616e742d6c6f6773
- Components: assistant-app, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge assistant-logs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence assistant-logs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d6c6f6773 — Verify live Source synchronization → Access and synchronization evidence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d6c6f6773
- Components: source-sync, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-logs with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-logs

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3735353139643431 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-75519d41

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d616363657373 — Verify REQ-004: The assistant shall authenticate each user and confirm their current source access and the exact document revision before sending excerpts to the model and again before releasing an answer. Missing, ambiguous or failed checks shall deny the affected content, including citations and cached results.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-73746166662d61757468, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-616e737765722d6d6f64656c, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-62726f777365722d7369676e696e, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773
- Components: assistant-app, staff-auth, sharepoint, confluence, answer-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-current-source-access

### Implementation steps

1. Basis: “People should get cited answers only from documents they can access.”; rationale: Copied permissions can become stale; checking source authority prevents cached access from exposing restricted material. Proposed enforcement must be tested against actual source permission semantics.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d7265636f76657279 — Verify REQ-005: Synchronization shall propagate document edits, deletions and permission changes using revisioned records, deletion tombstones and per-source checkpoints. Source uncertainty shall block affected content; recovery shall reconcile source state before restoring eligibility. Acceptance tests shall cover revocation, deletion, partial synchronization, source outage and recovery.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773, TASK-INTEGRATION-LIVE-73796e632d6c6f6773
- Components: source-sync, knowledge-catalog, assistant-app, sharepoint, confluence, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-source-change-recovery

### Implementation steps

1. Basis: “Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content.”; rationale: An outage or incomplete synchronization must not allow old restricted content to remain answerable. Durable per-source recovery state prevents failed batches or restores from silently reactivating stale revisions.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d726561646f6e6c792d67726f756e6465642d73636f7065 — Verify REQ-006: Proposed first-version scope is internal, read-only browser question answering over SharePoint and Confluence, with citations to the authorized document revisions supporting each answer and abstention when evidence is insufficient. Source write-back and autonomous actions are excluded unless separately agreed; source content shall never authorize tool execution.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-616e737765722d6d6f64656c, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-62726f777365722d7369676e696e, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773
- Components: staff-browser, assistant-app, answer-model, sharepoint, confluence
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-readonly-grounded-scope

### Implementation steps

1. Basis: “Build an internal assistant over our existing SharePoint and Confluence content.” and “People should get cited answers only from documents they can access.” Existing requirement req-75519d41 records source citations.; rationale: Clear scope keeps document content from granting action permissions and ensures users can trace answers to authorized evidence. Read-only browser delivery is a proposed boundary rather than confirmed policy.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379 — Verify REQ-007: Content, indexes and processing shall remain in Australia. Proposed implementation coverage includes excerpts, prompts, answers, temporary copies, replicas, backups and content-bearing telemetry. Each service and selected model shall have documented location, routing and retention evidence before use; unqualified destinations and overseas failover shall remain disabled. Existing source residency shall be assessed separately without assuming relocation.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67, TASK-RESOURCE-616e737765722d6d6f64656c, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773, TASK-INTEGRATION-LIVE-73796e632d6c6f6773
- Components: assistant-app, sharepoint, confluence, source-sync, knowledge-catalog, answer-model, operational-logs
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-australian-residency

### Implementation steps

1. Basis: “Australia for content, indexes and processing; explain service/model residency gaps.”; rationale: Prevents an Australian application from silently sending content to overseas inference, backups or telemetry. Service names and a candidate region do not prove compliance.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d636f6c6c656374696f6e2d7363616c65 — Verify REQ-008: The assistant shall support a combined collection of 10,000 company documents across SharePoint and Confluence. Qualification shall exercise initial ingestion, incremental reconciliation and authorized cited retrieval against representative document sizes, formats and permission structures. Storage capacity, concurrent demand, answer quality and latency acceptance targets remain open.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773, TASK-INTEGRATION-LIVE-73796e632d6c6f6773
- Components: sharepoint, confluence, source-sync, knowledge-catalog, assistant-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-collection-scale

### Implementation steps

1. Basis: “Ten thousand company documents.”; rationale: Establishes the known collection size while avoiding invented storage, concurrency or latency targets. Representative retrieval and synchronization tests must determine suitability.
2. Implement a check for Supported collection size >= 10000 documents; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-73746166662d61757468, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67, TASK-RESOURCE-616e737765722d6d6f64656c, TASK-RESOURCE-72756e74696d652d73656372657473, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773, TASK-INTEGRATION-62726f777365722d617373697374616e74, TASK-INTEGRATION-62726f777365722d7369676e696e, TASK-INTEGRATION-617373697374616e742d61757468, TASK-INTEGRATION-73796e632d7368617265706f696e74, TASK-INTEGRATION-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-73796e632d636174616c6f67, TASK-INTEGRATION-617373697374616e742d636174616c6f67, TASK-INTEGRATION-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-617373697374616e742d6d6f64656c, TASK-INTEGRATION-617373697374616e742d73656372657473, TASK-INTEGRATION-73796e632d73656372657473, TASK-INTEGRATION-617373697374616e742d6c6f6773, TASK-INTEGRATION-73796e632d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-73746166662d62726f77736572, TASK-RESOURCE-617373697374616e742d617070, TASK-RESOURCE-73746166662d61757468, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6b6e6f776c656467652d636174616c6f67, TASK-RESOURCE-616e737765722d6d6f64656c, TASK-RESOURCE-72756e74696d652d73656372657473, TASK-RESOURCE-6f7065726174696f6e616c2d6c6f6773, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-62726f777365722d7369676e696e, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773, TASK-INTEGRATION-LIVE-73796e632d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3735353139643431, TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d616363657373, TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d7265636f76657279, TASK-ACCEPTANCE-61692d726561646f6e6c792d67726f756e6465642d73636f7065, TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379, TASK-ACCEPTANCE-61692d636f6c6c656374696f6e2d7363616c65, TASK-INTEGRATION-LIVE-62726f777365722d617373697374616e74, TASK-INTEGRATION-LIVE-62726f777365722d7369676e696e, TASK-INTEGRATION-LIVE-617373697374616e742d61757468, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d636174616c6f67, TASK-INTEGRATION-LIVE-617373697374616e742d7368617265706f696e742d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d636f6e666c75656e63652d636865636b, TASK-INTEGRATION-LIVE-617373697374616e742d6d6f64656c, TASK-INTEGRATION-LIVE-617373697374616e742d73656372657473, TASK-INTEGRATION-LIVE-73796e632d73656372657473, TASK-INTEGRATION-LIVE-617373697374616e742d6c6f6773, TASK-INTEGRATION-LIVE-73796e632d6c6f6773
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-001 (req-75519d41) → TASK-ACCEPTANCE-7265712d3735353139643431; Recorded from user discussion
- REQ-004 (ai-current-source-access) → TASK-ACCEPTANCE-61692d63757272656e742d736f757263652d616363657373; Proposed; needs confirmation
- REQ-005 (ai-source-change-recovery) → TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d7265636f76657279; Proposed; needs confirmation
- REQ-006 (ai-readonly-grounded-scope) → TASK-ACCEPTANCE-61692d726561646f6e6c792d67726f756e6465642d73636f7065; Proposed; needs confirmation
- REQ-007 (ai-australian-residency) → TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379; Proposed; needs confirmation
- REQ-008 (ai-collection-scale) → TASK-ACCEPTANCE-61692d636f6c6c656374696f6e2d7363616c65; Proposed; needs confirmation
