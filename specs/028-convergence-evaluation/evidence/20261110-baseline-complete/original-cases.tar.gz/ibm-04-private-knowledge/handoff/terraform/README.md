# Infrastructure implementation required

Requested providers: ibm. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Private knowledge assistant: Implementation needed.
- Staff sign-in: Implementation needed.
- Source synchronization: Implementation needed.
- Revisioned knowledge catalog: Implementation needed.
- Grounded answer model: Implementation needed.
- Connector and runtime secrets: Implementation needed.
- Access and synchronization evidence: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire staff-browser → staff-auth: implement data flow, access policy and acceptance test.
- Wire assistant-app → staff-auth: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → answer-model: implement data flow, access policy and acceptance test.
- Wire assistant-app → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → operational-logs: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
