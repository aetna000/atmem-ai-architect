# Delivery handoff

Snapshot f719ccb7-432f-493f-885e-470b4f05627e · design r3 · generated 2026-11-09T18:05:46.746Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Source synchronization / Data processed: input needed (data_gb).
- Revisioned knowledge catalog / Index storage: input needed (data_gb).
- Grounded answer model / Endpoint hours: price needed.
- Connector and runtime secrets / Checked requests: input needed (requests_per_month).
- Internal staff browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Private knowledge assistant: no cost lines; add charges or an explicit zero-cost line with a reason.
- Access and synchronization evidence: no cost lines; add charges or an explicit zero-cost line with a reason.
- Private knowledge assistant: Implementation needed.
- Staff sign-in: Implementation needed.
- Source synchronization: Implementation needed.
- Revisioned knowledge catalog: Implementation needed.
- Grounded answer model: Implementation needed.
- Connector and runtime secrets: Implementation needed.
- Access and synchronization evidence: Implementation needed.
- Wire staff-browser → assistant-app: implement data flow, access policy and acceptance test.
- Wire staff-browser → staff-auth: implement data flow, access policy and acceptance test.
- Wire assistant-app → staff-auth: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → knowledge-catalog: implement data flow, access policy and acceptance test.
- Wire assistant-app → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-app → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-app → answer-model: implement data flow, access policy and acceptance test.
- Wire assistant-app → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire source-sync → runtime-secrets: implement data flow, access policy and acceptance test.
- Wire assistant-app → operational-logs: implement data flow, access policy and acceptance test.
- Wire source-sync → operational-logs: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
