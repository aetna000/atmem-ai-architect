# Questions and assumptions to resolve

Snapshot f8b79778-ab4e-4ccd-b5be-6d930cbb1feb · design r1 · generated 2026-11-09T17:51:00.501Z

- [platform.cloud] Confirm cloud provider; diagram labels alone are not a selection.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [architecture] Define the system components and interactions before implementation.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [architecture-empty] No deployable or existing components are described. Define the components and interactions; an empty Terraform configuration is not a deployment.
- [requirements-empty] No acceptance requirements are recorded. Agree observable behavior and success criteria before declaring the handoff implementation-ready.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
