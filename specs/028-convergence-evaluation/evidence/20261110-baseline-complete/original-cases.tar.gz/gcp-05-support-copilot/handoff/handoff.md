# Delivery handoff

Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in boundary / Checked requests: input needed (requests_per_month).
- Existing CRM / Storage: input needed (data_gb).
- Approved support knowledge / Storage: input needed (data_gb).
- Grounded draft generation / Endpoint hours: price needed.
- Approval and operation ledger / Storage: input needed (data_gb).
- Scoped connector credentials / Checked requests: input needed (requests_per_month).
- Support staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Copilot workspace and drafting: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved action executor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing outbound mail: no cost lines; add charges or an explicit zero-cost line with a reason.
- Staff sign-in boundary: Implementation needed.
- Copilot workspace and drafting: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and operation ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped connector credentials: Implementation needed.
- Wire staff → staff-access: implement data flow, access policy and acceptance test.
- Wire staff-access → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-app → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → outbound-mail: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
