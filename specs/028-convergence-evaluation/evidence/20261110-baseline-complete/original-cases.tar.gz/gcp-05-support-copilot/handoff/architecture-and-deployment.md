Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

# Human-approved support copilot — deployment document

Generated 2026-11-09 17:49 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

- **Cloud:** Google Cloud
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 10 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system. Fifty support agents and five supervisors. Account-changing actions require supervisor approval.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** CRM and outbound mail already exist, with administrator-supplied API credentials. Do not recreate them.
- **How good, fast and safe:** —
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**Staff access**

- Support staff (Tools & data, existing, sketch) — Existing 50 support agents and five supervisors using browsers, outside provisioning scope. Review cited drafts, edit or reject them, explicitly approve permitted sends and inspect pending or uncertain outcomes. Account-changing actions require supervisor approval. This actor represents both staff roles, not a provisioned identity service.
- Staff sign-in boundary (Google Cloud, sketch) — Proposed Identity-Aware Proxy access to the copilot. Existing staff identity provider and compatibility remain unresolved. Deny unauthenticated ingress and prevent bypass of the proxy. Application authorization must resolve agent/supervisor roles from an authoritative server-side mapping, never browser-supplied role claims, and check case/account permissions. Sign-in alone does not authorize account changes.

**Draft and review**

- Copilot workspace and drafting (Google Cloud, sketch) — Proposed Cloud Run application serving the staff workspace and backend for 50 agents and five supervisors; request volume and concurrency remain unknown. Reads authorized CRM cases and approved knowledge, retrieves permitted passages and asks Vertex AI for a cited draft and proposed actions. Treats source text as untrusted; unsupported answers are flagged for staff rather than invented. Shows sources and exact action details, including mail recipients, subject, body and attachments when applicable. Provides a pending supervisor-review view within this application for account changes. Server-side approval requires current supervisor authority for every account mutation and binds authenticated approver, exact payload, case/account version and operation ID in Firestore. Agent-only approval of account changes is rejected even if the browser is bypassed. Edits invalidate approval. Sends separately require authorized staff approval. Has no CRM write or outbound-mail send credentials. Returns drafts and execution status in the same application. Source adapters, identity integration, deployment artifacts and application behavior require implementation.
- Grounded draft generation (Google Cloud, sketch) — Proposed Vertex AI managed model endpoint. Receives only necessary authorized case context and approved passages; returns a structured draft, source references and action suggestions. Has no executor tools or CRM/mail credentials. Model selection, regional processing, data handling, quotas and grounding quality require verification after residency is established.

**Existing business systems**

- Existing CRM (Tools & data, existing, sketch) — Client-owned existing CRM accessed through administrator-supplied API credentials; vendor and API capabilities remain unknown. Reference only: do not provision, import, recreate or modify the existing service. Source of case/account data and destination for approved account changes. Drafting access must be read-only and executor write credentials separately scoped. Outbound responses use the separate existing mail service. Qualify conditional updates, stable operation keys and authoritative operation-status lookup. If an action cannot be safely deduplicated or reconciled, block its automatic retry and retain the unresolved requirement.
- Approved support knowledge (Tools & data, existing, sketch) — Logical reference to the client's approved knowledge in its current system, not a newly provisioned store. Location, approval markers and permissions remain unresolved. Adapter must retrieve authorized approved revisions with source identifiers for citations and exclude withdrawn or unauthorized material. No vector-search platform or native connector is assumed.
- Existing outbound mail (Tools & data, existing, sketch) — Client-owned existing outbound-mail service with administrator-supplied API credentials. Reference only, outside provisioning scope; do not recreate, import or modify this service. Vendor and API capabilities are unknown. Receives only explicitly approved messages from the executor. Qualify permitted sender identities, credential scopes, API idempotency and authoritative send-status lookup. A message identifier alone does not prove deduplication. If send acceptance is uncertain and cannot be authoritatively reconciled, retain an uncertain ledger state and prohibit blind resending. API integration and failure tests remain engineering work; no native compatibility or delivery guarantee is claimed.

**Approval and execution**

- Approval and operation ledger (Google Cloud, sketch) — Proposed Firestore database for draft revisions, exact approved payload hashes, authenticated approvers, authority evidence, source/case revisions, stable per-action operation IDs and execution states/results. Mail approval binds exact recipients and message content; every account mutation requires recorded supervisor approval for its exact target and payload. Pending-review records support supervisor worklists in the existing workspace. Transactions serialize claims and reject concurrent duplicate execution. Separate intents for mail sends and each CRM mutation expose partial completion without replaying successful actions. Record pending, executing, succeeded, rejected and uncertain states, external operation identifiers and reconciliation evidence. Uncertain external outcomes require reconciliation. Persist audit events with restricted mutation rights. Retention and recovery targets remain open. Firestore transactions do not make CRM or mail side effects atomic.
- Approved action executor (Google Cloud, sketch) — Separate private Cloud Run service with its own service account and separately scoped administrator-supplied CRM write and outbound-mail API credentials. Accepts operation IDs only from the authorized copilot backend; loads the approved payload from Firestore, independently checks current approver authority, action allowlist and current case/account state, then claims the operation transactionally. Every account mutation requires supervisor approval; missing, revoked or agent-only authority fails closed before any CRM write. Sends require explicit authorized staff approval of exact recipients and content. Does not trust browser claims or model-suggested action categories. Uses separate CRM-change and mail-send adapters and stable per-action operation keys where supported. Replays stored success results without another external action. On timeout or crash after a possible external commit, reconcile through authoritative CRM/mail status; otherwise mark uncertain and block blind retry, including manual resubmission of the same unresolved action. Track partial completion independently; no cross-system atomicity is assumed. Reject expired or changed approvals and require fresh approval. Connector, reconciliation and concurrency/failure tests are required, including duplicate mail submissions, agent denial, revoked supervisor authority and payload changes. Mail acceptance is distinct from recipient delivery. These application integrations are not implemented by the current generator.

**Service access**

- Scoped connector credentials (Google Cloud, sketch) — Proposed Secret Manager storage for administrator-supplied CRM and outbound-mail API credentials, plus knowledge-source credentials if required. Separate CRM read-only, CRM account-write and outbound-mail send secrets; drafting runtime can access only read credentials and executor only its required write/send credentials. Administrator-supplied credentials are not evidence of least privilege: validate external scopes before enabling actions and request separately scoped credentials through the administrator where needed. Provisioning creates secret containers and access policies; secret values are supplied separately through a controlled operator process, never through chat, diagram or Terraform values. Rotation, revocation and connector authorization require implementation and verification. Existing CRM and mail identities/services are not recreated.

```mermaid
flowchart LR
  n0["Support staff<br/>Tools & data"]
  n1["Staff sign-in boundary<br/>Google Cloud"]
  n2["Copilot workspace and drafting<br/>Google Cloud"]
  n3["Existing CRM<br/>Tools & data"]
  n4["Approved support knowledge<br/>Tools & data"]
  n5["Grounded draft generation<br/>Google Cloud"]
  n6["Approval and operation ledger<br/>Google Cloud"]
  n7["Approved action executor<br/>Google Cloud"]
  n8["Scoped connector credentials<br/>Google Cloud"]
  n9["Existing outbound mail<br/>Tools & data"]
  n0 -->|HTTPS staff sign-in and workspace access| n1
  n1 -->|Authenticated HTTPS; staff review and supervisor account approval| n2
  n2 -->|CRM API: authorized read-only case/account lookup| n3
  n2 -->|Source API: permitted approved passages and revisions| n4
  n2 -->|Vertex AI API: context → structured cited draft| n5
  n2 -->|Firestore transactions: drafts, supervisor approvals and status| n6
  n2 -->|IAM-authenticated HTTPS: approved operation ID → result| n7
  n7 -->|Firestore transactions: check approval authority, claim and record outcome| n6
  n7 -->|CRM API: supervisor-approved account change; deduplication and reconciliation re| n3
  n2 -->|Secret Manager API: read-only connector credentials| n8
  n7 -->|Secret Manager API: separate CRM-write and mail-send credentials| n8
  n7 -->|Mail API: exact approved message → acceptance/status; retry safety requires qual| n9
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff | Support staff | tools | Approval workflow | Existing location — unknown | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| staff-access | Staff sign-in boundary | gcp | Identity-Aware Proxy | To be selected | Proposed | Implementation needed |
| copilot-app | Copilot workspace and drafting | gcp | Google Cloud Run | To be selected | Proposed | Implementation needed |
| crm | Existing CRM | tools | Storage or existing data connector | Existing location — unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| approved-knowledge | Approved support knowledge | tools | Storage or existing data connector | Existing location — unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| draft-model | Grounded draft generation | gcp | Vertex AI | To be selected | Proposed | Implementation needed |
| approval-ledger | Approval and operation ledger | gcp | Firestore | To be selected | Proposed | Implementation needed |
| action-executor | Approved action executor | gcp | Google Cloud Run | To be selected | Proposed | Implementation needed |
| connector-secrets | Scoped connector credentials | gcp | Google Cloud Secret Manager | To be selected | Proposed | Implementation needed |
| outbound-mail | Existing outbound mail | tools | Application runtime and API | Existing location — unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |

### Resources and cost dimensions

- **Support staff** (staff): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Staff sign-in boundary** (staff-access): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff.
- **Copilot workspace and drafting** (copilot-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-access.
- **Existing CRM** (crm): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved support knowledge** (approved-knowledge): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Grounded draft generation** (draft-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Approval and operation ledger** (approval-ledger): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved action executor** (action-executor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Scoped connector credentials** (connector-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Existing outbound mail** (outbound-mail): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: action-executor.

### Engineering work remaining

- Staff sign-in boundary: Implementation needed.
- Copilot workspace and drafting: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and operation ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped connector credentials: Implementation needed.
- Wire staff → staff-access: implement data flow, access policy and acceptance test.
- Wire staff-access → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-app → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → outbound-mail: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Support staff | Staff sign-in boundary | HTTPS staff sign-in and workspace access | Confidential |
| Staff sign-in boundary | Copilot workspace and drafting | Authenticated HTTPS; staff review and supervisor account approval | Confidential |
| Copilot workspace and drafting | Existing CRM | CRM API: authorized read-only case/account lookup | Confidential |
| Copilot workspace and drafting | Approved support knowledge | Source API: permitted approved passages and revisions | Confidential |
| Copilot workspace and drafting | Grounded draft generation | Vertex AI API: context → structured cited draft | Confidential |
| Copilot workspace and drafting | Approval and operation ledger | Firestore transactions: drafts, supervisor approvals and status | Confidential |
| Copilot workspace and drafting | Approved action executor | IAM-authenticated HTTPS: approved operation ID → result | Confidential |
| Approved action executor | Approval and operation ledger | Firestore transactions: check approval authority, claim and record outcome | Confidential |
| Approved action executor | Existing CRM | CRM API: supervisor-approved account change; deduplication and reconciliation re | Confidential |
| Copilot workspace and drafting | Scoped connector credentials | Secret Manager API: read-only connector credentials | Confidential |
| Approved action executor | Scoped connector credentials | Secret Manager API: separate CRM-write and mail-send credentials | Confidential |
| Approved action executor | Existing outbound mail | Mail API: exact approved message → acceptance/status; retry safety requires qual | Confidential |

## 5. Security controls

- **Support staff** — Existing 50 support agents and five supervisors using browsers, outside provisioning scope. Review cited drafts, edit or reject them, explicitly approve permitted sends and inspect pending or uncertain outcomes. Account-changing actions require supervisor approval. This actor represents both staff roles, not a provisioned identity service.
- **Staff sign-in boundary** — Proposed Identity-Aware Proxy access to the copilot. Existing staff identity provider and compatibility remain unresolved. Deny unauthenticated ingress and prevent bypass of the proxy. Application authorization must resolve agent/supervisor roles from an authoritative server-side mapping, never browser-supplied role claims, and check case/account permissions. Sign-in alone does not authorize account changes.
- **Scoped connector credentials** — Proposed Secret Manager storage for administrator-supplied CRM and outbound-mail API credentials, plus knowledge-source credentials if required. Separate CRM read-only, CRM account-write and outbound-mail send secrets; drafting runtime can access only read credentials and executor only its required write/send credentials. Administrator-supplied credentials are not evidence of least privilege: validate external scopes before enabling actions and request separately scoped credentials through the administrator where needed. Provisioning creates secret containers and access policies; secret values are supplied separately through a controlled operator process, never through chat, diagram or Terraform values. Rotation, revocation and connector authorization require implementation and verification. Existing CRM and mail identities/services are not recreated.
- Requirement: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval. (must)
- Requirement: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration. (must)
- Open finding SEC-002: Sensitive data is involved but where it must be stored is not stated.

## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded. | reliability | not measurable yet | Open |

**Functional**

- Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval. (must, open)
- The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer. (must, open)
- Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Security & controls**

- [major] Sensitive data is involved but where it must be stored is not stated. Add a compliance requirement such as “data stays in the EU”, and set regions on data blocks. _(AtMem AI Architect rule SEC-002 v1.0.0)_

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_
- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 1 quality requirement has no measurable target. Add a metric and target to: “Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 10 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in boundary | Checked requests | needs requests_per_month | price needed | — | — |
| Existing CRM | Storage | needs data_gb | price needed | — | — |
| Approved support knowledge | Storage | needs data_gb | price needed | — | — |
| Grounded draft generation | Endpoint hours | 730 hours | price needed | — | — |
| Approval and operation ledger | Storage | needs data_gb | price needed | — | — |
| Scoped connector credentials | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Support staff, Copilot workspace and drafting, Approved action executor, Existing outbound mail.

**Estimate gaps:**

- Staff sign-in boundary / Checked requests: input needed (requests_per_month).
- Existing CRM / Storage: input needed (data_gb).
- Approved support knowledge / Storage: input needed (data_gb).
- Grounded draft generation / Endpoint hours: price needed.
- Approval and operation ledger / Storage: input needed (data_gb).
- Scoped connector credentials / Checked requests: input needed (requests_per_month).
- Support staff: no cost lines; add charges or an explicit zero-cost line with a reason.
- Copilot workspace and drafting: no cost lines; add charges or an explicit zero-cost line with a reason.
- Approved action executor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing outbound mail: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff access: Staff sign-in boundary.
4. Provision draft and review: Copilot workspace and drafting, Grounded draft generation.
5. Provision approval and execution: Approved action executor, Approval and operation ledger.
6. Provision service access: Scoped connector credentials.
7. Connect existing systems: Support staff, Existing CRM, Approved support knowledge, Existing outbound mail; test failure behaviour.
8. Run the acceptance checks (success measures and requirements) in staging; record results.
9. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Staff sign-in boundary: needs requests_per_month _(estimate)_
- Existing CRM: needs data_gb _(estimate)_
- Approved support knowledge: needs data_gb _(estimate)_
- Grounded draft generation: needs a unit price with a source _(estimate)_
- Approval and operation ledger: needs data_gb _(estimate)_
- Scoped connector credentials: needs requests_per_month _(estimate)_
