# Infrastructure implementation required

Requested providers: gcp. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Staff sign-in boundary: Implementation needed.
- Copilot workspace and drafting: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and operation ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped connector credentials: Implementation needed.
- Wire staff → staff-access: implement data flow, access policy and acceptance test.
- Wire staff-access → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-app → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → outbound-mail: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
