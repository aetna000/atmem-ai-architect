# Questions and assumptions to resolve

Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

- [ai-explicit-approval] Confirm REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.
- [ai-no-duplicate-actions] Confirm REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.
- [ai-grounded-support-drafts] Confirm REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.
- [ai-existing-system-boundaries] Confirm REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
- [acceptance-ai-explicit-approval] Agree a measurable acceptance check for REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.
- [acceptance-ai-no-duplicate-actions] Agree a measurable acceptance check for REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.
- [acceptance-ai-grounded-support-drafts] Agree a measurable acceptance check for REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.
- [acceptance-ai-existing-system-boundaries] Agree a measurable acceptance check for REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d6578697374696e672d73797374656d2d626f756e646172696573] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6578706c696369742d617070726f76616c] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d737570706f72742d647261667473] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6e6f2d6475706c69636174652d616374696f6e73] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
