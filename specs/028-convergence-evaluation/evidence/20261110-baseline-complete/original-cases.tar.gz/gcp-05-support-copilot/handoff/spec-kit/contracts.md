# Component and interface contracts

Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component staff: Support staff

- Responsibility: Existing 50 support agents and five supervisors using browsers, outside provisioning scope. Review cited drafts, edit or reject them, explicitly approve permitted sends and inspect pending or uncertain outcomes. Account-changing actions require supervisor approval. This actor represents both staff roles, not a provisioned identity service.
- Service: Approval workflow
- Provider / placement: tools / Existing location — unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7374616666
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component staff-access: Staff sign-in boundary

- Responsibility: Proposed Identity-Aware Proxy access to the copilot. Existing staff identity provider and compatibility remain unresolved. Deny unauthenticated ingress and prevent bypass of the proxy. Application authorization must resolve agent/supervisor roles from an authoritative server-side mapping, never browser-supplied role claims, and check case/account permissions. Sign-in alone does not authorize account changes.
- Service: Identity-Aware Proxy
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d616363657373
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component copilot-app: Copilot workspace and drafting

- Responsibility: Proposed Cloud Run application serving the staff workspace and backend for 50 agents and five supervisors; request volume and concurrency remain unknown. Reads authorized CRM cases and approved knowledge, retrieves permitted passages and asks Vertex AI for a cited draft and proposed actions. Treats source text as untrusted; unsupported answers are flagged for staff rather than invented. Shows sources and exact action details, including mail recipients, subject, body and attachments when applicable. Provides a pending supervisor-review view within this application for account changes. Server-side approval requires current supervisor authority for every account mutation and binds authenticated approver, exact payload, case/account version and operation ID in Firestore. Agent-only approval of account changes is rejected even if the browser is bypassed. Edits invalidate approval. Sends separately require authorized staff approval. Has no CRM write or outbound-mail send credentials. Returns drafts and execution status in the same application. Source adapters, identity integration, deployment artifacts and application behavior require implementation.
- Service: Google Cloud Run
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f70696c6f742d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component crm: Existing CRM

- Responsibility: Client-owned existing CRM accessed through administrator-supplied API credentials; vendor and API capabilities remain unknown. Reference only: do not provision, import, recreate or modify the existing service. Source of case/account data and destination for approved account changes. Drafting access must be read-only and executor write credentials separately scoped. Outbound responses use the separate existing mail service. Qualify conditional updates, stable operation keys and authoritative operation-status lookup. If an action cannot be safely deduplicated or reconciled, block its automatic retry and retain the unresolved requirement.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing location — unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-63726d
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component approved-knowledge: Approved support knowledge

- Responsibility: Logical reference to the client's approved knowledge in its current system, not a newly provisioned store. Location, approval markers and permissions remain unresolved. Adapter must retrieve authorized approved revisions with source identifiers for citations and exclude withdrawn or unauthorized material. No vector-search platform or native connector is assumed.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing location — unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component draft-model: Grounded draft generation

- Responsibility: Proposed Vertex AI managed model endpoint. Receives only necessary authorized case context and approved passages; returns a structured draft, source references and action suggestions. Has no executor tools or CRM/mail credentials. Model selection, regional processing, data handling, quotas and grounding quality require verification after residency is established.
- Service: Vertex AI
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-64726166742d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component approval-ledger: Approval and operation ledger

- Responsibility: Proposed Firestore database for draft revisions, exact approved payload hashes, authenticated approvers, authority evidence, source/case revisions, stable per-action operation IDs and execution states/results. Mail approval binds exact recipients and message content; every account mutation requires recorded supervisor approval for its exact target and payload. Pending-review records support supervisor worklists in the existing workspace. Transactions serialize claims and reject concurrent duplicate execution. Separate intents for mail sends and each CRM mutation expose partial completion without replaying successful actions. Record pending, executing, succeeded, rejected and uncertain states, external operation identifiers and reconciliation evidence. Uncertain external outcomes require reconciliation. Persist audit events with restricted mutation rights. Retention and recovery targets remain open. Firestore transactions do not make CRM or mail side effects atomic.
- Service: Firestore
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617070726f76616c2d6c6564676572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component action-executor: Approved action executor

- Responsibility: Separate private Cloud Run service with its own service account and separately scoped administrator-supplied CRM write and outbound-mail API credentials. Accepts operation IDs only from the authorized copilot backend; loads the approved payload from Firestore, independently checks current approver authority, action allowlist and current case/account state, then claims the operation transactionally. Every account mutation requires supervisor approval; missing, revoked or agent-only authority fails closed before any CRM write. Sends require explicit authorized staff approval of exact recipients and content. Does not trust browser claims or model-suggested action categories. Uses separate CRM-change and mail-send adapters and stable per-action operation keys where supported. Replays stored success results without another external action. On timeout or crash after a possible external commit, reconcile through authoritative CRM/mail status; otherwise mark uncertain and block blind retry, including manual resubmission of the same unresolved action. Track partial completion independently; no cross-system atomicity is assumed. Reject expired or changed approvals and require fresh approval. Connector, reconciliation and concurrency/failure tests are required, including duplicate mail submissions, agent denial, revoked supervisor authority and payload changes. Mail acceptance is distinct from recipient delivery. These application integrations are not implemented by the current generator.
- Service: Google Cloud Run
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-616374696f6e2d6578656375746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component connector-secrets: Scoped connector credentials

- Responsibility: Proposed Secret Manager storage for administrator-supplied CRM and outbound-mail API credentials, plus knowledge-source credentials if required. Separate CRM read-only, CRM account-write and outbound-mail send secrets; drafting runtime can access only read credentials and executor only its required write/send credentials. Administrator-supplied credentials are not evidence of least privilege: validate external scopes before enabling actions and request separately scoped credentials through the administrator where needed. Provisioning creates secret containers and access policies; secret values are supplied separately through a controlled operator process, never through chat, diagram or Terraform values. Rotation, revocation and connector authorization require implementation and verification. Existing CRM and mail identities/services are not recreated.
- Service: Google Cloud Secret Manager
- Provider / placement: gcp / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component outbound-mail: Existing outbound mail

- Responsibility: Client-owned existing outbound-mail service with administrator-supplied API credentials. Reference only, outside provisioning scope; do not recreate, import or modify this service. Vendor and API capabilities are unknown. Receives only explicitly approved messages from the executor. Qualify permitted sender identities, credential scopes, API idempotency and authoritative send-status lookup. A message identifier alone does not prove deduplication. If send acceptance is uncertain and cannot be authoritatively reconciled, retain an uncertain ledger state and prohibit blind resending. API integration and failure tests remain engineering work; no native compatibility or delivery guarantee is claimed.
- Service: Application runtime and API
- Provider / placement: tools / Existing location — unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6f7574626f756e642d6d61696c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Interfaces

### staff-signin: staff → staff-access

- Drawn payload/purpose: HTTPS staff sign-in and workspace access
- Contract task: TASK-CONTRACT-73746166662d7369676e696e
- Integration task: TASK-INTEGRATION-73746166662d7369676e696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### authenticated-workspace: staff-access → copilot-app

- Drawn payload/purpose: Authenticated HTTPS; staff review and supervisor account approval
- Contract task: TASK-CONTRACT-61757468656e746963617465642d776f726b7370616365
- Integration task: TASK-INTEGRATION-61757468656e746963617465642d776f726b7370616365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### read-crm: copilot-app → crm

- Drawn payload/purpose: CRM API: authorized read-only case/account lookup
- Contract task: TASK-CONTRACT-726561642d63726d
- Integration task: TASK-INTEGRATION-726561642d63726d
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### retrieve-knowledge: copilot-app → approved-knowledge

- Drawn payload/purpose: Source API: permitted approved passages and revisions
- Contract task: TASK-CONTRACT-72657472696576652d6b6e6f776c65646765
- Integration task: TASK-INTEGRATION-72657472696576652d6b6e6f776c65646765
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### generate-draft: copilot-app → draft-model

- Drawn payload/purpose: Vertex AI API: context → structured cited draft
- Contract task: TASK-CONTRACT-67656e65726174652d6472616674
- Integration task: TASK-INTEGRATION-67656e65726174652d6472616674
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### record-approval: copilot-app → approval-ledger

- Drawn payload/purpose: Firestore transactions: drafts, supervisor approvals and status
- Contract task: TASK-CONTRACT-7265636f72642d617070726f76616c
- Integration task: TASK-INTEGRATION-7265636f72642d617070726f76616c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### request-execution: copilot-app → action-executor

- Drawn payload/purpose: IAM-authenticated HTTPS: approved operation ID → result
- Contract task: TASK-CONTRACT-726571756573742d657865637574696f6e
- Integration task: TASK-INTEGRATION-726571756573742d657865637574696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### claim-operation: action-executor → approval-ledger

- Drawn payload/purpose: Firestore transactions: check approval authority, claim and record outcome
- Contract task: TASK-CONTRACT-636c61696d2d6f7065726174696f6e
- Integration task: TASK-INTEGRATION-636c61696d2d6f7065726174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### execute-crm: action-executor → crm

- Drawn payload/purpose: CRM API: supervisor-approved account change; deduplication and reconciliation re
- Contract task: TASK-CONTRACT-657865637574652d63726d
- Integration task: TASK-INTEGRATION-657865637574652d63726d
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### drafting-credentials: copilot-app → connector-secrets

- Drawn payload/purpose: Secret Manager API: read-only connector credentials
- Contract task: TASK-CONTRACT-6472616674696e672d63726564656e7469616c73
- Integration task: TASK-INTEGRATION-6472616674696e672d63726564656e7469616c73
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### execution-credentials: action-executor → connector-secrets

- Drawn payload/purpose: Secret Manager API: separate CRM-write and mail-send credentials
- Contract task: TASK-CONTRACT-657865637574696f6e2d63726564656e7469616c73
- Integration task: TASK-INTEGRATION-657865637574696f6e2d63726564656e7469616c73
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### send-approved-mail: action-executor → outbound-mail

- Drawn payload/purpose: Mail API: exact approved message → acceptance/status; retry safety requires qual
- Contract task: TASK-CONTRACT-73656e642d617070726f7665642d6d61696c
- Integration task: TASK-INTEGRATION-73656e642d617070726f7665642d6d61696c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
