# Detailed implementation tasks

Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-73746166662d7369676e696e — Define Support staff → Staff sign-in boundary

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: staff, staff-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection staff-signin: HTTPS staff sign-in and workspace access. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge staff-signin
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-61757468656e746963617465642d776f726b7370616365 — Define Staff sign-in boundary → Copilot workspace and drafting

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: staff-access, copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection authenticated-workspace: Authenticated HTTPS; staff review and supervisor account approval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge authenticated-workspace
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-726561642d63726d — Define Copilot workspace and drafting → Existing CRM

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection read-crm: CRM API: authorized read-only case/account lookup. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge read-crm
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72657472696576652d6b6e6f776c65646765 — Define Copilot workspace and drafting → Approved support knowledge

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, approved-knowledge
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection retrieve-knowledge: Source API: permitted approved passages and revisions. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge retrieve-knowledge
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-67656e65726174652d6472616674 — Define Copilot workspace and drafting → Grounded draft generation

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection generate-draft: Vertex AI API: context → structured cited draft. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge generate-draft
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7265636f72642d617070726f76616c — Define Copilot workspace and drafting → Approval and operation ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection record-approval: Firestore transactions: drafts, supervisor approvals and status. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge record-approval
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-726571756573742d657865637574696f6e — Define Copilot workspace and drafting → Approved action executor

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, action-executor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection request-execution: IAM-authenticated HTTPS: approved operation ID → result. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge request-execution
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-636c61696d2d6f7065726174696f6e — Define Approved action executor → Approval and operation ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection claim-operation: Firestore transactions: check approval authority, claim and record outcome. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge claim-operation
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-657865637574652d63726d — Define Approved action executor → Existing CRM

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection execute-crm: CRM API: supervisor-approved account change; deduplication and reconciliation re. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge execute-crm
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6472616674696e672d63726564656e7469616c73 — Define Copilot workspace and drafting → Scoped connector credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: copilot-app, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection drafting-credentials: Secret Manager API: read-only connector credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge drafting-credentials
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-657865637574696f6e2d63726564656e7469616c73 — Define Approved action executor → Scoped connector credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection execution-credentials: Secret Manager API: separate CRM-write and mail-send credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge execution-credentials
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73656e642d617070726f7665642d6d61696c — Define Approved action executor → Existing outbound mail

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: action-executor, outbound-mail
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection send-approved-mail: Mail API: exact approved message → acceptance/status; retry safety requires qual. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge send-approved-mail
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-7374616666 — Integrate existing Support staff

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d7369676e696e
- Components: staff
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing 50 support agents and five supervisors using browsers, outside provisioning scope. Review cited drafts, edit or reject them, explicitly approve permitted sends and inspect pending or uncertain outcomes. Account-changing actions require supervisor approval. This actor represents both staff roles, not a provisioned identity service.
2. Verify Approval workflow on tools in Existing location — unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff
- Application/configuration and tests for Support staff

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73746166662d616363657373 — Implement Staff sign-in boundary

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73746166662d7369676e696e, TASK-CONTRACT-61757468656e746963617465642d776f726b7370616365
- Components: staff-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Proposed Identity-Aware Proxy access to the copilot. Existing staff identity provider and compatibility remain unresolved. Deny unauthenticated ingress and prevent bypass of the proxy. Application authorization must resolve agent/supervisor roles from an authoritative server-side mapping, never browser-supplied role claims, and check case/account permissions. Sign-in alone does not authorize account changes.
2. Verify Identity-Aware Proxy on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Identity-Aware Proxy; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component staff-access
- Application/configuration and tests for Staff sign-in boundary

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f70696c6f742d617070 — Implement Copilot workspace and drafting

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-61757468656e746963617465642d776f726b7370616365, TASK-CONTRACT-726561642d63726d, TASK-CONTRACT-72657472696576652d6b6e6f776c65646765, TASK-CONTRACT-67656e65726174652d6472616674, TASK-CONTRACT-7265636f72642d617070726f76616c, TASK-CONTRACT-726571756573742d657865637574696f6e, TASK-CONTRACT-6472616674696e672d63726564656e7469616c73
- Components: copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval, ai-grounded-support-drafts, ai-existing-system-boundaries

### Implementation steps

1. Responsibility from the board: Proposed Cloud Run application serving the staff workspace and backend for 50 agents and five supervisors; request volume and concurrency remain unknown. Reads authorized CRM cases and approved knowledge, retrieves permitted passages and asks Vertex AI for a cited draft and proposed actions. Treats source text as untrusted; unsupported answers are flagged for staff rather than invented. Shows sources and exact action details, including mail recipients, subject, body and attachments when applicable. Provides a pending supervisor-review view within this application for account changes. Server-side approval requires current supervisor authority for every account mutation and binds authenticated approver, exact payload, case/account version and operation ID in Firestore. Agent-only approval of account changes is rejected even if the browser is bypassed. Edits invalidate approval. Sends separately require authorized staff approval. Has no CRM write or outbound-mail send credentials. Returns drafts and execution status in the same application. Source adapters, identity integration, deployment artifacts and application behavior require implementation.
2. Verify Google Cloud Run on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Run; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.; REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.; REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component copilot-app
- Application/configuration and tests for Copilot workspace and drafting

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-63726d — Integrate existing Existing CRM

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-726561642d63726d, TASK-CONTRACT-657865637574652d63726d
- Components: crm
- Generated files: No implementation files generated yet
- Requirements: ai-no-duplicate-actions, ai-grounded-support-drafts, ai-existing-system-boundaries

### Implementation steps

1. Responsibility from the board: Client-owned existing CRM accessed through administrator-supplied API credentials; vendor and API capabilities remain unknown. Reference only: do not provision, import, recreate or modify the existing service. Source of case/account data and destination for approved account changes. Drafting access must be read-only and executor write credentials separately scoped. Outbound responses use the separate existing mail service. Qualify conditional updates, stable operation keys and authoritative operation-status lookup. If an action cannot be safely deduplicated or reconciled, block its automatic retry and retain the unresolved requirement.
2. Verify Storage or existing data connector on tools in Existing location — unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.; REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.; REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component crm
- Application/configuration and tests for Existing CRM

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765 — Integrate existing Approved support knowledge

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72657472696576652d6b6e6f776c65646765
- Components: approved-knowledge
- Generated files: No implementation files generated yet
- Requirements: ai-grounded-support-drafts

### Implementation steps

1. Responsibility from the board: Logical reference to the client's approved knowledge in its current system, not a newly provisioned store. Location, approval markers and permissions remain unresolved. Adapter must retrieve authorized approved revisions with source identifiers for citations and exclude withdrawn or unauthorized material. No vector-search platform or native connector is assumed.
2. Verify Storage or existing data connector on tools in Existing location — unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component approved-knowledge
- Application/configuration and tests for Approved support knowledge

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-64726166742d6d6f64656c — Implement Grounded draft generation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-67656e65726174652d6472616674
- Components: draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-support-drafts

### Implementation steps

1. Responsibility from the board: Proposed Vertex AI managed model endpoint. Receives only necessary authorized case context and approved passages; returns a structured draft, source references and action suggestions. Has no executor tools or CRM/mail credentials. Model selection, regional processing, data handling, quotas and grounding quality require verification after residency is established.
2. Verify Vertex AI on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Vertex AI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component draft-model
- Application/configuration and tests for Grounded draft generation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617070726f76616c2d6c6564676572 — Implement Approval and operation ledger

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7265636f72642d617070726f76616c, TASK-CONTRACT-636c61696d2d6f7065726174696f6e
- Components: approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval, ai-no-duplicate-actions

### Implementation steps

1. Responsibility from the board: Proposed Firestore database for draft revisions, exact approved payload hashes, authenticated approvers, authority evidence, source/case revisions, stable per-action operation IDs and execution states/results. Mail approval binds exact recipients and message content; every account mutation requires recorded supervisor approval for its exact target and payload. Pending-review records support supervisor worklists in the existing workspace. Transactions serialize claims and reject concurrent duplicate execution. Separate intents for mail sends and each CRM mutation expose partial completion without replaying successful actions. Record pending, executing, succeeded, rejected and uncertain states, external operation identifiers and reconciliation evidence. Uncertain external outcomes require reconciliation. Persist audit events with restricted mutation rights. Retention and recovery targets remain open. Firestore transactions do not make CRM or mail side effects atomic.
2. Verify Firestore on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Firestore; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.; REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component approval-ledger
- Application/configuration and tests for Approval and operation ledger

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-616374696f6e2d6578656375746f72 — Implement Approved action executor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-726571756573742d657865637574696f6e, TASK-CONTRACT-636c61696d2d6f7065726174696f6e, TASK-CONTRACT-657865637574652d63726d, TASK-CONTRACT-657865637574696f6e2d63726564656e7469616c73, TASK-CONTRACT-73656e642d617070726f7665642d6d61696c
- Components: action-executor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval, ai-no-duplicate-actions, ai-existing-system-boundaries

### Implementation steps

1. Responsibility from the board: Separate private Cloud Run service with its own service account and separately scoped administrator-supplied CRM write and outbound-mail API credentials. Accepts operation IDs only from the authorized copilot backend; loads the approved payload from Firestore, independently checks current approver authority, action allowlist and current case/account state, then claims the operation transactionally. Every account mutation requires supervisor approval; missing, revoked or agent-only authority fails closed before any CRM write. Sends require explicit authorized staff approval of exact recipients and content. Does not trust browser claims or model-suggested action categories. Uses separate CRM-change and mail-send adapters and stable per-action operation keys where supported. Replays stored success results without another external action. On timeout or crash after a possible external commit, reconcile through authoritative CRM/mail status; otherwise mark uncertain and block blind retry, including manual resubmission of the same unresolved action. Track partial completion independently; no cross-system atomicity is assumed. Reject expired or changed approvals and require fresh approval. Connector, reconciliation and concurrency/failure tests are required, including duplicate mail submissions, agent denial, revoked supervisor authority and payload changes. Mail acceptance is distinct from recipient delivery. These application integrations are not implemented by the current generator.
2. Verify Google Cloud Run on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Run; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.; REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.; REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component action-executor
- Application/configuration and tests for Approved action executor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e6e6563746f722d73656372657473 — Implement Scoped connector credentials

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6472616674696e672d63726564656e7469616c73, TASK-CONTRACT-657865637574696f6e2d63726564656e7469616c73
- Components: connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-existing-system-boundaries

### Implementation steps

1. Responsibility from the board: Proposed Secret Manager storage for administrator-supplied CRM and outbound-mail API credentials, plus knowledge-source credentials if required. Separate CRM read-only, CRM account-write and outbound-mail send secrets; drafting runtime can access only read credentials and executor only its required write/send credentials. Administrator-supplied credentials are not evidence of least privilege: validate external scopes before enabling actions and request separately scoped credentials through the administrator where needed. Provisioning creates secret containers and access policies; secret values are supplied separately through a controlled operator process, never through chat, diagram or Terraform values. Rotation, revocation and connector authorization require implementation and verification. Existing CRM and mail identities/services are not recreated.
2. Verify Google Cloud Secret Manager on gcp in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Secret Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component connector-secrets
- Application/configuration and tests for Scoped connector credentials

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6f7574626f756e642d6d61696c — Integrate existing Existing outbound mail

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-73656e642d617070726f7665642d6d61696c
- Components: outbound-mail
- Generated files: No implementation files generated yet
- Requirements: ai-existing-system-boundaries

### Implementation steps

1. Responsibility from the board: Client-owned existing outbound-mail service with administrator-supplied API credentials. Reference only, outside provisioning scope; do not recreate, import or modify this service. Vendor and API capabilities are unknown. Receives only explicitly approved messages from the executor. Qualify permitted sender identities, credential scopes, API idempotency and authoritative send-status lookup. A message identifier alone does not prove deduplication. If send acceptance is uncertain and cannot be authoritatively reconciled, retain an uncertain ledger state and prohibit blind resending. API integration and failure tests remain engineering work; no native compatibility or delivery guarantee is claimed.
2. Verify Application runtime and API on tools in Existing location — unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component outbound-mail
- Application/configuration and tests for Existing outbound mail

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-73746166662d7369676e696e — Wire Support staff to Staff sign-in boundary

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73746166662d7369676e696e, TASK-RESOURCE-7374616666, TASK-RESOURCE-73746166662d616363657373
- Components: staff, staff-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge staff-signin carrying HTTPS staff sign-in and workspace access, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation staff-signin
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-61757468656e746963617465642d776f726b7370616365 — Wire Staff sign-in boundary to Copilot workspace and drafting

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-61757468656e746963617465642d776f726b7370616365, TASK-RESOURCE-73746166662d616363657373, TASK-RESOURCE-636f70696c6f742d617070
- Components: staff-access, copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge authenticated-workspace carrying Authenticated HTTPS; staff review and supervisor account approval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation authenticated-workspace
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-726561642d63726d — Wire Copilot workspace and drafting to Existing CRM

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-726561642d63726d, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-63726d
- Components: copilot-app, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge read-crm carrying CRM API: authorized read-only case/account lookup, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation read-crm
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72657472696576652d6b6e6f776c65646765 — Wire Copilot workspace and drafting to Approved support knowledge

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72657472696576652d6b6e6f776c65646765, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765
- Components: copilot-app, approved-knowledge
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge retrieve-knowledge carrying Source API: permitted approved passages and revisions, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation retrieve-knowledge
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-67656e65726174652d6472616674 — Wire Copilot workspace and drafting to Grounded draft generation

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-67656e65726174652d6472616674, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-64726166742d6d6f64656c
- Components: copilot-app, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge generate-draft carrying Vertex AI API: context → structured cited draft, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation generate-draft
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7265636f72642d617070726f76616c — Wire Copilot workspace and drafting to Approval and operation ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7265636f72642d617070726f76616c, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-617070726f76616c2d6c6564676572
- Components: copilot-app, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge record-approval carrying Firestore transactions: drafts, supervisor approvals and status, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation record-approval
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-726571756573742d657865637574696f6e — Wire Copilot workspace and drafting to Approved action executor

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-726571756573742d657865637574696f6e, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-616374696f6e2d6578656375746f72
- Components: copilot-app, action-executor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge request-execution carrying IAM-authenticated HTTPS: approved operation ID → result, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation request-execution
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-636c61696d2d6f7065726174696f6e — Wire Approved action executor to Approval and operation ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-636c61696d2d6f7065726174696f6e, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge claim-operation carrying Firestore transactions: check approval authority, claim and record outcome, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation claim-operation
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-657865637574652d63726d — Wire Approved action executor to Existing CRM

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-657865637574652d63726d, TASK-RESOURCE-63726d, TASK-RESOURCE-616374696f6e2d6578656375746f72
- Components: action-executor, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge execute-crm carrying CRM API: supervisor-approved account change; deduplication and reconciliation re, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation execute-crm
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6472616674696e672d63726564656e7469616c73 — Wire Copilot workspace and drafting to Scoped connector credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6472616674696e672d63726564656e7469616c73, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Components: copilot-app, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge drafting-credentials carrying Secret Manager API: read-only connector credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation drafting-credentials
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-657865637574696f6e2d63726564656e7469616c73 — Wire Approved action executor to Scoped connector credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-657865637574696f6e2d63726564656e7469616c73, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-636f6e6e6563746f722d73656372657473
- Components: action-executor, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge execution-credentials carrying Secret Manager API: separate CRM-write and mail-send credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation execution-credentials
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73656e642d617070726f7665642d6d61696c — Wire Approved action executor to Existing outbound mail

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73656e642d617070726f7665642d6d61696c, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-6f7574626f756e642d6d61696c
- Components: action-executor, outbound-mail
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge send-approved-mail carrying Mail API: exact approved message → acceptance/status; retry safety requires qual, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation send-approved-mail
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-73746166662d7369676e696e — Verify live Support staff → Staff sign-in boundary

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73746166662d7369676e696e
- Components: staff, staff-access
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge staff-signin with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence staff-signin

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-61757468656e746963617465642d776f726b7370616365 — Verify live Staff sign-in boundary → Copilot workspace and drafting

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-61757468656e746963617465642d776f726b7370616365
- Components: staff-access, copilot-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge authenticated-workspace with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence authenticated-workspace

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-726561642d63726d — Verify live Copilot workspace and drafting → Existing CRM

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-726561642d63726d
- Components: copilot-app, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge read-crm with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence read-crm

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72657472696576652d6b6e6f776c65646765 — Verify live Copilot workspace and drafting → Approved support knowledge

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72657472696576652d6b6e6f776c65646765
- Components: copilot-app, approved-knowledge
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge retrieve-knowledge with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence retrieve-knowledge

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-67656e65726174652d6472616674 — Verify live Copilot workspace and drafting → Grounded draft generation

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-67656e65726174652d6472616674
- Components: copilot-app, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge generate-draft with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence generate-draft

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c — Verify live Copilot workspace and drafting → Approval and operation ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7265636f72642d617070726f76616c
- Components: copilot-app, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge record-approval with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence record-approval

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e — Verify live Copilot workspace and drafting → Approved action executor

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-726571756573742d657865637574696f6e
- Components: copilot-app, action-executor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge request-execution with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence request-execution

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-636c61696d2d6f7065726174696f6e — Verify live Approved action executor → Approval and operation ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-636c61696d2d6f7065726174696f6e
- Components: action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge claim-operation with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence claim-operation

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-657865637574652d63726d — Verify live Approved action executor → Existing CRM

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-657865637574652d63726d
- Components: action-executor, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge execute-crm with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence execute-crm

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6472616674696e672d63726564656e7469616c73 — Verify live Copilot workspace and drafting → Scoped connector credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6472616674696e672d63726564656e7469616c73
- Components: copilot-app, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge drafting-credentials with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence drafting-credentials

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-657865637574696f6e2d63726564656e7469616c73 — Verify live Approved action executor → Scoped connector credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-657865637574696f6e2d63726564656e7469616c73
- Components: action-executor, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge execution-credentials with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence execution-credentials

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73656e642d617070726f7665642d6d61696c — Verify live Approved action executor → Existing outbound mail

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73656e642d617070726f7665642d6d61696c
- Components: action-executor, outbound-mail
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge send-approved-mail with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence send-approved-mail

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c — Verify REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-INTEGRATION-LIVE-61757468656e746963617465642d776f726b7370616365, TASK-INTEGRATION-LIVE-726561642d63726d, TASK-INTEGRATION-LIVE-72657472696576652d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-67656e65726174652d6472616674, TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c, TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e, TASK-INTEGRATION-LIVE-636c61696d2d6f7065726174696f6e, TASK-INTEGRATION-LIVE-657865637574652d63726d, TASK-INTEGRATION-LIVE-6472616674696e672d63726564656e7469616c73, TASK-INTEGRATION-LIVE-657865637574696f6e2d63726564656e7469616c73, TASK-INTEGRATION-LIVE-73656e642d617070726f7665642d6d61696c
- Components: copilot-app, action-executor, approval-ledger
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-explicit-approval

### Implementation steps

1. Basis: User: “Nothing is sent or changed until a staff member explicitly approves it.” The separate executor and approval ledger are proposed enforcement mechanisms.; rationale: Prevents model suggestions, unauthorized callers or edits after approval from causing unintended customer communications or account changes.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73 — Verify REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-63726d, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-INTEGRATION-LIVE-726561642d63726d, TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c, TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e, TASK-INTEGRATION-LIVE-636c61696d2d6f7065726174696f6e, TASK-INTEGRATION-LIVE-657865637574652d63726d, TASK-INTEGRATION-LIVE-657865637574696f6e2d63726564656e7469616c73, TASK-INTEGRATION-LIVE-73656e642d617070726f7665642d6d61696c
- Components: action-executor, approval-ledger, crm
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-no-duplicate-actions

### Implementation steps

1. Basis: User: “Retries must not perform an action twice.” CRM idempotency and reconciliation capabilities have not been established.; rationale: A CRM operation can succeed before a network timeout or worker crash; a local success flag alone cannot prevent the next attempt from repeating that external effect.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d737570706f72742d647261667473 — Verify REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-64726166742d6d6f64656c, TASK-INTEGRATION-LIVE-61757468656e746963617465642d776f726b7370616365, TASK-INTEGRATION-LIVE-726561642d63726d, TASK-INTEGRATION-LIVE-72657472696576652d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-67656e65726174652d6472616674, TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c, TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e, TASK-INTEGRATION-LIVE-657865637574652d63726d, TASK-INTEGRATION-LIVE-6472616674696e672d63726564656e7469616c73
- Components: copilot-app, crm, approved-knowledge, draft-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-support-drafts

### Implementation steps

1. Basis: User: “reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions.”; rationale: Makes draft provenance reviewable and limits the risk of using unapproved or unauthorized material. Citations and abstention are proposed safeguards, not established company policy.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6578697374696e672d73797374656d2d626f756e646172696573 — Verify REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-63726d, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-6f7574626f756e642d6d61696c, TASK-INTEGRATION-LIVE-61757468656e746963617465642d776f726b7370616365, TASK-INTEGRATION-LIVE-726561642d63726d, TASK-INTEGRATION-LIVE-72657472696576652d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-67656e65726174652d6472616674, TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c, TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e, TASK-INTEGRATION-LIVE-636c61696d2d6f7065726174696f6e, TASK-INTEGRATION-LIVE-657865637574652d63726d, TASK-INTEGRATION-LIVE-6472616674696e672d63726564656e7469616c73, TASK-INTEGRATION-LIVE-657865637574696f6e2d63726564656e7469616c73, TASK-INTEGRATION-LIVE-73656e642d617070726f7665642d6d61696c
- Components: crm, outbound-mail, copilot-app, action-executor, connector-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-existing-system-boundaries

### Implementation steps

1. Basis: “CRM and outbound mail already exist, with administrator-supplied API credentials. Do not recreate them.” Existing copilot-app, action-executor and connector-secrets establish separate drafting and execution responsibilities.; rationale: Preserves existing service ownership and prevents the drafting path from gaining send or account-write privileges; administrator-supplied credentials still require scope verification.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-7374616666, TASK-RESOURCE-73746166662d616363657373, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-6f7574626f756e642d6d61696c, TASK-INTEGRATION-73746166662d7369676e696e, TASK-INTEGRATION-61757468656e746963617465642d776f726b7370616365, TASK-INTEGRATION-726561642d63726d, TASK-INTEGRATION-72657472696576652d6b6e6f776c65646765, TASK-INTEGRATION-67656e65726174652d6472616674, TASK-INTEGRATION-7265636f72642d617070726f76616c, TASK-INTEGRATION-726571756573742d657865637574696f6e, TASK-INTEGRATION-636c61696d2d6f7065726174696f6e, TASK-INTEGRATION-657865637574652d63726d, TASK-INTEGRATION-6472616674696e672d63726564656e7469616c73, TASK-INTEGRATION-657865637574696f6e2d63726564656e7469616c73, TASK-INTEGRATION-73656e642d617070726f7665642d6d61696c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-7374616666, TASK-RESOURCE-73746166662d616363657373, TASK-RESOURCE-636f70696c6f742d617070, TASK-RESOURCE-63726d, TASK-RESOURCE-617070726f7665642d6b6e6f776c65646765, TASK-RESOURCE-64726166742d6d6f64656c, TASK-RESOURCE-617070726f76616c2d6c6564676572, TASK-RESOURCE-616374696f6e2d6578656375746f72, TASK-RESOURCE-636f6e6e6563746f722d73656372657473, TASK-RESOURCE-6f7574626f756e642d6d61696c, TASK-INTEGRATION-LIVE-73746166662d7369676e696e, TASK-INTEGRATION-LIVE-61757468656e746963617465642d776f726b7370616365, TASK-INTEGRATION-LIVE-726561642d63726d, TASK-INTEGRATION-LIVE-72657472696576652d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-67656e65726174652d6472616674, TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c, TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e, TASK-INTEGRATION-LIVE-636c61696d2d6f7065726174696f6e, TASK-INTEGRATION-LIVE-657865637574652d63726d, TASK-INTEGRATION-LIVE-6472616674696e672d63726564656e7469616c73, TASK-INTEGRATION-LIVE-657865637574696f6e2d63726564656e7469616c73, TASK-INTEGRATION-LIVE-73656e642d617070726f7665642d6d61696c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d6578706c696369742d617070726f76616c, TASK-ACCEPTANCE-61692d6e6f2d6475706c69636174652d616374696f6e73, TASK-ACCEPTANCE-61692d67726f756e6465642d737570706f72742d647261667473, TASK-ACCEPTANCE-61692d6578697374696e672d73797374656d2d626f756e646172696573, TASK-INTEGRATION-LIVE-73746166662d7369676e696e, TASK-INTEGRATION-LIVE-61757468656e746963617465642d776f726b7370616365, TASK-INTEGRATION-LIVE-726561642d63726d, TASK-INTEGRATION-LIVE-72657472696576652d6b6e6f776c65646765, TASK-INTEGRATION-LIVE-67656e65726174652d6472616674, TASK-INTEGRATION-LIVE-7265636f72642d617070726f76616c, TASK-INTEGRATION-LIVE-726571756573742d657865637574696f6e, TASK-INTEGRATION-LIVE-636c61696d2d6f7065726174696f6e, TASK-INTEGRATION-LIVE-657865637574652d63726d, TASK-INTEGRATION-LIVE-6472616674696e672d63726564656e7469616c73, TASK-INTEGRATION-LIVE-657865637574696f6e2d63726564656e7469616c73, TASK-INTEGRATION-LIVE-73656e642d617070726f7665642d6d61696c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
