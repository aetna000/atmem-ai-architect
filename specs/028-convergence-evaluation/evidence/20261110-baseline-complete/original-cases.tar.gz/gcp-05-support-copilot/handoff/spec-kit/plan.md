# Implementation Spec Kit

Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

7 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

## Confirmed design decisions

- platform.cloud: gcp

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Support staff (staff): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing location — unknown.
- Staff sign-in boundary (staff-access): Implementation needed; gcp, To be selected.
- Copilot workspace and drafting (copilot-app): Implementation needed; gcp, To be selected.
- Existing CRM (crm): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — unknown.
- Approved support knowledge (approved-knowledge): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — unknown.
- Grounded draft generation (draft-model): Implementation needed; gcp, To be selected.
- Approval and operation ledger (approval-ledger): Implementation needed; gcp, To be selected.
- Approved action executor (action-executor): Implementation needed; gcp, To be selected.
- Scoped connector credentials (connector-secrets): Implementation needed; gcp, To be selected.
- Existing outbound mail (outbound-mail): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — unknown.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
