Snapshot e4844003-0df5-445a-9d6b-fd61f28abbfe · design r4 · generated 2026-11-09T17:49:18.543Z

# Human-approved support copilot — solution specification

## Problem and intended outcome

Build a support copilot that reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions. Nothing is sent or changed until a staff member explicitly approves it. Retries must not perform an action twice. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
Fifty support agents and five supervisors. Account-changing actions require supervisor approval.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval. (must, open); target: acceptance target needed; linked blocks: copilot-app, action-executor, approval-ledger

Design explanation: Prevents model suggestions, unauthorized callers or edits after approval from causing unintended customer communications or account changes.

Basis: User: “Nothing is sent or changed until a staff member explicitly approves it.” The separate executor and approval ledger are proposed enforcement mechanisms.
- [REQ-004] Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded. (must, open); target: acceptance target needed; linked blocks: action-executor, approval-ledger, crm

Design explanation: A CRM operation can succeed before a network timeout or worker crash; a local success flag alone cannot prevent the next attempt from repeating that external effect.

Basis: User: “Retries must not perform an action twice.” CRM idempotency and reconciliation capabilities have not been established.
- [REQ-005] The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer. (must, open); target: acceptance target needed; linked blocks: copilot-app, crm, approved-knowledge, draft-model

Design explanation: Makes draft provenance reviewable and limits the risk of using unapproved or unauthorized material. Citations and abstention are proposed safeguards, not established company policy.

Basis: User: “reads an existing CRM case, drafts a response from approved support knowledge, and recommends account actions.”
- [REQ-006] Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration. (must, open); target: acceptance target needed; linked blocks: crm, outbound-mail, copilot-app, action-executor, connector-secrets

Design explanation: Preserves existing service ownership and prevents the drafting path from gaining send or account-write privileges; administrator-supplied credentials still require scope verification.

Basis: “CRM and outbound mail already exist, with administrator-supplied API credentials. Do not recreate them.” Existing copilot-app, action-executor and connector-secrets establish separate drafting and execution responsibilities.

## How the system works

The current design contains 10 components and 12 connections. 4 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Support staff → Staff sign-in boundary

HTTPS staff sign-in and workspace access

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Staff sign-in boundary → Copilot workspace and drafting

Authenticated HTTPS; staff review and supervisor account approval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Copilot workspace and drafting → Existing CRM

CRM API: authorized read-only case/account lookup

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Copilot workspace and drafting → Approved support knowledge

Source API: permitted approved passages and revisions

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Copilot workspace and drafting → Grounded draft generation

Vertex AI API: context → structured cited draft

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Copilot workspace and drafting → Approval and operation ledger

Firestore transactions: drafts, supervisor approvals and status

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Copilot workspace and drafting → Approved action executor

IAM-authenticated HTTPS: approved operation ID → result

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Approved action executor → Approval and operation ledger

Firestore transactions: check approval authority, claim and record outcome

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Approved action executor → Existing CRM

CRM API: supervisor-approved account change; deduplication and reconciliation re

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Copilot workspace and drafting → Scoped connector credentials

Secret Manager API: read-only connector credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Approved action executor → Scoped connector credentials

Secret Manager API: separate CRM-write and mail-send credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Approved action executor → Existing outbound mail

Mail API: exact approved message → acceptance/status; retry safety requires qual

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Support staff

Approval workflow · tools · region: Existing location — unknown · classification: Confidential

Existing 50 support agents and five supervisors using browsers, outside provisioning scope. Review cited drafts, edit or reject them, explicitly approve permitted sends and inspect pending or uncertain outcomes. Account-changing actions require supervisor approval. This actor represents both staff roles, not a provisioned identity service.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Support staff → Staff sign-in boundary: HTTPS staff sign-in and workspace access

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Staff sign-in boundary

Identity-Aware Proxy · gcp · region: To be selected · classification: Confidential

Proposed Identity-Aware Proxy access to the copilot. Existing staff identity provider and compatibility remain unresolved. Deny unauthenticated ingress and prevent bypass of the proxy. Application authorization must resolve agent/supervisor roles from an authoritative server-side mapping, never browser-supplied role claims, and check case/account permissions. Sign-in alone does not authorize account changes.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Support staff → Staff sign-in boundary: HTTPS staff sign-in and workspace access

Outputs: Staff sign-in boundary → Copilot workspace and drafting: Authenticated HTTPS; staff review and supervisor account approval

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Copilot workspace and drafting

Google Cloud Run · gcp · region: To be selected · classification: Confidential

Proposed Cloud Run application serving the staff workspace and backend for 50 agents and five supervisors; request volume and concurrency remain unknown. Reads authorized CRM cases and approved knowledge, retrieves permitted passages and asks Vertex AI for a cited draft and proposed actions. Treats source text as untrusted; unsupported answers are flagged for staff rather than invented. Shows sources and exact action details, including mail recipients, subject, body and attachments when applicable. Provides a pending supervisor-review view within this application for account changes. Server-side approval requires current supervisor authority for every account mutation and binds authenticated approver, exact payload, case/account version and operation ID in Firestore. Agent-only approval of account changes is rejected even if the browser is bypassed. Edits invalidate approval. Sends separately require authorized staff approval. Has no CRM write or outbound-mail send credentials. Returns drafts and execution status in the same application. Source adapters, identity integration, deployment artifacts and application behavior require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff sign-in boundary → Copilot workspace and drafting: Authenticated HTTPS; staff review and supervisor account approval

Outputs: Copilot workspace and drafting → Existing CRM: CRM API: authorized read-only case/account lookup; Copilot workspace and drafting → Approved support knowledge: Source API: permitted approved passages and revisions; Copilot workspace and drafting → Grounded draft generation: Vertex AI API: context → structured cited draft; Copilot workspace and drafting → Approval and operation ledger: Firestore transactions: drafts, supervisor approvals and status; Copilot workspace and drafting → Approved action executor: IAM-authenticated HTTPS: approved operation ID → result; Copilot workspace and drafting → Scoped connector credentials: Secret Manager API: read-only connector credentials

Requirement traceability: REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.; REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.; REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing CRM

Storage or existing data connector · tools · region: Existing location — unknown · classification: Confidential

Client-owned existing CRM accessed through administrator-supplied API credentials; vendor and API capabilities remain unknown. Reference only: do not provision, import, recreate or modify the existing service. Source of case/account data and destination for approved account changes. Drafting access must be read-only and executor write credentials separately scoped. Outbound responses use the separate existing mail service. Qualify conditional updates, stable operation keys and authoritative operation-status lookup. If an action cannot be safely deduplicated or reconciled, block its automatic retry and retain the unresolved requirement.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Copilot workspace and drafting → Existing CRM: CRM API: authorized read-only case/account lookup; Approved action executor → Existing CRM: CRM API: supervisor-approved account change; deduplication and reconciliation re

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.; REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.; REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Approved support knowledge

Storage or existing data connector · tools · region: Existing location — unknown · classification: Confidential

Logical reference to the client's approved knowledge in its current system, not a newly provisioned store. Location, approval markers and permissions remain unresolved. Adapter must retrieve authorized approved revisions with source identifiers for citations and exclude withdrawn or unauthorized material. No vector-search platform or native connector is assumed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Copilot workspace and drafting → Approved support knowledge: Source API: permitted approved passages and revisions

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Grounded draft generation

Vertex AI · gcp · region: To be selected · classification: Confidential

Proposed Vertex AI managed model endpoint. Receives only necessary authorized case context and approved passages; returns a structured draft, source references and action suggestions. Has no executor tools or CRM/mail credentials. Model selection, regional processing, data handling, quotas and grounding quality require verification after residency is established.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Copilot workspace and drafting → Grounded draft generation: Vertex AI API: context → structured cited draft

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: The copilot must draft responses and recommend actions using the authorized CRM case and approved support knowledge. Proposed acceptance: show supporting source revisions to staff, exclude unapproved or unauthorized content, and flag insufficient evidence before approval rather than inventing an answer.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Approval and operation ledger

Firestore · gcp · region: To be selected · classification: Confidential

Proposed Firestore database for draft revisions, exact approved payload hashes, authenticated approvers, authority evidence, source/case revisions, stable per-action operation IDs and execution states/results. Mail approval binds exact recipients and message content; every account mutation requires recorded supervisor approval for its exact target and payload. Pending-review records support supervisor worklists in the existing workspace. Transactions serialize claims and reject concurrent duplicate execution. Separate intents for mail sends and each CRM mutation expose partial completion without replaying successful actions. Record pending, executing, succeeded, rejected and uncertain states, external operation identifiers and reconciliation evidence. Uncertain external outcomes require reconciliation. Persist audit events with restricted mutation rights. Retention and recovery targets remain open. Firestore transactions do not make CRM or mail side effects atomic.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Copilot workspace and drafting → Approval and operation ledger: Firestore transactions: drafts, supervisor approvals and status; Approved action executor → Approval and operation ledger: Firestore transactions: check approval authority, claim and record outcome

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.; REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Approved action executor

Google Cloud Run · gcp · region: To be selected · classification: Confidential

Separate private Cloud Run service with its own service account and separately scoped administrator-supplied CRM write and outbound-mail API credentials. Accepts operation IDs only from the authorized copilot backend; loads the approved payload from Firestore, independently checks current approver authority, action allowlist and current case/account state, then claims the operation transactionally. Every account mutation requires supervisor approval; missing, revoked or agent-only authority fails closed before any CRM write. Sends require explicit authorized staff approval of exact recipients and content. Does not trust browser claims or model-suggested action categories. Uses separate CRM-change and mail-send adapters and stable per-action operation keys where supported. Replays stored success results without another external action. On timeout or crash after a possible external commit, reconcile through authoritative CRM/mail status; otherwise mark uncertain and block blind retry, including manual resubmission of the same unresolved action. Track partial completion independently; no cross-system atomicity is assumed. Reject expired or changed approvals and require fresh approval. Connector, reconciliation and concurrency/failure tests are required, including duplicate mail submissions, agent denial, revoked supervisor authority and payload changes. Mail acceptance is distinct from recipient delivery. These application integrations are not implemented by the current generator.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Copilot workspace and drafting → Approved action executor: IAM-authenticated HTTPS: approved operation ID → result

Outputs: Approved action executor → Approval and operation ledger: Firestore transactions: check approval authority, claim and record outcome; Approved action executor → Existing CRM: CRM API: supervisor-approved account change; deduplication and reconciliation re; Approved action executor → Scoped connector credentials: Secret Manager API: separate CRM-write and mail-send credentials; Approved action executor → Existing outbound mail: Mail API: exact approved message → acceptance/status; retry safety requires qual

Requirement traceability: REQ-003: Every response send and account mutation must require explicit approval by an authorized staff member for the exact payload and target case/account. The server must reject missing approval, unauthorized approval and payload changes after approval; changed or stale actions require renewed approval.; REQ-004: Retries and concurrent submissions of the same approved operation must not repeat a response send or account mutation. Persist a stable operation identity and outcome, qualify CRM-side deduplication or authoritative reconciliation, and block blind retries of uncertain outcomes. Acceptance must cover concurrent requests, timeouts after CRM commit and crashes before local completion is recorded.; REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Scoped connector credentials

Google Cloud Secret Manager · gcp · region: To be selected · classification: Confidential

Proposed Secret Manager storage for administrator-supplied CRM and outbound-mail API credentials, plus knowledge-source credentials if required. Separate CRM read-only, CRM account-write and outbound-mail send secrets; drafting runtime can access only read credentials and executor only its required write/send credentials. Administrator-supplied credentials are not evidence of least privilege: validate external scopes before enabling actions and request separately scoped credentials through the administrator where needed. Provisioning creates secret containers and access policies; secret values are supplied separately through a controlled operator process, never through chat, diagram or Terraform values. Rotation, revocation and connector authorization require implementation and verification. Existing CRM and mail identities/services are not recreated.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Copilot workspace and drafting → Scoped connector credentials: Secret Manager API: read-only connector credentials; Approved action executor → Scoped connector credentials: Secret Manager API: separate CRM-write and mail-send credentials

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing outbound mail

Application runtime and API · tools · region: Existing location — unknown · classification: Confidential

Client-owned existing outbound-mail service with administrator-supplied API credentials. Reference only, outside provisioning scope; do not recreate, import or modify this service. Vendor and API capabilities are unknown. Receives only explicitly approved messages from the executor. Qualify permitted sender identities, credential scopes, API idempotency and authoritative send-status lookup. A message identifier alone does not prove deduplication. If send acceptance is uncertain and cannot be authoritatively reconciled, retain an uncertain ledger state and prohibit blind resending. API integration and failure tests remain engineering work; no native compatibility or delivery guarantee is claimed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Approved action executor → Existing outbound mail: Mail API: exact approved message → acceptance/status; retry safety requires qual

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Integrate the existing CRM and outbound-mail services through their APIs without recreating, importing or modifying their service infrastructure. Store administrator-supplied credentials through a controlled secret-management process. Restrict drafting to read access and approved execution to separately scoped CRM-write and mail-send access; verify credential scopes and deny unauthorized operations before enabling integration.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Architecture

```mermaid
flowchart LR
  n0["Support staff<br/>Tools & data"]
  n1["Staff sign-in boundary<br/>Google Cloud"]
  n2["Copilot workspace and drafting<br/>Google Cloud"]
  n3["Existing CRM<br/>Tools & data"]
  n4["Approved support knowledge<br/>Tools & data"]
  n5["Grounded draft generation<br/>Google Cloud"]
  n6["Approval and operation ledger<br/>Google Cloud"]
  n7["Approved action executor<br/>Google Cloud"]
  n8["Scoped connector credentials<br/>Google Cloud"]
  n9["Existing outbound mail<br/>Tools & data"]
  n0 -->|HTTPS staff sign-in and workspace access| n1
  n1 -->|Authenticated HTTPS; staff review and supervisor account approval| n2
  n2 -->|CRM API: authorized read-only case/account lookup| n3
  n2 -->|Source API: permitted approved passages and revisions| n4
  n2 -->|Vertex AI API: context → structured cited draft| n5
  n2 -->|Firestore transactions: drafts, supervisor approvals and status| n6
  n2 -->|IAM-authenticated HTTPS: approved operation ID → result| n7
  n7 -->|Firestore transactions: check approval authority, claim and record outcome| n6
  n7 -->|CRM API: supervisor-approved account change; deduplication and reconciliation re| n3
  n2 -->|Secret Manager API: read-only connector credentials| n8
  n7 -->|Secret Manager API: separate CRM-write and mail-send credentials| n8
  n7 -->|Mail API: exact approved message → acceptance/status; retry safety requires qual| n9
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff | Support staff | tools | Approval workflow | Existing location — unknown | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| staff-access | Staff sign-in boundary | gcp | Identity-Aware Proxy | To be selected | Proposed | Implementation needed |
| copilot-app | Copilot workspace and drafting | gcp | Google Cloud Run | To be selected | Proposed | Implementation needed |
| crm | Existing CRM | tools | Storage or existing data connector | Existing location — unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| approved-knowledge | Approved support knowledge | tools | Storage or existing data connector | Existing location — unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| draft-model | Grounded draft generation | gcp | Vertex AI | To be selected | Proposed | Implementation needed |
| approval-ledger | Approval and operation ledger | gcp | Firestore | To be selected | Proposed | Implementation needed |
| action-executor | Approved action executor | gcp | Google Cloud Run | To be selected | Proposed | Implementation needed |
| connector-secrets | Scoped connector credentials | gcp | Google Cloud Secret Manager | To be selected | Proposed | Implementation needed |
| outbound-mail | Existing outbound mail | tools | Application runtime and API | Existing location — unknown | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |

### Resources and cost dimensions

- **Support staff** (staff): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Staff sign-in boundary** (staff-access): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff.
- **Copilot workspace and drafting** (copilot-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-access.
- **Existing CRM** (crm): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved support knowledge** (approved-knowledge): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Grounded draft generation** (draft-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Approval and operation ledger** (approval-ledger): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Approved action executor** (action-executor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app.
- **Scoped connector credentials** (connector-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: copilot-app, action-executor.
- **Existing outbound mail** (outbound-mail): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: action-executor.

### Engineering work remaining

- Staff sign-in boundary: Implementation needed.
- Copilot workspace and drafting: Implementation needed.
- Grounded draft generation: Implementation needed.
- Approval and operation ledger: Implementation needed.
- Approved action executor: Implementation needed.
- Scoped connector credentials: Implementation needed.
- Wire staff → staff-access: implement data flow, access policy and acceptance test.
- Wire staff-access → copilot-app: implement data flow, access policy and acceptance test.
- Wire copilot-app → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → approved-knowledge: implement data flow, access policy and acceptance test.
- Wire copilot-app → draft-model: implement data flow, access policy and acceptance test.
- Wire copilot-app → approval-ledger: implement data flow, access policy and acceptance test.
- Wire copilot-app → action-executor: implement data flow, access policy and acceptance test.
- Wire action-executor → approval-ledger: implement data flow, access policy and acceptance test.
- Wire action-executor → crm: implement data flow, access policy and acceptance test.
- Wire copilot-app → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → connector-secrets: implement data flow, access policy and acceptance test.
- Wire action-executor → outbound-mail: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
