Snapshot eaf1caed-5eb8-4ea2-8854-c6006c94b5c4 · design r3 · generated 2026-11-09T17:14:28.826Z

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—
