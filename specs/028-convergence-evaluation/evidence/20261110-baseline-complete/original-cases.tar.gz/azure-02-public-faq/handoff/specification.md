Snapshot eaf1caed-5eb8-4ea2-8854-c6006c94b5c4 · design r3 · generated 2026-11-09T17:14:28.826Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release. (must, open); target: acceptance target needed; linked blocks: faq-web, faq-api, faq-model, public-article-store

Design explanation: Proposed acceptance requirement: plausible unsupported answers would undermine trust even if they contain valid article links.

Basis: “answers questions from our twenty public help articles, cites the articles it used, and says when it does not know.” Existing source-display requirement req-9016ee02.
- [REQ-005] Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions. (must, open); target: acceptance target needed; linked blocks: faq-api, public-article-store, article-editor, faq-model

Design explanation: Proposed access boundary: anonymous question answering must not expose private content or permit visitors to change the article collection.

Basis: “public website assistant” and “It must not answer from private sources.” Editor separation is an architectural proposal supporting article management.
- [REQ-006] Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed. (must, open); target: acceptance target needed; linked blocks: article-editor, public-article-store, faq-api

Design explanation: Proposed lifecycle requirement: stale retrieval or cached passages could keep withdrawn or superseded information in new answers.

Basis: “We need to update and remove articles.” Publication revision checks are a proposed implementation choice.
- [REQ-007] Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection. (must, open); target: acceptance target needed; linked blocks: article-editor, public-article-store, faq-api

Design explanation: Makes the supplied-file workflow testable without introducing private connectors or silently accepting incompatible files; validation limits are proposed from the supplied collection.

Basis: “Twenty public UTF-8 help articles under 30 KB each, supplied as files.”
- [REQ-008] Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing. (should, open); target: acceptance target needed; linked blocks: faq-web, faq-api, public-article-store, faq-model, faq-observability

Design explanation: An Australian resource address alone does not establish model processing geography; explicit verification prevents an unnoticed overseas fallback. The stated preference is not a mandatory residency policy.

Basis: “Australia is preferred; make model/data-location limitations explicit.”

## How the system works

The current design contains 7 components and 6 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Visitor’s browser → Public FAQ website

HTTPS: questions and displayed cited answers

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Public FAQ website → Article search and cited answers

HTTPS JSON: question → cited answer or uncertainty

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Article search and cited answers → Approved public articles

Blob SDK: managed-identity reads and publication revision checks

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Article search and cited answers → Grounded answer model

HTTPS: managed-identity inference with retrieved public passages

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Authorised article editor → Approved public articles

Authenticated publishing tool: upload, update and withdraw articles

Access contract: storage-object-admin.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Article search and cited answers → Failures and usage monitoring

Telemetry SDK: outcomes, latency, errors and usage metadata

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Visitor’s browser

Web browser · tools · region: Not applicable · classification: Public

External browser client for anonymous public questions. Outside provisioning scope; displays answers, clickable article citations and explicit uncertainty. Visitors may connect from outside Australia; browser location is outside the backend placement boundary.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Visitor’s browser → Public FAQ website: HTTPS: questions and displayed cited answers

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public FAQ website

Azure Static Web Apps · azure · region: To be selected · classification: Public

Azure Static Web Apps hosts the proposed standalone question interface, showing cited answers or uncertainty. Embedding into an existing website is not assumed. Browser assets contain no model credentials. Static asset delivery may use global infrastructure; an Australian backend does not establish Australia-only hosting or processing for this service. Keep questions out of URLs and static assets; verify routing, service location and request handling before deployment. Frontend code and backend routing require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Visitor’s browser → Public FAQ website: HTTPS: questions and displayed cited answers

Outputs: Public FAQ website → Article search and cited answers: HTTPS JSON: question → cited answer or uncertainty

Requirement traceability: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Article search and cited answers

Azure Functions · azure · region: Australia East (proposed; unverified) · classification: Public

Azure Functions owns the anonymous public question API, bounded keyword retrieval over the twenty published UTF-8 articles, model orchestration and returned answer. This is keyword retrieval, not vector search; test representative paraphrases and abstain when evidence is insufficient. Request: question text; response: answer, article IDs/titles/URLs and uncertainty indicator. Read the authoritative manifest and matching passages, treat article text as untrusted evidence, and reject unsupported or invalid citations. Recheck publication revision before returning; discard and retry within a bound or abstain if changed. Storage/model failure or exhausted limits returns uncertainty/unavailable. Use managed identity for scoped read-only Blob access and model invocation, bounded requests and server-side abuse controls. No private connectors, browsing, model tools or persistent chat history. Candidate placement: Australia East, subject to service/plan verification; single-region operation without an assumed availability commitment. Owns Functions support storage and runtime dependencies, to be specified in the handoff. Application, publishing tools, permissions and integrations require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public FAQ website → Article search and cited answers: HTTPS JSON: question → cited answer or uncertainty

Outputs: Article search and cited answers → Approved public articles: Blob SDK: managed-identity reads and publication revision checks; Article search and cited answers → Grounded answer model: HTTPS: managed-identity inference with retrieved public passages; Article search and cited answers → Failures and usage monitoring: Telemetry SDK: outcomes, latency, errors and usage metadata

Requirement traceability: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.; REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Approved public articles

Azure Blob Storage · azure · region: Australia East (proposed; unverified) · classification: Public

Azure Blob Storage privately stores the twenty supplied public UTF-8 article files, each under 30 KB, stable article IDs, titles, public citation URLs and a revisioned publication manifest. These file bounds do not establish total billed storage including versions and dependencies. Public classification does not permit anonymous Blob access. Runtime identity is read-only; editor identity can manage objects. Publishing tooling validates UTF-8 and file bounds, requires explicit public-content approval and citation metadata, uploads immutable revisions, then conditionally switches the manifest using ETags. File titles and citation URLs must be supplied; no public article URLs are invented. Withdrawal first removes the article from the manifest, then deletes content; failures remain visible and retryable. No private imports. Australia East is proposed; redundancy, retained versions, backup location and deletion behavior require explicit implementation review. Principal, tooling, access policies and lifecycle tests remain engineering work. No narrow storage adapter is claimed to implement the full publishing/runtime composition.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Article search and cited answers → Approved public articles: Blob SDK: managed-identity reads and publication revision checks; Authorised article editor → Approved public articles: Authenticated publishing tool: upload, update and withdraw articles (access: storage-object-admin)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.; REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Grounded answer model

Azure OpenAI · azure · region: Australia East (candidate; unverified) · classification: Public

Azure OpenAI drafts answers only from supplied public passages and citation identifiers, without browsing or private-source tools. Require abstention for insufficient evidence; backend checks and representative quality tests remain necessary because prompting alone cannot guarantee grounding. Australia East is a candidate resource location, not proof of model availability or Australian inference. Verify the exact model, deployment type, processing geography, stored data, service-side monitoring/retention, quotas and managed-identity permissions before selection. Do not silently select a Global or Data Zone deployment or overseas fallback; resource location alone does not establish inference location. If a suitable Australian processing option cannot be verified, return for a material location/model decision. No model entitlement, regional compatibility or runtime success is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Article search and cited answers → Grounded answer model: HTTPS: managed-identity inference with retrieved public passages

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authorised article editor

Approval workflow · tools · region: Not applicable · classification: Internal

External client-side editor reference, outside provisioning scope. Uses proposed authenticated publishing tooling to upload, update and withdraw the supplied public UTF-8 files and their citation metadata. A destination principal and scoped Azure object permissions must be supplied and reviewed; no existing identity or permission has been verified. Public visitors receive no publishing permissions.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorised article editor → Approved public articles: Authenticated publishing tool: upload, update and withdraw articles

Requirement traceability: REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.; REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### Failures and usage monitoring

Azure Monitor Application Insights · azure · region: Australia East (proposed; unverified) · classification: Internal

Azure Monitor Application Insights records outcomes, latency, dependency failures, abstentions and model usage metadata. Exclude raw questions, article bodies and generated answers because visitors may enter personal information; review automatic telemetry collection as well as application logs. Australia East is proposed for telemetry storage, subject to workspace/service availability and data-flow verification; no Australia-only processing claim is established. Configure retention, alerts and an operational owner during implementation. Supporting workspace dependencies must be specified in the handoff; no operating team or response commitment is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Article search and cited answers → Failures and usage monitoring: Telemetry SDK: outcomes, latency, errors and usage metadata

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Visitor’s browser<br/>Tools & data"]
  n1["Public FAQ website<br/>Azure"]
  n2["Article search and cited answers<br/>Azure"]
  n3["Approved public articles<br/>Azure"]
  n4["Grounded answer model<br/>Azure"]
  n5["Authorised article editor<br/>Tools & data"]
  n6["Failures and usage monitoring<br/>Azure"]
  n0 -->|HTTPS: questions and displayed cited answers| n1
  n1 -->|HTTPS JSON: question → cited answer or uncertainty| n2
  n2 -->|Blob SDK: managed-identity reads and publication revision checks| n3
  n2 -->|HTTPS: managed-identity inference with retrieved public passages| n4
  n5 -->|Authenticated publishing tool: upload, update and withdraw articles| n3
  n2 -->|Telemetry SDK: outcomes, latency, errors and usage metadata| n6
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| public-browser | Visitor’s browser | tools | Web browser | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-web | Public FAQ website | azure | Azure Static Web Apps | To be selected | Proposed | Implementation needed |
| faq-api | Article search and cited answers | azure | Azure Functions | Australia East (proposed; unverified) | Proposed | Implementation needed |
| public-article-store | Approved public articles | azure | Azure Blob Storage | Australia East (proposed; unverified) | Proposed | Implementation needed |
| faq-model | Grounded answer model | azure | Azure OpenAI | Australia East (candidate; unverified) | Proposed | Implementation needed |
| article-editor | Authorised article editor | tools | Approval workflow | Not applicable | Existing | Existing — reference/import plan needed |
| faq-observability | Failures and usage monitoring | azure | Azure Monitor Application Insights | Australia East (proposed; unverified) | Proposed | Implementation needed |

### Resources and cost dimensions

- **Visitor’s browser** (public-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public FAQ website** (faq-web): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: public-browser.
- **Article search and cited answers** (faq-api): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-web.
- **Approved public articles** (public-article-store): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-api, article-editor.
- **Grounded answer model** (faq-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-api.
- **Authorised article editor** (article-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Failures and usage monitoring** (faq-observability): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-api.

### Engineering work remaining

- Public FAQ website: Implementation needed.
- Article search and cited answers: Implementation needed.
- Approved public articles: Implementation needed.
- Grounded answer model: Implementation needed.
- Authorised article editor: Existing — reference/import plan needed.
- Failures and usage monitoring: Implementation needed.
- Wire public-browser → faq-web: implement data flow, access policy and acceptance test.
- Wire faq-web → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-api → public-article-store: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-model: implement data flow, access policy and acceptance test.
- Wire article-editor → public-article-store: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-observability: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
