Snapshot eaf1caed-5eb8-4ea2-8854-c6006c94b5c4 · design r3 · generated 2026-11-09T17:14:28.826Z

# Cited public FAQ — deployment document

Generated 2026-11-09 17:14 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Azure
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** Azure Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. Australia is preferred; make model/data-location limitations explicit.
- **Budget and timeline:** —

## 3. Architecture

**Public experience**

- Visitor’s browser (Tools & data, existing, sketch) — External browser client for anonymous public questions. Outside provisioning scope; displays answers, clickable article citations and explicit uncertainty. Visitors may connect from outside Australia; browser location is outside the backend placement boundary.
- Public FAQ website (Azure, sketch) — Azure Static Web Apps hosts the proposed standalone question interface, showing cited answers or uncertainty. Embedding into an existing website is not assumed. Browser assets contain no model credentials. Static asset delivery may use global infrastructure; an Australian backend does not establish Australia-only hosting or processing for this service. Keep questions out of URLs and static assets; verify routing, service location and request handling before deployment. Frontend code and backend routing require implementation.

**Answer service**

- Article search and cited answers (Azure, sketch) — Azure Functions owns the anonymous public question API, bounded keyword retrieval over the twenty published UTF-8 articles, model orchestration and returned answer. This is keyword retrieval, not vector search; test representative paraphrases and abstain when evidence is insufficient. Request: question text; response: answer, article IDs/titles/URLs and uncertainty indicator. Read the authoritative manifest and matching passages, treat article text as untrusted evidence, and reject unsupported or invalid citations. Recheck publication revision before returning; discard and retry within a bound or abstain if changed. Storage/model failure or exhausted limits returns uncertainty/unavailable. Use managed identity for scoped read-only Blob access and model invocation, bounded requests and server-side abuse controls. No private connectors, browsing, model tools or persistent chat history. Candidate placement: Australia East, subject to service/plan verification; single-region operation without an assumed availability commitment. Owns Functions support storage and runtime dependencies, to be specified in the handoff. Application, publishing tools, permissions and integrations require implementation.
- Grounded answer model (Azure, sketch) — Azure OpenAI drafts answers only from supplied public passages and citation identifiers, without browsing or private-source tools. Require abstention for insufficient evidence; backend checks and representative quality tests remain necessary because prompting alone cannot guarantee grounding. Australia East is a candidate resource location, not proof of model availability or Australian inference. Verify the exact model, deployment type, processing geography, stored data, service-side monitoring/retention, quotas and managed-identity permissions before selection. Do not silently select a Global or Data Zone deployment or overseas fallback; resource location alone does not establish inference location. If a suitable Australian processing option cannot be verified, return for a material location/model decision. No model entitlement, regional compatibility or runtime success is assumed.

**Article publishing**

- Approved public articles (Azure, sketch) — Azure Blob Storage privately stores the twenty supplied public UTF-8 article files, each under 30 KB, stable article IDs, titles, public citation URLs and a revisioned publication manifest. These file bounds do not establish total billed storage including versions and dependencies. Public classification does not permit anonymous Blob access. Runtime identity is read-only; editor identity can manage objects. Publishing tooling validates UTF-8 and file bounds, requires explicit public-content approval and citation metadata, uploads immutable revisions, then conditionally switches the manifest using ETags. File titles and citation URLs must be supplied; no public article URLs are invented. Withdrawal first removes the article from the manifest, then deletes content; failures remain visible and retryable. No private imports. Australia East is proposed; redundancy, retained versions, backup location and deletion behavior require explicit implementation review. Principal, tooling, access policies and lifecycle tests remain engineering work. No narrow storage adapter is claimed to implement the full publishing/runtime composition.
- Authorised article editor (Tools & data, existing, sketch) — External client-side editor reference, outside provisioning scope. Uses proposed authenticated publishing tooling to upload, update and withdraw the supplied public UTF-8 files and their citation metadata. A destination principal and scoped Azure object permissions must be supplied and reviewed; no existing identity or permission has been verified. Public visitors receive no publishing permissions.

**Operations**

- Failures and usage monitoring (Azure, sketch) — Azure Monitor Application Insights records outcomes, latency, dependency failures, abstentions and model usage metadata. Exclude raw questions, article bodies and generated answers because visitors may enter personal information; review automatic telemetry collection as well as application logs. Australia East is proposed for telemetry storage, subject to workspace/service availability and data-flow verification; no Australia-only processing claim is established. Configure retention, alerts and an operational owner during implementation. Supporting workspace dependencies must be specified in the handoff; no operating team or response commitment is assumed.

```mermaid
flowchart LR
  n0["Visitor’s browser<br/>Tools & data"]
  n1["Public FAQ website<br/>Azure"]
  n2["Article search and cited answers<br/>Azure"]
  n3["Approved public articles<br/>Azure"]
  n4["Grounded answer model<br/>Azure"]
  n5["Authorised article editor<br/>Tools & data"]
  n6["Failures and usage monitoring<br/>Azure"]
  n0 -->|HTTPS: questions and displayed cited answers| n1
  n1 -->|HTTPS JSON: question → cited answer or uncertainty| n2
  n2 -->|Blob SDK: managed-identity reads and publication revision checks| n3
  n2 -->|HTTPS: managed-identity inference with retrieved public passages| n4
  n5 -->|Authenticated publishing tool: upload, update and withdraw articles| n3
  n2 -->|Telemetry SDK: outcomes, latency, errors and usage metadata| n6
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| public-browser | Visitor’s browser | tools | Web browser | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-web | Public FAQ website | azure | Azure Static Web Apps | To be selected | Proposed | Implementation needed |
| faq-api | Article search and cited answers | azure | Azure Functions | Australia East (proposed; unverified) | Proposed | Implementation needed |
| public-article-store | Approved public articles | azure | Azure Blob Storage | Australia East (proposed; unverified) | Proposed | Implementation needed |
| faq-model | Grounded answer model | azure | Azure OpenAI | Australia East (candidate; unverified) | Proposed | Implementation needed |
| article-editor | Authorised article editor | tools | Approval workflow | Not applicable | Existing | Existing — reference/import plan needed |
| faq-observability | Failures and usage monitoring | azure | Azure Monitor Application Insights | Australia East (proposed; unverified) | Proposed | Implementation needed |

### Resources and cost dimensions

- **Visitor’s browser** (public-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public FAQ website** (faq-web): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: public-browser.
- **Article search and cited answers** (faq-api): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-web.
- **Approved public articles** (public-article-store): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-api, article-editor.
- **Grounded answer model** (faq-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-api.
- **Authorised article editor** (article-editor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Failures and usage monitoring** (faq-observability): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-api.

### Engineering work remaining

- Public FAQ website: Implementation needed.
- Article search and cited answers: Implementation needed.
- Approved public articles: Implementation needed.
- Grounded answer model: Implementation needed.
- Authorised article editor: Existing — reference/import plan needed.
- Failures and usage monitoring: Implementation needed.
- Wire public-browser → faq-web: implement data flow, access policy and acceptance test.
- Wire faq-web → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-api → public-article-store: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-model: implement data flow, access policy and acceptance test.
- Wire article-editor → public-article-store: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-observability: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Visitor’s browser | Public FAQ website | HTTPS: questions and displayed cited answers | Public |
| Public FAQ website | Article search and cited answers | HTTPS JSON: question → cited answer or uncertainty | Public |
| Article search and cited answers | Approved public articles | Blob SDK: managed-identity reads and publication revision checks | Public |
| Article search and cited answers | Grounded answer model | HTTPS: managed-identity inference with retrieved public passages | Public |
| Authorised article editor | Approved public articles | Authenticated publishing tool: upload, update and withdraw articles | Internal |
| Article search and cited answers | Failures and usage monitoring | Telemetry SDK: outcomes, latency, errors and usage metadata | Internal |

## 5. Security controls

- **Authorised article editor** — External client-side editor reference, outside provisioning scope. Uses proposed authenticated publishing tooling to upload, update and withdraw the supplied public UTF-8 files and their citation metadata. A destination principal and scoped Azure object permissions must be supplied and reviewed; no existing identity or permission has been verified. Public visitors receive no publishing permissions.
- Requirement: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions. (must)
- Requirement: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions. | security | not measurable yet | Open |
| Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release. (must, open)
- Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed. (must, open)
- Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.”, “Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 7 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Approved public articles | Storage | needs data_gb | price needed | — | — |
| Grounded answer model | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Visitor’s browser, Public FAQ website, Article search and cited answers, Authorised article editor, Failures and usage monitoring.

**Estimate gaps:**

- Approved public articles / Storage: input needed (data_gb).
- Grounded answer model / Endpoint hours: price needed.
- Visitor’s browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public FAQ website: no cost lines; add charges or an explicit zero-cost line with a reason.
- Article search and cited answers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorised article editor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Failures and usage monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public experience: Public FAQ website.
4. Provision article publishing: Approved public articles.
5. Provision answer service: Article search and cited answers, Grounded answer model.
6. Provision operations: Failures and usage monitoring.
7. Connect existing systems: Visitor’s browser, Authorised article editor; test failure behaviour.
8. Run the acceptance checks (success measures and requirements) in staging; record results.
9. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Azure.

**Options considered**

—

**Decision**

azure

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Approved public articles: needs data_gb _(estimate)_
- Grounded answer model: needs a unit price with a source _(estimate)_
