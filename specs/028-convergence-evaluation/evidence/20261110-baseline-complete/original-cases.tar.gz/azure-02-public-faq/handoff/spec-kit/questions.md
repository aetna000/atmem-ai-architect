# Questions and assumptions to resolve

Snapshot eaf1caed-5eb8-4ea2-8854-c6006c94b5c4 · design r3 · generated 2026-11-09T17:14:28.826Z

- [ai-grounded-answers] Confirm REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.
- [ai-public-source-boundary] Confirm REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.
- [ai-article-lifecycle] Confirm REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.
- [ai-public-file-publishing] Confirm REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.
- [ai-location-transparency] Confirm REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
- [acceptance-req-9016ee02] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-grounded-answers] Agree a measurable acceptance check for REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.
- [acceptance-ai-public-source-boundary] Agree a measurable acceptance check for REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.
- [acceptance-ai-article-lifecycle] Agree a measurable acceptance check for REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.
- [acceptance-ai-public-file-publishing] Agree a measurable acceptance check for REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.
- [acceptance-ai-location-transparency] Agree a measurable acceptance check for REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d61727469636c652d6c6966656379636c65] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d616e7377657273] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d66696c652d7075626c697368696e67] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d736f757263652d626f756e64617279] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
