# Component and interface contracts

Snapshot eaf1caed-5eb8-4ea2-8854-c6006c94b5c4 · design r3 · generated 2026-11-09T17:14:28.826Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component public-browser: Visitor’s browser

- Responsibility: External browser client for anonymous public questions. Outside provisioning scope; displays answers, clickable article citations and explicit uncertainty. Visitors may connect from outside Australia; browser location is outside the backend placement boundary.
- Service: Web browser
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7075626c69632d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-web: Public FAQ website

- Responsibility: Azure Static Web Apps hosts the proposed standalone question interface, showing cited answers or uncertainty. Embedding into an existing website is not assumed. Browser assets contain no model credentials. Static asset delivery may use global infrastructure; an Australian backend does not establish Australia-only hosting or processing for this service. Keep questions out of URLs and static assets; verify routing, service location and request handling before deployment. Frontend code and backend routing require implementation.
- Service: Azure Static Web Apps
- Provider / placement: azure / To be selected
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-api: Article search and cited answers

- Responsibility: Azure Functions owns the anonymous public question API, bounded keyword retrieval over the twenty published UTF-8 articles, model orchestration and returned answer. This is keyword retrieval, not vector search; test representative paraphrases and abstain when evidence is insufficient. Request: question text; response: answer, article IDs/titles/URLs and uncertainty indicator. Read the authoritative manifest and matching passages, treat article text as untrusted evidence, and reject unsupported or invalid citations. Recheck publication revision before returning; discard and retry within a bound or abstain if changed. Storage/model failure or exhausted limits returns uncertainty/unavailable. Use managed identity for scoped read-only Blob access and model invocation, bounded requests and server-side abuse controls. No private connectors, browsing, model tools or persistent chat history. Candidate placement: Australia East, subject to service/plan verification; single-region operation without an assumed availability commitment. Owns Functions support storage and runtime dependencies, to be specified in the handoff. Application, publishing tools, permissions and integrations require implementation.
- Service: Azure Functions
- Provider / placement: azure / Australia East (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component public-article-store: Approved public articles

- Responsibility: Azure Blob Storage privately stores the twenty supplied public UTF-8 article files, each under 30 KB, stable article IDs, titles, public citation URLs and a revisioned publication manifest. These file bounds do not establish total billed storage including versions and dependencies. Public classification does not permit anonymous Blob access. Runtime identity is read-only; editor identity can manage objects. Publishing tooling validates UTF-8 and file bounds, requires explicit public-content approval and citation metadata, uploads immutable revisions, then conditionally switches the manifest using ETags. File titles and citation URLs must be supplied; no public article URLs are invented. Withdrawal first removes the article from the manifest, then deletes content; failures remain visible and retryable. No private imports. Australia East is proposed; redundancy, retained versions, backup location and deletion behavior require explicit implementation review. Principal, tooling, access policies and lifecycle tests remain engineering work. No narrow storage adapter is claimed to implement the full publishing/runtime composition.
- Service: Azure Blob Storage
- Provider / placement: azure / Australia East (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-model: Grounded answer model

- Responsibility: Azure OpenAI drafts answers only from supplied public passages and citation identifiers, without browsing or private-source tools. Require abstention for insufficient evidence; backend checks and representative quality tests remain necessary because prompting alone cannot guarantee grounding. Australia East is a candidate resource location, not proof of model availability or Australian inference. Verify the exact model, deployment type, processing geography, stored data, service-side monitoring/retention, quotas and managed-identity permissions before selection. Do not silently select a Global or Data Zone deployment or overseas fallback; resource location alone does not establish inference location. If a suitable Australian processing option cannot be verified, return for a material location/model decision. No model entitlement, regional compatibility or runtime success is assumed.
- Service: Azure OpenAI
- Provider / placement: azure / Australia East (candidate; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component article-editor: Authorised article editor

- Responsibility: External client-side editor reference, outside provisioning scope. Uses proposed authenticated publishing tooling to upload, update and withdraw the supplied public UTF-8 files and their citation metadata. A destination principal and scoped Azure object permissions must be supplied and reviewed; no existing identity or permission has been verified. Public visitors receive no publishing permissions.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-61727469636c652d656469746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component faq-observability: Failures and usage monitoring

- Responsibility: Azure Monitor Application Insights records outcomes, latency, dependency failures, abstentions and model usage metadata. Exclude raw questions, article bodies and generated answers because visitors may enter personal information; review automatic telemetry collection as well as application logs. Australia East is proposed for telemetry storage, subject to workspace/service availability and data-flow verification; no Australia-only processing claim is established. Configure retention, alerts and an operational owner during implementation. Supporting workspace dependencies must be specified in the handoff; no operating team or response commitment is assumed.
- Service: Azure Monitor Application Insights
- Provider / placement: azure / Australia East (proposed; unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d6f62736572766162696c697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### browser-web: public-browser → faq-web

- Drawn payload/purpose: HTTPS: questions and displayed cited answers
- Contract task: TASK-CONTRACT-62726f777365722d776562
- Integration task: TASK-INTEGRATION-62726f777365722d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-api: faq-web → faq-api

- Drawn payload/purpose: HTTPS JSON: question → cited answer or uncertainty
- Contract task: TASK-CONTRACT-7765622d617069
- Integration task: TASK-INTEGRATION-7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-articles: faq-api → public-article-store

- Drawn payload/purpose: Blob SDK: managed-identity reads and publication revision checks
- Contract task: TASK-CONTRACT-6170692d61727469636c6573
- Integration task: TASK-INTEGRATION-6170692d61727469636c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-model: faq-api → faq-model

- Drawn payload/purpose: HTTPS: managed-identity inference with retrieved public passages
- Contract task: TASK-CONTRACT-6170692d6d6f64656c
- Integration task: TASK-INTEGRATION-6170692d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### editor-articles: article-editor → public-article-store

- Drawn payload/purpose: Authenticated publishing tool: upload, update and withdraw articles
- Contract task: TASK-CONTRACT-656469746f722d61727469636c6573
- Integration task: TASK-INTEGRATION-656469746f722d61727469636c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-telemetry: faq-api → faq-observability

- Drawn payload/purpose: Telemetry SDK: outcomes, latency, errors and usage metadata
- Contract task: TASK-CONTRACT-6170692d74656c656d65747279
- Integration task: TASK-INTEGRATION-6170692d74656c656d65747279
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
