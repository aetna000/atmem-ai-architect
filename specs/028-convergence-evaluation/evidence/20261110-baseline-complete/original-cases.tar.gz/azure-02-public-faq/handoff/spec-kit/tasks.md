# Detailed implementation tasks

Snapshot eaf1caed-5eb8-4ea2-8854-c6006c94b5c4 · design r3 · generated 2026-11-09T17:14:28.826Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-62726f777365722d776562 — Define Visitor’s browser → Public FAQ website

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: public-browser, faq-web
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection browser-web: HTTPS: questions and displayed cited answers. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge browser-web
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d617069 — Define Public FAQ website → Article search and cited answers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-web, faq-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-api: HTTPS JSON: question → cited answer or uncertainty. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170692d61727469636c6573 — Define Article search and cited answers → Approved public articles

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-api, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection api-articles: Blob SDK: managed-identity reads and publication revision checks. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge api-articles
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170692d6d6f64656c — Define Article search and cited answers → Grounded answer model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-api, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection api-model: HTTPS: managed-identity inference with retrieved public passages. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge api-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-656469746f722d61727469636c6573 — Define Authorised article editor → Approved public articles

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: article-editor, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection editor-articles: Authenticated publishing tool: upload, update and withdraw articles. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge editor-articles
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170692d74656c656d65747279 — Define Article search and cited answers → Failures and usage monitoring

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-api, faq-observability
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection api-telemetry: Telemetry SDK: outcomes, latency, errors and usage metadata. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge api-telemetry
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-7075626c69632d62726f77736572 — Integrate existing Visitor’s browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d776562
- Components: public-browser
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: External browser client for anonymous public questions. Outside provisioning scope; displays answers, clickable article citations and explicit uncertainty. Visitors may connect from outside Australia; browser location is outside the backend placement boundary.
2. Verify Web browser on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component public-browser
- Application/configuration and tests for Visitor’s browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d776562 — Implement Public FAQ website

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-62726f777365722d776562, TASK-CONTRACT-7765622d617069
- Components: faq-web
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Azure Static Web Apps hosts the proposed standalone question interface, showing cited answers or uncertainty. Embedding into an existing website is not assumed. Browser assets contain no model credentials. Static asset delivery may use global infrastructure; an Australian backend does not establish Australia-only hosting or processing for this service. Keep questions out of URLs and static assets; verify routing, service location and request handling before deployment. Frontend code and backend routing require implementation.
2. Verify Azure Static Web Apps on azure in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Static Web Apps; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-web
- Application/configuration and tests for Public FAQ website

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617069 — Implement Article search and cited answers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7765622d617069, TASK-CONTRACT-6170692d61727469636c6573, TASK-CONTRACT-6170692d6d6f64656c, TASK-CONTRACT-6170692d74656c656d65747279
- Components: faq-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-article-lifecycle, ai-public-file-publishing, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Azure Functions owns the anonymous public question API, bounded keyword retrieval over the twenty published UTF-8 articles, model orchestration and returned answer. This is keyword retrieval, not vector search; test representative paraphrases and abstain when evidence is insufficient. Request: question text; response: answer, article IDs/titles/URLs and uncertainty indicator. Read the authoritative manifest and matching passages, treat article text as untrusted evidence, and reject unsupported or invalid citations. Recheck publication revision before returning; discard and retry within a bound or abstain if changed. Storage/model failure or exhausted limits returns uncertainty/unavailable. Use managed identity for scoped read-only Blob access and model invocation, bounded requests and server-side abuse controls. No private connectors, browsing, model tools or persistent chat history. Candidate placement: Australia East, subject to service/plan verification; single-region operation without an assumed availability commitment. Owns Functions support storage and runtime dependencies, to be specified in the handoff. Application, publishing tools, permissions and integrations require implementation.
2. Verify Azure Functions on azure in Australia East (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Functions; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.; REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-api
- Application/configuration and tests for Article search and cited answers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265 — Implement Approved public articles

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170692d61727469636c6573, TASK-CONTRACT-656469746f722d61727469636c6573
- Components: public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-article-lifecycle, ai-public-file-publishing, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Azure Blob Storage privately stores the twenty supplied public UTF-8 article files, each under 30 KB, stable article IDs, titles, public citation URLs and a revisioned publication manifest. These file bounds do not establish total billed storage including versions and dependencies. Public classification does not permit anonymous Blob access. Runtime identity is read-only; editor identity can manage objects. Publishing tooling validates UTF-8 and file bounds, requires explicit public-content approval and citation metadata, uploads immutable revisions, then conditionally switches the manifest using ETags. File titles and citation URLs must be supplied; no public article URLs are invented. Withdrawal first removes the article from the manifest, then deletes content; failures remain visible and retryable. No private imports. Australia East is proposed; redundancy, retained versions, backup location and deletion behavior require explicit implementation review. Principal, tooling, access policies and lifecycle tests remain engineering work. No narrow storage adapter is claimed to implement the full publishing/runtime composition.
2. Verify Azure Blob Storage on azure in Australia East (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Blob Storage; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.; REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component public-article-store
- Application/configuration and tests for Approved public articles

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d6d6f64656c — Implement Grounded answer model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170692d6d6f64656c
- Components: faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Azure OpenAI drafts answers only from supplied public passages and citation identifiers, without browsing or private-source tools. Require abstention for insufficient evidence; backend checks and representative quality tests remain necessary because prompting alone cannot guarantee grounding. Australia East is a candidate resource location, not proof of model availability or Australian inference. Verify the exact model, deployment type, processing geography, stored data, service-side monitoring/retention, quotas and managed-identity permissions before selection. Do not silently select a Global or Data Zone deployment or overseas fallback; resource location alone does not establish inference location. If a suitable Australian processing option cannot be verified, return for a material location/model decision. No model entitlement, regional compatibility or runtime success is assumed.
2. Verify Azure OpenAI on azure in Australia East (candidate; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure OpenAI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.; REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-model
- Application/configuration and tests for Grounded answer model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-61727469636c652d656469746f72 — Integrate existing Authorised article editor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-656469746f722d61727469636c6573
- Components: article-editor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-source-boundary, ai-article-lifecycle, ai-public-file-publishing

### Implementation steps

1. Responsibility from the board: External client-side editor reference, outside provisioning scope. Uses proposed authenticated publishing tooling to upload, update and withdraw the supplied public UTF-8 files and their citation metadata. A destination principal and scoped Azure object permissions must be supplied and reviewed; no existing identity or permission has been verified. Public visitors receive no publishing permissions.
2. Verify Approval workflow on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.; REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.; REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component article-editor
- Application/configuration and tests for Authorised article editor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d6f62736572766162696c697479 — Implement Failures and usage monitoring

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170692d74656c656d65747279
- Components: faq-observability
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-location-transparency

### Implementation steps

1. Responsibility from the board: Azure Monitor Application Insights records outcomes, latency, dependency failures, abstentions and model usage metadata. Exclude raw questions, article bodies and generated answers because visitors may enter personal information; review automatic telemetry collection as well as application logs. Australia East is proposed for telemetry storage, subject to workspace/service availability and data-flow verification; no Australia-only processing claim is established. Configure retention, alerts and an operational owner during implementation. Supporting workspace dependencies must be specified in the handoff; no operating team or response commitment is assumed.
2. Verify Azure Monitor Application Insights on azure in Australia East (proposed; unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Azure Monitor Application Insights; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact azure service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-observability
- Application/configuration and tests for Failures and usage monitoring

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-62726f777365722d776562 — Wire Visitor’s browser to Public FAQ website

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-62726f777365722d776562, TASK-RESOURCE-7075626c69632d62726f77736572, TASK-RESOURCE-6661712d776562
- Components: public-browser, faq-web
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge browser-web carrying HTTPS: questions and displayed cited answers, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation browser-web
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d617069 — Wire Public FAQ website to Article search and cited answers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d617069, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069
- Components: faq-web, faq-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-api carrying HTTPS JSON: question → cited answer or uncertainty, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170692d61727469636c6573 — Wire Article search and cited answers to Approved public articles

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170692d61727469636c6573, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265
- Components: faq-api, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge api-articles carrying Blob SDK: managed-identity reads and publication revision checks, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation api-articles
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170692d6d6f64656c — Wire Article search and cited answers to Grounded answer model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170692d6d6f64656c, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d6d6f64656c
- Components: faq-api, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge api-model carrying HTTPS: managed-identity inference with retrieved public passages, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation api-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-656469746f722d61727469636c6573 — Wire Authorised article editor to Approved public articles

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-656469746f722d61727469636c6573, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-61727469636c652d656469746f72
- Components: article-editor, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge editor-articles carrying Authenticated publishing tool: upload, update and withdraw articles, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation editor-articles
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170692d74656c656d65747279 — Wire Article search and cited answers to Failures and usage monitoring

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170692d74656c656d65747279, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d6f62736572766162696c697479
- Components: faq-api, faq-observability
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge api-telemetry carrying Telemetry SDK: outcomes, latency, errors and usage metadata, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation api-telemetry
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-62726f777365722d776562 — Verify live Visitor’s browser → Public FAQ website

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-62726f777365722d776562
- Components: public-browser, faq-web
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge browser-web with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence browser-web

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d617069 — Verify live Public FAQ website → Article search and cited answers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d617069
- Components: faq-web, faq-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170692d61727469636c6573 — Verify live Article search and cited answers → Approved public articles

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170692d61727469636c6573
- Components: faq-api, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge api-articles with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence api-articles

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170692d6d6f64656c — Verify live Article search and cited answers → Grounded answer model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170692d6d6f64656c
- Components: faq-api, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge api-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence api-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573 — Verify live Authorised article editor → Approved public articles

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-656469746f722d61727469636c6573
- Components: article-editor, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge editor-articles with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence editor-articles

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170692d74656c656d65747279 — Verify live Article search and cited answers → Failures and usage monitoring

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170692d74656c656d65747279
- Components: faq-api, faq-observability
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge api-telemetry with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence api-telemetry

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3930313665653032 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-9016ee02

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273 — Verify REQ-004: Return substantive answers only when supported by currently published public article passages, with citations resolving to the supporting articles; otherwise explicitly say the assistant does not know. Evaluate supported, unsupported and misleading questions before release.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-62726f777365722d776562, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: faq-web, faq-api, faq-model, public-article-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers

### Implementation steps

1. Basis: “answers questions from our twenty public help articles, cites the articles it used, and says when it does not know.” Existing source-display requirement req-9016ee02.; rationale: Proposed acceptance requirement: plausible unsupported answers would undermine trust even if they contain valid article links.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279 — Verify REQ-005: Restrict retrieval and model context to an explicitly published public article collection, with no private-source connectors. Permit public question access while restricting publishing to authenticated authorised editors and runtime storage access to read-only permissions.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-RESOURCE-61727469636c652d656469746f72, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: faq-api, public-article-store, article-editor, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-source-boundary

### Implementation steps

1. Basis: “public website assistant” and “It must not answer from private sources.” Editor separation is an architectural proposal supporting article management.; rationale: Proposed access boundary: anonymous question answering must not expose private content or permit visitors to change the article collection.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65 — Verify REQ-006: Provide authenticated article publication, update and withdrawal with stable citation metadata and conditional publication changes. After a publication change succeeds, new answer requests must use the current collection; in-flight requests must recheck its revision before returning and retry or abstain if it changed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-61727469636c652d656469746f72, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: article-editor, public-article-store, faq-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-article-lifecycle

### Implementation steps

1. Basis: “We need to update and remove articles.” Publication revision checks are a proposed implementation choice.; rationale: Proposed lifecycle requirement: stale retrieval or cached passages could keep withdrawn or superseded information in new answers.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d66696c652d7075626c697368696e67 — Verify REQ-007: Support publication of the twenty supplied public UTF-8 article files, each under 30 KB, with stable IDs and public citation metadata. Proposed publishing validation must reject invalid encoding, out-of-bound files and incomplete citation metadata without changing the active collection.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-61727469636c652d656469746f72, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: article-editor, public-article-store, faq-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-file-publishing

### Implementation steps

1. Basis: “Twenty public UTF-8 help articles under 30 KB each, supplied as files.”; rationale: Makes the supplied-file workflow testable without introducing private connectors or silently accepting incompatible files; validation limits are proposed from the supplied collection.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379 — Verify REQ-008: Prefer Australian storage and processing. Before deployment, document actual locations and limitations for article storage, inference, website delivery and telemetry, including model deployment type and service-side retention. Disclose any unavailable or unverified Australian option and obtain a separate decision before adopting overseas processing.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-RESOURCE-6661712d6f62736572766162696c697479, TASK-INTEGRATION-LIVE-62726f777365722d776562, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: faq-web, faq-api, public-article-store, faq-model, faq-observability
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-location-transparency

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.”; rationale: An Australian resource address alone does not establish model processing geography; explicit verification prevents an unnoticed overseas fallback. The stated preference is not a mandatory residency policy.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-7075626c69632d62726f77736572, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-RESOURCE-61727469636c652d656469746f72, TASK-RESOURCE-6661712d6f62736572766162696c697479, TASK-INTEGRATION-62726f777365722d776562, TASK-INTEGRATION-7765622d617069, TASK-INTEGRATION-6170692d61727469636c6573, TASK-INTEGRATION-6170692d6d6f64656c, TASK-INTEGRATION-656469746f722d61727469636c6573, TASK-INTEGRATION-6170692d74656c656d65747279
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-7075626c69632d62726f77736572, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-7075626c69632d61727469636c652d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-RESOURCE-61727469636c652d656469746f72, TASK-RESOURCE-6661712d6f62736572766162696c697479, TASK-INTEGRATION-LIVE-62726f777365722d776562, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3930313665653032, TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273, TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279, TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65, TASK-ACCEPTANCE-61692d7075626c69632d66696c652d7075626c697368696e67, TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379, TASK-INTEGRATION-LIVE-62726f777365722d776562, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6170692d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d6d6f64656c, TASK-INTEGRATION-LIVE-656469746f722d61727469636c6573, TASK-INTEGRATION-LIVE-6170692d74656c656d65747279
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use Azure. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
