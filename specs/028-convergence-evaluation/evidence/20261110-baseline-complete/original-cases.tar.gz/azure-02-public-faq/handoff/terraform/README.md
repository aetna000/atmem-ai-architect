# Infrastructure implementation required

Requested providers: azure. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Public FAQ website: Implementation needed.
- Article search and cited answers: Implementation needed.
- Approved public articles: Implementation needed.
- Grounded answer model: Implementation needed.
- Authorised article editor: Existing — reference/import plan needed.
- Failures and usage monitoring: Implementation needed.
- Wire public-browser → faq-web: implement data flow, access policy and acceptance test.
- Wire faq-web → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-api → public-article-store: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-model: implement data flow, access policy and acceptance test.
- Wire article-editor → public-article-store: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-observability: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
