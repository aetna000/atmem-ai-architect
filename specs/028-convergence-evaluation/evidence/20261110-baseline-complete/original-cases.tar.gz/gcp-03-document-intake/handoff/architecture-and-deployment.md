Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

# Asynchronous document intake — deployment document

Generated 2026-11-09 17:39 UTC from design revision r4 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** Google Cloud
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 9 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** PDF invoices up to 10 MB, around 500 per day; they may contain personal data. Keep originals and extraction audit history for 90 days. Keep documents and extracted data in Australia; flag unverified service availability.
- **Who uses it, and how much:** —
- **Systems it connects to:** Twenty signed-in staff and three reviewers; ordinary uploaders cannot approve. The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.
- **How good, fast and safe:** —
- **Cloud preference:** Google Cloud
- **Budget and timeline:** —

## 3. Architecture

**People**

- Uploaders and reviewers (Tools & data, existing) — Existing people using a browser, outside provisioning scope. Twenty signed-in staff and three reviewers are stated; whether reviewers are included in the twenty is unspecified. Uploaders submit PDF invoices up to 10 MB; only authorized reviewers inspect the source and extracted fields, correct them and explicitly approve or reject. Ordinary uploaders cannot approve. Enforce these permissions server-side; actual user directory and role assignments remain to be established. Documents may contain personal data.

**Invoice workflow**

- Invoice intake and review application (Google Cloud, sketch) — Proposed Cloud Run deployment containing upload/review UI, API, extraction and accounting delivery handlers. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Verify user tokens and authoritative roles on every operation; deny approval to ordinary uploaders even through direct API calls. Test denied approval and role changes. Isolate authenticated service-only routes. Plan for approximately 500 PDFs per day, each up to 10 MB; peak load and page counts remain unknown. Enforce size and PDF validation server-side and select a processing path compatible with verified processor limits. Issue narrowly scoped expiring upload URLs. Reviewers inspect PDFs and editable fields. Transactions enforce approval of an immutable revision; edits invalidate approval. Use exact object generations, durable leases and stable operation keys. Keep unsupported documents and failures visible. Run processing only through verified Australian endpoints; no overseas fallback. Avoid invoice contents, personal fields and credentials in operational logs; regional log storage and platform metadata residency require verification. Recovery performs retention cleanup. An administrator supplies the existing accounting endpoint and credentials through controlled configuration and secret inputs, never browser requests or diagram text. Application, container artifact, authorization and connections require implementation.
- Private invoice PDFs (Google Cloud, sketch) — Proposed private Cloud Storage bucket in Sydney, subject to verification. Accept PDF invoices up to 10 MB through authorized restricted signed URLs and server validation. Immutable submission paths and exact object generations support repeat-safe processing. Retain originals for 90 days; proposed retention age starts at successful upload. Enforce minimum retention and scheduled expiry through compatible bucket settings and cleanup. Verify soft-delete, object versions, backups and deletion timing so hidden copies do not silently extend retention. Treat document content as untrusted. No public access or overseas replication. Storage settings and residency require verification.
- Review queue and delivery ledger (Google Cloud, sketch) — Proposed regional Firestore database in Sydney, subject to verification. Store exact source generations, fields, corrections, confidence/evidence, workflow state, approval history and accounting receipt references. Retain extraction audit history for 90 days; proposed age starts when each audit event is recorded. Application cleanup enforces expiry; asynchronous TTL alone does not prove an exact deletion deadline. Backup and recovery copies must follow the Australian boundary and reviewed retention policy. Extracted-field and minimal delivery-ledger lifetimes need explicit definition before implementation; never silently delete deduplication protection. Transactions claim work and commit approval with an outbox entry. Stable submission keys prevent repeated events creating internal duplicates. Fingerprints flag identical reuploads; business duplicate rules remain open. Browser clients cannot directly write workflow state. Edits invalidate approval.
- Invoice field extraction (Google Cloud, sketch) — Candidate Document AI Invoice Parser extracts supplier, invoice date, total and currency, including supported scanned PDFs. Australian processor availability, processing location, version, transient retention and input/page limits are UNVERIFIED. Do not send documents to an overseas endpoint. If a compliant Australian processor is unavailable, retain this extraction responsibility as blocked engineering work and evaluate an Australia-hosted implementation rather than silently changing residency. Application maps fields into a validated schema and retains confidence and source evidence for review. Missing or ambiguous values require review; never fabricate or auto-approve. Verify handling of 10 MB PDFs and approximately 500 daily submissions with representative documents.

**Access**

- User sign-in (Google Cloud, sketch) — Proposed Identity Platform authentication for the stated twenty signed-in staff and three reviewers; adapt to existing company sign-in when known. Authentication alone does not grant approval authority. Application checks authoritative upload/review permissions on every operation and denies approval to ordinary uploaders. Proposed role assignments are administrator-controlled, never self-selected by users. Do not send PDFs or extracted invoice fields to the identity service. User profile and authentication metadata locations require separate residency assessment; an Australian application region does not prove identity residency. Enrollment and operational ownership remain open. No anonymous invoice access.
- Accounting connection credentials (Google Cloud, sketch) — Proposed Secret Manager storage for accounting credentials supplied by an administrator outside the diagram and chat. The administrator also supplies the accounting endpoint through controlled application configuration; the external accounting system is not provisioned or modified. Explicit Australian secret replication is proposed, subject to verification; no implicit global replication assumption. Only the application runtime identity accesses necessary versions. Proposed provisioning inputs reference secrets rather than embedding credential values in Terraform state or logs. API authentication, rotation and regional service behavior require engineering and verification.

**Recovery and delivery**

- Durable processing messages (Google Cloud, sketch) — Proposed Pub/Sub topic and authenticated push subscription for object-finalization events and approved-delivery outbox references. Carry opaque identifiers, never invoice contents or extracted fields. Configure Australian message storage and regional publishing/delivery behavior where supported; verify policies and endpoints independently. At-least-once delivery uses transactional state, leases and stable keys to handle duplicates. Bounded retries and dead-letter forwarding require scoped service identities. Expired or deleted submissions must not be recreated by late events. Topic, subscriptions, permissions and connections require implementation.
- Failed processing messages (Google Cloud, sketch) — Separate Pub/Sub dead-letter topic and retained operator subscription for exhausted attempts. Store opaque invoice references and safe failure metadata, not PDF contents or extracted personal data. Apply and verify Australian message storage policy. Alert operators and support audited replay with original keys only while the underlying submission remains eligible; expired submissions cannot be resurrected. Poison documents remain visible for manual handling. Operational ownership and recovery targets remain open.
- Recover work and enforce retention (Google Cloud, sketch) — Proposed Cloud Scheduler job invokes an authenticated application recovery route. Application recovers pending outbox entries and expired leases, reconciles finalized uploads and republishes eligible work with unchanged keys. Also checks 90-day original/audit expiry, performs idempotent cleanup and reports failures. Retention enforcement must cover generations, retained copies and associated records without losing required duplicate protection; retention exceptions cannot be invented. Repeated sweeps are harmless and cannot resurrect expired work. Schedule and alert thresholds are engineering proposals. Sydney availability and authenticated integration require verification.

**Existing accounting**

- Existing accounting API (Tools & data, existing) — Client-owned existing service outside provisioning scope; do not create, import or modify it. An administrator will supply its endpoint and credentials through controlled configuration and secret inputs outside the diagram. Hosting, processing and storage locations remain unknown; this ownership clarification does not establish Australian residency. Sending invoice fields remains blocked until compatibility with Australian residency is established. Receive only the approved revision with a stable delivery key. Establish native idempotency or authoritative lookup before automatic retries. After a timeout with possible acceptance, mark uncertain and reconcile rather than blindly resend. Without downstream duplicate protection, exactly-once creation cannot be guaranteed. Existing accounting retention is separate from the proposed intake retention and remains unverified. Endpoint schema, authentication and reconciliation behavior require evidence.

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice intake and review application<br/>Google Cloud"]
  n2["User sign-in<br/>Google Cloud"]
  n3["Private invoice PDFs<br/>Google Cloud"]
  n4["Durable processing messages<br/>Google Cloud"]
  n5["Failed processing messages<br/>Google Cloud"]
  n6["Review queue and delivery ledger<br/>Google Cloud"]
  n7["Invoice field extraction<br/>Google Cloud"]
  n8["Recover work and enforce retention<br/>Google Cloud"]
  n9["Accounting connection credentials<br/>Google Cloud"]
  n10["Existing accounting API<br/>Tools & data"]
  n0 -->|HTTPS: signed-in upload; reviewer-only correction and approval| n1
  n0 -->|Sign in and receive user token| n2
  n1 -->|Verify tokens; server enforces uploader and reviewer permissions| n2
  n0 -->|HTTPS signed upload: PDF up to 10 MB| n3
  n1 -->|Scoped identity: exact-generation reads and retention cleanup| n3
  n3 -->|Object-finalization notification with generation| n4
  n4 -->|OIDC-authenticated push; acknowledge durable completion| n1
  n4 -->|Forward exhausted attempts with scoped permissions| n5
  n1 -->|Transactional workflow, approvals, outbox and 90-day audit cleanup| n6
  n1 -->|PDF processing — blocked pending Australian endpoint verification| n7
  n8 -->|OIDC-authenticated recovery and retention sweep| n1
  n1 -->|Publish eligible approved-delivery and recovery references| n4
  n1 -->|Scoped runtime access to administrator-supplied accounting credentials| n9
  n1 -->|Approved revision to configured external endpoint; residency and retry safety un| n10
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Approval workflow | Existing users — location to confirm | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-app | Invoice intake and review application | gcp | Google Cloud Run | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-identity | User sign-in | gcp | Identity Platform | Identity residency unverified | Proposed | Implementation needed |
| invoice-files | Private invoice PDFs | gcp | Google Cloud Storage | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-events | Durable processing messages | gcp | Google Cloud Pub/Sub | Australia-only message policy — unverified | Proposed | Implementation needed |
| invoice-dead-letter | Failed processing messages | gcp | Google Cloud Pub/Sub | Australia-only message policy — unverified | Proposed | Implementation needed |
| invoice-state | Review queue and delivery ledger | gcp | Cloud Firestore | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-extractor | Invoice field extraction | gcp | Google Cloud Document AI | Australian processing endpoint — unverified | Proposed | Implementation needed |
| invoice-recovery | Recover work and enforce retention | gcp | Google Cloud Scheduler | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-secrets | Accounting connection credentials | gcp | Secret Manager | Australian replication — proposed, unverified | Proposed | Implementation needed |
| accounting-api | Existing accounting API | tools | Existing accounting API | Existing location — Australian residency to confirm | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Invoice intake and review application** (invoice-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users, invoice-events, invoice-recovery.
- **User sign-in** (invoice-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users, invoice-app.
- **Private invoice PDFs** (invoice-files): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users, invoice-app.
- **Durable processing messages** (invoice-events): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-files, invoice-app.
- **Failed processing messages** (invoice-dead-letter): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-events.
- **Review queue and delivery ledger** (invoice-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Invoice field extraction** (invoice-extractor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Recover work and enforce retention** (invoice-recovery): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Accounting connection credentials** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Existing accounting API** (accounting-api): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.

### Engineering work remaining

- Invoice intake and review application: Implementation needed.
- User sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Durable processing messages: Implementation needed.
- Failed processing messages: Implementation needed.
- Review queue and delivery ledger: Implementation needed.
- Invoice field extraction: Implementation needed.
- Recover work and enforce retention: Implementation needed.
- Accounting connection credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-files → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-dead-letter: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-extractor: implement data flow, access policy and acceptance test.
- Wire invoice-recovery → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → accounting-api: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Uploaders and reviewers | Invoice intake and review application | HTTPS: signed-in upload; reviewer-only correction and approval | Confidential |
| Uploaders and reviewers | User sign-in | Sign in and receive user token | Confidential |
| Invoice intake and review application | User sign-in | Verify tokens; server enforces uploader and reviewer permissions | Confidential |
| Uploaders and reviewers | Private invoice PDFs | HTTPS signed upload: PDF up to 10 MB | Confidential |
| Invoice intake and review application | Private invoice PDFs | Scoped identity: exact-generation reads and retention cleanup | Confidential |
| Private invoice PDFs | Durable processing messages | Object-finalization notification with generation | Confidential |
| Durable processing messages | Invoice intake and review application | OIDC-authenticated push; acknowledge durable completion | Confidential |
| Durable processing messages | Failed processing messages | Forward exhausted attempts with scoped permissions | Confidential |
| Invoice intake and review application | Review queue and delivery ledger | Transactional workflow, approvals, outbox and 90-day audit cleanup | Confidential |
| Invoice intake and review application | Invoice field extraction | PDF processing — blocked pending Australian endpoint verification | Confidential |
| Recover work and enforce retention | Invoice intake and review application | OIDC-authenticated recovery and retention sweep | Confidential |
| Invoice intake and review application | Durable processing messages | Publish eligible approved-delivery and recovery references | Confidential |
| Invoice intake and review application | Accounting connection credentials | Scoped runtime access to administrator-supplied accounting credentials | Confidential |
| Invoice intake and review application | Existing accounting API | Approved revision to configured external endpoint; residency and retry safety un | Confidential |

## 5. Security controls

- **Uploaders and reviewers** — Existing people using a browser, outside provisioning scope. Twenty signed-in staff and three reviewers are stated; whether reviewers are included in the twenty is unspecified. Uploaders submit PDF invoices up to 10 MB; only authorized reviewers inspect the source and extracted fields, correct them and explicitly approve or reject. Ordinary uploaders cannot approve. Enforce these permissions server-side; actual user directory and role assignments remain to be established. Documents may contain personal data.
- **User sign-in** — Proposed Identity Platform authentication for the stated twenty signed-in staff and three reviewers; adapt to existing company sign-in when known. Authentication alone does not grant approval authority. Application checks authoritative upload/review permissions on every operation and denies approval to ordinary uploaders. Proposed role assignments are administrator-controlled, never self-selected by users. Do not send PDFs or extracted invoice fields to the identity service. User profile and authentication metadata locations require separate residency assessment; an Australian application region does not prove identity residency. Enrollment and operational ownership remain open. No anonymous invoice access.
- **Accounting connection credentials** — Proposed Secret Manager storage for accounting credentials supplied by an administrator outside the diagram and chat. The administrator also supplies the accounting endpoint through controlled application configuration; the external accounting system is not provisioned or modified. Explicit Australian secret replication is proposed, subject to verification; no implicit global replication assumption. Only the application runtime identity accesses necessary versions. Proposed provisioning inputs reference secrets rather than embedding credential values in Terraform state or logs. API authentication, rotation and regional service behavior require engineering and verification.
- Requirement: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials. (must)
- Requirement: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved. (must)
- Requirement: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety. (must)
- Requirement: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved. | compliance | not measurable yet | Open |
| Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety. | compliance | Original and extraction audit retention == 90days | Open |
| The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed. | scalability | not measurable yet | Open |

**Functional**

- Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open. (must, open)
- Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established. (must, open)
- Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials. (must, open)
- Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_
- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.”, “The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 9 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| User sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Private invoice PDFs | Storage | 0.01 GB-month | price needed | — | — |
| Durable processing messages | Data processed | 0.01 GB | price needed | — | — |
| Failed processing messages | Storage | 0.01 GB-month | price needed | — | — |
| Review queue and delivery ledger | Storage | 0.01 GB-month | price needed | — | — |
| Invoice field extraction | Endpoint hours | 730 hours | price needed | — | — |
| Accounting connection credentials | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: 0.01 (discovery (2026-11-10)); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Uploaders and reviewers, Invoice intake and review application, Recover work and enforce retention, Existing accounting API.

**Estimate gaps:**

- User sign-in / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: price needed.
- Durable processing messages / Data processed: price needed.
- Failed processing messages / Storage: price needed.
- Review queue and delivery ledger / Storage: price needed.
- Invoice field extraction / Endpoint hours: price needed.
- Accounting connection credentials / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice intake and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Recover work and enforce retention: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision invoice workflow: Invoice intake and review application, Private invoice PDFs, Review queue and delivery ledger, Invoice field extraction.
4. Provision access: User sign-in, Accounting connection credentials.
5. Provision recovery and delivery: Durable processing messages, Failed processing messages, Recover work and enforce retention.
6. Connect existing systems: Uploaders and reviewers, Existing accounting API; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Keep documents and extracted data in Australia; flag unverified service availability.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- User sign-in: needs requests_per_month _(estimate)_
- Private invoice PDFs: needs a unit price with a source _(estimate)_
- Durable processing messages: needs a unit price with a source _(estimate)_
- Failed processing messages: needs a unit price with a source _(estimate)_
- Review queue and delivery ledger: needs a unit price with a source _(estimate)_
- Invoice field extraction: needs a unit price with a source _(estimate)_
- Accounting connection credentials: needs requests_per_month _(estimate)_
