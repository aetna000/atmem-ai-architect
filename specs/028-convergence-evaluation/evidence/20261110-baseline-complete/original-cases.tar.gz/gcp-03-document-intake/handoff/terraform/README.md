# Infrastructure implementation required

Requested providers: gcp. No substitute provider or application resources have been generated. This file contains a blocking review gate only. It is not deployment infrastructure.

- Invoice intake and review application: Implementation needed.
- User sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Durable processing messages: Implementation needed.
- Failed processing messages: Implementation needed.
- Review queue and delivery ledger: Implementation needed.
- Invoice field extraction: Implementation needed.
- Recover work and enforce retention: Implementation needed.
- Accounting connection credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-files → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-dead-letter: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-extractor: implement data flow, access policy and acceptance test.
- Wire invoice-recovery → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → accounting-api: implement data flow, access policy and acceptance test.

Preserve the design and implement the missing compiler capabilities; do not clear the gate to obtain a pass.
