Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

# Asynchronous document intake — solution specification

## Problem and intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-003] Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-files, invoice-extractor, invoice-state

Design explanation: Provides the requested reviewable result while keeping uncertain extraction visible instead of silently accepting incorrect financial data.

Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.”
- [REQ-004] Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established. (must, open); target: acceptance target needed; linked blocks: invoice-events, invoice-app, invoice-state, invoice-recovery, accounting-api

Design explanation: Repeated events and uncertain API responses can create duplicate financial records. Durable internal deduplication and downstream idempotency or reconciliation are both necessary; downstream capability remains unverified.

Basis: “Delivery can repeat; retries must not create duplicate invoices.”
- [REQ-005] Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials. (must, open); target: acceptance target needed; linked blocks: invoice-users, invoice-identity, invoice-app, invoice-state, accounting-api

Design explanation: Prevents unreviewed or subsequently changed extraction results from being posted as approved invoices; server authorization and an approval history are proposed enforcement mechanisms.

Basis: “A reviewer approves a result before it is sent to our existing accounting API.”
- [REQ-006] Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-files, invoice-events, invoice-dead-letter, invoice-state, invoice-extractor, accounting-api

Design explanation: Personal invoice information could leave Australia through extraction, messaging, logs, backups or accounting delivery even when the main bucket is Australian.

Basis: “they may contain personal data” and “Keep documents and extracted data in Australia; flag unverified service availability.”
- [REQ-007] Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety. (must, open); target: Original and extraction audit retention == 90days; linked blocks: invoice-files, invoice-state, invoice-app, invoice-recovery

Design explanation: Cleanup must preserve the required evidence period while preventing unnoticed retention in object generations or recovery copies; deletion must also preserve duplicate-prevention safety.

Basis: “Keep originals and extraction audit history for 90 days.”
- [REQ-008] The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-files, invoice-events, invoice-extractor

Design explanation: Large or scanned invoices can exceed processor limits; daily volume alone does not establish peak capacity or processing latency.

Basis: “PDF invoices up to 10 MB, around 500 per day”
- [REQ-009] Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery. (must, open); target: acceptance target needed; linked blocks: invoice-app, invoice-secrets, accounting-api

Design explanation: Preserves the existing accounting system's ownership and prevents credentials from being exposed through the browser, diagram or generated configuration. Secret handling and connection tests remain implementation work.

Basis: “The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.”

## How the system works

The current design contains 11 components and 14 connections. 2 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Uploaders and reviewers → Invoice intake and review application

HTTPS: signed-in upload; reviewer-only correction and approval

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Uploaders and reviewers → User sign-in

Sign in and receive user token

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Invoice intake and review application → User sign-in

Verify tokens; server enforces uploader and reviewer permissions

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Uploaders and reviewers → Private invoice PDFs

HTTPS signed upload: PDF up to 10 MB

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Invoice intake and review application → Private invoice PDFs

Scoped identity: exact-generation reads and retention cleanup

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Private invoice PDFs → Durable processing messages

Object-finalization notification with generation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Durable processing messages → Invoice intake and review application

OIDC-authenticated push; acknowledge durable completion

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Durable processing messages → Failed processing messages

Forward exhausted attempts with scoped permissions

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Invoice intake and review application → Review queue and delivery ledger

Transactional workflow, approvals, outbox and 90-day audit cleanup

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Invoice intake and review application → Invoice field extraction

PDF processing — blocked pending Australian endpoint verification

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Recover work and enforce retention → Invoice intake and review application

OIDC-authenticated recovery and retention sweep

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: Invoice intake and review application → Durable processing messages

Publish eligible approved-delivery and recovery references

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: Invoice intake and review application → Accounting connection credentials

Scoped runtime access to administrator-supplied accounting credentials

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: Invoice intake and review application → Existing accounting API

Approved revision to configured external endpoint; residency and retry safety un

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Uploaders and reviewers

Approval workflow · tools · region: Existing users — location to confirm · classification: Confidential

Existing people using a browser, outside provisioning scope. Twenty signed-in staff and three reviewers are stated; whether reviewers are included in the twenty is unspecified. Uploaders submit PDF invoices up to 10 MB; only authorized reviewers inspect the source and extracted fields, correct them and explicitly approve or reject. Ordinary uploaders cannot approve. Enforce these permissions server-side; actual user directory and role assignments remain to be established. Documents may contain personal data.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Uploaders and reviewers → Invoice intake and review application: HTTPS: signed-in upload; reviewer-only correction and approval; Uploaders and reviewers → User sign-in: Sign in and receive user token; Uploaders and reviewers → Private invoice PDFs: HTTPS signed upload: PDF up to 10 MB

Requirement traceability: REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Invoice intake and review application

Google Cloud Run · gcp · region: australia-southeast1 — proposed, unverified · classification: Confidential

Proposed Cloud Run deployment containing upload/review UI, API, extraction and accounting delivery handlers. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Verify user tokens and authoritative roles on every operation; deny approval to ordinary uploaders even through direct API calls. Test denied approval and role changes. Isolate authenticated service-only routes. Plan for approximately 500 PDFs per day, each up to 10 MB; peak load and page counts remain unknown. Enforce size and PDF validation server-side and select a processing path compatible with verified processor limits. Issue narrowly scoped expiring upload URLs. Reviewers inspect PDFs and editable fields. Transactions enforce approval of an immutable revision; edits invalidate approval. Use exact object generations, durable leases and stable operation keys. Keep unsupported documents and failures visible. Run processing only through verified Australian endpoints; no overseas fallback. Avoid invoice contents, personal fields and credentials in operational logs; regional log storage and platform metadata residency require verification. Recovery performs retention cleanup. An administrator supplies the existing accounting endpoint and credentials through controlled configuration and secret inputs, never browser requests or diagram text. Application, container artifact, authorization and connections require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Uploaders and reviewers → Invoice intake and review application: HTTPS: signed-in upload; reviewer-only correction and approval; Durable processing messages → Invoice intake and review application: OIDC-authenticated push; acknowledge durable completion; Recover work and enforce retention → Invoice intake and review application: OIDC-authenticated recovery and retention sweep

Outputs: Invoice intake and review application → User sign-in: Verify tokens; server enforces uploader and reviewer permissions; Invoice intake and review application → Private invoice PDFs: Scoped identity: exact-generation reads and retention cleanup; Invoice intake and review application → Review queue and delivery ledger: Transactional workflow, approvals, outbox and 90-day audit cleanup; Invoice intake and review application → Invoice field extraction: PDF processing — blocked pending Australian endpoint verification; Invoice intake and review application → Durable processing messages: Publish eligible approved-delivery and recovery references; Invoice intake and review application → Accounting connection credentials: Scoped runtime access to administrator-supplied accounting credentials; Invoice intake and review application → Existing accounting API: Approved revision to configured external endpoint; residency and retry safety un

Requirement traceability: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.; REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### User sign-in

Identity Platform · gcp · region: Identity residency unverified · classification: Confidential

Proposed Identity Platform authentication for the stated twenty signed-in staff and three reviewers; adapt to existing company sign-in when known. Authentication alone does not grant approval authority. Application checks authoritative upload/review permissions on every operation and denies approval to ordinary uploaders. Proposed role assignments are administrator-controlled, never self-selected by users. Do not send PDFs or extracted invoice fields to the identity service. User profile and authentication metadata locations require separate residency assessment; an Australian application region does not prove identity residency. Enrollment and operational ownership remain open. No anonymous invoice access.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Uploaders and reviewers → User sign-in: Sign in and receive user token; Invoice intake and review application → User sign-in: Verify tokens; server enforces uploader and reviewer permissions

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Private invoice PDFs

Google Cloud Storage · gcp · region: australia-southeast1 — proposed, unverified · classification: Confidential

Proposed private Cloud Storage bucket in Sydney, subject to verification. Accept PDF invoices up to 10 MB through authorized restricted signed URLs and server validation. Immutable submission paths and exact object generations support repeat-safe processing. Retain originals for 90 days; proposed retention age starts at successful upload. Enforce minimum retention and scheduled expiry through compatible bucket settings and cleanup. Verify soft-delete, object versions, backups and deletion timing so hidden copies do not silently extend retention. Treat document content as untrusted. No public access or overseas replication. Storage settings and residency require verification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Uploaders and reviewers → Private invoice PDFs: HTTPS signed upload: PDF up to 10 MB; Invoice intake and review application → Private invoice PDFs: Scoped identity: exact-generation reads and retention cleanup

Outputs: Private invoice PDFs → Durable processing messages: Object-finalization notification with generation

Requirement traceability: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Durable processing messages

Google Cloud Pub/Sub · gcp · region: Australia-only message policy — unverified · classification: Confidential

Proposed Pub/Sub topic and authenticated push subscription for object-finalization events and approved-delivery outbox references. Carry opaque identifiers, never invoice contents or extracted fields. Configure Australian message storage and regional publishing/delivery behavior where supported; verify policies and endpoints independently. At-least-once delivery uses transactional state, leases and stable keys to handle duplicates. Bounded retries and dead-letter forwarding require scoped service identities. Expired or deleted submissions must not be recreated by late events. Topic, subscriptions, permissions and connections require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Private invoice PDFs → Durable processing messages: Object-finalization notification with generation; Invoice intake and review application → Durable processing messages: Publish eligible approved-delivery and recovery references

Outputs: Durable processing messages → Invoice intake and review application: OIDC-authenticated push; acknowledge durable completion; Durable processing messages → Failed processing messages: Forward exhausted attempts with scoped permissions

Requirement traceability: REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Failed processing messages

Google Cloud Pub/Sub · gcp · region: Australia-only message policy — unverified · classification: Confidential

Separate Pub/Sub dead-letter topic and retained operator subscription for exhausted attempts. Store opaque invoice references and safe failure metadata, not PDF contents or extracted personal data. Apply and verify Australian message storage policy. Alert operators and support audited replay with original keys only while the underlying submission remains eligible; expired submissions cannot be resurrected. Poison documents remain visible for manual handling. Operational ownership and recovery targets remain open.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Durable processing messages → Failed processing messages: Forward exhausted attempts with scoped permissions

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Review queue and delivery ledger

Cloud Firestore · gcp · region: australia-southeast1 — proposed, unverified · classification: Confidential

Proposed regional Firestore database in Sydney, subject to verification. Store exact source generations, fields, corrections, confidence/evidence, workflow state, approval history and accounting receipt references. Retain extraction audit history for 90 days; proposed age starts when each audit event is recorded. Application cleanup enforces expiry; asynchronous TTL alone does not prove an exact deletion deadline. Backup and recovery copies must follow the Australian boundary and reviewed retention policy. Extracted-field and minimal delivery-ledger lifetimes need explicit definition before implementation; never silently delete deduplication protection. Transactions claim work and commit approval with an outbox entry. Stable submission keys prevent repeated events creating internal duplicates. Fingerprints flag identical reuploads; business duplicate rules remain open. Browser clients cannot directly write workflow state. Edits invalidate approval.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice intake and review application → Review queue and delivery ledger: Transactional workflow, approvals, outbox and 90-day audit cleanup

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Invoice field extraction

Google Cloud Document AI · gcp · region: Australian processing endpoint — unverified · classification: Confidential

Candidate Document AI Invoice Parser extracts supplier, invoice date, total and currency, including supported scanned PDFs. Australian processor availability, processing location, version, transient retention and input/page limits are UNVERIFIED. Do not send documents to an overseas endpoint. If a compliant Australian processor is unavailable, retain this extraction responsibility as blocked engineering work and evaluate an Australia-hosted implementation rather than silently changing residency. Application maps fields into a validated schema and retains confidence and source evidence for review. Missing or ambiguous values require review; never fabricate or auto-approve. Verify handling of 10 MB PDFs and approximately 500 daily submissions with representative documents.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice intake and review application → Invoice field extraction: PDF processing — blocked pending Australian endpoint verification

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Recover work and enforce retention

Google Cloud Scheduler · gcp · region: australia-southeast1 — proposed, unverified · classification: Confidential

Proposed Cloud Scheduler job invokes an authenticated application recovery route. Application recovers pending outbox entries and expired leases, reconciles finalized uploads and republishes eligible work with unchanged keys. Also checks 90-day original/audit expiry, performs idempotent cleanup and reports failures. Retention enforcement must cover generations, retained copies and associated records without losing required duplicate protection; retention exceptions cannot be invented. Repeated sweeps are harmless and cannot resurrect expired work. Schedule and alert thresholds are engineering proposals. Sydney availability and authenticated integration require verification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Recover work and enforce retention → Invoice intake and review application: OIDC-authenticated recovery and retention sweep

Requirement traceability: REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Accounting connection credentials

Secret Manager · gcp · region: Australian replication — proposed, unverified · classification: Confidential

Proposed Secret Manager storage for accounting credentials supplied by an administrator outside the diagram and chat. The administrator also supplies the accounting endpoint through controlled application configuration; the external accounting system is not provisioned or modified. Explicit Australian secret replication is proposed, subject to verification; no implicit global replication assumption. Only the application runtime identity accesses necessary versions. Proposed provisioning inputs reference secrets rather than embedding credential values in Terraform state or logs. API authentication, rotation and regional service behavior require engineering and verification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Invoice intake and review application → Accounting connection credentials: Scoped runtime access to administrator-supplied accounting credentials

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing accounting API

Existing accounting API · tools · region: Existing location — Australian residency to confirm · classification: Confidential

Client-owned existing service outside provisioning scope; do not create, import or modify it. An administrator will supply its endpoint and credentials through controlled configuration and secret inputs outside the diagram. Hosting, processing and storage locations remain unknown; this ownership clarification does not establish Australian residency. Sending invoice fields remains blocked until compatibility with Australian residency is established. Receive only the approved revision with a stable delivery key. Establish native idempotency or authoritative lookup before automatic retries. After a timeout with possible acceptance, mark uncertain and reconcile rather than blindly resend. Without downstream duplicate protection, exactly-once creation cannot be guaranteed. Existing accounting retention is separate from the proposed intake retention and remains unverified. Endpoint schema, authentication and reconciliation behavior require evidence.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Invoice intake and review application → Existing accounting API: Approved revision to configured external endpoint; residency and retry safety un

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Architecture

```mermaid
flowchart LR
  n0["Uploaders and reviewers<br/>Tools & data"]
  n1["Invoice intake and review application<br/>Google Cloud"]
  n2["User sign-in<br/>Google Cloud"]
  n3["Private invoice PDFs<br/>Google Cloud"]
  n4["Durable processing messages<br/>Google Cloud"]
  n5["Failed processing messages<br/>Google Cloud"]
  n6["Review queue and delivery ledger<br/>Google Cloud"]
  n7["Invoice field extraction<br/>Google Cloud"]
  n8["Recover work and enforce retention<br/>Google Cloud"]
  n9["Accounting connection credentials<br/>Google Cloud"]
  n10["Existing accounting API<br/>Tools & data"]
  n0 -->|HTTPS: signed-in upload; reviewer-only correction and approval| n1
  n0 -->|Sign in and receive user token| n2
  n1 -->|Verify tokens; server enforces uploader and reviewer permissions| n2
  n0 -->|HTTPS signed upload: PDF up to 10 MB| n3
  n1 -->|Scoped identity: exact-generation reads and retention cleanup| n3
  n3 -->|Object-finalization notification with generation| n4
  n4 -->|OIDC-authenticated push; acknowledge durable completion| n1
  n4 -->|Forward exhausted attempts with scoped permissions| n5
  n1 -->|Transactional workflow, approvals, outbox and 90-day audit cleanup| n6
  n1 -->|PDF processing — blocked pending Australian endpoint verification| n7
  n8 -->|OIDC-authenticated recovery and retention sweep| n1
  n1 -->|Publish eligible approved-delivery and recovery references| n4
  n1 -->|Scoped runtime access to administrator-supplied accounting credentials| n9
  n1 -->|Approved revision to configured external endpoint; residency and retry safety un| n10
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| invoice-users | Uploaders and reviewers | tools | Approval workflow | Existing users — location to confirm | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| invoice-app | Invoice intake and review application | gcp | Google Cloud Run | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-identity | User sign-in | gcp | Identity Platform | Identity residency unverified | Proposed | Implementation needed |
| invoice-files | Private invoice PDFs | gcp | Google Cloud Storage | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-events | Durable processing messages | gcp | Google Cloud Pub/Sub | Australia-only message policy — unverified | Proposed | Implementation needed |
| invoice-dead-letter | Failed processing messages | gcp | Google Cloud Pub/Sub | Australia-only message policy — unverified | Proposed | Implementation needed |
| invoice-state | Review queue and delivery ledger | gcp | Cloud Firestore | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-extractor | Invoice field extraction | gcp | Google Cloud Document AI | Australian processing endpoint — unverified | Proposed | Implementation needed |
| invoice-recovery | Recover work and enforce retention | gcp | Google Cloud Scheduler | australia-southeast1 — proposed, unverified | Proposed | Implementation needed |
| invoice-secrets | Accounting connection credentials | gcp | Secret Manager | Australian replication — proposed, unverified | Proposed | Implementation needed |
| accounting-api | Existing accounting API | tools | Existing accounting API | Existing location — Australian residency to confirm | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |

### Resources and cost dimensions

- **Uploaders and reviewers** (invoice-users): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Invoice intake and review application** (invoice-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users, invoice-events, invoice-recovery.
- **User sign-in** (invoice-identity): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users, invoice-app.
- **Private invoice PDFs** (invoice-files): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-users, invoice-app.
- **Durable processing messages** (invoice-events): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-files, invoice-app.
- **Failed processing messages** (invoice-dead-letter): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-events.
- **Review queue and delivery ledger** (invoice-state): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Invoice field extraction** (invoice-extractor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Recover work and enforce retention** (invoice-recovery): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Accounting connection credentials** (invoice-secrets): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.
- **Existing accounting API** (accounting-api): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: invoice-app.

### Engineering work remaining

- Invoice intake and review application: Implementation needed.
- User sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Durable processing messages: Implementation needed.
- Failed processing messages: Implementation needed.
- Review queue and delivery ledger: Implementation needed.
- Invoice field extraction: Implementation needed.
- Recover work and enforce retention: Implementation needed.
- Accounting connection credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-files → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-dead-letter: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-extractor: implement data flow, access policy and acceptance test.
- Wire invoice-recovery → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → accounting-api: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use Google Cloud.

**Options considered**

—

**Decision**

gcp

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Keep documents and extracted data in Australia; flag unverified service availability.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
