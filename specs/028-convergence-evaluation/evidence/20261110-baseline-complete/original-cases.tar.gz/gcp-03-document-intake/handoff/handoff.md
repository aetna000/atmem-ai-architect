# Delivery handoff

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- User sign-in / Checked requests: input needed (requests_per_month).
- Private invoice PDFs / Storage: price needed.
- Durable processing messages / Data processed: price needed.
- Failed processing messages / Storage: price needed.
- Review queue and delivery ledger / Storage: price needed.
- Invoice field extraction / Endpoint hours: price needed.
- Accounting connection credentials / Checked requests: input needed (requests_per_month).
- Uploaders and reviewers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice intake and review application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Recover work and enforce retention: no cost lines; add charges or an explicit zero-cost line with a reason.
- Existing accounting API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Invoice intake and review application: Implementation needed.
- User sign-in: Implementation needed.
- Private invoice PDFs: Implementation needed.
- Durable processing messages: Implementation needed.
- Failed processing messages: Implementation needed.
- Review queue and delivery ledger: Implementation needed.
- Invoice field extraction: Implementation needed.
- Recover work and enforce retention: Implementation needed.
- Accounting connection credentials: Implementation needed.
- Wire invoice-users → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-identity: implement data flow, access policy and acceptance test.
- Wire invoice-users → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-files: implement data flow, access policy and acceptance test.
- Wire invoice-files → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-events → invoice-dead-letter: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-state: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-extractor: implement data flow, access policy and acceptance test.
- Wire invoice-recovery → invoice-app: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-events: implement data flow, access policy and acceptance test.
- Wire invoice-app → invoice-secrets: implement data flow, access policy and acceptance test.
- Wire invoice-app → accounting-api: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
