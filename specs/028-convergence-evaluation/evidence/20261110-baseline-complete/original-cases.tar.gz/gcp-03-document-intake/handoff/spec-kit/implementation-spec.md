# Implementation Spec Kit

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

9 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: gcp
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Uploaders and reviewers (invoice-users): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing users — location to confirm.
- Invoice intake and review application (invoice-app): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- User sign-in (invoice-identity): Implementation needed; gcp, Identity residency unverified.
- Private invoice PDFs (invoice-files): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- Durable processing messages (invoice-events): Implementation needed; gcp, Australia-only message policy — unverified.
- Failed processing messages (invoice-dead-letter): Implementation needed; gcp, Australia-only message policy — unverified.
- Review queue and delivery ledger (invoice-state): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- Invoice field extraction (invoice-extractor): Implementation needed; gcp, Australian processing endpoint — unverified.
- Recover work and enforce retention (invoice-recovery): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- Accounting connection credentials (invoice-secrets): Implementation needed; gcp, Australian replication — proposed, unverified.
- Existing accounting API (accounting-api): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — Australian residency to confirm.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279 — priority 1

REQ-009 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279

### requirement-proposed-61692d696e766f6963652d617070726f76616c — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c

### requirement-proposed-61692d696e766f6963652d6361706163697479 — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6361706163697479

### requirement-proposed-61692d696e766f6963652d65787472616374696f6e — priority 1

REQ-003 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e

### requirement-proposed-61692d696e766f6963652d6964656d706f74656e6379 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379

### requirement-proposed-61692d696e766f6963652d7265736964656e6379 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379

### requirement-proposed-61692d696e766f6963652d726574656e74696f6e — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e

### placement-696e766f6963652d617070 — priority 2

Invoice intake and review application: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-696e766f6963652d617070

### placement-696e766f6963652d66696c6573 — priority 2

Private invoice PDFs: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-696e766f6963652d66696c6573

### placement-696e766f6963652d7265636f76657279 — priority 2

Recover work and enforce retention: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-696e766f6963652d7265636f76657279

### placement-696e766f6963652d73656372657473 — priority 2

Accounting connection credentials: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-696e766f6963652d73656372657473

### placement-696e766f6963652d7374617465 — priority 2

Review queue and delivery ledger: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-696e766f6963652d7374617465

### review-52454c2d3030313a696e766f6963652d657874726163746f72 — priority 2

No monitoring for model quality or drift.

Action: Add a monitoring block (quality, drift, cost) and decide who is alerted.

Tasks: TASK-SECURITY-DESIGN, TASK-SECURITY

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

11 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279 — priority 2

REQ-009: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279

### acceptance-61692d696e766f6963652d617070726f76616c — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c

### acceptance-61692d696e766f6963652d6361706163697479 — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6361706163697479

### acceptance-61692d696e766f6963652d65787472616374696f6e — priority 2

REQ-003: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e

### acceptance-61692d696e766f6963652d6964656d706f74656e6379 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379

### acceptance-61692d696e766f6963652d7265736964656e6379 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379

### acceptance-61692d696e766f6963652d726574656e74696f6e — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Define workload, measurement window, first-output versus completed-response boundary and repeatable positive/negative cases.

Tasks: TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e

### implementation-696e766f6963652d617070 — priority 2

Invoice intake and review application: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d617070

### implementation-696e766f6963652d646561642d6c6574746572 — priority 2

Failed processing messages: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d646561642d6c6574746572

### implementation-696e766f6963652d6576656e7473 — priority 2

Durable processing messages: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d6576656e7473

### implementation-696e766f6963652d657874726163746f72 — priority 2

Invoice field extraction: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d657874726163746f72

### implementation-696e766f6963652d66696c6573 — priority 2

Private invoice PDFs: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d66696c6573

### implementation-696e766f6963652d6964656e74697479 — priority 2

User sign-in: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d6964656e74697479

### implementation-696e766f6963652d7265636f76657279 — priority 2

Recover work and enforce retention: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d7265636f76657279

### implementation-696e766f6963652d73656372657473 — priority 2

Accounting connection credentials: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d73656372657473

### implementation-696e766f6963652d7374617465 — priority 2

Review queue and delivery ledger: native infrastructure/application implementation is absent.

Action: Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-696e766f6963652d7374617465

### existing-6163636f756e74696e672d617069 — priority 2

Existing accounting API: existing-system contract and access are unverified.

Action: Preserve this externally managed service without creating or importing it.

Tasks: TASK-RESOURCE-6163636f756e74696e672d617069

### existing-696e766f6963652d7573657273 — priority 2

Uploaders and reviewers: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-696e766f6963652d7573657273


# Component and interface contracts

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component invoice-users: Uploaders and reviewers

- Responsibility: Existing people using a browser, outside provisioning scope. Twenty signed-in staff and three reviewers are stated; whether reviewers are included in the twenty is unspecified. Uploaders submit PDF invoices up to 10 MB; only authorized reviewers inspect the source and extracted fields, correct them and explicitly approve or reject. Ordinary uploaders cannot approve. Enforce these permissions server-side; actual user directory and role assignments remain to be established. Documents may contain personal data.
- Service: Approval workflow
- Provider / placement: tools / Existing users — location to confirm
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component invoice-app: Invoice intake and review application

- Responsibility: Proposed Cloud Run deployment containing upload/review UI, API, extraction and accounting delivery handlers. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Verify user tokens and authoritative roles on every operation; deny approval to ordinary uploaders even through direct API calls. Test denied approval and role changes. Isolate authenticated service-only routes. Plan for approximately 500 PDFs per day, each up to 10 MB; peak load and page counts remain unknown. Enforce size and PDF validation server-side and select a processing path compatible with verified processor limits. Issue narrowly scoped expiring upload URLs. Reviewers inspect PDFs and editable fields. Transactions enforce approval of an immutable revision; edits invalidate approval. Use exact object generations, durable leases and stable operation keys. Keep unsupported documents and failures visible. Run processing only through verified Australian endpoints; no overseas fallback. Avoid invoice contents, personal fields and credentials in operational logs; regional log storage and platform metadata residency require verification. Recovery performs retention cleanup. An administrator supplies the existing accounting endpoint and credentials through controlled configuration and secret inputs, never browser requests or diagram text. Application, container artifact, authorization and connections require implementation.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-identity: User sign-in

- Responsibility: Proposed Identity Platform authentication for the stated twenty signed-in staff and three reviewers; adapt to existing company sign-in when known. Authentication alone does not grant approval authority. Application checks authoritative upload/review permissions on every operation and denies approval to ordinary uploaders. Proposed role assignments are administrator-controlled, never self-selected by users. Do not send PDFs or extracted invoice fields to the identity service. User profile and authentication metadata locations require separate residency assessment; an Australian application region does not prove identity residency. Enrollment and operational ownership remain open. No anonymous invoice access.
- Service: Identity Platform
- Provider / placement: gcp / Identity residency unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-files: Private invoice PDFs

- Responsibility: Proposed private Cloud Storage bucket in Sydney, subject to verification. Accept PDF invoices up to 10 MB through authorized restricted signed URLs and server validation. Immutable submission paths and exact object generations support repeat-safe processing. Retain originals for 90 days; proposed retention age starts at successful upload. Enforce minimum retention and scheduled expiry through compatible bucket settings and cleanup. Verify soft-delete, object versions, backups and deletion timing so hidden copies do not silently extend retention. Treat document content as untrusted. No public access or overseas replication. Storage settings and residency require verification.
- Service: Google Cloud Storage
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d66696c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-events: Durable processing messages

- Responsibility: Proposed Pub/Sub topic and authenticated push subscription for object-finalization events and approved-delivery outbox references. Carry opaque identifiers, never invoice contents or extracted fields. Configure Australian message storage and regional publishing/delivery behavior where supported; verify policies and endpoints independently. At-least-once delivery uses transactional state, leases and stable keys to handle duplicates. Bounded retries and dead-letter forwarding require scoped service identities. Expired or deleted submissions must not be recreated by late events. Topic, subscriptions, permissions and connections require implementation.
- Service: Google Cloud Pub/Sub
- Provider / placement: gcp / Australia-only message policy — unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6576656e7473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-dead-letter: Failed processing messages

- Responsibility: Separate Pub/Sub dead-letter topic and retained operator subscription for exhausted attempts. Store opaque invoice references and safe failure metadata, not PDF contents or extracted personal data. Apply and verify Australian message storage policy. Alert operators and support audited replay with original keys only while the underlying submission remains eligible; expired submissions cannot be resurrected. Poison documents remain visible for manual handling. Operational ownership and recovery targets remain open.
- Service: Google Cloud Pub/Sub
- Provider / placement: gcp / Australia-only message policy — unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d646561642d6c6574746572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-state: Review queue and delivery ledger

- Responsibility: Proposed regional Firestore database in Sydney, subject to verification. Store exact source generations, fields, corrections, confidence/evidence, workflow state, approval history and accounting receipt references. Retain extraction audit history for 90 days; proposed age starts when each audit event is recorded. Application cleanup enforces expiry; asynchronous TTL alone does not prove an exact deletion deadline. Backup and recovery copies must follow the Australian boundary and reviewed retention policy. Extracted-field and minimal delivery-ledger lifetimes need explicit definition before implementation; never silently delete deduplication protection. Transactions claim work and commit approval with an outbox entry. Stable submission keys prevent repeated events creating internal duplicates. Fingerprints flag identical reuploads; business duplicate rules remain open. Browser clients cannot directly write workflow state. Edits invalidate approval.
- Service: Cloud Firestore
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-extractor: Invoice field extraction

- Responsibility: Candidate Document AI Invoice Parser extracts supplier, invoice date, total and currency, including supported scanned PDFs. Australian processor availability, processing location, version, transient retention and input/page limits are UNVERIFIED. Do not send documents to an overseas endpoint. If a compliant Australian processor is unavailable, retain this extraction responsibility as blocked engineering work and evaluate an Australia-hosted implementation rather than silently changing residency. Application maps fields into a validated schema and retains confidence and source evidence for review. Missing or ambiguous values require review; never fabricate or auto-approve. Verify handling of 10 MB PDFs and approximately 500 daily submissions with representative documents.
- Service: Google Cloud Document AI
- Provider / placement: gcp / Australian processing endpoint — unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d657874726163746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-recovery: Recover work and enforce retention

- Responsibility: Proposed Cloud Scheduler job invokes an authenticated application recovery route. Application recovers pending outbox entries and expired leases, reconciles finalized uploads and republishes eligible work with unchanged keys. Also checks 90-day original/audit expiry, performs idempotent cleanup and reports failures. Retention enforcement must cover generations, retained copies and associated records without losing required duplicate protection; retention exceptions cannot be invented. Repeated sweeps are harmless and cannot resurrect expired work. Schedule and alert thresholds are engineering proposals. Sydney availability and authenticated integration require verification.
- Service: Google Cloud Scheduler
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d7265636f76657279
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-secrets: Accounting connection credentials

- Responsibility: Proposed Secret Manager storage for accounting credentials supplied by an administrator outside the diagram and chat. The administrator also supplies the accounting endpoint through controlled application configuration; the external accounting system is not provisioned or modified. Explicit Australian secret replication is proposed, subject to verification; no implicit global replication assumption. Only the application runtime identity accesses necessary versions. Proposed provisioning inputs reference secrets rather than embedding credential values in Terraform state or logs. API authentication, rotation and regional service behavior require engineering and verification.
- Service: Secret Manager
- Provider / placement: gcp / Australian replication — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component accounting-api: Existing accounting API

- Responsibility: Client-owned existing service outside provisioning scope; do not create, import or modify it. An administrator will supply its endpoint and credentials through controlled configuration and secret inputs outside the diagram. Hosting, processing and storage locations remain unknown; this ownership clarification does not establish Australian residency. Sending invoice fields remains blocked until compatibility with Australian residency is established. Receive only the approved revision with a stable delivery key. Establish native idempotency or authoritative lookup before automatic retries. After a timeout with possible acceptance, mark uncertain and reconcile rather than blindly resend. Without downstream duplicate protection, exactly-once creation cannot be guaranteed. Existing accounting retention is separate from the proposed intake retention and remains unverified. Endpoint schema, authentication and reconciliation behavior require evidence.
- Service: Existing accounting API
- Provider / placement: tools / Existing location — Australian residency to confirm
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6163636f756e74696e672d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Interfaces

### users-app: invoice-users → invoice-app

- Drawn payload/purpose: HTTPS: signed-in upload; reviewer-only correction and approval
- Contract task: TASK-CONTRACT-75736572732d617070
- Integration task: TASK-INTEGRATION-75736572732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### users-identity: invoice-users → invoice-identity

- Drawn payload/purpose: Sign in and receive user token
- Contract task: TASK-CONTRACT-75736572732d6964656e74697479
- Integration task: TASK-INTEGRATION-75736572732d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: invoice-app → invoice-identity

- Drawn payload/purpose: Verify tokens; server enforces uploader and reviewer permissions
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### users-upload: invoice-users → invoice-files

- Drawn payload/purpose: HTTPS signed upload: PDF up to 10 MB
- Contract task: TASK-CONTRACT-75736572732d75706c6f6164
- Integration task: TASK-INTEGRATION-75736572732d75706c6f6164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-files: invoice-app → invoice-files

- Drawn payload/purpose: Scoped identity: exact-generation reads and retention cleanup
- Contract task: TASK-CONTRACT-6170702d66696c6573
- Integration task: TASK-INTEGRATION-6170702d66696c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### files-events: invoice-files → invoice-events

- Drawn payload/purpose: Object-finalization notification with generation
- Contract task: TASK-CONTRACT-66696c65732d6576656e7473
- Integration task: TASK-INTEGRATION-66696c65732d6576656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### events-app: invoice-events → invoice-app

- Drawn payload/purpose: OIDC-authenticated push; acknowledge durable completion
- Contract task: TASK-CONTRACT-6576656e74732d617070
- Integration task: TASK-INTEGRATION-6576656e74732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### events-dead-letter: invoice-events → invoice-dead-letter

- Drawn payload/purpose: Forward exhausted attempts with scoped permissions
- Contract task: TASK-CONTRACT-6576656e74732d646561642d6c6574746572
- Integration task: TASK-INTEGRATION-6576656e74732d646561642d6c6574746572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-state: invoice-app → invoice-state

- Drawn payload/purpose: Transactional workflow, approvals, outbox and 90-day audit cleanup
- Contract task: TASK-CONTRACT-6170702d7374617465
- Integration task: TASK-INTEGRATION-6170702d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-extraction: invoice-app → invoice-extractor

- Drawn payload/purpose: PDF processing — blocked pending Australian endpoint verification
- Contract task: TASK-CONTRACT-6170702d65787472616374696f6e
- Integration task: TASK-INTEGRATION-6170702d65787472616374696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### scheduler-app: invoice-recovery → invoice-app

- Drawn payload/purpose: OIDC-authenticated recovery and retention sweep
- Contract task: TASK-CONTRACT-7363686564756c65722d617070
- Integration task: TASK-INTEGRATION-7363686564756c65722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-events: invoice-app → invoice-events

- Drawn payload/purpose: Publish eligible approved-delivery and recovery references
- Contract task: TASK-CONTRACT-6170702d6576656e7473
- Integration task: TASK-INTEGRATION-6170702d6576656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: invoice-app → invoice-secrets

- Drawn payload/purpose: Scoped runtime access to administrator-supplied accounting credentials
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-accounting: invoice-app → accounting-api

- Drawn payload/purpose: Approved revision to configured external endpoint; residency and retry safety un
- Contract task: TASK-CONTRACT-6170702d6163636f756e74696e67
- Integration task: TASK-INTEGRATION-6170702d6163636f756e74696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-75736572732d617070 — Define Uploaders and reviewers → Invoice intake and review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-app: HTTPS: signed-in upload; reviewer-only correction and approval. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-75736572732d6964656e74697479 — Define Uploaders and reviewers → User sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-users, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-identity: Sign in and receive user token. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-identity
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6964656e74697479 — Define Invoice intake and review application → User sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-identity: Verify tokens; server enforces uploader and reviewer permissions. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-identity
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-75736572732d75706c6f6164 — Define Uploaders and reviewers → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-users, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection users-upload: HTTPS signed upload: PDF up to 10 MB. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge users-upload
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d66696c6573 — Define Invoice intake and review application → Private invoice PDFs

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-files: Scoped identity: exact-generation reads and retention cleanup. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-files
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-66696c65732d6576656e7473 — Define Private invoice PDFs → Durable processing messages

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-files, invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection files-events: Object-finalization notification with generation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge files-events
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6576656e74732d617070 — Define Durable processing messages → Invoice intake and review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-events, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection events-app: OIDC-authenticated push; acknowledge durable completion. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge events-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6576656e74732d646561642d6c6574746572 — Define Durable processing messages → Failed processing messages

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-events, invoice-dead-letter
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection events-dead-letter: Forward exhausted attempts with scoped permissions. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge events-dead-letter
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d7374617465 — Define Invoice intake and review application → Review queue and delivery ledger

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-state: Transactional workflow, approvals, outbox and 90-day audit cleanup. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d65787472616374696f6e — Define Invoice intake and review application → Invoice field extraction

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-extractor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-extraction: PDF processing — blocked pending Australian endpoint verification. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-extraction
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7363686564756c65722d617070 — Define Recover work and enforce retention → Invoice intake and review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-recovery, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection scheduler-app: OIDC-authenticated recovery and retention sweep. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge scheduler-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6576656e7473 — Define Invoice intake and review application → Durable processing messages

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-events: Publish eligible approved-delivery and recovery references. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-events
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d73656372657473 — Define Invoice intake and review application → Accounting connection credentials

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-secrets: Scoped runtime access to administrator-supplied accounting credentials. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-secrets
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6163636f756e74696e67 — Define Invoice intake and review application → Existing accounting API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: invoice-app, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-accounting: Approved revision to configured external endpoint; residency and retry safety un. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-accounting
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-696e766f6963652d7573657273 — Integrate existing Uploaders and reviewers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d617070, TASK-CONTRACT-75736572732d6964656e74697479, TASK-CONTRACT-75736572732d75706c6f6164
- Components: invoice-users
- Generated files: No implementation files generated yet
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Existing people using a browser, outside provisioning scope. Twenty signed-in staff and three reviewers are stated; whether reviewers are included in the twenty is unspecified. Uploaders submit PDF invoices up to 10 MB; only authorized reviewers inspect the source and extracted fields, correct them and explicitly approve or reject. Ordinary uploaders cannot approve. Enforce these permissions server-side; actual user directory and role assignments remain to be established. Documents may contain personal data.
2. Verify Approval workflow on tools in Existing users — location to confirm; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-users
- Application/configuration and tests for Uploaders and reviewers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d617070 — Implement Invoice intake and review application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d617070, TASK-CONTRACT-6170702d6964656e74697479, TASK-CONTRACT-6170702d66696c6573, TASK-CONTRACT-6576656e74732d617070, TASK-CONTRACT-6170702d7374617465, TASK-CONTRACT-6170702d65787472616374696f6e, TASK-CONTRACT-7363686564756c65722d617070, TASK-CONTRACT-6170702d6576656e7473, TASK-CONTRACT-6170702d73656372657473, TASK-CONTRACT-6170702d6163636f756e74696e67
- Components: invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency, ai-invoice-retention, ai-invoice-capacity, ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Proposed Cloud Run deployment containing upload/review UI, API, extraction and accounting delivery handlers. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Verify user tokens and authoritative roles on every operation; deny approval to ordinary uploaders even through direct API calls. Test denied approval and role changes. Isolate authenticated service-only routes. Plan for approximately 500 PDFs per day, each up to 10 MB; peak load and page counts remain unknown. Enforce size and PDF validation server-side and select a processing path compatible with verified processor limits. Issue narrowly scoped expiring upload URLs. Reviewers inspect PDFs and editable fields. Transactions enforce approval of an immutable revision; edits invalidate approval. Use exact object generations, durable leases and stable operation keys. Keep unsupported documents and failures visible. Run processing only through verified Australian endpoints; no overseas fallback. Avoid invoice contents, personal fields and credentials in operational logs; regional log storage and platform metadata residency require verification. Recovery performs retention cleanup. An administrator supplies the existing accounting endpoint and credentials through controlled configuration and secret inputs, never browser requests or diagram text. Application, container artifact, authorization and connections require implementation.
2. Verify Google Cloud Run on gcp in australia-southeast1 — proposed, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Run; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.; REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-app
- Application/configuration and tests for Invoice intake and review application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6964656e74697479 — Implement User sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d6964656e74697479, TASK-CONTRACT-6170702d6964656e74697479
- Components: invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Responsibility from the board: Proposed Identity Platform authentication for the stated twenty signed-in staff and three reviewers; adapt to existing company sign-in when known. Authentication alone does not grant approval authority. Application checks authoritative upload/review permissions on every operation and denies approval to ordinary uploaders. Proposed role assignments are administrator-controlled, never self-selected by users. Do not send PDFs or extracted invoice fields to the identity service. User profile and authentication metadata locations require separate residency assessment; an Australian application region does not prove identity residency. Enrollment and operational ownership remain open. No anonymous invoice access.
2. Verify Identity Platform on gcp in Identity residency unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Identity Platform; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-identity
- Application/configuration and tests for User sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d66696c6573 — Implement Private invoice PDFs

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-75736572732d75706c6f6164, TASK-CONTRACT-6170702d66696c6573, TASK-CONTRACT-66696c65732d6576656e7473
- Components: invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-residency, ai-invoice-retention, ai-invoice-capacity

### Implementation steps

1. Responsibility from the board: Proposed private Cloud Storage bucket in Sydney, subject to verification. Accept PDF invoices up to 10 MB through authorized restricted signed URLs and server validation. Immutable submission paths and exact object generations support repeat-safe processing. Retain originals for 90 days; proposed retention age starts at successful upload. Enforce minimum retention and scheduled expiry through compatible bucket settings and cleanup. Verify soft-delete, object versions, backups and deletion timing so hidden copies do not silently extend retention. Treat document content as untrusted. No public access or overseas replication. Storage settings and residency require verification.
2. Verify Google Cloud Storage on gcp in australia-southeast1 — proposed, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Storage; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-files
- Application/configuration and tests for Private invoice PDFs

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d6576656e7473 — Implement Durable processing messages

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-66696c65732d6576656e7473, TASK-CONTRACT-6576656e74732d617070, TASK-CONTRACT-6576656e74732d646561642d6c6574746572, TASK-CONTRACT-6170702d6576656e7473
- Components: invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-idempotency, ai-invoice-residency, ai-invoice-capacity

### Implementation steps

1. Responsibility from the board: Proposed Pub/Sub topic and authenticated push subscription for object-finalization events and approved-delivery outbox references. Carry opaque identifiers, never invoice contents or extracted fields. Configure Australian message storage and regional publishing/delivery behavior where supported; verify policies and endpoints independently. At-least-once delivery uses transactional state, leases and stable keys to handle duplicates. Bounded retries and dead-letter forwarding require scoped service identities. Expired or deleted submissions must not be recreated by late events. Topic, subscriptions, permissions and connections require implementation.
2. Verify Google Cloud Pub/Sub on gcp in Australia-only message policy — unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Pub/Sub; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-events
- Application/configuration and tests for Durable processing messages

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d646561642d6c6574746572 — Implement Failed processing messages

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6576656e74732d646561642d6c6574746572
- Components: invoice-dead-letter
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-residency

### Implementation steps

1. Responsibility from the board: Separate Pub/Sub dead-letter topic and retained operator subscription for exhausted attempts. Store opaque invoice references and safe failure metadata, not PDF contents or extracted personal data. Apply and verify Australian message storage policy. Alert operators and support audited replay with original keys only while the underlying submission remains eligible; expired submissions cannot be resurrected. Poison documents remain visible for manual handling. Operational ownership and recovery targets remain open.
2. Verify Google Cloud Pub/Sub on gcp in Australia-only message policy — unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Pub/Sub; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-dead-letter
- Application/configuration and tests for Failed processing messages

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d7374617465 — Implement Review queue and delivery ledger

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d7374617465
- Components: invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency, ai-invoice-retention

### Implementation steps

1. Responsibility from the board: Proposed regional Firestore database in Sydney, subject to verification. Store exact source generations, fields, corrections, confidence/evidence, workflow state, approval history and accounting receipt references. Retain extraction audit history for 90 days; proposed age starts when each audit event is recorded. Application cleanup enforces expiry; asynchronous TTL alone does not prove an exact deletion deadline. Backup and recovery copies must follow the Australian boundary and reviewed retention policy. Extracted-field and minimal delivery-ledger lifetimes need explicit definition before implementation; never silently delete deduplication protection. Transactions claim work and commit approval with an outbox entry. Stable submission keys prevent repeated events creating internal duplicates. Fingerprints flag identical reuploads; business duplicate rules remain open. Browser clients cannot directly write workflow state. Edits invalidate approval.
2. Verify Cloud Firestore on gcp in australia-southeast1 — proposed, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Cloud Firestore; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-state
- Application/configuration and tests for Review queue and delivery ledger

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d657874726163746f72 — Implement Invoice field extraction

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d65787472616374696f6e
- Components: invoice-extractor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction, ai-invoice-residency, ai-invoice-capacity

### Implementation steps

1. Responsibility from the board: Candidate Document AI Invoice Parser extracts supplier, invoice date, total and currency, including supported scanned PDFs. Australian processor availability, processing location, version, transient retention and input/page limits are UNVERIFIED. Do not send documents to an overseas endpoint. If a compliant Australian processor is unavailable, retain this extraction responsibility as blocked engineering work and evaluate an Australia-hosted implementation rather than silently changing residency. Application maps fields into a validated schema and retains confidence and source evidence for review. Missing or ambiguous values require review; never fabricate or auto-approve. Verify handling of 10 MB PDFs and approximately 500 daily submissions with representative documents.
2. Verify Google Cloud Document AI on gcp in Australian processing endpoint — unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Document AI; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-extractor
- Application/configuration and tests for Invoice field extraction

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d7265636f76657279 — Implement Recover work and enforce retention

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7363686564756c65722d617070
- Components: invoice-recovery
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-idempotency, ai-invoice-retention

### Implementation steps

1. Responsibility from the board: Proposed Cloud Scheduler job invokes an authenticated application recovery route. Application recovers pending outbox entries and expired leases, reconciles finalized uploads and republishes eligible work with unchanged keys. Also checks 90-day original/audit expiry, performs idempotent cleanup and reports failures. Retention enforcement must cover generations, retained copies and associated records without losing required duplicate protection; retention exceptions cannot be invented. Repeated sweeps are harmless and cannot resurrect expired work. Schedule and alert thresholds are engineering proposals. Sydney availability and authenticated integration require verification.
2. Verify Google Cloud Scheduler on gcp in australia-southeast1 — proposed, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Google Cloud Scheduler; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-recovery
- Application/configuration and tests for Recover work and enforce retention

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-696e766f6963652d73656372657473 — Implement Accounting connection credentials

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d73656372657473
- Components: invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Proposed Secret Manager storage for accounting credentials supplied by an administrator outside the diagram and chat. The administrator also supplies the accounting endpoint through controlled application configuration; the external accounting system is not provisioned or modified. Explicit Australian secret replication is proposed, subject to verification; no implicit global replication assumption. Only the application runtime identity accesses necessary versions. Proposed provisioning inputs reference secrets rather than embedding credential values in Terraform state or logs. API authentication, rotation and regional service behavior require engineering and verification.
2. Verify Secret Manager on gcp in Australian replication — proposed, unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Secret Manager; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component invoice-secrets
- Application/configuration and tests for Accounting connection credentials

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6163636f756e74696e672d617069 — Integrate existing Existing accounting API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6163636f756e74696e67
- Components: accounting-api
- Generated files: No implementation files generated yet
- Requirements: ai-invoice-idempotency, ai-invoice-approval, ai-invoice-residency, ai-invoice-accounting-boundary

### Implementation steps

1. Responsibility from the board: Client-owned existing service outside provisioning scope; do not create, import or modify it. An administrator will supply its endpoint and credentials through controlled configuration and secret inputs outside the diagram. Hosting, processing and storage locations remain unknown; this ownership clarification does not establish Australian residency. Sending invoice fields remains blocked until compatibility with Australian residency is established. Receive only the approved revision with a stable delivery key. Establish native idempotency or authoritative lookup before automatic retries. After a timeout with possible acceptance, mark uncertain and reconcile rather than blindly resend. Without downstream duplicate protection, exactly-once creation cannot be guaranteed. Existing accounting retention is separate from the proposed intake retention and remains unverified. Endpoint schema, authentication and reconciliation behavior require evidence.
2. Verify Existing accounting API on tools in Existing location — Australian residency to confirm; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.; REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.; REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.; REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component accounting-api
- Application/configuration and tests for Existing accounting API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-75736572732d617070 — Wire Uploaders and reviewers to Invoice intake and review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d617070, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-app carrying HTTPS: signed-in upload; reviewer-only correction and approval, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-75736572732d6964656e74697479 — Wire Uploaders and reviewers to User sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d6964656e74697479, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d6964656e74697479
- Components: invoice-users, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-identity carrying Sign in and receive user token, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-identity
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6964656e74697479 — Wire Invoice intake and review application to User sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6964656e74697479, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-identity carrying Verify tokens; server enforces uploader and reviewer permissions, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-identity
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-75736572732d75706c6f6164 — Wire Uploaders and reviewers to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-75736572732d75706c6f6164, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d66696c6573
- Components: invoice-users, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge users-upload carrying HTTPS signed upload: PDF up to 10 MB, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation users-upload
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d66696c6573 — Wire Invoice intake and review application to Private invoice PDFs

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d66696c6573, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573
- Components: invoice-app, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-files carrying Scoped identity: exact-generation reads and retention cleanup, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-files
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-66696c65732d6576656e7473 — Wire Private invoice PDFs to Durable processing messages

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-66696c65732d6576656e7473, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6576656e7473
- Components: invoice-files, invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge files-events carrying Object-finalization notification with generation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation files-events
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6576656e74732d617070 — Wire Durable processing messages to Invoice intake and review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6576656e74732d617070, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6576656e7473
- Components: invoice-events, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge events-app carrying OIDC-authenticated push; acknowledge durable completion, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation events-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6576656e74732d646561642d6c6574746572 — Wire Durable processing messages to Failed processing messages

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6576656e74732d646561642d6c6574746572, TASK-RESOURCE-696e766f6963652d6576656e7473, TASK-RESOURCE-696e766f6963652d646561642d6c6574746572
- Components: invoice-events, invoice-dead-letter
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge events-dead-letter carrying Forward exhausted attempts with scoped permissions, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation events-dead-letter
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d7374617465 — Wire Invoice intake and review application to Review queue and delivery ledger

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d7374617465, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d7374617465
- Components: invoice-app, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-state carrying Transactional workflow, approvals, outbox and 90-day audit cleanup, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d65787472616374696f6e — Wire Invoice intake and review application to Invoice field extraction

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d65787472616374696f6e, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d657874726163746f72
- Components: invoice-app, invoice-extractor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-extraction carrying PDF processing — blocked pending Australian endpoint verification, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-extraction
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7363686564756c65722d617070 — Wire Recover work and enforce retention to Invoice intake and review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7363686564756c65722d617070, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d7265636f76657279
- Components: invoice-recovery, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge scheduler-app carrying OIDC-authenticated recovery and retention sweep, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation scheduler-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6576656e7473 — Wire Invoice intake and review application to Durable processing messages

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6576656e7473, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6576656e7473
- Components: invoice-app, invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-events carrying Publish eligible approved-delivery and recovery references, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-events
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d73656372657473 — Wire Invoice intake and review application to Accounting connection credentials

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d73656372657473, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d73656372657473
- Components: invoice-app, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-secrets carrying Scoped runtime access to administrator-supplied accounting credentials, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-secrets
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6163636f756e74696e67 — Wire Invoice intake and review application to Existing accounting API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6163636f756e74696e67, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-6163636f756e74696e672d617069
- Components: invoice-app, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-accounting carrying Approved revision to configured external endpoint; residency and retry safety un, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-accounting
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-75736572732d617070 — Verify live Uploaders and reviewers → Invoice intake and review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d617070
- Components: invoice-users, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-75736572732d6964656e74697479 — Verify live Uploaders and reviewers → User sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d6964656e74697479
- Components: invoice-users, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-identity with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-identity

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6964656e74697479 — Verify live Invoice intake and review application → User sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6964656e74697479
- Components: invoice-app, invoice-identity
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-identity with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-identity

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-75736572732d75706c6f6164 — Verify live Uploaders and reviewers → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-75736572732d75706c6f6164
- Components: invoice-users, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge users-upload with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence users-upload

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d66696c6573 — Verify live Invoice intake and review application → Private invoice PDFs

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d66696c6573
- Components: invoice-app, invoice-files
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-files with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-files

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-66696c65732d6576656e7473 — Verify live Private invoice PDFs → Durable processing messages

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-66696c65732d6576656e7473
- Components: invoice-files, invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge files-events with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence files-events

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6576656e74732d617070 — Verify live Durable processing messages → Invoice intake and review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6576656e74732d617070
- Components: invoice-events, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge events-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence events-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6576656e74732d646561642d6c6574746572 — Verify live Durable processing messages → Failed processing messages

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6576656e74732d646561642d6c6574746572
- Components: invoice-events, invoice-dead-letter
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge events-dead-letter with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence events-dead-letter

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d7374617465 — Verify live Invoice intake and review application → Review queue and delivery ledger

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d7374617465
- Components: invoice-app, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e — Verify live Invoice intake and review application → Invoice field extraction

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d65787472616374696f6e
- Components: invoice-app, invoice-extractor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-extraction with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-extraction

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7363686564756c65722d617070 — Verify live Recover work and enforce retention → Invoice intake and review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7363686564756c65722d617070
- Components: invoice-recovery, invoice-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge scheduler-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence scheduler-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6576656e7473 — Verify live Invoice intake and review application → Durable processing messages

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6576656e7473
- Components: invoice-app, invoice-events
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-events with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-events

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d73656372657473 — Verify live Invoice intake and review application → Accounting connection credentials

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d73656372657473
- Components: invoice-app, invoice-secrets
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-secrets with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-secrets

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67 — Verify live Invoice intake and review application → Existing accounting API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6163636f756e74696e67
- Components: invoice-app, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-accounting with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-accounting

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e — Verify REQ-003: Each accepted PDF submission shall produce a durable review record containing supplier, invoice date, total and currency, or an explicit processing failure; missing or uncertain values shall be visible for reviewer correction. Accuracy targets remain open.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d657874726163746f72, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-app, invoice-files, invoice-extractor, invoice-state
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-extraction

### Implementation steps

1. Basis: “Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue.”; rationale: Provides the requested reviewable result while keeping uncertain extraction visible instead of silently accepting incorrect financial data.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379 — Verify REQ-004: Repeated deliveries, concurrent processing and recovery shall not create duplicate internal invoices or accounting entries. Use stable operation identities and conditional state transitions; automatic accounting retries shall remain blocked until downstream idempotency or authoritative reconciliation is established.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6576656e7473, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d7265636f76657279, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6576656e74732d646561642d6c6574746572, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-events, invoice-app, invoice-state, invoice-recovery, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-idempotency

### Implementation steps

1. Basis: “Delivery can repeat; retries must not create duplicate invoices.”; rationale: Repeated events and uncertain API responses can create duplicate financial records. Durable internal deduplication and downstream idempotency or reconciliation are both necessary; downstream capability remains unverified.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c — Verify REQ-005: Accounting delivery shall require an authorized reviewer's recorded approval of the exact submitted revision. Changes shall invalidate approval, and the system shall retain the approver, revision, delivery state and accounting receipt without exposing credentials.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-75736572732d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-users, invoice-identity, invoice-app, invoice-state, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-approval

### Implementation steps

1. Basis: “A reviewer approves a result before it is sent to our existing accounting API.”; rationale: Prevents unreviewed or subsequently changed extraction results from being posted as approved invoices; server authorization and an approval history are proposed enforcement mechanisms.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379 — Verify REQ-006: Invoice documents and extracted data shall remain stored and processed in Australia across application, extraction, messaging, logs and recovery copies. Verify service-specific locations before enabling each data path; no overseas fallback is authorized. Accounting destination compatibility remains unresolved.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6576656e7473, TASK-RESOURCE-696e766f6963652d646561642d6c6574746572, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d657874726163746f72, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6576656e74732d646561642d6c6574746572, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-app, invoice-files, invoice-events, invoice-dead-letter, invoice-state, invoice-extractor, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-residency

### Implementation steps

1. Basis: “they may contain personal data” and “Keep documents and extracted data in Australia; flag unverified service availability.”; rationale: Personal invoice information could leave Australia through extraction, messaging, logs, backups or accounting delivery even when the main bucket is Australian.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e — Verify REQ-007: Retain original PDFs and extraction audit history for 90 days and implement monitored expiry covering retained copies. Proposed clocks are upload time for originals and event time for audit entries. Deletion timing, extracted-field retention and the minimal duplicate-prevention ledger lifetime remain to be resolved without silently weakening retention or retry safety.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d7265636f76657279, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-files, invoice-state, invoice-app, invoice-recovery
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-retention

### Implementation steps

1. Basis: “Keep originals and extraction audit history for 90 days.”; rationale: Cleanup must preserve the required evidence period while preventing unnoticed retention in object generations or recovery copies; deletion must also preserve duplicate-prevention safety.
2. Implement a check for Original and extraction audit retention == 90 days; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6361706163697479 — Verify REQ-008: The intake workflow shall support approximately 500 PDF invoices per day with files up to 10 MB, enforcing upload limits server-side and validating processor size/page compatibility. Unsupported documents shall remain visible for manual handling. Peak throughput, page distribution and completion-time targets remain unconfirmed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6576656e7473, TASK-RESOURCE-696e766f6963652d657874726163746f72, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6576656e74732d646561642d6c6574746572, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-app, invoice-files, invoice-events, invoice-extractor
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-capacity

### Implementation steps

1. Basis: “PDF invoices up to 10 MB, around 500 per day”; rationale: Large or scanned invoices can exceed processor limits; daily volume alone does not establish peak capacity or processing latency.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279 — Verify REQ-009: Integrate with the existing accounting API as an external reference without provisioning or modifying it. Accept its endpoint through controlled administrator configuration and credentials through protected secret inputs; expose neither credentials to browser clients nor secret values in diagrams, logs or Terraform state. Verify authentication, Australian residency and safe retry behavior before enabling delivery.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: invoice-app, invoice-secrets, accounting-api
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-invoice-accounting-boundary

### Implementation steps

1. Basis: “The accounting system already exists. An administrator will supply its endpoint and credentials; treat it as external, not a new system to provision.”; rationale: Preserves the existing accounting system's ownership and prevents credentials from being exposed through the browser, diagram or generated configuration. Secret handling and connection tests remain implementation work.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-009

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6576656e7473, TASK-RESOURCE-696e766f6963652d646561642d6c6574746572, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d657874726163746f72, TASK-RESOURCE-696e766f6963652d7265636f76657279, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-75736572732d617070, TASK-INTEGRATION-75736572732d6964656e74697479, TASK-INTEGRATION-6170702d6964656e74697479, TASK-INTEGRATION-75736572732d75706c6f6164, TASK-INTEGRATION-6170702d66696c6573, TASK-INTEGRATION-66696c65732d6576656e7473, TASK-INTEGRATION-6576656e74732d617070, TASK-INTEGRATION-6576656e74732d646561642d6c6574746572, TASK-INTEGRATION-6170702d7374617465, TASK-INTEGRATION-6170702d65787472616374696f6e, TASK-INTEGRATION-7363686564756c65722d617070, TASK-INTEGRATION-6170702d6576656e7473, TASK-INTEGRATION-6170702d73656372657473, TASK-INTEGRATION-6170702d6163636f756e74696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-696e766f6963652d7573657273, TASK-RESOURCE-696e766f6963652d617070, TASK-RESOURCE-696e766f6963652d6964656e74697479, TASK-RESOURCE-696e766f6963652d66696c6573, TASK-RESOURCE-696e766f6963652d6576656e7473, TASK-RESOURCE-696e766f6963652d646561642d6c6574746572, TASK-RESOURCE-696e766f6963652d7374617465, TASK-RESOURCE-696e766f6963652d657874726163746f72, TASK-RESOURCE-696e766f6963652d7265636f76657279, TASK-RESOURCE-696e766f6963652d73656372657473, TASK-RESOURCE-6163636f756e74696e672d617069, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-75736572732d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6576656e74732d646561642d6c6574746572, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e, TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379, TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c, TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379, TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e, TASK-ACCEPTANCE-61692d696e766f6963652d6361706163697479, TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279, TASK-INTEGRATION-LIVE-75736572732d617070, TASK-INTEGRATION-LIVE-75736572732d6964656e74697479, TASK-INTEGRATION-LIVE-6170702d6964656e74697479, TASK-INTEGRATION-LIVE-75736572732d75706c6f6164, TASK-INTEGRATION-LIVE-6170702d66696c6573, TASK-INTEGRATION-LIVE-66696c65732d6576656e7473, TASK-INTEGRATION-LIVE-6576656e74732d617070, TASK-INTEGRATION-LIVE-6576656e74732d646561642d6c6574746572, TASK-INTEGRATION-LIVE-6170702d7374617465, TASK-INTEGRATION-LIVE-6170702d65787472616374696f6e, TASK-INTEGRATION-LIVE-7363686564756c65722d617070, TASK-INTEGRATION-LIVE-6170702d6576656e7473, TASK-INTEGRATION-LIVE-6170702d73656372657473, TASK-INTEGRATION-LIVE-6170702d6163636f756e74696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-003 (ai-invoice-extraction) → TASK-ACCEPTANCE-61692d696e766f6963652d65787472616374696f6e; Proposed; needs confirmation
- REQ-004 (ai-invoice-idempotency) → TASK-ACCEPTANCE-61692d696e766f6963652d6964656d706f74656e6379; Proposed; needs confirmation
- REQ-005 (ai-invoice-approval) → TASK-ACCEPTANCE-61692d696e766f6963652d617070726f76616c; Proposed; needs confirmation
- REQ-006 (ai-invoice-residency) → TASK-ACCEPTANCE-61692d696e766f6963652d7265736964656e6379; Proposed; needs confirmation
- REQ-007 (ai-invoice-retention) → TASK-ACCEPTANCE-61692d696e766f6963652d726574656e74696f6e; Proposed; needs confirmation
- REQ-008 (ai-invoice-capacity) → TASK-ACCEPTANCE-61692d696e766f6963652d6361706163697479; Proposed; needs confirmation
- REQ-009 (ai-invoice-accounting-boundary) → TASK-ACCEPTANCE-61692d696e766f6963652d6163636f756e74696e672d626f756e64617279; Proposed; needs confirmation
