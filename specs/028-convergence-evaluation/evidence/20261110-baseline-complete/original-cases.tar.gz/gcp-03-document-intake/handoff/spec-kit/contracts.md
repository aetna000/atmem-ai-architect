# Component and interface contracts

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component invoice-users: Uploaders and reviewers

- Responsibility: Existing people using a browser, outside provisioning scope. Twenty signed-in staff and three reviewers are stated; whether reviewers are included in the twenty is unspecified. Uploaders submit PDF invoices up to 10 MB; only authorized reviewers inspect the source and extracted fields, correct them and explicitly approve or reject. Ordinary uploaders cannot approve. Enforce these permissions server-side; actual user directory and role assignments remain to be established. Documents may contain personal data.
- Service: Approval workflow
- Provider / placement: tools / Existing users — location to confirm
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-696e766f6963652d7573657273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component invoice-app: Invoice intake and review application

- Responsibility: Proposed Cloud Run deployment containing upload/review UI, API, extraction and accounting delivery handlers. Support the stated twenty signed-in staff and three reviewers without assuming group overlap. Verify user tokens and authoritative roles on every operation; deny approval to ordinary uploaders even through direct API calls. Test denied approval and role changes. Isolate authenticated service-only routes. Plan for approximately 500 PDFs per day, each up to 10 MB; peak load and page counts remain unknown. Enforce size and PDF validation server-side and select a processing path compatible with verified processor limits. Issue narrowly scoped expiring upload URLs. Reviewers inspect PDFs and editable fields. Transactions enforce approval of an immutable revision; edits invalidate approval. Use exact object generations, durable leases and stable operation keys. Keep unsupported documents and failures visible. Run processing only through verified Australian endpoints; no overseas fallback. Avoid invoice contents, personal fields and credentials in operational logs; regional log storage and platform metadata residency require verification. Recovery performs retention cleanup. An administrator supplies the existing accounting endpoint and credentials through controlled configuration and secret inputs, never browser requests or diagram text. Application, container artifact, authorization and connections require implementation.
- Service: Google Cloud Run
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-identity: User sign-in

- Responsibility: Proposed Identity Platform authentication for the stated twenty signed-in staff and three reviewers; adapt to existing company sign-in when known. Authentication alone does not grant approval authority. Application checks authoritative upload/review permissions on every operation and denies approval to ordinary uploaders. Proposed role assignments are administrator-controlled, never self-selected by users. Do not send PDFs or extracted invoice fields to the identity service. User profile and authentication metadata locations require separate residency assessment; an Australian application region does not prove identity residency. Enrollment and operational ownership remain open. No anonymous invoice access.
- Service: Identity Platform
- Provider / placement: gcp / Identity residency unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-files: Private invoice PDFs

- Responsibility: Proposed private Cloud Storage bucket in Sydney, subject to verification. Accept PDF invoices up to 10 MB through authorized restricted signed URLs and server validation. Immutable submission paths and exact object generations support repeat-safe processing. Retain originals for 90 days; proposed retention age starts at successful upload. Enforce minimum retention and scheduled expiry through compatible bucket settings and cleanup. Verify soft-delete, object versions, backups and deletion timing so hidden copies do not silently extend retention. Treat document content as untrusted. No public access or overseas replication. Storage settings and residency require verification.
- Service: Google Cloud Storage
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d66696c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-events: Durable processing messages

- Responsibility: Proposed Pub/Sub topic and authenticated push subscription for object-finalization events and approved-delivery outbox references. Carry opaque identifiers, never invoice contents or extracted fields. Configure Australian message storage and regional publishing/delivery behavior where supported; verify policies and endpoints independently. At-least-once delivery uses transactional state, leases and stable keys to handle duplicates. Bounded retries and dead-letter forwarding require scoped service identities. Expired or deleted submissions must not be recreated by late events. Topic, subscriptions, permissions and connections require implementation.
- Service: Google Cloud Pub/Sub
- Provider / placement: gcp / Australia-only message policy — unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d6576656e7473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-dead-letter: Failed processing messages

- Responsibility: Separate Pub/Sub dead-letter topic and retained operator subscription for exhausted attempts. Store opaque invoice references and safe failure metadata, not PDF contents or extracted personal data. Apply and verify Australian message storage policy. Alert operators and support audited replay with original keys only while the underlying submission remains eligible; expired submissions cannot be resurrected. Poison documents remain visible for manual handling. Operational ownership and recovery targets remain open.
- Service: Google Cloud Pub/Sub
- Provider / placement: gcp / Australia-only message policy — unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d646561642d6c6574746572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-state: Review queue and delivery ledger

- Responsibility: Proposed regional Firestore database in Sydney, subject to verification. Store exact source generations, fields, corrections, confidence/evidence, workflow state, approval history and accounting receipt references. Retain extraction audit history for 90 days; proposed age starts when each audit event is recorded. Application cleanup enforces expiry; asynchronous TTL alone does not prove an exact deletion deadline. Backup and recovery copies must follow the Australian boundary and reviewed retention policy. Extracted-field and minimal delivery-ledger lifetimes need explicit definition before implementation; never silently delete deduplication protection. Transactions claim work and commit approval with an outbox entry. Stable submission keys prevent repeated events creating internal duplicates. Fingerprints flag identical reuploads; business duplicate rules remain open. Browser clients cannot directly write workflow state. Edits invalidate approval.
- Service: Cloud Firestore
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-extractor: Invoice field extraction

- Responsibility: Candidate Document AI Invoice Parser extracts supplier, invoice date, total and currency, including supported scanned PDFs. Australian processor availability, processing location, version, transient retention and input/page limits are UNVERIFIED. Do not send documents to an overseas endpoint. If a compliant Australian processor is unavailable, retain this extraction responsibility as blocked engineering work and evaluate an Australia-hosted implementation rather than silently changing residency. Application maps fields into a validated schema and retains confidence and source evidence for review. Missing or ambiguous values require review; never fabricate or auto-approve. Verify handling of 10 MB PDFs and approximately 500 daily submissions with representative documents.
- Service: Google Cloud Document AI
- Provider / placement: gcp / Australian processing endpoint — unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d657874726163746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-recovery: Recover work and enforce retention

- Responsibility: Proposed Cloud Scheduler job invokes an authenticated application recovery route. Application recovers pending outbox entries and expired leases, reconciles finalized uploads and republishes eligible work with unchanged keys. Also checks 90-day original/audit expiry, performs idempotent cleanup and reports failures. Retention enforcement must cover generations, retained copies and associated records without losing required duplicate protection; retention exceptions cannot be invented. Repeated sweeps are harmless and cannot resurrect expired work. Schedule and alert thresholds are engineering proposals. Sydney availability and authenticated integration require verification.
- Service: Google Cloud Scheduler
- Provider / placement: gcp / australia-southeast1 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d7265636f76657279
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component invoice-secrets: Accounting connection credentials

- Responsibility: Proposed Secret Manager storage for accounting credentials supplied by an administrator outside the diagram and chat. The administrator also supplies the accounting endpoint through controlled application configuration; the external accounting system is not provisioned or modified. Explicit Australian secret replication is proposed, subject to verification; no implicit global replication assumption. Only the application runtime identity accesses necessary versions. Proposed provisioning inputs reference secrets rather than embedding credential values in Terraform state or logs. API authentication, rotation and regional service behavior require engineering and verification.
- Service: Secret Manager
- Provider / placement: gcp / Australian replication — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-696e766f6963652d73656372657473
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact gcp service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component accounting-api: Existing accounting API

- Responsibility: Client-owned existing service outside provisioning scope; do not create, import or modify it. An administrator will supply its endpoint and credentials through controlled configuration and secret inputs outside the diagram. Hosting, processing and storage locations remain unknown; this ownership clarification does not establish Australian residency. Sending invoice fields remains blocked until compatibility with Australian residency is established. Receive only the approved revision with a stable delivery key. Establish native idempotency or authoritative lookup before automatic retries. After a timeout with possible acceptance, mark uncertain and reconcile rather than blindly resend. Without downstream duplicate protection, exactly-once creation cannot be guaranteed. Existing accounting retention is separate from the proposed intake retention and remains unverified. Endpoint schema, authentication and reconciliation behavior require evidence.
- Service: Existing accounting API
- Provider / placement: tools / Existing location — Australian residency to confirm
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6163636f756e74696e672d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Interfaces

### users-app: invoice-users → invoice-app

- Drawn payload/purpose: HTTPS: signed-in upload; reviewer-only correction and approval
- Contract task: TASK-CONTRACT-75736572732d617070
- Integration task: TASK-INTEGRATION-75736572732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### users-identity: invoice-users → invoice-identity

- Drawn payload/purpose: Sign in and receive user token
- Contract task: TASK-CONTRACT-75736572732d6964656e74697479
- Integration task: TASK-INTEGRATION-75736572732d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-identity: invoice-app → invoice-identity

- Drawn payload/purpose: Verify tokens; server enforces uploader and reviewer permissions
- Contract task: TASK-CONTRACT-6170702d6964656e74697479
- Integration task: TASK-INTEGRATION-6170702d6964656e74697479
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### users-upload: invoice-users → invoice-files

- Drawn payload/purpose: HTTPS signed upload: PDF up to 10 MB
- Contract task: TASK-CONTRACT-75736572732d75706c6f6164
- Integration task: TASK-INTEGRATION-75736572732d75706c6f6164
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-files: invoice-app → invoice-files

- Drawn payload/purpose: Scoped identity: exact-generation reads and retention cleanup
- Contract task: TASK-CONTRACT-6170702d66696c6573
- Integration task: TASK-INTEGRATION-6170702d66696c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### files-events: invoice-files → invoice-events

- Drawn payload/purpose: Object-finalization notification with generation
- Contract task: TASK-CONTRACT-66696c65732d6576656e7473
- Integration task: TASK-INTEGRATION-66696c65732d6576656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### events-app: invoice-events → invoice-app

- Drawn payload/purpose: OIDC-authenticated push; acknowledge durable completion
- Contract task: TASK-CONTRACT-6576656e74732d617070
- Integration task: TASK-INTEGRATION-6576656e74732d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### events-dead-letter: invoice-events → invoice-dead-letter

- Drawn payload/purpose: Forward exhausted attempts with scoped permissions
- Contract task: TASK-CONTRACT-6576656e74732d646561642d6c6574746572
- Integration task: TASK-INTEGRATION-6576656e74732d646561642d6c6574746572
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-state: invoice-app → invoice-state

- Drawn payload/purpose: Transactional workflow, approvals, outbox and 90-day audit cleanup
- Contract task: TASK-CONTRACT-6170702d7374617465
- Integration task: TASK-INTEGRATION-6170702d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-extraction: invoice-app → invoice-extractor

- Drawn payload/purpose: PDF processing — blocked pending Australian endpoint verification
- Contract task: TASK-CONTRACT-6170702d65787472616374696f6e
- Integration task: TASK-INTEGRATION-6170702d65787472616374696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### scheduler-app: invoice-recovery → invoice-app

- Drawn payload/purpose: OIDC-authenticated recovery and retention sweep
- Contract task: TASK-CONTRACT-7363686564756c65722d617070
- Integration task: TASK-INTEGRATION-7363686564756c65722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-events: invoice-app → invoice-events

- Drawn payload/purpose: Publish eligible approved-delivery and recovery references
- Contract task: TASK-CONTRACT-6170702d6576656e7473
- Integration task: TASK-INTEGRATION-6170702d6576656e7473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-secrets: invoice-app → invoice-secrets

- Drawn payload/purpose: Scoped runtime access to administrator-supplied accounting credentials
- Contract task: TASK-CONTRACT-6170702d73656372657473
- Integration task: TASK-INTEGRATION-6170702d73656372657473
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-accounting: invoice-app → accounting-api

- Drawn payload/purpose: Approved revision to configured external endpoint; residency and retry safety un
- Contract task: TASK-CONTRACT-6170702d6163636f756e74696e67
- Integration task: TASK-INTEGRATION-6170702d6163636f756e74696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
