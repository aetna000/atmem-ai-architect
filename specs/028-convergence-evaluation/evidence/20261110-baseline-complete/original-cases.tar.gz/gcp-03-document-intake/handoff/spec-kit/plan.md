# Implementation Spec Kit

Snapshot 54c838af-0f8d-4161-8bb1-172ae12a553c · design r4 · generated 2026-11-09T17:39:58.617Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

9 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Users upload PDF invoices. Extract the supplier, invoice date, total and currency into a review queue. Delivery can repeat; retries must not create duplicate invoices. A reviewer approves a result before it is sent to our existing accounting API. Use Google Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: gcp
- data.country: Australia

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Uploaders and reviewers (invoice-users): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Existing users — location to confirm.
- Invoice intake and review application (invoice-app): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- User sign-in (invoice-identity): Implementation needed; gcp, Identity residency unverified.
- Private invoice PDFs (invoice-files): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- Durable processing messages (invoice-events): Implementation needed; gcp, Australia-only message policy — unverified.
- Failed processing messages (invoice-dead-letter): Implementation needed; gcp, Australia-only message policy — unverified.
- Review queue and delivery ledger (invoice-state): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- Invoice field extraction (invoice-extractor): Implementation needed; gcp, Australian processing endpoint — unverified.
- Recover work and enforce retention (invoice-recovery): Implementation needed; gcp, australia-southeast1 — proposed, unverified.
- Accounting connection credentials (invoice-secrets): Implementation needed; gcp, Australian replication — proposed, unverified.
- Existing accounting API (accounting-api): Existing service reference — preserved without provisioning or import; behavior and connections remain unverified; tools, Existing location — Australian residency to confirm.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.
