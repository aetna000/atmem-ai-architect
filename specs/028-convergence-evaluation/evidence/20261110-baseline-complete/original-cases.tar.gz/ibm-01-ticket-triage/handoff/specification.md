Snapshot ed12aaa9-7862-4ae7-b240-1536f4acacd2 · design r3 · generated 2026-11-09T17:55:23.696Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis. (must, open); target: acceptance target needed; linked blocks: team-reviewer, triage-app, triage-model

Design explanation: Defines the complete first-version outcome without expanding into autonomous ticket handling; urgency definitions and representative acceptance examples remain open.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use. (must, open); target: acceptance target needed; linked blocks: triage-app, team-sign-in, triage-model

Design explanation: Proposed access and privacy boundary reduces exposure of customer information while keeping this small internal tool simple; retention and residency still need confirmation.

Basis: The user calls this a “small internal tool”; the proposed triage-app processes pasted tickets and team-sign-in restricts access.
- [REQ-004] Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback. (must, open); target: acceptance target needed; linked blocks: triage-app, triage-model, team-sign-in

Design explanation: Australian application placement alone does not establish where inference, identity information, logs or provider support access occur; unresolved overseas paths must be visible before real data is used.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”

## How the system works

The current design contains 4 components and 3 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Team member → Ticket review application

HTTPS: paste ticket; receive suggestions for review

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Ticket review application → Team sign-in

OpenID Connect sign-in; identity-data location unverified

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Ticket review application → Ticket analysis model

Authenticated HTTPS inference; Australian endpoint requires verification

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Team member

Approval workflow · tools · region: Not applicable · classification: Confidential

Existing human using a browser, outside provisioning scope. Pastes a ticket and reviews the returned summary, topic and suggested urgency. Any subsequent customer action happens outside this tool.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Team member → Ticket review application: HTTPS: paste ticket; receive suggestions for review

Requirement traceability: REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket review application

IBM Cloud Code Engine · ibm · region: Sydney (au-syd) proposed; availability unverified · classification: Confidential

Proposed single IBM Cloud Code Engine application serving the browser interface and server-side analysis endpoint. Authenticates and authorizes team access on the server. Accepts ticket text and returns structured summary, topic, suggested urgency and a short reason for human review. Treats ticket text as untrusted data, validates model output and shows a retryable error on inference failure. No credentials or connectors for sending replies or modifying customer records. Proposed defaults: transient ticket processing, no saved history and metadata-only operational logs. Sydney (au-syd) is a candidate only; service availability and processing location need verification. Propose a single-region first version with no automatic overseas failover; regional outages may interrupt service. Review outbound destinations, logs and support access and flag any overseas processing before real-ticket use. Runtime identity, secret handling, bounded requests, authentication, UI and API code require engineering; no supplied image or supported generated application contract is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Team member → Ticket review application: HTTPS: paste ticket; receive suggestions for review

Outputs: Ticket review application → Team sign-in: OpenID Connect sign-in; identity-data location unverified; Ticket review application → Ticket analysis model: Authenticated HTTPS inference; Australian endpoint requires verification

Requirement traceability: REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.; REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.; REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Ticket analysis model

IBM watsonx.ai · ibm · region: Sydney (au-syd) proposed; model availability unverified · classification: Confidential

Proposed IBM watsonx.ai inference service. Receives ticket text from the application and returns draft summary, topic and urgency with a reason. Has no action tools or customer-system access. Sydney (au-syd) is a candidate only: the selected model, regional inference availability, entitlement, quotas, retention and processing location require verification. No overseas inference fallback is proposed. Flag any required overseas processing for user review before sending ticket data. Evaluate the selected model against representative tickets and agreed urgency definitions. Provisioning and inference adapter require engineering.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket review application → Ticket analysis model: Authenticated HTTPS inference; Australian endpoint requires verification

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.; REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.; REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Team sign-in

IBM Security Verify · ibm · region: Australian identity processing unverified · classification: Confidential

IBM Security Verify is the proposed identity service for approved team access using OpenID Connect. Company identity arrangements are unknown; federation or a suitable existing identity service can refine this proposal later. The application must validate the session and enforce team membership before processing a ticket. Australian tenant availability, identity-data processing, logs, retention and support access are unverified; identity information may leave Australia and this must be resolved and flagged before use. Do not include ticket text in sign-in requests. Plan suitability and Code Engine application integration need verification and implementation. No existing identity tenant is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket review application → Team sign-in: OpenID Connect sign-in; identity-data location unverified

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.; REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Ticket review application<br/>IBM"]
  n2["Ticket analysis model<br/>IBM"]
  n3["Team sign-in<br/>IBM"]
  n0 -->|HTTPS: paste ticket; receive suggestions for review| n1
  n1 -->|OpenID Connect sign-in; identity-data location unverified| n3
  n1 -->|Authenticated HTTPS inference; Australian endpoint requires verification| n2
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-reviewer | Team member | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-app | Ticket review application | ibm | IBM Cloud Code Engine | Sydney (au-syd) proposed; availability unverified | Proposed | Implementation needed |
| triage-model | Ticket analysis model | ibm | IBM watsonx.ai | Sydney (au-syd) proposed; model availability unverified | Proposed | Implementation needed |
| team-sign-in | Team sign-in | ibm | IBM Security Verify | Australian identity processing unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Team member** (team-reviewer): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket review application** (triage-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-reviewer.
- **Ticket analysis model** (triage-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Team sign-in** (team-sign-in): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.

### Engineering work remaining

- Ticket review application: Implementation needed.
- Ticket analysis model: Implementation needed.
- Team sign-in: Implementation needed.
- Wire team-reviewer → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → team-sign-in: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
