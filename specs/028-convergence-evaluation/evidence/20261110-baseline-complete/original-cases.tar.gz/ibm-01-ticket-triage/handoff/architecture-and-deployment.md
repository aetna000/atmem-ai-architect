Snapshot ed12aaa9-7862-4ae7-b240-1536f4acacd2 · design r3 · generated 2026-11-09T17:55:23.696Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 17:55 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** IBM
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM
- **Budget and timeline:** —

## 3. Architecture

**Team access**

- Team member (Tools & data, existing, sketch) — Existing human using a browser, outside provisioning scope. Pastes a ticket and reviews the returned summary, topic and suggested urgency. Any subsequent customer action happens outside this tool.
- Team sign-in (IBM, sketch) — IBM Security Verify is the proposed identity service for approved team access using OpenID Connect. Company identity arrangements are unknown; federation or a suitable existing identity service can refine this proposal later. The application must validate the session and enforce team membership before processing a ticket. Australian tenant availability, identity-data processing, logs, retention and support access are unverified; identity information may leave Australia and this must be resolved and flagged before use. Do not include ticket text in sign-in requests. Plan suitability and Code Engine application integration need verification and implementation. No existing identity tenant is assumed.

**Ticket analysis**

- Ticket review application (IBM, sketch) — Proposed single IBM Cloud Code Engine application serving the browser interface and server-side analysis endpoint. Authenticates and authorizes team access on the server. Accepts ticket text and returns structured summary, topic, suggested urgency and a short reason for human review. Treats ticket text as untrusted data, validates model output and shows a retryable error on inference failure. No credentials or connectors for sending replies or modifying customer records. Proposed defaults: transient ticket processing, no saved history and metadata-only operational logs. Sydney (au-syd) is a candidate only; service availability and processing location need verification. Propose a single-region first version with no automatic overseas failover; regional outages may interrupt service. Review outbound destinations, logs and support access and flag any overseas processing before real-ticket use. Runtime identity, secret handling, bounded requests, authentication, UI and API code require engineering; no supplied image or supported generated application contract is assumed.
- Ticket analysis model (IBM, sketch) — Proposed IBM watsonx.ai inference service. Receives ticket text from the application and returns draft summary, topic and urgency with a reason. Has no action tools or customer-system access. Sydney (au-syd) is a candidate only: the selected model, regional inference availability, entitlement, quotas, retention and processing location require verification. No overseas inference fallback is proposed. Flag any required overseas processing for user review before sending ticket data. Evaluate the selected model against representative tickets and agreed urgency definitions. Provisioning and inference adapter require engineering.

```mermaid
flowchart LR
  n0["Team member<br/>Tools & data"]
  n1["Ticket review application<br/>IBM"]
  n2["Ticket analysis model<br/>IBM"]
  n3["Team sign-in<br/>IBM"]
  n0 -->|HTTPS: paste ticket; receive suggestions for review| n1
  n1 -->|OpenID Connect sign-in; identity-data location unverified| n3
  n1 -->|Authenticated HTTPS inference; Australian endpoint requires verification| n2
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| team-reviewer | Team member | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-app | Ticket review application | ibm | IBM Cloud Code Engine | Sydney (au-syd) proposed; availability unverified | Proposed | Implementation needed |
| triage-model | Ticket analysis model | ibm | IBM watsonx.ai | Sydney (au-syd) proposed; model availability unverified | Proposed | Implementation needed |
| team-sign-in | Team sign-in | ibm | IBM Security Verify | Australian identity processing unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Team member** (team-reviewer): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket review application** (triage-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: team-reviewer.
- **Ticket analysis model** (triage-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.
- **Team sign-in** (team-sign-in): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: triage-app.

### Engineering work remaining

- Ticket review application: Implementation needed.
- Ticket analysis model: Implementation needed.
- Team sign-in: Implementation needed.
- Wire team-reviewer → triage-app: implement data flow, access policy and acceptance test.
- Wire triage-app → team-sign-in: implement data flow, access policy and acceptance test.
- Wire triage-app → triage-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Team member | Ticket review application | HTTPS: paste ticket; receive suggestions for review | Confidential |
| Ticket review application | Team sign-in | OpenID Connect sign-in; identity-data location unverified | Confidential |
| Ticket review application | Ticket analysis model | Authenticated HTTPS inference; Australian endpoint requires verification | Confidential |

## 5. Security controls

- **Team member** — Existing human using a browser, outside provisioning scope. Pastes a ticket and reviews the returned summary, topic and suggested urgency. Any subsequent customer action happens outside this tool.
- **Team sign-in** — IBM Security Verify is the proposed identity service for approved team access using OpenID Connect. Company identity arrangements are unknown; federation or a suitable existing identity service can refine this proposal later. The application must validate the session and enforce team membership before processing a ticket. Australian tenant availability, identity-data processing, logs, retention and support access are unverified; identity information may leave Australia and this must be resolved and flagged before use. Do not include ticket text in sign-in requests. Plan suitability and Code Engine application integration need verification and implementation. No existing identity tenant is assumed.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use. (must)
- Requirement: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use. | security | not measurable yet | Open |
| Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback. | compliance | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.”, “Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 4 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Ticket analysis model | Endpoint hours | 730 hours | price needed | — | — |
| Team sign-in | Checked requests | needs requests_per_month | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Team member, Ticket review application.

**Estimate gaps:**

- Ticket analysis model / Endpoint hours: price needed.
- Team sign-in / Checked requests: input needed (requests_per_month).
- Team member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket review application: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision team access: Team sign-in.
4. Provision ticket analysis: Ticket review application, Ticket analysis model.
5. Connect existing systems: Team member; test failure behaviour.
6. Run the acceptance checks (success measures and requirements) in staging; record results.
7. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- Ticket analysis model: needs a unit price with a source _(estimate)_
- Team sign-in: needs requests_per_month _(estimate)_
