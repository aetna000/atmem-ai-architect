# Questions and assumptions to resolve

Snapshot ed12aaa9-7862-4ae7-b240-1536f4acacd2 · design r3 · generated 2026-11-09T17:55:23.696Z

- [ai-ticket-triage] Confirm REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.
- [ai-ticket-access-privacy] Confirm REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.
- [ai-ticket-residency] Confirm REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.
- [acceptance-req-679ba3b1] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-ticket-triage] Agree a measurable acceptance check for REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.
- [acceptance-ai-ticket-access-privacy] Agree a measurable acceptance check for REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.
- [acceptance-ai-ticket-residency] Agree a measurable acceptance check for REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d7469636b65742d6163636573732d70726976616379] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d7265736964656e6379] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7469636b65742d747269616765] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
