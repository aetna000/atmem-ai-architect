# Component and interface contracts

Snapshot ed12aaa9-7862-4ae7-b240-1536f4acacd2 · design r3 · generated 2026-11-09T17:55:23.696Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component team-reviewer: Team member

- Responsibility: Existing human using a browser, outside provisioning scope. Pastes a ticket and reviews the returned summary, topic and suggested urgency. Any subsequent customer action happens outside this tool.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7465616d2d7265766965776572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component triage-app: Ticket review application

- Responsibility: Proposed single IBM Cloud Code Engine application serving the browser interface and server-side analysis endpoint. Authenticates and authorizes team access on the server. Accepts ticket text and returns structured summary, topic, suggested urgency and a short reason for human review. Treats ticket text as untrusted data, validates model output and shows a retryable error on inference failure. No credentials or connectors for sending replies or modifying customer records. Proposed defaults: transient ticket processing, no saved history and metadata-only operational logs. Sydney (au-syd) is a candidate only; service availability and processing location need verification. Propose a single-region first version with no automatic overseas failover; regional outages may interrupt service. Review outbound destinations, logs and support access and flag any overseas processing before real-ticket use. Runtime identity, secret handling, bounded requests, authentication, UI and API code require engineering; no supplied image or supported generated application contract is assumed.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Sydney (au-syd) proposed; availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-model: Ticket analysis model

- Responsibility: Proposed IBM watsonx.ai inference service. Receives ticket text from the application and returns draft summary, topic and urgency with a reason. Has no action tools or customer-system access. Sydney (au-syd) is a candidate only: the selected model, regional inference availability, entitlement, quotas, retention and processing location require verification. No overseas inference fallback is proposed. Flag any required overseas processing for user review before sending ticket data. Evaluate the selected model against representative tickets and agreed urgency definitions. Provisioning and inference adapter require engineering.
- Service: IBM watsonx.ai
- Provider / placement: ibm / Sydney (au-syd) proposed; model availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component team-sign-in: Team sign-in

- Responsibility: IBM Security Verify is the proposed identity service for approved team access using OpenID Connect. Company identity arrangements are unknown; federation or a suitable existing identity service can refine this proposal later. The application must validate the session and enforce team membership before processing a ticket. Australian tenant availability, identity-data processing, logs, retention and support access are unverified; identity information may leave Australia and this must be resolved and flagged before use. Do not include ticket text in sign-in requests. Plan suitability and Code Engine application integration need verification and implementation. No existing identity tenant is assumed.
- Service: IBM Security Verify
- Provider / placement: ibm / Australian identity processing unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7465616d2d7369676e2d696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### reviewer-app: team-reviewer → triage-app

- Drawn payload/purpose: HTTPS: paste ticket; receive suggestions for review
- Contract task: TASK-CONTRACT-72657669657765722d617070
- Integration task: TASK-INTEGRATION-72657669657765722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-sign-in: triage-app → team-sign-in

- Drawn payload/purpose: OpenID Connect sign-in; identity-data location unverified
- Contract task: TASK-CONTRACT-6170702d7369676e2d696e
- Integration task: TASK-INTEGRATION-6170702d7369676e2d696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### app-model: triage-app → triage-model

- Drawn payload/purpose: Authenticated HTTPS inference; Australian endpoint requires verification
- Contract task: TASK-CONTRACT-6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
