# Detailed implementation tasks

Snapshot ed12aaa9-7862-4ae7-b240-1536f4acacd2 · design r3 · generated 2026-11-09T17:55:23.696Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-72657669657765722d617070 — Define Team member → Ticket review application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: team-reviewer, triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection reviewer-app: HTTPS: paste ticket; receive suggestions for review. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge reviewer-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d7369676e2d696e — Define Ticket review application → Team sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: triage-app, team-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-sign-in: OpenID Connect sign-in; identity-data location unverified. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-sign-in
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170702d6d6f64656c — Define Ticket review application → Ticket analysis model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection app-model: Authenticated HTTPS inference; Australian endpoint requires verification. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge app-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-7465616d2d7265766965776572 — Integrate existing Team member

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72657669657765722d617070
- Components: team-reviewer
- Generated files: No implementation files generated yet
- Requirements: ai-ticket-triage

### Implementation steps

1. Responsibility from the board: Existing human using a browser, outside provisioning scope. Pastes a ticket and reviews the returned summary, topic and suggested urgency. Any subsequent customer action happens outside this tool.
2. Verify Approval workflow on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component team-reviewer
- Application/configuration and tests for Team member

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7472696167652d617070 — Implement Ticket review application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72657669657765722d617070, TASK-CONTRACT-6170702d7369676e2d696e, TASK-CONTRACT-6170702d6d6f64656c
- Components: triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-triage, ai-ticket-access-privacy, ai-ticket-residency

### Implementation steps

1. Responsibility from the board: Proposed single IBM Cloud Code Engine application serving the browser interface and server-side analysis endpoint. Authenticates and authorizes team access on the server. Accepts ticket text and returns structured summary, topic, suggested urgency and a short reason for human review. Treats ticket text as untrusted data, validates model output and shows a retryable error on inference failure. No credentials or connectors for sending replies or modifying customer records. Proposed defaults: transient ticket processing, no saved history and metadata-only operational logs. Sydney (au-syd) is a candidate only; service availability and processing location need verification. Propose a single-region first version with no automatic overseas failover; regional outages may interrupt service. Review outbound destinations, logs and support access and flag any overseas processing before real-ticket use. Runtime identity, secret handling, bounded requests, authentication, UI and API code require engineering; no supplied image or supported generated application contract is assumed.
2. Verify IBM Cloud Code Engine on ibm in Sydney (au-syd) proposed; availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.; REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.; REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component triage-app
- Application/configuration and tests for Ticket review application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7472696167652d6d6f64656c — Implement Ticket analysis model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d6d6f64656c
- Components: triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-triage, ai-ticket-access-privacy, ai-ticket-residency

### Implementation steps

1. Responsibility from the board: Proposed IBM watsonx.ai inference service. Receives ticket text from the application and returns draft summary, topic and urgency with a reason. Has no action tools or customer-system access. Sydney (au-syd) is a candidate only: the selected model, regional inference availability, entitlement, quotas, retention and processing location require verification. No overseas inference fallback is proposed. Flag any required overseas processing for user review before sending ticket data. Evaluate the selected model against representative tickets and agreed urgency definitions. Provisioning and inference adapter require engineering.
2. Verify IBM watsonx.ai on ibm in Sydney (au-syd) proposed; model availability unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM watsonx.ai; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.; REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.; REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component triage-model
- Application/configuration and tests for Ticket analysis model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7465616d2d7369676e2d696e — Implement Team sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170702d7369676e2d696e
- Components: team-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-access-privacy, ai-ticket-residency

### Implementation steps

1. Responsibility from the board: IBM Security Verify is the proposed identity service for approved team access using OpenID Connect. Company identity arrangements are unknown; federation or a suitable existing identity service can refine this proposal later. The application must validate the session and enforce team membership before processing a ticket. Australian tenant availability, identity-data processing, logs, retention and support access are unverified; identity information may leave Australia and this must be resolved and flagged before use. Do not include ticket text in sign-in requests. Plan suitability and Code Engine application integration need verification and implementation. No existing identity tenant is assumed.
2. Verify IBM Security Verify on ibm in Australian identity processing unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Security Verify; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.; REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component team-sign-in
- Application/configuration and tests for Team sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-72657669657765722d617070 — Wire Team member to Ticket review application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72657669657765722d617070, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070
- Components: team-reviewer, triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge reviewer-app carrying HTTPS: paste ticket; receive suggestions for review, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation reviewer-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d7369676e2d696e — Wire Ticket review application to Team sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d7369676e2d696e, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7465616d2d7369676e2d696e
- Components: triage-app, team-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-sign-in carrying OpenID Connect sign-in; identity-data location unverified, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-sign-in
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170702d6d6f64656c — Wire Ticket review application to Ticket analysis model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170702d6d6f64656c, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c
- Components: triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge app-model carrying Authenticated HTTPS inference; Australian endpoint requires verification, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation app-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-72657669657765722d617070 — Verify live Team member → Ticket review application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72657669657765722d617070
- Components: team-reviewer, triage-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge reviewer-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence reviewer-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d7369676e2d696e — Verify live Ticket review application → Team sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d7369676e2d696e
- Components: triage-app, team-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-sign-in with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-sign-in

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170702d6d6f64656c — Verify live Ticket review application → Ticket analysis model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170702d6d6f64656c
- Components: triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge app-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence app-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3637396261336231 — Verify REQ-001: A person approves sensitive actions before they happen

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-679ba3b1

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d747269616765 — Verify REQ-002: The application shall accept manually pasted support-ticket text and display a short summary, topic and suggested urgency for human review; inference failures shall be visible rather than presented as completed analysis.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-INTEGRATION-LIVE-72657669657765722d617070, TASK-INTEGRATION-LIVE-6170702d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d6d6f64656c
- Components: team-reviewer, triage-app, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-triage

### Implementation steps

1. Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”; rationale: Defines the complete first-version outcome without expanding into autonomous ticket handling; urgency definitions and representative acceptance examples remain open.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-002

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d6163636573732d70726976616379 — Verify REQ-003: Proposed: only authenticated, authorized team members may submit tickets; the application shall avoid persistent ticket history and exclude ticket contents from operational logs, with model-provider retention and processing location reviewed before use.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7465616d2d7369676e2d696e, TASK-INTEGRATION-LIVE-72657669657765722d617070, TASK-INTEGRATION-LIVE-6170702d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d6d6f64656c
- Components: triage-app, team-sign-in, triage-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-access-privacy

### Implementation steps

1. Basis: The user calls this a “small internal tool”; the proposed triage-app processes pasted tickets and team-sign-in restricts access.; rationale: Proposed access and privacy boundary reduces exposure of customer information while keeping this small internal tool simple; retention and residency still need confirmation.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-003

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7469636b65742d7265736964656e6379 — Verify REQ-004: Use Australian deployment and processing locations where the selected IBM services support them. Document and flag any ticket content, generated suggestions, identity information or operational data that would be processed, retained or accessed outside Australia before real-ticket use; do not silently enable overseas fallback.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7465616d2d7369676e2d696e, TASK-INTEGRATION-LIVE-72657669657765722d617070, TASK-INTEGRATION-LIVE-6170702d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d6d6f64656c
- Components: triage-app, triage-model, team-sign-in
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-ticket-residency

### Implementation steps

1. Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”; rationale: Australian application placement alone does not establish where inference, identity information, logs or provider support access occur; unresolved overseas paths must be visible before real data is used.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7465616d2d7369676e2d696e, TASK-INTEGRATION-72657669657765722d617070, TASK-INTEGRATION-6170702d7369676e2d696e, TASK-INTEGRATION-6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-7465616d2d7265766965776572, TASK-RESOURCE-7472696167652d617070, TASK-RESOURCE-7472696167652d6d6f64656c, TASK-RESOURCE-7465616d2d7369676e2d696e, TASK-INTEGRATION-LIVE-72657669657765722d617070, TASK-INTEGRATION-LIVE-6170702d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3637396261336231, TASK-ACCEPTANCE-61692d7469636b65742d747269616765, TASK-ACCEPTANCE-61692d7469636b65742d6163636573732d70726976616379, TASK-ACCEPTANCE-61692d7469636b65742d7265736964656e6379, TASK-INTEGRATION-LIVE-72657669657765722d617070, TASK-INTEGRATION-LIVE-6170702d7369676e2d696e, TASK-INTEGRATION-LIVE-6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
