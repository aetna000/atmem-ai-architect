Snapshot f6d2ce26-8572-4bd0-bf0f-2754454ff7a6 · design r3 · generated 2026-11-09T16:48:57.815Z

# Ticket triage assistant — solution specification

## Problem and intended outcome

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] A person approves sensitive actions before they happen (must, open); target: acceptance target needed; linked blocks: not linked

Design explanation: This requirement makes “A person approves sensitive actions before they happen” an outcome the implementation must demonstrate. Its linked components identify where that behavior belongs; acceptance should exercise the complete user-visible path rather than checking that those resources merely exist.
- [REQ-002] For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses. (must, open); target: acceptance target needed; linked blocks: triage-web, triage-api, triage-function, triage-model

Design explanation: Defines the required result so implementation and evaluation cover classification and urgency as well as summarization.

Basis: “our team pastes a support ticket and gets a short summary, topic and suggested urgency”
- [REQ-003] Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement. (must, open); target: acceptance target needed; linked blocks: staff-sign-in, triage-api, triage-function, triage-model

Design explanation: Proposed access and data-minimization boundaries reduce exposure of potentially sensitive ticket content.

Basis: The user requests a “small internal tool”; staff-sign-in, triage-api and triage-function introduce the proposed enforcement points.
- [REQ-004] Accept synthetic or redacted support-ticket text up to 20 KB and explicitly reject oversized input without truncation; propose interpreting the limit as 20,000 UTF-8 bytes and enforce it on the server. (must, open); target: acceptance target needed; linked blocks: triage-web, triage-function

Design explanation: Bounds processing and enables explicit rejection rather than silent truncation. Decimal KB is a proposed interpretation, not an additional user decision.

Basis: “We paste synthetic or redacted text, up to 20 KB per ticket.”
- [REQ-005] Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification. (must, open); target: acceptance target needed; linked blocks: triage-web, staff-sign-in, triage-api, triage-function, triage-model

Design explanation: Regional resource placement alone does not establish residency for inference, delivery, identity metadata or telemetry; overseas paths must remain visible.

Basis: “Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.”

## How the system works

The current design contains 6 components and 6 connections. 1 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Staff member → Ticket review web app

HTTPS: paste redacted/synthetic ticket; review suggestions

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Ticket review web app → Staff sign-in

OAuth authorization code with PKCE; no ticket content; implementation required

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Staff sign-in → Authenticated triage API

JWT issuer and signing-key validation; implementation required

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Ticket review web app → Authenticated triage API

HTTPS POST /triage with access token; transient text; no-store response

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Authenticated triage API → Ticket triage backend

Synchronous regional Lambda invocation; validated suggestions or safe error

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Ticket triage backend → Managed language model

IAM-authorized regional Converse; no cross-region fallback; handling unverified

Integration contract: bedrock-converse.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Staff member

Web browser · tools · region: Australia — existing client · classification: Confidential

Existing staff member in Australia using a browser outside provisioning scope. Pastes synthetic or redacted ticket text up to 20 KB and reviews suggestions before taking any action separately. Redaction is the staff member's responsibility; automatic redaction is outside current scope.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Staff member → Ticket review web app: HTTPS: paste redacted/synthetic ticket; review suggestions

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Ticket review web app

AWS Amplify Hosting · aws · region: ap-southeast-2 — proposed; delivery boundary unverified · classification: Confidential

Proposed static application hosted by AWS Amplify Hosting. Provides ticket entry, sign-in and a clearly labelled suggestion panel showing summary, topic and urgency. Proposes a 20,000-byte UTF-8 input limit; the backend independently enforces it. Holds ticket text only in transient page memory and clears it on completion, failure or sign-out. No persistent browser storage, service-worker caching, session replay or analytics capture of ticket content. API responses use no-store caching controls. Amplify global delivery may involve locations outside Australia: regional hosting does not establish Australian-only delivery, access metadata or control-plane handling. Review and flag these paths before deployment. Frontend and hosting implementation remain required; no existing application or supplied image is assumed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff member → Ticket review web app: HTTPS: paste redacted/synthetic ticket; review suggestions

Outputs: Ticket review web app → Staff sign-in: OAuth authorization code with PKCE; no ticket content; implementation required; Ticket review web app → Authenticated triage API: HTTPS POST /triage with access token; transient text; no-store response

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses.; REQ-004: Accept synthetic or redacted support-ticket text up to 20 KB and explicitly reject oversized input without truncation; propose interpreting the limit as 20,000 UTF-8 bytes and enforce it on the server.; REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Staff sign-in

Amazon Cognito · aws · region: ap-southeast-2 — proposed, unverified · classification: Confidential

Proposed Amazon Cognito user pool with administrator-created staff accounts, self-registration disabled and MFA required. Browser sign-in uses authorization code with PKCE; API access requires an authorized staff token. Ticket content must never enter sign-in requests or identity attributes. Existing company sign-in is unknown; federation can be refined later. Verify Sydney availability and identity metadata/data-handling boundaries, flagging any overseas paths. General triage authentication requires custom implementation rather than the RAG-specific generator.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket review web app → Staff sign-in: OAuth authorization code with PKCE; no ticket content; implementation required

Outputs: Staff sign-in → Authenticated triage API: JWT issuer and signing-key validation; implementation required

Requirement traceability: REQ-003: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.; REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authenticated triage API

Amazon API Gateway · aws · region: ap-southeast-2 — proposed, unverified · classification: Confidential

Proposed regional Amazon API Gateway HTTP API exposing POST /triage. A JWT authorizer validates the intended Cognito issuer, audience and access scope; unauthenticated requests are denied. Restrict browser origins to the application and apply request throttling. Accepts ticket text and returns structured suggestions or a safe error with Cache-Control: no-store. Do not cache or log request/response bodies, tokens or ticket-derived content. Backend enforces the 20,000-byte UTF-8 text limit separately from JSON envelope size. Verify regional availability and telemetry handling; no automatic overseas endpoint failover. General API and authorization wiring require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff sign-in → Authenticated triage API: JWT issuer and signing-key validation; implementation required; Ticket review web app → Authenticated triage API: HTTPS POST /triage with access token; transient text; no-store response

Outputs: Authenticated triage API → Ticket triage backend: Synchronous regional Lambda invocation; validated suggestions or safe error

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses.; REQ-003: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.; REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Ticket triage backend

AWS Lambda · aws · region: ap-southeast-2 — proposed, unverified · classification: Confidential

Proposed custom AWS Lambda application. Accepts synthetic or redacted text and rejects text exceeding 20,000 UTF-8 bytes, interpreting KB as decimal. Treats ticket contents as untrusted data and requests a structured summary, topic, suggested urgency and brief urgency rationale. Proposed urgency labels: low, normal, high and needs-review; ambiguous or invalid results require review. Checks response schema and never executes model instructions or external actions. No ticket database, queues, customer-system permissions, persistent ticket files or payload tracing. Ticket text is request-scoped only; release references on success/failure and never reuse content across invocations. Owns execution role and regional CloudWatch log group containing metadata/errors without ticket bodies or model responses. Bound output, retries, timeouts and concurrency during implementation. Reject unavailable regional inference rather than silently routing overseas. No runtime proof of non-retention or regional handling exists. Structured triage requires custom code and tests; bedrock-summary is insufficient.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Authenticated triage API → Ticket triage backend: Synchronous regional Lambda invocation; validated suggestions or safe error

Outputs: Ticket triage backend → Managed language model: IAM-authorized regional Converse; no cross-region fallback; handling unverified (integration: bedrock-converse)

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses.; REQ-003: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.; REQ-004: Accept synthetic or redacted support-ticket text up to 20 KB and explicitly reject oversized input without truncation; propose interpreting the limit as 20,000 UTF-8 bytes and enforce it on the server.; REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Managed language model

Amazon Bedrock · aws · region: ap-southeast-2 — proposed, model availability unverified · classification: Confidential

Proposed Amazon Bedrock managed inference dependency for ticket analysis. Qualify a direct model in Sydney with sufficient input capacity for 20 KB of UTF-8 text plus instructions; no model ID is selected. Do not enable cross-region inference or overseas fallback. Verify availability, model access, Converse support, quotas and provider/model data handling against the no-ticket-retention requirement. Disable invocation payload logging and do not use persisted conversations or batch storage. These are required implementation checks, not verified capabilities or entitlement. If no suitable Australian model meets the constraints, flag the conflict rather than routing elsewhere. Evaluate summaries and urgency suggestions using approved synthetic or redacted test tickets.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Ticket triage backend → Managed language model: IAM-authorized regional Converse; no cross-region fallback; handling unverified (integration: bedrock-converse)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses.; REQ-003: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.; REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Select exact generation and, if needed, embedding model IDs, invocation API and inference mode; verify account access, regional availability and quotas with dated evidence.
- Map every inference destination to the agreed processing boundary; a regional endpoint or APAC profile does not by itself establish country-only processing.
- Implement scoped invocation IAM, token/time limits, retries and budget controls; keep source authorization before model invocation.
- Define prompt-injection handling, authorized citations, insufficient-evidence responses and output checks; test these separately from model guardrails.

## Architecture

```mermaid
flowchart LR
  n0["Staff member<br/>Tools & data"]
  n1["Ticket review web app<br/>AWS"]
  n2["Staff sign-in<br/>AWS"]
  n3["Authenticated triage API<br/>AWS"]
  n4["Ticket triage backend<br/>AWS"]
  n5["Managed language model<br/>AWS"]
  n0 -->|HTTPS: paste redacted/synthetic ticket; review suggestions| n1
  n1 -->|OAuth authorization code with PKCE; no ticket content; implementation required| n2
  n2 -->|JWT issuer and signing-key validation; implementation required| n3
  n1 -->|HTTPS POST /triage with access token; transient text; no-store response| n3
  n3 -->|Synchronous regional Lambda invocation; validated suggestions or safe error| n4
  n4 -->|IAM-authorized regional Converse; no cross-region fallback; handling unverified| n5
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Staff member | tools | Web browser | Australia — existing client | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-web | Ticket review web app | aws | AWS Amplify Hosting | ap-southeast-2 — proposed; delivery boundary unverified | Proposed | Implementation needed |
| staff-sign-in | Staff sign-in | aws | Amazon Cognito | ap-southeast-2 — proposed, unverified | Proposed | Implementation needed |
| triage-api | Authenticated triage API | aws | Amazon API Gateway | ap-southeast-2 — proposed, unverified | Proposed | Implementation needed |
| triage-function | Ticket triage backend | aws | AWS Lambda | ap-southeast-2 — proposed, unverified | Proposed | Implementation needed |
| triage-model | Managed language model | aws | Amazon Bedrock | ap-southeast-2 — proposed, model availability unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Staff member** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket review web app** (triage-web): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser.
- **Staff sign-in** (staff-sign-in): aws_cognito_user_pool. Active users and authentication features. Depends on: triage-web.
- **Authenticated triage API** (triage-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: staff-sign-in, triage-web.
- **Ticket triage backend** (triage-function): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: triage-api.
- **Managed language model** (triage-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: triage-function.

### Engineering work remaining

- Ticket review web app: Implementation needed.
- Staff sign-in: Implementation needed.
- Authenticated triage API: Implementation needed.
- Ticket triage backend: Implementation needed.
- Managed language model: Implementation needed.
- Wire staff-browser → triage-web: implement data flow, access policy and acceptance test.
- Wire triage-web → staff-sign-in: implement data flow, access policy and acceptance test.
- Wire staff-sign-in → triage-api: implement data flow, access policy and acceptance test.
- Wire triage-web → triage-api: implement data flow, access policy and acceptance test.
- Wire triage-api → triage-function: implement data flow, access policy and acceptance test.
- Wire triage-function → triage-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
