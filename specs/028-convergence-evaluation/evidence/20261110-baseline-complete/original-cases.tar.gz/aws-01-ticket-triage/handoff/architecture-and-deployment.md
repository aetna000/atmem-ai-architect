Snapshot f6d2ce26-8572-4bd0-bf0f-2754454ff7a6 · design r3 · generated 2026-11-09T16:48:57.815Z

# Ticket triage assistant — deployment document

Generated 2026-11-09 16:48 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a small internal tool where our team pastes a support ticket and gets a short summary, topic and suggested urgency. A person reviews the suggestion; it must not send replies or change customer records. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** We paste synthetic or redacted text, up to 20 KB per ticket. Do not retain ticket text after processing. Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** AWS
- **Budget and timeline:** —

## 3. Architecture

**Staff experience**

- Staff member (Tools & data, existing) — Existing staff member in Australia using a browser outside provisioning scope. Pastes synthetic or redacted ticket text up to 20 KB and reviews suggestions before taking any action separately. Redaction is the staff member's responsibility; automatic redaction is outside current scope.
- Ticket review web app (AWS, sketch) — Proposed static application hosted by AWS Amplify Hosting. Provides ticket entry, sign-in and a clearly labelled suggestion panel showing summary, topic and urgency. Proposes a 20,000-byte UTF-8 input limit; the backend independently enforces it. Holds ticket text only in transient page memory and clears it on completion, failure or sign-out. No persistent browser storage, service-worker caching, session replay or analytics capture of ticket content. API responses use no-store caching controls. Amplify global delivery may involve locations outside Australia: regional hosting does not establish Australian-only delivery, access metadata or control-plane handling. Review and flag these paths before deployment. Frontend and hosting implementation remain required; no existing application or supplied image is assumed.

**Staff access**

- Staff sign-in (AWS, sketch) — Proposed Amazon Cognito user pool with administrator-created staff accounts, self-registration disabled and MFA required. Browser sign-in uses authorization code with PKCE; API access requires an authorized staff token. Ticket content must never enter sign-in requests or identity attributes. Existing company sign-in is unknown; federation can be refined later. Verify Sydney availability and identity metadata/data-handling boundaries, flagging any overseas paths. General triage authentication requires custom implementation rather than the RAG-specific generator.

**Ticket analysis**

- Authenticated triage API (AWS, sketch) — Proposed regional Amazon API Gateway HTTP API exposing POST /triage. A JWT authorizer validates the intended Cognito issuer, audience and access scope; unauthenticated requests are denied. Restrict browser origins to the application and apply request throttling. Accepts ticket text and returns structured suggestions or a safe error with Cache-Control: no-store. Do not cache or log request/response bodies, tokens or ticket-derived content. Backend enforces the 20,000-byte UTF-8 text limit separately from JSON envelope size. Verify regional availability and telemetry handling; no automatic overseas endpoint failover. General API and authorization wiring require implementation.
- Ticket triage backend (AWS, sketch) — Proposed custom AWS Lambda application. Accepts synthetic or redacted text and rejects text exceeding 20,000 UTF-8 bytes, interpreting KB as decimal. Treats ticket contents as untrusted data and requests a structured summary, topic, suggested urgency and brief urgency rationale. Proposed urgency labels: low, normal, high and needs-review; ambiguous or invalid results require review. Checks response schema and never executes model instructions or external actions. No ticket database, queues, customer-system permissions, persistent ticket files or payload tracing. Ticket text is request-scoped only; release references on success/failure and never reuse content across invocations. Owns execution role and regional CloudWatch log group containing metadata/errors without ticket bodies or model responses. Bound output, retries, timeouts and concurrency during implementation. Reject unavailable regional inference rather than silently routing overseas. No runtime proof of non-retention or regional handling exists. Structured triage requires custom code and tests; bedrock-summary is insufficient.
- Managed language model (AWS, sketch) — Proposed Amazon Bedrock managed inference dependency for ticket analysis. Qualify a direct model in Sydney with sufficient input capacity for 20 KB of UTF-8 text plus instructions; no model ID is selected. Do not enable cross-region inference or overseas fallback. Verify availability, model access, Converse support, quotas and provider/model data handling against the no-ticket-retention requirement. Disable invocation payload logging and do not use persisted conversations or batch storage. These are required implementation checks, not verified capabilities or entitlement. If no suitable Australian model meets the constraints, flag the conflict rather than routing elsewhere. Evaluate summaries and urgency suggestions using approved synthetic or redacted test tickets.

```mermaid
flowchart LR
  n0["Staff member<br/>Tools & data"]
  n1["Ticket review web app<br/>AWS"]
  n2["Staff sign-in<br/>AWS"]
  n3["Authenticated triage API<br/>AWS"]
  n4["Ticket triage backend<br/>AWS"]
  n5["Managed language model<br/>AWS"]
  n0 -->|HTTPS: paste redacted/synthetic ticket; review suggestions| n1
  n1 -->|OAuth authorization code with PKCE; no ticket content; implementation required| n2
  n2 -->|JWT issuer and signing-key validation; implementation required| n3
  n1 -->|HTTPS POST /triage with access token; transient text; no-store response| n3
  n3 -->|Synchronous regional Lambda invocation; validated suggestions or safe error| n4
  n4 -->|IAM-authorized regional Converse; no cross-region fallback; handling unverified| n5
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| staff-browser | Staff member | tools | Web browser | Australia — existing client | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| triage-web | Ticket review web app | aws | AWS Amplify Hosting | ap-southeast-2 — proposed; delivery boundary unverified | Proposed | Implementation needed |
| staff-sign-in | Staff sign-in | aws | Amazon Cognito | ap-southeast-2 — proposed, unverified | Proposed | Implementation needed |
| triage-api | Authenticated triage API | aws | Amazon API Gateway | ap-southeast-2 — proposed, unverified | Proposed | Implementation needed |
| triage-function | Ticket triage backend | aws | AWS Lambda | ap-southeast-2 — proposed, unverified | Proposed | Implementation needed |
| triage-model | Managed language model | aws | Amazon Bedrock | ap-southeast-2 — proposed, model availability unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Staff member** (staff-browser): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Ticket review web app** (triage-web): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: staff-browser.
- **Staff sign-in** (staff-sign-in): aws_cognito_user_pool. Active users and authentication features. Depends on: triage-web.
- **Authenticated triage API** (triage-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: staff-sign-in, triage-web.
- **Ticket triage backend** (triage-function): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: triage-api.
- **Managed language model** (triage-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: triage-function.

### Engineering work remaining

- Ticket review web app: Implementation needed.
- Staff sign-in: Implementation needed.
- Authenticated triage API: Implementation needed.
- Ticket triage backend: Implementation needed.
- Managed language model: Implementation needed.
- Wire staff-browser → triage-web: implement data flow, access policy and acceptance test.
- Wire triage-web → staff-sign-in: implement data flow, access policy and acceptance test.
- Wire staff-sign-in → triage-api: implement data flow, access policy and acceptance test.
- Wire triage-web → triage-api: implement data flow, access policy and acceptance test.
- Wire triage-api → triage-function: implement data flow, access policy and acceptance test.
- Wire triage-function → triage-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Staff member | Ticket review web app | HTTPS: paste redacted/synthetic ticket; review suggestions | Confidential |
| Ticket review web app | Staff sign-in | OAuth authorization code with PKCE; no ticket content; implementation required | Confidential |
| Staff sign-in | Authenticated triage API | JWT issuer and signing-key validation; implementation required | Confidential |
| Ticket review web app | Authenticated triage API | HTTPS POST /triage with access token; transient text; no-store response | Confidential |
| Authenticated triage API | Ticket triage backend | Synchronous regional Lambda invocation; validated suggestions or safe error | Confidential |
| Ticket triage backend | Managed language model | IAM-authorized regional Converse; no cross-region fallback; handling unverified | Confidential |

## 5. Security controls

- **Staff member** — Existing staff member in Australia using a browser outside provisioning scope. Pastes synthetic or redacted ticket text up to 20 KB and reviews suggestions before taking any action separately. Redaction is the staff member's responsibility; automatic redaction is outside current scope.
- **Staff sign-in** — Proposed Amazon Cognito user pool with administrator-created staff accounts, self-registration disabled and MFA required. Browser sign-in uses authorization code with PKCE; API access requires an authorized staff token. Ticket content must never enter sign-in requests or identity attributes. Existing company sign-in is unknown; federation can be refined later. Verify Sydney availability and identity metadata/data-handling boundaries, flagging any overseas paths. General triage authentication requires custom implementation rather than the RAG-specific generator.
- Requirement: A person approves sensitive actions before they happen (must)
- Requirement: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement. (must)
- Requirement: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement. | security | not measurable yet | Open |
| Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification. | compliance | not measurable yet | Open |

**Functional**

- A person approves sensitive actions before they happen (must, open)
- For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses. (must, open)
- Accept synthetic or redacted support-ticket text up to 20 KB and explicitly reject oversized input without truncation; propose interpreting the limit as 20,000 UTF-8 bytes and enforce it on the server. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.”, “Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 5 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Managed language model | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Staff member, Ticket review web app, Authenticated triage API, Ticket triage backend.

**Estimate gaps:**

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Managed language model / Endpoint hours: price needed.
- Staff member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket review web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated triage API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage backend: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision staff experience: Ticket review web app.
4. Provision staff access: Staff sign-in.
5. Provision ticket analysis: Authenticated triage API, Ticket triage backend, Managed language model.
6. Connect existing systems: Staff member; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Our users are in Australia; use an Australian region where the chosen services support it. Flag anything that would leave Australia.

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- Staff sign-in: needs requests_per_month _(estimate)_
- Managed language model: needs a unit price with a source _(estimate)_
