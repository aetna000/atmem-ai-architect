# Delivery handoff

Snapshot f6d2ce26-8572-4bd0-bf0f-2754454ff7a6 · design r3 · generated 2026-11-09T16:48:57.815Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Staff sign-in / Checked requests: input needed (requests_per_month).
- Managed language model / Endpoint hours: price needed.
- Staff member: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket review web app: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated triage API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket triage backend: no cost lines; add charges or an explicit zero-cost line with a reason.
- Ticket review web app: Implementation needed.
- Staff sign-in: Implementation needed.
- Authenticated triage API: Implementation needed.
- Ticket triage backend: Implementation needed.
- Managed language model: Implementation needed.
- Wire staff-browser → triage-web: implement data flow, access policy and acceptance test.
- Wire triage-web → staff-sign-in: implement data flow, access policy and acceptance test.
- Wire staff-sign-in → triage-api: implement data flow, access policy and acceptance test.
- Wire triage-web → triage-api: implement data flow, access policy and acceptance test.
- Wire triage-api → triage-function: implement data flow, access policy and acceptance test.
- Wire triage-function → triage-model: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
