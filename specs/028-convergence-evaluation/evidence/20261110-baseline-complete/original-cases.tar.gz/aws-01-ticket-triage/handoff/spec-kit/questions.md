# Questions and assumptions to resolve

Snapshot f6d2ce26-8572-4bd0-bf0f-2754454ff7a6 · design r3 · generated 2026-11-09T16:48:57.815Z

- [ai-triage-result] Confirm REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses.
- [ai-triage-private-access] Confirm REQ-003: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.
- [ai-triage-input-bound] Confirm REQ-004: Accept synthetic or redacted support-ticket text up to 20 KB and explicitly reject oversized input without truncation; propose interpreting the limit as 20,000 UTF-8 bytes and enforce it on the server.
- [ai-triage-australian-processing] Confirm REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.
- [acceptance-req-49507123] Agree a measurable acceptance check for REQ-001: A person approves sensitive actions before they happen
- [acceptance-ai-triage-result] Agree a measurable acceptance check for REQ-002: For a pasted support ticket, return a short summary, topic and suggested urgency clearly presented as suggestions for staff review; failures must not appear as successful analyses.
- [acceptance-ai-triage-private-access] Agree a measurable acceptance check for REQ-003: Proposed: permit analysis only for authorized staff, retain no ticket history in the application, and exclude ticket text and generated content from operational logs; confirm country and model data-handling constraints before placement.
- [acceptance-ai-triage-input-bound] Agree a measurable acceptance check for REQ-004: Accept synthetic or redacted support-ticket text up to 20 KB and explicitly reject oversized input without truncation; propose interpreting the limit as 20,000 UTF-8 bytes and enforce it on the server.
- [acceptance-ai-triage-australian-processing] Agree a measurable acceptance check for REQ-005: Use Australian regional services where supported, identify any data or metadata path leaving Australia, and do not silently enable overseas inference or failover. Verify the selected model's location and handling before implementation; Sydney is a proposal pending verification.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d7472696167652d6175737472616c69616e2d70726f63657373696e67] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d696e7075742d626f756e64] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d707269766174652d616363657373] REQ-003 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7472696167652d726573756c74] REQ-002 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
