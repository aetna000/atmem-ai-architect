# Component and interface contracts

Snapshot f6d2ce26-8572-4bd0-bf0f-2754454ff7a6 · design r3 · generated 2026-11-09T16:48:57.815Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component staff-browser: Staff member

- Responsibility: Existing staff member in Australia using a browser outside provisioning scope. Pastes synthetic or redacted ticket text up to 20 KB and reviews suggestions before taking any action separately. Redaction is the staff member's responsibility; automatic redaction is outside current scope.
- Service: Web browser
- Provider / placement: tools / Australia — existing client
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-73746166662d62726f77736572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component triage-web: Ticket review web app

- Responsibility: Proposed static application hosted by AWS Amplify Hosting. Provides ticket entry, sign-in and a clearly labelled suggestion panel showing summary, topic and urgency. Proposes a 20,000-byte UTF-8 input limit; the backend independently enforces it. Holds ticket text only in transient page memory and clears it on completion, failure or sign-out. No persistent browser storage, service-worker caching, session replay or analytics capture of ticket content. API responses use no-store caching controls. Amplify global delivery may involve locations outside Australia: regional hosting does not establish Australian-only delivery, access metadata or control-plane handling. Review and flag these paths before deployment. Frontend and hosting implementation remain required; no existing application or supplied image is assumed.
- Service: AWS Amplify Hosting
- Provider / placement: aws / ap-southeast-2 — proposed; delivery boundary unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component staff-sign-in: Staff sign-in

- Responsibility: Proposed Amazon Cognito user pool with administrator-created staff accounts, self-registration disabled and MFA required. Browser sign-in uses authorization code with PKCE; API access requires an authorized staff token. Ticket content must never enter sign-in requests or identity attributes. Existing company sign-in is unknown; federation can be refined later. Verify Sydney availability and identity metadata/data-handling boundaries, flagging any overseas paths. General triage authentication requires custom implementation rather than the RAG-specific generator.
- Service: Amazon Cognito
- Provider / placement: aws / ap-southeast-2 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73746166662d7369676e2d696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-api: Authenticated triage API

- Responsibility: Proposed regional Amazon API Gateway HTTP API exposing POST /triage. A JWT authorizer validates the intended Cognito issuer, audience and access scope; unauthenticated requests are denied. Restrict browser origins to the application and apply request throttling. Accepts ticket text and returns structured suggestions or a safe error with Cache-Control: no-store. Do not cache or log request/response bodies, tokens or ticket-derived content. Backend enforces the 20,000-byte UTF-8 text limit separately from JSON envelope size. Verify regional availability and telemetry handling; no automatic overseas endpoint failover. General API and authorization wiring require implementation.
- Service: Amazon API Gateway
- Provider / placement: aws / ap-southeast-2 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component triage-function: Ticket triage backend

- Responsibility: Proposed custom AWS Lambda application. Accepts synthetic or redacted text and rejects text exceeding 20,000 UTF-8 bytes, interpreting KB as decimal. Treats ticket contents as untrusted data and requests a structured summary, topic, suggested urgency and brief urgency rationale. Proposed urgency labels: low, normal, high and needs-review; ambiguous or invalid results require review. Checks response schema and never executes model instructions or external actions. No ticket database, queues, customer-system permissions, persistent ticket files or payload tracing. Ticket text is request-scoped only; release references on success/failure and never reuse content across invocations. Owns execution role and regional CloudWatch log group containing metadata/errors without ticket bodies or model responses. Bound output, retries, timeouts and concurrency during implementation. Reject unavailable regional inference rather than silently routing overseas. No runtime proof of non-retention or regional handling exists. Structured triage requires custom code and tests; bedrock-summary is insufficient.
- Service: AWS Lambda
- Provider / placement: aws / ap-southeast-2 — proposed, unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d66756e6374696f6e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component triage-model: Managed language model

- Responsibility: Proposed Amazon Bedrock managed inference dependency for ticket analysis. Qualify a direct model in Sydney with sufficient input capacity for 20 KB of UTF-8 text plus instructions; no model ID is selected. Do not enable cross-region inference or overseas fallback. Verify availability, model access, Converse support, quotas and provider/model data handling against the no-ticket-retention requirement. Disable invocation payload logging and do not use persisted conversations or batch storage. These are required implementation checks, not verified capabilities or entitlement. If no suitable Australian model meets the constraints, flag the conflict rather than routing elsewhere. Evaluate summaries and urgency suggestions using approved synthetic or redacted test tickets.
- Service: Amazon Bedrock
- Provider / placement: aws / ap-southeast-2 — proposed, model availability unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7472696167652d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Select exact generation and, if needed, embedding model IDs, invocation API and inference mode; verify account access, regional availability and quotas with dated evidence.
- Map every inference destination to the agreed processing boundary; a regional endpoint or APAC profile does not by itself establish country-only processing.
- Implement scoped invocation IAM, token/time limits, retries and budget controls; keep source authorization before model invocation.
- Define prompt-injection handling, authorized citations, insufficient-evidence responses and output checks; test these separately from model guardrails.

## Interfaces

### staff-web: staff-browser → triage-web

- Drawn payload/purpose: HTTPS: paste redacted/synthetic ticket; review suggestions
- Contract task: TASK-CONTRACT-73746166662d776562
- Integration task: TASK-INTEGRATION-73746166662d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-sign-in: triage-web → staff-sign-in

- Drawn payload/purpose: OAuth authorization code with PKCE; no ticket content; implementation required
- Contract task: TASK-CONTRACT-7765622d7369676e2d696e
- Integration task: TASK-INTEGRATION-7765622d7369676e2d696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sign-in-api: staff-sign-in → triage-api

- Drawn payload/purpose: JWT issuer and signing-key validation; implementation required
- Contract task: TASK-CONTRACT-7369676e2d696e2d617069
- Integration task: TASK-INTEGRATION-7369676e2d696e2d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-api: triage-web → triage-api

- Drawn payload/purpose: HTTPS POST /triage with access token; transient text; no-store response
- Contract task: TASK-CONTRACT-7765622d617069
- Integration task: TASK-INTEGRATION-7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-function: triage-api → triage-function

- Drawn payload/purpose: Synchronous regional Lambda invocation; validated suggestions or safe error
- Contract task: TASK-CONTRACT-6170692d66756e6374696f6e
- Integration task: TASK-INTEGRATION-6170692d66756e6374696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### function-model: triage-function → triage-model

- Drawn payload/purpose: IAM-authorized regional Converse; no cross-region fallback; handling unverified
- Contract task: TASK-CONTRACT-66756e6374696f6e2d6d6f64656c
- Integration task: TASK-INTEGRATION-66756e6374696f6e2d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
