# Delivery handoff

Snapshot 72ab4113-f8b7-4d37-a522-dac4fe9e27dd · design r3 · generated 2026-11-09T16:51:36.656Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Approved public article collection / Storage: input needed (data_gb).
- Answer generation model / Endpoint hours: price needed.
- Website visitor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public assistant website: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public questions and protected publishing: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorized article publisher: no cost lines; add charges or an explicit zero-cost line with a reason.
- Grounded FAQ answers: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public assistant website: Implementation needed.
- Public questions and protected publishing: Implementation needed.
- Authorized article publisher: Existing — reference/import plan needed.
- Grounded FAQ answers: Implementation needed.
- Approved public article collection: Implementation needed.
- Answer generation model: Existing — reference/import plan needed.
- Wire faq-visitor → faq-web: implement data flow, access policy and acceptance test.
- Wire faq-web → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-publisher → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
