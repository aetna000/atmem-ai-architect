Snapshot 72ab4113-f8b7-4d37-a522-dac4fe9e27dd · design r3 · generated 2026-11-09T16:51:36.656Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch. (must, open); target: acceptance target needed; linked blocks: faq-app, faq-articles, faq-model

Design explanation: Proposed acceptance requirement: prevents unsupported answers from appearing authoritative. Complements existing citation requirement req-ebfa0712.

Basis: User: “cites the articles it used, and says when it does not know.”
- [REQ-005] The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access. (must, open); target: acceptance target needed; linked blocks: faq-api, faq-publisher, faq-app, faq-articles

Design explanation: Proposed access boundary: public visitors must not introduce sources or cause private information to enter retrieval.

Basis: User: “It must not answer from private sources.” Public website access and faq-publisher require distinct permissions.
- [REQ-006] Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery. (must, open); target: acceptance target needed; linked blocks: faq-publisher, faq-api, faq-app, faq-articles

Design explanation: Proposed lifecycle requirement: prevents removed or superseded articles from continuing to support new answers.

Basis: User: “We need to update and remove articles.”
- [REQ-007] Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable. (should, open); target: acceptance target needed; linked blocks: faq-web, faq-api, faq-app, faq-articles, faq-model

Design explanation: Australia is a preference rather than an absolute residency rule; documenting actual locations and model limitations prevents an unsupported Australia-only claim.

Basis: “Australia is preferred; make model/data-location limitations explicit.” Sydney placement and no overseas fallback are architectural proposals, not confirmed regional decisions.

## How the system works

The current design contains 7 components and 6 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Website visitor → Public assistant website

HTTPS: public static assistant interface

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Public assistant website → Public questions and protected publishing

Browser HTTPS to regional API: question; cited answer or unknown/unavailable

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Authorized article publisher → Public questions and protected publishing

SigV4: publish, revise or remove approved articles

Access contract: api-invoke.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Public questions and protected publishing → Grounded FAQ answers

REST Lambda proxy: validated route and authorization context

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Grounded FAQ answers → Approved public article collection

Regional AWS SDK: active article reads and conditional publishing writes

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Grounded FAQ answers → Answer generation model

Direct regional Converse: question/public excerpts; draft cited answer; no overs

Integration contract: bedrock-converse.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Website visitor

Web browser · tools · region: External · classification: Public

Existing visitor browser outside provisioning scope. Uses the assistant anonymously; receives cited answers or an explicit unknown response. No article-management permissions. Visitor devices and networks may be outside Australia.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Website visitor → Public assistant website: HTTPS: public static assistant interface (integration: browser-https)

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Public assistant website

Amazon CloudFront · aws · region: Global edge; Australian origin proposed · classification: Public

Proposed Amazon CloudFront distribution delivers public static assistant assets globally over HTTPS. Hosting module owns private S3 web assets and origin access control, with the origin proposed in Sydney. Browser sends questions directly to the regional API; do not cache questions or answers at the edge. Interface displays source links and unknown/unavailable states. Global delivery is not Australia-only residency; delivery metadata and logging locations require review. Anonymous hosting requires implementation beyond the Cognito-based rag-web-app contract.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Website visitor → Public assistant website: HTTPS: public static assistant interface (integration: browser-https)

Outputs: Public assistant website → Public questions and protected publishing: Browser HTTPS to regional API: question; cited answer or unknown/unavailable

Requirement traceability: REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Public questions and protected publishing

Amazon API Gateway · aws · region: ap-southeast-2 · classification: Public

Proposed regional REST API in Sydney; region choice and service availability remain unverified. Anonymous POST /questions accepts bounded questions; separate article-management routes require AWS IAM authorization. Apply request validation and throttling, restrict browser origins and never rely on browser controls for publisher authorization. No public article-management route. Disable response caching and avoid question bodies in access logs. Regional outage returns unavailable without overseas failover. Public routes, authorization configuration and Lambda integration need implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public assistant website → Public questions and protected publishing: Browser HTTPS to regional API: question; cited answer or unknown/unavailable; Authorized article publisher → Public questions and protected publishing: SigV4: publish, revise or remove approved articles (access: api-invoke)

Outputs: Public questions and protected publishing → Grounded FAQ answers: REST Lambda proxy: validated route and authorization context

Requirement traceability: REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authorized article publisher

Existing AWS IAM principal · tools · region: External · classification: Internal

External reference for a proposed publishing workflow operated by an existing authorized AWS principal. Identity remains an account input, not a verified permission. A signed operator tool submits approved public article text, canonical URL and revision, and requests updates or removal. No existing CMS or native connector is assumed; operator-tool implementation is required.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Authorized article publisher → Public questions and protected publishing: SigV4: publish, revise or remove approved articles

Requirement traceability: REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### Grounded FAQ answers

AWS Lambda · aws · region: ap-southeast-2 · classification: Public

One proposed Lambda deployment in Sydney owns question answering and protected publishing handlers. Recommend bounded keyword retrieval over the twenty approved articles, with no vector store initially. Send only retrieved active public excerpts and the question to a reviewed direct model in the same region; no cross-region inference profiles or overseas fallback. Treat article text as untrusted data, validate returned citation IDs and recheck revisions before responding. Return answer plus canonical article links, or explicit unknown/unavailable response; inference failure must not trigger unsupported answers. Grounding and abstention require evaluation. Publisher operations use conditional revisions and deletion tombstones. No private connectors or general web search. Bound input, output, SDK retries and concurrency; avoid full question/answer logging, persistent conversation history and answer caching initially. Module owns execution role, scoped regional logs and deployment versioning. Single-region availability is proposed, without cross-region disaster recovery. Custom application and IAM implementation required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public questions and protected publishing → Grounded FAQ answers: REST Lambda proxy: validated route and authorization context

Outputs: Grounded FAQ answers → Approved public article collection: Regional AWS SDK: active article reads and conditional publishing writes; Grounded FAQ answers → Answer generation model: Direct regional Converse: question/public excerpts; draft cited answer; no overs (integration: bedrock-converse)

Requirement traceability: REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.; REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Approved public article collection

Amazon DynamoDB · aws · region: ap-southeast-2 · classification: Public

Dedicated DynamoDB table proposed in Sydney stores approved article text chunks, canonical URLs, titles, active revisions and deletion tombstones. Start with the twenty public help articles. Only the application role may read or conditionally update this collection; visitors cannot write it. Publishing must atomically activate revisions and invalidate removed content; strongly consistent revision checks prevent stale citations. Propose regional point-in-time recovery, no global-table replicas or overseas backup copies, and restore procedures retaining deletions before serving traffic. Backup location, retention and recovery behavior require implementation review. Custom catalog and lifecycle implementation required.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Grounded FAQ answers → Approved public article collection: Regional AWS SDK: active article reads and conditional publishing writes

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.; REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

### Answer generation model

Amazon Bedrock · aws · region: ap-southeast-2 · classification: Public

Reference to Amazon Bedrock managed inference, not a provisioned foundation model or verified entitlement. Propose direct regional inference in Sydney through Converse using only approved public excerpts and the question. No model ID is selected: exact regional availability, Converse support, account access, quotas and model/provider data-handling and retention terms require verification. A regional endpoint alone does not prove every processing, metadata or support boundary. No cross-region inference profile or overseas fallback; if a suitable direct regional model is unavailable, return unavailable and revisit the design before enabling inference. Model instructions alone do not prove grounding or abstention.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Grounded FAQ answers → Answer generation model: Direct regional Converse: question/public excerpts; draft cited answer; no overs (integration: bedrock-converse)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Website visitor<br/>Tools & data"]
  n1["Public assistant website<br/>AWS"]
  n2["Public questions and protected publishing<br/>AWS"]
  n3["Authorized article publisher<br/>Tools & data"]
  n4["Grounded FAQ answers<br/>AWS"]
  n5["Approved public article collection<br/>AWS"]
  n6["Answer generation model<br/>AWS"]
  n0 -->|HTTPS: public static assistant interface| n1
  n1 -->|Browser HTTPS to regional API: question; cited answer or unknown/unavailable| n2
  n3 -->|SigV4: publish, revise or remove approved articles| n2
  n2 -->|REST Lambda proxy: validated route and authorization context| n4
  n4 -->|Regional AWS SDK: active article reads and conditional publishing writes| n5
  n4 -->|Direct regional Converse: question/public excerpts; draft cited answer; no overs| n6
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitor | Website visitor | tools | Web browser | External | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-web | Public assistant website | aws | Amazon CloudFront | Global edge; Australian origin proposed | Proposed | Implementation needed |
| faq-api | Public questions and protected publishing | aws | Amazon API Gateway | ap-southeast-2 | Proposed | Implementation needed |
| faq-publisher | Authorized article publisher | tools | Existing AWS IAM principal | External | Existing | Existing — reference/import plan needed |
| faq-app | Grounded FAQ answers | aws | AWS Lambda | ap-southeast-2 | Proposed | Implementation needed |
| faq-articles | Approved public article collection | aws | Amazon DynamoDB | ap-southeast-2 | Proposed | Implementation needed |
| faq-model | Answer generation model | aws | Amazon Bedrock | ap-southeast-2 | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Website visitor** (faq-visitor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public assistant website** (faq-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: faq-visitor.
- **Public questions and protected publishing** (faq-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: faq-web, faq-publisher.
- **Authorized article publisher** (faq-publisher): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Grounded FAQ answers** (faq-app): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: faq-api.
- **Approved public article collection** (faq-articles): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: faq-app.
- **Answer generation model** (faq-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: faq-app.

### Engineering work remaining

- Public assistant website: Implementation needed.
- Public questions and protected publishing: Implementation needed.
- Authorized article publisher: Existing — reference/import plan needed.
- Grounded FAQ answers: Implementation needed.
- Approved public article collection: Implementation needed.
- Answer generation model: Existing — reference/import plan needed.
- Wire faq-visitor → faq-web: implement data flow, access policy and acceptance test.
- Wire faq-web → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-publisher → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia (preferred)

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
