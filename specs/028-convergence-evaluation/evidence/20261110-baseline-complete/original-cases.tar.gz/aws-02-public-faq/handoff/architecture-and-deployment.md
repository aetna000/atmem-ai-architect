Snapshot 72ab4113-f8b7-4d37-a522-dac4fe9e27dd · design r3 · generated 2026-11-09T16:51:36.656Z

# Cited public FAQ — deployment document

Generated 2026-11-09 16:51 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 9 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** Australia is preferred; make model/data-location limitations explicit.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** AWS
- **Budget and timeline:** —

## 3. Architecture

**Public website**

- Website visitor (Tools & data, existing) — Existing visitor browser outside provisioning scope. Uses the assistant anonymously; receives cited answers or an explicit unknown response. No article-management permissions. Visitor devices and networks may be outside Australia.
- Public assistant website (AWS, sketch) — Proposed Amazon CloudFront distribution delivers public static assistant assets globally over HTTPS. Hosting module owns private S3 web assets and origin access control, with the origin proposed in Sydney. Browser sends questions directly to the regional API; do not cache questions or answers at the edge. Interface displays source links and unknown/unavailable states. Global delivery is not Australia-only residency; delivery metadata and logging locations require review. Anonymous hosting requires implementation beyond the Cognito-based rag-web-app contract.

**Answer and publish**

- Public questions and protected publishing (AWS, sketch) — Proposed regional REST API in Sydney; region choice and service availability remain unverified. Anonymous POST /questions accepts bounded questions; separate article-management routes require AWS IAM authorization. Apply request validation and throttling, restrict browser origins and never rely on browser controls for publisher authorization. No public article-management route. Disable response caching and avoid question bodies in access logs. Regional outage returns unavailable without overseas failover. Public routes, authorization configuration and Lambda integration need implementation.
- Grounded FAQ answers (AWS, sketch) — One proposed Lambda deployment in Sydney owns question answering and protected publishing handlers. Recommend bounded keyword retrieval over the twenty approved articles, with no vector store initially. Send only retrieved active public excerpts and the question to a reviewed direct model in the same region; no cross-region inference profiles or overseas fallback. Treat article text as untrusted data, validate returned citation IDs and recheck revisions before responding. Return answer plus canonical article links, or explicit unknown/unavailable response; inference failure must not trigger unsupported answers. Grounding and abstention require evaluation. Publisher operations use conditional revisions and deletion tombstones. No private connectors or general web search. Bound input, output, SDK retries and concurrency; avoid full question/answer logging, persistent conversation history and answer caching initially. Module owns execution role, scoped regional logs and deployment versioning. Single-region availability is proposed, without cross-region disaster recovery. Custom application and IAM implementation required.
- Answer generation model (AWS, existing, sketch) — Reference to Amazon Bedrock managed inference, not a provisioned foundation model or verified entitlement. Propose direct regional inference in Sydney through Converse using only approved public excerpts and the question. No model ID is selected: exact regional availability, Converse support, account access, quotas and model/provider data-handling and retention terms require verification. A regional endpoint alone does not prove every processing, metadata or support boundary. No cross-region inference profile or overseas fallback; if a suitable direct regional model is unavailable, return unavailable and revisit the design before enabling inference. Model instructions alone do not prove grounding or abstention.

**Article publishing**

- Authorized article publisher (Tools & data, existing) — External reference for a proposed publishing workflow operated by an existing authorized AWS principal. Identity remains an account input, not a verified permission. A signed operator tool submits approved public article text, canonical URL and revision, and requests updates or removal. No existing CMS or native connector is assumed; operator-tool implementation is required.
- Approved public article collection (AWS, sketch) — Dedicated DynamoDB table proposed in Sydney stores approved article text chunks, canonical URLs, titles, active revisions and deletion tombstones. Start with the twenty public help articles. Only the application role may read or conditionally update this collection; visitors cannot write it. Publishing must atomically activate revisions and invalidate removed content; strongly consistent revision checks prevent stale citations. Propose regional point-in-time recovery, no global-table replicas or overseas backup copies, and restore procedures retaining deletions before serving traffic. Backup location, retention and recovery behavior require implementation review. Custom catalog and lifecycle implementation required.

```mermaid
flowchart LR
  n0["Website visitor<br/>Tools & data"]
  n1["Public assistant website<br/>AWS"]
  n2["Public questions and protected publishing<br/>AWS"]
  n3["Authorized article publisher<br/>Tools & data"]
  n4["Grounded FAQ answers<br/>AWS"]
  n5["Approved public article collection<br/>AWS"]
  n6["Answer generation model<br/>AWS"]
  n0 -->|HTTPS: public static assistant interface| n1
  n1 -->|Browser HTTPS to regional API: question; cited answer or unknown/unavailable| n2
  n3 -->|SigV4: publish, revise or remove approved articles| n2
  n2 -->|REST Lambda proxy: validated route and authorization context| n4
  n4 -->|Regional AWS SDK: active article reads and conditional publishing writes| n5
  n4 -->|Direct regional Converse: question/public excerpts; draft cited answer; no overs| n6
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitor | Website visitor | tools | Web browser | External | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-web | Public assistant website | aws | Amazon CloudFront | Global edge; Australian origin proposed | Proposed | Implementation needed |
| faq-api | Public questions and protected publishing | aws | Amazon API Gateway | ap-southeast-2 | Proposed | Implementation needed |
| faq-publisher | Authorized article publisher | tools | Existing AWS IAM principal | External | Existing | Existing — reference/import plan needed |
| faq-app | Grounded FAQ answers | aws | AWS Lambda | ap-southeast-2 | Proposed | Implementation needed |
| faq-articles | Approved public article collection | aws | Amazon DynamoDB | ap-southeast-2 | Proposed | Implementation needed |
| faq-model | Answer generation model | aws | Amazon Bedrock | ap-southeast-2 | Existing | Existing — reference/import plan needed |

### Resources and cost dimensions

- **Website visitor** (faq-visitor): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Public assistant website** (faq-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: faq-visitor.
- **Public questions and protected publishing** (faq-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: faq-web, faq-publisher.
- **Authorized article publisher** (faq-publisher): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Grounded FAQ answers** (faq-app): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: faq-api.
- **Approved public article collection** (faq-articles): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: faq-app.
- **Answer generation model** (faq-model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: faq-app.

### Engineering work remaining

- Public assistant website: Implementation needed.
- Public questions and protected publishing: Implementation needed.
- Authorized article publisher: Existing — reference/import plan needed.
- Grounded FAQ answers: Implementation needed.
- Approved public article collection: Implementation needed.
- Answer generation model: Existing — reference/import plan needed.
- Wire faq-visitor → faq-web: implement data flow, access policy and acceptance test.
- Wire faq-web → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-publisher → faq-api: implement data flow, access policy and acceptance test.
- Wire faq-api → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-articles: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Website visitor | Public assistant website | HTTPS: public static assistant interface | Public |
| Public assistant website | Public questions and protected publishing | Browser HTTPS to regional API: question; cited answer or unknown/unavailable | Public |
| Authorized article publisher | Public questions and protected publishing | SigV4: publish, revise or remove approved articles | Internal |
| Public questions and protected publishing | Grounded FAQ answers | REST Lambda proxy: validated route and authorization context | Public |
| Grounded FAQ answers | Approved public article collection | Regional AWS SDK: active article reads and conditional publishing writes | Public |
| Grounded FAQ answers | Answer generation model | Direct regional Converse: question/public excerpts; draft cited answer; no overs | Public |

## 5. Security controls

- _No guardrail or approval components in the design._
- Requirement: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access. (must)
- Requirement: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access. | security | not measurable yet | Open |
| Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch. (must, open)
- Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_
- [minor] The design depends on existing systems; their failure behaviour is not described. State what happens when each existing system is unavailable (retry, queue, fallback). _(AtMem AI Architect rule REL-002 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.”, “Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 5 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Approved public article collection | Storage | needs data_gb | price needed | — | — |
| Answer generation model | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Website visitor, Public assistant website, Public questions and protected publishing, Authorized article publisher, Grounded FAQ answers.

**Estimate gaps:**

- Approved public article collection / Storage: input needed (data_gb).
- Answer generation model / Endpoint hours: price needed.
- Website visitor: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public assistant website: no cost lines; add charges or an explicit zero-cost line with a reason.
- Public questions and protected publishing: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorized article publisher: no cost lines; add charges or an explicit zero-cost line with a reason.
- Grounded FAQ answers: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision public website: Public assistant website.
4. Provision article publishing: Approved public article collection.
5. Provision answer and publish: Public questions and protected publishing, Grounded FAQ answers.
6. Connect existing systems: Website visitor, Authorized article publisher, Answer generation model; test failure behaviour.
7. Run the acceptance checks (success measures and requirements) in staging; record results.
8. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia is preferred; make model/data-location limitations explicit.

**Options considered**

—

**Decision**

Australia (preferred)

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Who will use this system? _(discovery)_
- Approved public article collection: needs data_gb _(estimate)_
- Answer generation model: needs a unit price with a source _(estimate)_
