# Questions and assumptions to resolve

Snapshot 72ab4113-f8b7-4d37-a522-dac4fe9e27dd · design r3 · generated 2026-11-09T16:51:36.656Z

- [ai-grounded-abstention] Confirm REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.
- [ai-public-source-boundary] Confirm REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.
- [ai-article-lifecycle] Confirm REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.
- [ai-location-transparency] Confirm REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
- [acceptance-req-ebfa0712] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-grounded-abstention] Agree a measurable acceptance check for REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.
- [acceptance-ai-public-source-boundary] Agree a measurable acceptance check for REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.
- [acceptance-ai-article-lifecycle] Agree a measurable acceptance check for REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.
- [acceptance-ai-location-transparency] Agree a measurable acceptance check for REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d61727469636c652d6c6966656379636c65] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d61627374656e74696f6e] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d736f757263652d626f756e64617279] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
