# Component and interface contracts

Snapshot 72ab4113-f8b7-4d37-a522-dac4fe9e27dd · design r3 · generated 2026-11-09T16:51:36.656Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-visitor: Website visitor

- Responsibility: Existing visitor browser outside provisioning scope. Uses the assistant anonymously; receives cited answers or an explicit unknown response. No article-management permissions. Visitor devices and networks may be outside Australia.
- Service: Web browser
- Provider / placement: tools / External
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d76697369746f72
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-web: Public assistant website

- Responsibility: Proposed Amazon CloudFront distribution delivers public static assistant assets globally over HTTPS. Hosting module owns private S3 web assets and origin access control, with the origin proposed in Sydney. Browser sends questions directly to the regional API; do not cache questions or answers at the edge. Interface displays source links and unknown/unavailable states. Global delivery is not Australia-only residency; delivery metadata and logging locations require review. Anonymous hosting requires implementation beyond the Cognito-based rag-web-app contract.
- Service: Amazon CloudFront
- Provider / placement: aws / Global edge; Australian origin proposed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-api: Public questions and protected publishing

- Responsibility: Proposed regional REST API in Sydney; region choice and service availability remain unverified. Anonymous POST /questions accepts bounded questions; separate article-management routes require AWS IAM authorization. Apply request validation and throttling, restrict browser origins and never rely on browser controls for publisher authorization. No public article-management route. Disable response caching and avoid question bodies in access logs. Regional outage returns unavailable without overseas failover. Public routes, authorization configuration and Lambda integration need implementation.
- Service: Amazon API Gateway
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-publisher: Authorized article publisher

- Responsibility: External reference for a proposed publishing workflow operated by an existing authorized AWS principal. Identity remains an account input, not a verified permission. A signed operator tool submits approved public article text, canonical URL and revision, and requests updates or removal. No existing CMS or native connector is assumed; operator-tool implementation is required.
- Service: Existing AWS IAM principal
- Provider / placement: tools / External
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d7075626c6973686572
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component faq-app: Grounded FAQ answers

- Responsibility: One proposed Lambda deployment in Sydney owns question answering and protected publishing handlers. Recommend bounded keyword retrieval over the twenty approved articles, with no vector store initially. Send only retrieved active public excerpts and the question to a reviewed direct model in the same region; no cross-region inference profiles or overseas fallback. Treat article text as untrusted data, validate returned citation IDs and recheck revisions before responding. Return answer plus canonical article links, or explicit unknown/unavailable response; inference failure must not trigger unsupported answers. Grounding and abstention require evaluation. Publisher operations use conditional revisions and deletion tombstones. No private connectors or general web search. Bound input, output, SDK retries and concurrency; avoid full question/answer logging, persistent conversation history and answer caching initially. Module owns execution role, scoped regional logs and deployment versioning. Single-region availability is proposed, without cross-region disaster recovery. Custom application and IAM implementation required.
- Service: AWS Lambda
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component faq-articles: Approved public article collection

- Responsibility: Dedicated DynamoDB table proposed in Sydney stores approved article text chunks, canonical URLs, titles, active revisions and deletion tombstones. Start with the twenty public help articles. Only the application role may read or conditionally update this collection; visitors cannot write it. Publishing must atomically activate revisions and invalidate removed content; strongly consistent revision checks prevent stale citations. Propose regional point-in-time recovery, no global-table replicas or overseas backup copies, and restore procedures retaining deletions before serving traffic. Backup location, retention and recovery behavior require implementation review. Custom catalog and lifecycle implementation required.
- Service: Amazon DynamoDB
- Provider / placement: aws / ap-southeast-2
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d61727469636c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

## Component faq-model: Answer generation model

- Responsibility: Reference to Amazon Bedrock managed inference, not a provisioned foundation model or verified entitlement. Propose direct regional inference in Sydney through Converse using only approved public excerpts and the question. No model ID is selected: exact regional availability, Converse support, account access, quotas and model/provider data-handling and retention terms require verification. A regional endpoint alone does not prove every processing, metadata or support boundary. No cross-region inference profile or overseas fallback; if a suitable direct regional model is unavailable, return unavailable and revisit the design before enabling inference. Model instructions alone do not prove grounding or abstention.
- Service: Amazon Bedrock
- Provider / placement: aws / ap-southeast-2
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Interfaces

### faq-browser-web: faq-visitor → faq-web

- Drawn payload/purpose: HTTPS: public static assistant interface
- Contract task: TASK-CONTRACT-6661712d62726f777365722d776562
- Integration task: TASK-INTEGRATION-6661712d62726f777365722d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-web-api: faq-web → faq-api

- Drawn payload/purpose: Browser HTTPS to regional API: question; cited answer or unknown/unavailable
- Contract task: TASK-CONTRACT-6661712d7765622d617069
- Integration task: TASK-INTEGRATION-6661712d7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-publisher-api: faq-publisher → faq-api

- Drawn payload/purpose: SigV4: publish, revise or remove approved articles
- Contract task: TASK-CONTRACT-6661712d7075626c69736865722d617069
- Integration task: TASK-INTEGRATION-6661712d7075626c69736865722d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-api-app: faq-api → faq-app

- Drawn payload/purpose: REST Lambda proxy: validated route and authorization context
- Contract task: TASK-CONTRACT-6661712d6170692d617070
- Integration task: TASK-INTEGRATION-6661712d6170692d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-articles: faq-app → faq-articles

- Drawn payload/purpose: Regional AWS SDK: active article reads and conditional publishing writes
- Contract task: TASK-CONTRACT-6661712d6170702d61727469636c6573
- Integration task: TASK-INTEGRATION-6661712d6170702d61727469636c6573
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-model: faq-app → faq-model

- Drawn payload/purpose: Direct regional Converse: question/public excerpts; draft cited answer; no overs
- Contract task: TASK-CONTRACT-6661712d6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
