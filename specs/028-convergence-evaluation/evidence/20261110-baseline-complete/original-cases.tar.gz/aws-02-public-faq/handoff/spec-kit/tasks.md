# Detailed implementation tasks

Snapshot 72ab4113-f8b7-4d37-a522-dac4fe9e27dd · design r3 · generated 2026-11-09T16:51:36.656Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d62726f777365722d776562 — Define Website visitor → Public assistant website

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-visitor, faq-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-browser-web: HTTPS: public static assistant interface. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-browser-web
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d7765622d617069 — Define Public assistant website → Public questions and protected publishing

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-web, faq-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-web-api: Browser HTTPS to regional API: question; cited answer or unknown/unavailable. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-web-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d7075626c69736865722d617069 — Define Authorized article publisher → Public questions and protected publishing

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-publisher, faq-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-publisher-api: SigV4: publish, revise or remove approved articles. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-publisher-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170692d617070 — Define Public questions and protected publishing → Grounded FAQ answers

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-api, faq-app
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-api-app: REST Lambda proxy: validated route and authorization context. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-api-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d61727469636c6573 — Define Grounded FAQ answers → Approved public article collection

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-articles
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-articles: Regional AWS SDK: active article reads and conditional publishing writes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-articles
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d6d6f64656c — Define Grounded FAQ answers → Answer generation model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-model: Direct regional Converse: question/public excerpts; draft cited answer; no overs. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d76697369746f72 — Integrate existing Website visitor

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d776562
- Components: faq-visitor
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing visitor browser outside provisioning scope. Uses the assistant anonymously; receives cited answers or an explicit unknown response. No article-management permissions. Visitor devices and networks may be outside Australia.
2. Verify Web browser on tools in External; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-visitor
- Application/configuration and tests for Website visitor

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d776562 — Implement Public assistant website

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d62726f777365722d776562, TASK-CONTRACT-6661712d7765622d617069
- Components: faq-web
- Generated files: terraform/main.tf.json
- Requirements: ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed Amazon CloudFront distribution delivers public static assistant assets globally over HTTPS. Hosting module owns private S3 web assets and origin access control, with the origin proposed in Sydney. Browser sends questions directly to the regional API; do not cache questions or answers at the edge. Interface displays source links and unknown/unavailable states. Global delivery is not Australia-only residency; delivery metadata and logging locations require review. Anonymous hosting requires implementation beyond the Cognito-based rag-web-app contract.
2. Verify Amazon CloudFront on aws in Global edge; Australian origin proposed; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon CloudFront; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-web
- Application/configuration and tests for Public assistant website

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617069 — Implement Public questions and protected publishing

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d7765622d617069, TASK-CONTRACT-6661712d7075626c69736865722d617069, TASK-CONTRACT-6661712d6170692d617070
- Components: faq-api
- Generated files: terraform/main.tf.json
- Requirements: ai-public-source-boundary, ai-article-lifecycle, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed regional REST API in Sydney; region choice and service availability remain unverified. Anonymous POST /questions accepts bounded questions; separate article-management routes require AWS IAM authorization. Apply request validation and throttling, restrict browser origins and never rely on browser controls for publisher authorization. No public article-management route. Disable response caching and avoid question bodies in access logs. Regional outage returns unavailable without overseas failover. Public routes, authorization configuration and Lambda integration need implementation.
2. Verify Amazon API Gateway on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon API Gateway; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-api
- Application/configuration and tests for Public questions and protected publishing

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d7075626c6973686572 — Integrate existing Authorized article publisher

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d7075626c69736865722d617069
- Components: faq-publisher
- Generated files: terraform/main.tf.json
- Requirements: ai-public-source-boundary, ai-article-lifecycle

### Implementation steps

1. Responsibility from the board: External reference for a proposed publishing workflow operated by an existing authorized AWS principal. Identity remains an account input, not a verified permission. A signed operator tool submits approved public article text, canonical URL and revision, and requests updates or removal. No existing CMS or native connector is assumed; operator-tool implementation is required.
2. Verify Existing AWS IAM principal on tools in External; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-publisher
- Application/configuration and tests for Authorized article publisher

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Implement Grounded FAQ answers

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170692d617070, TASK-CONTRACT-6661712d6170702d61727469636c6573, TASK-CONTRACT-6661712d6170702d6d6f64656c
- Components: faq-app
- Generated files: terraform/main.tf.json
- Requirements: ai-grounded-abstention, ai-public-source-boundary, ai-article-lifecycle, ai-location-transparency

### Implementation steps

1. Responsibility from the board: One proposed Lambda deployment in Sydney owns question answering and protected publishing handlers. Recommend bounded keyword retrieval over the twenty approved articles, with no vector store initially. Send only retrieved active public excerpts and the question to a reviewed direct model in the same region; no cross-region inference profiles or overseas fallback. Treat article text as untrusted data, validate returned citation IDs and recheck revisions before responding. Return answer plus canonical article links, or explicit unknown/unavailable response; inference failure must not trigger unsupported answers. Grounding and abstention require evaluation. Publisher operations use conditional revisions and deletion tombstones. No private connectors or general web search. Bound input, output, SDK retries and concurrency; avoid full question/answer logging, persistent conversation history and answer caching initially. Module owns execution role, scoped regional logs and deployment versioning. Single-region availability is proposed, without cross-region disaster recovery. Custom application and IAM implementation required.
2. Verify AWS Lambda on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.; REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for Grounded FAQ answers

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d61727469636c6573 — Implement Approved public article collection

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170702d61727469636c6573
- Components: faq-articles
- Generated files: terraform/main.tf.json
- Requirements: ai-grounded-abstention, ai-public-source-boundary, ai-article-lifecycle, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Dedicated DynamoDB table proposed in Sydney stores approved article text chunks, canonical URLs, titles, active revisions and deletion tombstones. Start with the twenty public help articles. Only the application role may read or conditionally update this collection; visitors cannot write it. Publishing must atomically activate revisions and invalidate removed content; strongly consistent revision checks prevent stale citations. Propose regional point-in-time recovery, no global-table replicas or overseas backup copies, and restore procedures retaining deletions before serving traffic. Backup location, retention and recovery behavior require implementation review. Custom catalog and lifecycle implementation required.
2. Verify Amazon DynamoDB on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon DynamoDB; determine exact resource types and required application code. The export has not generated this implementation.
4. Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
5. Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.; REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.; REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-articles
- Application/configuration and tests for Approved public article collection

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d6d6f64656c — Integrate existing Answer generation model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170702d6d6f64656c
- Components: faq-model
- Generated files: terraform/main.tf.json
- Requirements: ai-grounded-abstention, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Reference to Amazon Bedrock managed inference, not a provisioned foundation model or verified entitlement. Propose direct regional inference in Sydney through Converse using only approved public excerpts and the question. No model ID is selected: exact regional availability, Converse support, account access, quotas and model/provider data-handling and retention terms require verification. A regional endpoint alone does not prove every processing, metadata or support boundary. No cross-region inference profile or overseas fallback; if a suitable direct regional model is unavailable, return unavailable and revisit the design before enabling inference. Model instructions alone do not prove grounding or abstention.
2. Verify Amazon Bedrock on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.; REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-model
- Application/configuration and tests for Answer generation model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d62726f777365722d776562 — Wire Website visitor to Public assistant website

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d62726f777365722d776562, TASK-RESOURCE-6661712d76697369746f72, TASK-RESOURCE-6661712d776562
- Components: faq-visitor, faq-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-browser-web carrying HTTPS: public static assistant interface, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-browser-web
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d7765622d617069 — Wire Public assistant website to Public questions and protected publishing

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d7765622d617069, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069
- Components: faq-web, faq-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-web-api carrying Browser HTTPS to regional API: question; cited answer or unknown/unavailable, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-web-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d7075626c69736865722d617069 — Wire Authorized article publisher to Public questions and protected publishing

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d7075626c69736865722d617069, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d7075626c6973686572
- Components: faq-publisher, faq-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-publisher-api carrying SigV4: publish, revise or remove approved articles, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-publisher-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170692d617070 — Wire Public questions and protected publishing to Grounded FAQ answers

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170692d617070, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d617070
- Components: faq-api, faq-app
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-api-app carrying REST Lambda proxy: validated route and authorization context, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-api-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d61727469636c6573 — Wire Grounded FAQ answers to Approved public article collection

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d61727469636c6573, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573
- Components: faq-app, faq-articles
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-articles carrying Regional AWS SDK: active article reads and conditional publishing writes, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-articles
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d6d6f64656c — Wire Grounded FAQ answers to Answer generation model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d6d6f64656c, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d6d6f64656c
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-model carrying Direct regional Converse: question/public excerpts; draft cited answer; no overs, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d62726f777365722d776562 — Verify live Website visitor → Public assistant website

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d62726f777365722d776562
- Components: faq-visitor, faq-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-browser-web with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-browser-web

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d7765622d617069 — Verify live Public assistant website → Public questions and protected publishing

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d7765622d617069
- Components: faq-web, faq-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-web-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-web-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d617069 — Verify live Authorized article publisher → Public questions and protected publishing

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d7075626c69736865722d617069
- Components: faq-publisher, faq-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-publisher-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-publisher-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170692d617070 — Verify live Public questions and protected publishing → Grounded FAQ answers

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170692d617070
- Components: faq-api, faq-app
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-api-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-api-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573 — Verify live Grounded FAQ answers → Approved public article collection

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d61727469636c6573
- Components: faq-app, faq-articles
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-articles with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-articles

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c — Verify live Grounded FAQ answers → Answer generation model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d6562666130373132 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-ebfa0712

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d61627374656e74696f6e — Verify REQ-004: The assistant shall answer from active approved articles with valid source links and explicitly state when those articles do not support an answer; grounding, citation validity and abstention shall be evaluated before launch.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d6170692d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-app, faq-articles, faq-model
- Generated files: terraform/main.tf.json
- Requirements: ai-grounded-abstention

### Implementation steps

1. Basis: User: “cites the articles it used, and says when it does not know.”; rationale: Proposed acceptance requirement: prevents unsupported answers from appearing authoritative. Complements existing citation requirement req-ebfa0712.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279 — Verify REQ-005: The answering path shall retrieve only explicitly approved public articles, with no private-source connectors; article-management operations shall require publisher authorization independently of anonymous question access.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d7075626c6973686572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d7765622d617069, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d617069, TASK-INTEGRATION-LIVE-6661712d6170692d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-api, faq-publisher, faq-app, faq-articles
- Generated files: terraform/main.tf.json
- Requirements: ai-public-source-boundary

### Implementation steps

1. Basis: User: “It must not answer from private sources.” Public website access and faq-publisher require distinct permissions.; rationale: Proposed access boundary: public visitors must not introduce sources or cause private information to enter retrieval.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65 — Verify REQ-006: Authorized publishers shall be able to add, update and remove articles; after a change is acknowledged, new answers shall use active revisions and reject removed or superseded citations, including after recovery.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d7075626c6973686572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d7765622d617069, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d617069, TASK-INTEGRATION-LIVE-6661712d6170692d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-publisher, faq-api, faq-app, faq-articles
- Generated files: terraform/main.tf.json
- Requirements: ai-article-lifecycle

### Implementation steps

1. Basis: User: “We need to update and remove articles.”; rationale: Proposed lifecycle requirement: prevents removed or superseded articles from continuing to support new answers.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379 — Verify REQ-007: Prefer Australian article storage and question processing. Before launch, document the selected region and direct model, verify model availability and data-handling terms, and disclose global delivery, logging, backup and processing exceptions. Proposed behavior is no overseas inference fallback; inability to use the reviewed regional model returns unavailable.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d62726f777365722d776562, TASK-INTEGRATION-LIVE-6661712d7765622d617069, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d617069, TASK-INTEGRATION-LIVE-6661712d6170692d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-web, faq-api, faq-app, faq-articles, faq-model
- Generated files: terraform/main.tf.json
- Requirements: ai-location-transparency

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.” Sydney placement and no overseas fallback are architectural proposals, not confirmed regional decisions.; rationale: Australia is a preference rather than an absolute residency rule; documenting actual locations and model limitations prevents an unsupported Australia-only claim.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d76697369746f72, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d7075626c6973686572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-6661712d62726f777365722d776562, TASK-INTEGRATION-6661712d7765622d617069, TASK-INTEGRATION-6661712d7075626c69736865722d617069, TASK-INTEGRATION-6661712d6170692d617070, TASK-INTEGRATION-6661712d6170702d61727469636c6573, TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d76697369746f72, TASK-RESOURCE-6661712d776562, TASK-RESOURCE-6661712d617069, TASK-RESOURCE-6661712d7075626c6973686572, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d62726f777365722d776562, TASK-INTEGRATION-LIVE-6661712d7765622d617069, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d617069, TASK-INTEGRATION-LIVE-6661712d6170692d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d6562666130373132, TASK-ACCEPTANCE-61692d67726f756e6465642d61627374656e74696f6e, TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279, TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65, TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379, TASK-INTEGRATION-LIVE-6661712d62726f777365722d776562, TASK-INTEGRATION-LIVE-6661712d7765622d617069, TASK-INTEGRATION-LIVE-6661712d7075626c69736865722d617069, TASK-INTEGRATION-LIVE-6661712d6170692d617070, TASK-INTEGRATION-LIVE-6661712d6170702d61727469636c6573, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
