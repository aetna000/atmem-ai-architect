Snapshot e7a7cad9-cf63-4f5b-a8ba-5cea7318fb94 · design r3 · generated 2026-11-09T17:01:04.031Z

# Permission-aware knowledge assistant — deployment document

Generated 2026-11-09 17:01 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** AWS
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 2

## 2. Scope and context

- **What you want to build:** Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** AWS Ten thousand company documents. Source permissions are authoritative; content and authorization can change independently. Australia for content, indexes and processing; explain service/model residency gaps.
- **Budget and timeline:** —

## 3. Architecture

**Employee access**

- Employees using a browser (Tools & data, existing, sketch) — Existing people outside provisioning scope. Browser loads static application assets, then sends questions and receives cited answers directly through regional API endpoints. No user count or employee location is assumed.
- Internal assistant website (AWS, sketch) — Proposed Amazon CloudFront distribution serving static application code only. Browser code calls regional authentication and question endpoints directly; documents, questions, answers, citations and tokens must not pass through distribution requests, URLs or caches. CloudFront is global: asset-request IP addresses and other connection metadata are a residency gap requiring review. Static origin, asset build and hosting integration remain implementation work; the origin is owned by this hosting boundary. This is not the bounded-RAG generated web contract.
- Company sign-in federation (AWS, sketch) — Proposed regional Amazon Cognito user pool federating with the actual company identity provider, which remains unknown. Validate access-token issuer, audience, scope and expiry; map subjects to independently established source identities. Authentication never grants document access. Identity-provider processing locations, Cognito regional support and federation behavior require verification. Browser redirects directly to authentication endpoints; tokens never traverse CloudFront asset URLs. Mapping, federation and denial tests remain implementation work.

**Answer delivery**

- Authenticated question API (AWS, sketch) — Proposed regional Amazon API Gateway HTTP API, called directly by browser application code. Validate access tokens and pass trusted subject claims to the runtime; bound request size and rate. Return cited answers, partial-source notices or abstention. No document text, questions, answers or tokens in access logs; disable shared response caching. Regional endpoint, CORS, authorization and application integration require implementation and tests.
- Permission-aware answer service (AWS, sketch) — Proposed custom AWS Lambda application. Embed the question regionally and retrieve candidates with ACL prefilters. Independently validate current effective per-user source access and exact content revision before sending evidence to the model; unchanged content never proves unchanged permission. Recheck evidence before answer release and discard or regenerate on change. Unknown identities, unavailable checks or source failures exclude affected evidence and derived context. Return authorized citations, incomplete-coverage notices or abstention. No durable conversation memory or personalized answer cache initially. Owns execution role and scoped logs. Native checks, bounded execution and concurrent-change tests require implementation. Separate source APIs cannot provide an atomic cross-system authorization snapshot; document the final-check race and acceptance behavior rather than promise instantaneous revocation.

**Source synchronization**

- Searchable document index (AWS, sketch) — Proposed Amazon OpenSearch Serverless vector-search collection for 10,000 source documents and their chunks. Stores text, embeddings, source/document identifiers, content revisions and separately tracked authorization metadata. Document count does not establish storage size or chunk count. Hybrid retrieval and regional support require qualification. ACL filters only reduce candidates; sources authorize disclosure. Only synchronization writes; runtime receives scoped read access. Tombstones and independent revision/authorization checks suppress stale evidence. Keep indexes, recovery copies and processing in Australia; capacity, encryption/network policy, retention and recovery remain engineering work.
- Source revisions and recovery state (AWS, sketch) — Proposed Amazon DynamoDB table with source-isolated content revisions, independently tracked authorization observations, deletion tombstones, separate change/reconciliation checkpoints, health and identity mappings. A content revision never substitutes for permission freshness. Conditional updates prevent older work restoring deleted, superseded or authorization-stale index entries. State is coordination evidence, not authority for current source access. No credentials. Keep table, backups and recovery processing in Australia; no global replication assumed. Reconciliation, backup and retention behavior require implementation.
- SharePoint and Confluence synchronization (AWS, sketch) — Proposed custom AWS Lambda worker with distinct native source adapter modules. Process 10,000 documents through bounded checkpointed pages, without assuming one invocation can scan the corpus. Track permission/group/inheritance changes independently of content changes; reconcile permissions even when content revisions do not change. Where native permission deltas are unavailable, use bounded reconciliation plus authoritative request-time checks. Track edits and tombstones, generate regional embeddings and conditionally update state/index. Source-specific checkpoints, bounded retries and nonoverlapping work isolate failures. Owns execution role and scoped logs. Source API semantics, credentials, pagination, rate limits, encrypted secret delivery and tenant-specific tests remain implementation work; no native connector is claimed.
- Change checks and reconciliation schedule (AWS, sketch) — Proposed Amazon EventBridge Scheduler schedules independent source content checks, permission reconciliation and recovery passes. Permission work must not depend on a content-change event. Cadences remain engineering proposals pending source limits and business freshness targets. Bounded worker pages resume from durable checkpoints after missed or failed invocations; execution payloads contain identifiers rather than source text. Regional support and retry/failure handling require qualification.

**Existing sources**

- Existing SharePoint (Tools & data, existing) — Existing authoritative content and permission system outside AWS provisioning scope. Content and effective authorization change independently. Native integration must establish current user access, inherited permissions, group membership, deletion and exact document revision. Tenant/API capabilities and existing content/processing locations are unverified; Australian AWS placement cannot establish SharePoint residency.
- Existing Confluence (Tools & data, existing) — Existing authoritative content and permission system outside AWS provisioning scope. Native integration must independently establish effective space/page/group access and current content revision/deletion. Cloud versus self-managed deployment, permission-change interfaces and existing content/processing locations are unverified; Australian AWS placement cannot establish Confluence residency.

**Managed inference**

- Answer and embedding models (AWS, sketch) — Proposed Amazon Bedrock managed inference access, with separate generation and embedding model selections rather than provisioned model servers. Embed questions and source chunks and generate answers within Australia. Each model needs verified direct regional availability, entitlement, quotas and data-handling terms; none is selected or verified. Regional API placement alone does not prove inference location. Exclude cross-region inference profiles and overseas fallback; block an unsupported model path. Only authorized evidence reaches generation. Model invocation logging is disabled initially to avoid extra content copies. Citation/abstention enforcement and model integrations remain application work.

**Operations**

- Source health and access-decision monitoring (AWS) — Proposed Amazon CloudWatch metrics, scoped logs and alarms for per-source content/permission synchronization lag, outages, access denials, reconciliation failures and answer errors. Keep logs in Australia; record request IDs, restricted source/revision references and decision outcomes without document text, question/answer bodies, tokens or credentials. Alert payloads must not disclose source content. Retention, operational owner and response targets remain open. Regional support, instrumentation and failure alerts require implementation and tests.

```mermaid
flowchart LR
  n0["Employees using a browser<br/>Tools & data"]
  n1["Internal assistant website<br/>AWS"]
  n2["Company sign-in federation<br/>AWS"]
  n3["Authenticated question API<br/>AWS"]
  n4["Permission-aware answer service<br/>AWS"]
  n5["Searchable document index<br/>AWS"]
  n6["Source revisions and recovery state<br/>AWS"]
  n7["SharePoint and Confluence synchronization<br/>AWS"]
  n8["Change checks and reconciliation schedule<br/>AWS"]
  n9["Existing SharePoint<br/>Tools & data"]
  n10["Existing Confluence<br/>Tools & data"]
  n11["Answer and embedding models<br/>AWS"]
  n12["Source health and access-decision monitoring<br/>AWS"]
  n0 -->|HTTPS: static application assets only| n1
  n1 -->|Browser code → regional sign-in: OAuth code with PKCE| n2
  n1 -->|Browser code → regional HTTPS API directly: question/token; cited response| n3
  n2 -->|Validate token issuer, audience, scope, signature and expiry| n3
  n3 -->|Authenticated invocation with trusted subject| n4
  n4 -->|Scoped hybrid candidate search; ACL filters never grant access| n5
  n4 -->|Read mappings, independent content/authorization state and tombstones| n6
  n4 -->|Native API: independently check current access and exact revision; fail closed| n9
  n4 -->|Native API: independently check current access and exact revision; fail closed| n10
  n4 -->|Australian inference: query embedding; authorized evidence → answer| n11
  n8 -->|Independent content checks, permission reconciliation and recovery passes| n7
  n7 -->|Native API: content deltas; independent permission/group reconciliation| n9
  n7 -->|Native API: content deltas; independent permission/group reconciliation| n10
  n7 -->|Generate document embeddings in Australia with scoped access| n11
  n7 -->|Conditional content/permission checkpoints, revisions, tombstones and health| n6
  n7 -->|Independent content/ACL updates; stale-write rejection and deletion| n5
  n4 -->|Redacted access decisions, latency and failures; Australian logs| n12
  n7 -->|Per-source content/permission lag, outages and recovery failures| n12
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| employees | Employees using a browser | tools | Web browser | Existing client locations | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| assistant-web | Internal assistant website | aws | Amazon CloudFront | Global — static assets only | Proposed | Implementation needed |
| assistant-identity | Company sign-in federation | aws | Amazon Cognito | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| assistant-api | Authenticated question API | aws | Amazon API Gateway | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| assistant-runtime | Permission-aware answer service | aws | AWS Lambda | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| search-index | Searchable document index | aws | Amazon OpenSearch Serverless | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| source-state | Source revisions and recovery state | aws | Amazon DynamoDB | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| source-sync | SharePoint and Confluence synchronization | aws | AWS Lambda | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| sync-schedule | Change checks and reconciliation schedule | aws | Amazon EventBridge Scheduler | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing placement — not established | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing placement — not established | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| model-service | Answer and embedding models | aws | Amazon Bedrock | ap-southeast-2 (proposed; models unverified) | Proposed | Implementation needed |
| operations | Source health and access-decision monitoring | aws | Amazon CloudWatch | ap-southeast-2 (proposed) | Proposed | Implementation needed |

### Resources and cost dimensions

- **Employees using a browser** (employees): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Internal assistant website** (assistant-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: employees.
- **Company sign-in federation** (assistant-identity): aws_cognito_user_pool. Active users and authentication features. Depends on: assistant-web.
- **Authenticated question API** (assistant-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: assistant-web, assistant-identity.
- **Permission-aware answer service** (assistant-runtime): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: assistant-api.
- **Searchable document index** (search-index): aws_opensearchserverless_collection. Deployment mode, indexing/search capacity and storage. Depends on: assistant-runtime, source-sync.
- **Source revisions and recovery state** (source-state): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: assistant-runtime, source-sync.
- **SharePoint and Confluence synchronization** (source-sync): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: sync-schedule.
- **Change checks and reconciliation schedule** (sync-schedule): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-runtime, source-sync.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-runtime, source-sync.
- **Answer and embedding models** (model-service): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: assistant-runtime, source-sync.
- **Source health and access-decision monitoring** (operations): aws_cloudwatch_log_group. Logs, metrics, alarms and retention. Depends on: assistant-runtime, source-sync.

### Engineering work remaining

- Internal assistant website: Implementation needed.
- Company sign-in federation: Implementation needed.
- Authenticated question API: Implementation needed.
- Permission-aware answer service: Implementation needed.
- Searchable document index: Implementation needed.
- Source revisions and recovery state: Implementation needed.
- SharePoint and Confluence synchronization: Implementation needed.
- Change checks and reconciliation schedule: Implementation needed.
- Answer and embedding models: Implementation needed.
- Source health and access-decision monitoring: Implementation needed.
- Wire employees → assistant-web: implement data flow, access policy and acceptance test.
- Wire assistant-web → assistant-identity: implement data flow, access policy and acceptance test.
- Wire assistant-web → assistant-api: implement data flow, access policy and acceptance test.
- Wire assistant-identity → assistant-api: implement data flow, access policy and acceptance test.
- Wire assistant-api → assistant-runtime: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → search-index: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → source-state: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → model-service: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → model-service: implement data flow, access policy and acceptance test.
- Wire source-sync → source-state: implement data flow, access policy and acceptance test.
- Wire source-sync → search-index: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → operations: implement data flow, access policy and acceptance test.
- Wire source-sync → operations: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Employees using a browser | Internal assistant website | HTTPS: static application assets only | Confidential |
| Internal assistant website | Company sign-in federation | Browser code → regional sign-in: OAuth code with PKCE | Confidential |
| Internal assistant website | Authenticated question API | Browser code → regional HTTPS API directly: question/token; cited response | Confidential |
| Company sign-in federation | Authenticated question API | Validate token issuer, audience, scope, signature and expiry | Confidential |
| Authenticated question API | Permission-aware answer service | Authenticated invocation with trusted subject | Confidential |
| Permission-aware answer service | Searchable document index | Scoped hybrid candidate search; ACL filters never grant access | Confidential |
| Permission-aware answer service | Source revisions and recovery state | Read mappings, independent content/authorization state and tombstones | Confidential |
| Permission-aware answer service | Existing SharePoint | Native API: independently check current access and exact revision; fail closed | Confidential |
| Permission-aware answer service | Existing Confluence | Native API: independently check current access and exact revision; fail closed | Confidential |
| Permission-aware answer service | Answer and embedding models | Australian inference: query embedding; authorized evidence → answer | Confidential |
| Change checks and reconciliation schedule | SharePoint and Confluence synchronization | Independent content checks, permission reconciliation and recovery passes | Confidential |
| SharePoint and Confluence synchronization | Existing SharePoint | Native API: content deltas; independent permission/group reconciliation | Confidential |
| SharePoint and Confluence synchronization | Existing Confluence | Native API: content deltas; independent permission/group reconciliation | Confidential |
| SharePoint and Confluence synchronization | Answer and embedding models | Generate document embeddings in Australia with scoped access | Confidential |
| SharePoint and Confluence synchronization | Source revisions and recovery state | Conditional content/permission checkpoints, revisions, tombstones and health | Confidential |
| SharePoint and Confluence synchronization | Searchable document index | Independent content/ACL updates; stale-write rejection and deletion | Confidential |
| Permission-aware answer service | Source health and access-decision monitoring | Redacted access decisions, latency and failures; Australian logs | Confidential |
| SharePoint and Confluence synchronization | Source health and access-decision monitoring | Per-source content/permission lag, outages and recovery failures | Confidential |

## 5. Security controls

- **Employees using a browser** — Existing people outside provisioning scope. Browser loads static application assets, then sends questions and receives cited answers directly through regional API endpoints. No user count or employee location is assumed.
- **Company sign-in federation** — Proposed regional Amazon Cognito user pool federating with the actual company identity provider, which remains unknown. Validate access-token issuer, audience, scope and expiry; map subjects to independently established source identities. Authentication never grants document access. Identity-provider processing locations, Cognito regional support and federation behavior require verification. Browser redirects directly to authentication endpoints; tokens never traverse CloudFront asset URLs. Mapping, federation and denial tests remain implementation work.
- Requirement: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations. (must)
- Requirement: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes. (must)
- Requirement: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations. | security | not measurable yet | Open |
| When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes. | security | not measurable yet | Open |
| Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance. (must, open)
- Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 3 quality requirements have no measurable target. Add a metric and target to: “Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.”, “When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.”, “Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 2 accepted decisions have no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 10 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Company sign-in federation | Checked requests | needs requests_per_month | price needed | — | — |
| Searchable document index | Index storage | needs data_gb | price needed | — | — |
| Source revisions and recovery state | Storage | needs data_gb | price needed | — | — |
| SharePoint and Confluence synchronization | Data processed | needs data_gb | price needed | — | — |
| Change checks and reconciliation schedule | Data processed | needs data_gb | price needed | — | — |
| Existing SharePoint | Storage | needs data_gb | price needed | — | — |
| Existing Confluence | Storage | needs data_gb | price needed | — | — |
| Answer and embedding models | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Employees using a browser, Internal assistant website, Authenticated question API, Permission-aware answer service, Source health and access-decision monitoring.

**Estimate gaps:**

- Company sign-in federation / Checked requests: input needed (requests_per_month).
- Searchable document index / Index storage: input needed (data_gb).
- Source revisions and recovery state / Storage: input needed (data_gb).
- SharePoint and Confluence synchronization / Data processed: input needed (data_gb).
- Change checks and reconciliation schedule / Data processed: input needed (data_gb).
- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Answer and embedding models / Endpoint hours: price needed.
- Employees using a browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Internal assistant website: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated question API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Permission-aware answer service: no cost lines; add charges or an explicit zero-cost line with a reason.
- Source health and access-decision monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision employee access: Internal assistant website, Company sign-in federation.
4. Provision source synchronization: Change checks and reconciliation schedule, SharePoint and Confluence synchronization, Searchable document index, Source revisions and recovery state.
5. Provision answer delivery: Authenticated question API, Permission-aware answer service.
6. Provision managed inference: Answer and embedding models.
7. Provision operations: Source health and access-decision monitoring.
8. Connect existing systems: Employees using a browser, Existing SharePoint, Existing Confluence; test failure behaviour.
9. Run the acceptance checks (success measures and requirements) in staging; record results.
10. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Company sign-in federation: needs requests_per_month _(estimate)_
- Searchable document index: needs data_gb _(estimate)_
- Source revisions and recovery state: needs data_gb _(estimate)_
- SharePoint and Confluence synchronization: needs data_gb _(estimate)_
- Change checks and reconciliation schedule: needs data_gb _(estimate)_
- Existing SharePoint: needs data_gb _(estimate)_
- Existing Confluence: needs data_gb _(estimate)_
- Answer and embedding models: needs a unit price with a source _(estimate)_
