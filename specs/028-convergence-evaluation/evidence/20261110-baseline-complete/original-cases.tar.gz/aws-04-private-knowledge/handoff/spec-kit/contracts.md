# Component and interface contracts

Snapshot e7a7cad9-cf63-4f5b-a8ba-5cea7318fb94 · design r3 · generated 2026-11-09T17:01:04.031Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component employees: Employees using a browser

- Responsibility: Existing people outside provisioning scope. Browser loads static application assets, then sends questions and receives cited answers directly through regional API endpoints. No user count or employee location is assumed.
- Service: Web browser
- Provider / placement: tools / Existing client locations
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-656d706c6f79656573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component assistant-web: Internal assistant website

- Responsibility: Proposed Amazon CloudFront distribution serving static application code only. Browser code calls regional authentication and question endpoints directly; documents, questions, answers, citations and tokens must not pass through distribution requests, URLs or caches. CloudFront is global: asset-request IP addresses and other connection metadata are a residency gap requiring review. Static origin, asset build and hosting integration remain implementation work; the origin is owned by this hosting boundary. This is not the bounded-RAG generated web contract.
- Service: Amazon CloudFront
- Provider / placement: aws / Global — static assets only
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d776562
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component assistant-identity: Company sign-in federation

- Responsibility: Proposed regional Amazon Cognito user pool federating with the actual company identity provider, which remains unknown. Validate access-token issuer, audience, scope and expiry; map subjects to independently established source identities. Authentication never grants document access. Identity-provider processing locations, Cognito regional support and federation behavior require verification. Browser redirects directly to authentication endpoints; tokens never traverse CloudFront asset URLs. Mapping, federation and denial tests remain implementation work.
- Service: Amazon Cognito
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d6964656e74697479
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component assistant-api: Authenticated question API

- Responsibility: Proposed regional Amazon API Gateway HTTP API, called directly by browser application code. Validate access tokens and pass trusted subject claims to the runtime; bound request size and rate. Return cited answers, partial-source notices or abstention. No document text, questions, answers or tokens in access logs; disable shared response caching. Regional endpoint, CORS, authorization and application integration require implementation and tests.
- Service: Amazon API Gateway
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d617069
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component assistant-runtime: Permission-aware answer service

- Responsibility: Proposed custom AWS Lambda application. Embed the question regionally and retrieve candidates with ACL prefilters. Independently validate current effective per-user source access and exact content revision before sending evidence to the model; unchanged content never proves unchanged permission. Recheck evidence before answer release and discard or regenerate on change. Unknown identities, unavailable checks or source failures exclude affected evidence and derived context. Return authorized citations, incomplete-coverage notices or abstention. No durable conversation memory or personalized answer cache initially. Owns execution role and scoped logs. Native checks, bounded execution and concurrent-change tests require implementation. Separate source APIs cannot provide an atomic cross-system authorization snapshot; document the final-check race and acceptance behavior rather than promise instantaneous revocation.
- Service: AWS Lambda
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-617373697374616e742d72756e74696d65
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component search-index: Searchable document index

- Responsibility: Proposed Amazon OpenSearch Serverless vector-search collection for 10,000 source documents and their chunks. Stores text, embeddings, source/document identifiers, content revisions and separately tracked authorization metadata. Document count does not establish storage size or chunk count. Hybrid retrieval and regional support require qualification. ACL filters only reduce candidates; sources authorize disclosure. Only synchronization writes; runtime receives scoped read access. Tombstones and independent revision/authorization checks suppress stale evidence. Keep indexes, recovery copies and processing in Australia; capacity, encryption/network policy, retention and recovery remain engineering work.
- Service: Amazon OpenSearch Serverless
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-7365617263682d696e646578
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify collection type, encryption, network and data-access policies, private connectivity and capacity limits.
- Define index mappings and creation ownership; for vector search select embedding model/dimensions and query strategy.
- Test permissions, document deletion, capacity, reindex/recovery and source ACL freshness.

## Component source-state: Source revisions and recovery state

- Responsibility: Proposed Amazon DynamoDB table with source-isolated content revisions, independently tracked authorization observations, deletion tombstones, separate change/reconciliation checkpoints, health and identity mappings. A content revision never substitutes for permission freshness. Conditional updates prevent older work restoring deleted, superseded or authorization-stale index entries. State is coordination evidence, not authority for current source access. No credentials. Keep table, backups and recovery processing in Australia; no global replication assumed. Reconciliation, backup and retention behavior require implementation.
- Service: Amazon DynamoDB
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736f757263652d7374617465
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

## Component source-sync: SharePoint and Confluence synchronization

- Responsibility: Proposed custom AWS Lambda worker with distinct native source adapter modules. Process 10,000 documents through bounded checkpointed pages, without assuming one invocation can scan the corpus. Track permission/group/inheritance changes independently of content changes; reconcile permissions even when content revisions do not change. Where native permission deltas are unavailable, use bounded reconciliation plus authoritative request-time checks. Track edits and tombstones, generate regional embeddings and conditionally update state/index. Source-specific checkpoints, bounded retries and nonoverlapping work isolate failures. Owns execution role and scoped logs. Source API semantics, credentials, pagination, rate limits, encrypted secret delivery and tenant-specific tests remain implementation work; no native connector is claimed.
- Service: AWS Lambda
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-736f757263652d73796e63
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

## Component sync-schedule: Change checks and reconciliation schedule

- Responsibility: Proposed Amazon EventBridge Scheduler schedules independent source content checks, permission reconciliation and recovery passes. Permission work must not depend on a content-change event. Cadences remain engineering proposals pending source limits and business freshness targets. Bounded worker pages resume from durable checkpoints after missed or failed invocations; execution payloads contain identifiers rather than source text. Regional support and retry/failure handling require qualification.
- Service: Amazon EventBridge Scheduler
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-73796e632d7363686564756c65
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component sharepoint: Existing SharePoint

- Responsibility: Existing authoritative content and permission system outside AWS provisioning scope. Content and effective authorization change independently. Native integration must establish current user access, inherited permissions, group membership, deletion and exact document revision. Tenant/API capabilities and existing content/processing locations are unverified; Australian AWS placement cannot establish SharePoint residency.
- Service: Microsoft SharePoint
- Provider / placement: tools / Existing placement — not established
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-7368617265706f696e74
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component confluence: Existing Confluence

- Responsibility: Existing authoritative content and permission system outside AWS provisioning scope. Native integration must independently establish effective space/page/group access and current content revision/deletion. Cloud versus self-managed deployment, permission-change interfaces and existing content/processing locations are unverified; Australian AWS placement cannot establish Confluence residency.
- Service: Atlassian Confluence
- Provider / placement: tools / Existing placement — not established
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-636f6e666c75656e6365
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

## Component model-service: Answer and embedding models

- Responsibility: Proposed Amazon Bedrock managed inference access, with separate generation and embedding model selections rather than provisioned model servers. Embed questions and source chunks and generate answers within Australia. Each model needs verified direct regional availability, entitlement, quotas and data-handling terms; none is selected or verified. Regional API placement alone does not prove inference location. Exclude cross-region inference profiles and overseas fallback; block an unsupported model path. Only authorized evidence reaches generation. Model invocation logging is disabled initially to avoid extra content copies. Citation/abstention enforcement and model integrations remain application work.
- Service: Amazon Bedrock
- Provider / placement: aws / ap-southeast-2 (proposed; models unverified)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6d6f64656c2d73657276696365
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Select exact generation and, if needed, embedding model IDs, invocation API and inference mode; verify account access, regional availability and quotas with dated evidence.
- Map every inference destination to the agreed processing boundary; a regional endpoint or APAC profile does not by itself establish country-only processing.
- Implement scoped invocation IAM, token/time limits, retries and budget controls; keep source authorization before model invocation.
- Define prompt-injection handling, authorized citations, insufficient-evidence responses and output checks; test these separately from model guardrails.

## Component operations: Source health and access-decision monitoring

- Responsibility: Proposed Amazon CloudWatch metrics, scoped logs and alarms for per-source content/permission synchronization lag, outages, access denials, reconciliation failures and answer errors. Keep logs in Australia; record request IDs, restricted source/revision references and decision outcomes without document text, question/answer bodies, tokens or credentials. Alert payloads must not disclose source content. Retention, operational owner and response targets remain open. Regional support, instrumentation and failure alerts require implementation and tests.
- Service: Amazon CloudWatch
- Provider / placement: aws / ap-southeast-2 (proposed)
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6f7065726174696f6e73
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Define structured redacted logs, retention, metrics, alarms, dashboards and alert ownership for each component.
- Test ingestion failure, denied access and latency alarms; verify sensitive prompts, source text and credentials are excluded.

## Interfaces

### employees-web: employees → assistant-web

- Drawn payload/purpose: HTTPS: static application assets only
- Contract task: TASK-CONTRACT-656d706c6f796565732d776562
- Integration task: TASK-INTEGRATION-656d706c6f796565732d776562
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-signin: assistant-web → assistant-identity

- Drawn payload/purpose: Browser code → regional sign-in: OAuth code with PKCE
- Contract task: TASK-CONTRACT-7765622d7369676e696e
- Integration task: TASK-INTEGRATION-7765622d7369676e696e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### web-api: assistant-web → assistant-api

- Drawn payload/purpose: Browser code → regional HTTPS API directly: question/token; cited response
- Contract task: TASK-CONTRACT-7765622d617069
- Integration task: TASK-INTEGRATION-7765622d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### identity-api: assistant-identity → assistant-api

- Drawn payload/purpose: Validate token issuer, audience, scope, signature and expiry
- Contract task: TASK-CONTRACT-6964656e746974792d617069
- Integration task: TASK-INTEGRATION-6964656e746974792d617069
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### api-runtime: assistant-api → assistant-runtime

- Drawn payload/purpose: Authenticated invocation with trusted subject
- Contract task: TASK-CONTRACT-6170692d72756e74696d65
- Integration task: TASK-INTEGRATION-6170692d72756e74696d65
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### runtime-search: assistant-runtime → search-index

- Drawn payload/purpose: Scoped hybrid candidate search; ACL filters never grant access
- Contract task: TASK-CONTRACT-72756e74696d652d736561726368
- Integration task: TASK-INTEGRATION-72756e74696d652d736561726368
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### runtime-state: assistant-runtime → source-state

- Drawn payload/purpose: Read mappings, independent content/authorization state and tombstones
- Contract task: TASK-CONTRACT-72756e74696d652d7374617465
- Integration task: TASK-INTEGRATION-72756e74696d652d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### runtime-sharepoint: assistant-runtime → sharepoint

- Drawn payload/purpose: Native API: independently check current access and exact revision; fail closed
- Contract task: TASK-CONTRACT-72756e74696d652d7368617265706f696e74
- Integration task: TASK-INTEGRATION-72756e74696d652d7368617265706f696e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### runtime-confluence: assistant-runtime → confluence

- Drawn payload/purpose: Native API: independently check current access and exact revision; fail closed
- Contract task: TASK-CONTRACT-72756e74696d652d636f6e666c75656e6365
- Integration task: TASK-INTEGRATION-72756e74696d652d636f6e666c75656e6365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### runtime-model: assistant-runtime → model-service

- Drawn payload/purpose: Australian inference: query embedding; authorized evidence → answer
- Contract task: TASK-CONTRACT-72756e74696d652d6d6f64656c
- Integration task: TASK-INTEGRATION-72756e74696d652d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### schedule-sync: sync-schedule → source-sync

- Drawn payload/purpose: Independent content checks, permission reconciliation and recovery passes
- Contract task: TASK-CONTRACT-7363686564756c652d73796e63
- Integration task: TASK-INTEGRATION-7363686564756c652d73796e63
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-sharepoint: source-sync → sharepoint

- Drawn payload/purpose: Native API: content deltas; independent permission/group reconciliation
- Contract task: TASK-CONTRACT-73796e632d7368617265706f696e74
- Integration task: TASK-INTEGRATION-73796e632d7368617265706f696e74
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-confluence: source-sync → confluence

- Drawn payload/purpose: Native API: content deltas; independent permission/group reconciliation
- Contract task: TASK-CONTRACT-73796e632d636f6e666c75656e6365
- Integration task: TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-model: source-sync → model-service

- Drawn payload/purpose: Generate document embeddings in Australia with scoped access
- Contract task: TASK-CONTRACT-73796e632d6d6f64656c
- Integration task: TASK-INTEGRATION-73796e632d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-state: source-sync → source-state

- Drawn payload/purpose: Conditional content/permission checkpoints, revisions, tombstones and health
- Contract task: TASK-CONTRACT-73796e632d7374617465
- Integration task: TASK-INTEGRATION-73796e632d7374617465
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-index: source-sync → search-index

- Drawn payload/purpose: Independent content/ACL updates; stale-write rejection and deletion
- Contract task: TASK-CONTRACT-73796e632d696e646578
- Integration task: TASK-INTEGRATION-73796e632d696e646578
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### runtime-monitoring: assistant-runtime → operations

- Drawn payload/purpose: Redacted access decisions, latency and failures; Australian logs
- Contract task: TASK-CONTRACT-72756e74696d652d6d6f6e69746f72696e67
- Integration task: TASK-INTEGRATION-72756e74696d652d6d6f6e69746f72696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### sync-monitoring: source-sync → operations

- Drawn payload/purpose: Per-source content/permission lag, outages and recovery failures
- Contract task: TASK-CONTRACT-73796e632d6d6f6e69746f72696e67
- Integration task: TASK-INTEGRATION-73796e632d6d6f6e69746f72696e67
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
