# Detailed implementation tasks

Snapshot e7a7cad9-cf63-4f5b-a8ba-5cea7318fb94 · design r3 · generated 2026-11-09T17:01:04.031Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-656d706c6f796565732d776562 — Define Employees using a browser → Internal assistant website

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: employees, assistant-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection employees-web: HTTPS: static application assets only. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge employees-web
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d7369676e696e — Define Internal assistant website → Company sign-in federation

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-web, assistant-identity
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-signin: Browser code → regional sign-in: OAuth code with PKCE. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-signin
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7765622d617069 — Define Internal assistant website → Authenticated question API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-web, assistant-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection web-api: Browser code → regional HTTPS API directly: question/token; cited response. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge web-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6964656e746974792d617069 — Define Company sign-in federation → Authenticated question API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-identity, assistant-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection identity-api: Validate token issuer, audience, scope, signature and expiry. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge identity-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6170692d72756e74696d65 — Define Authenticated question API → Permission-aware answer service

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-api, assistant-runtime
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection api-runtime: Authenticated invocation with trusted subject. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge api-runtime
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72756e74696d652d736561726368 — Define Permission-aware answer service → Searchable document index

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-runtime, search-index
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection runtime-search: Scoped hybrid candidate search; ACL filters never grant access. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge runtime-search
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72756e74696d652d7374617465 — Define Permission-aware answer service → Source revisions and recovery state

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-runtime, source-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection runtime-state: Read mappings, independent content/authorization state and tombstones. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge runtime-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72756e74696d652d7368617265706f696e74 — Define Permission-aware answer service → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-runtime, sharepoint
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection runtime-sharepoint: Native API: independently check current access and exact revision; fail closed. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge runtime-sharepoint
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72756e74696d652d636f6e666c75656e6365 — Define Permission-aware answer service → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-runtime, confluence
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection runtime-confluence: Native API: independently check current access and exact revision; fail closed. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge runtime-confluence
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72756e74696d652d6d6f64656c — Define Permission-aware answer service → Answer and embedding models

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-runtime, model-service
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection runtime-model: Australian inference: query embedding; authorized evidence → answer. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge runtime-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-7363686564756c652d73796e63 — Define Change checks and reconciliation schedule → SharePoint and Confluence synchronization

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: sync-schedule, source-sync
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection schedule-sync: Independent content checks, permission reconciliation and recovery passes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge schedule-sync
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d7368617265706f696e74 — Define SharePoint and Confluence synchronization → Existing SharePoint

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-sharepoint: Native API: content deltas; independent permission/group reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-sharepoint
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d636f6e666c75656e6365 — Define SharePoint and Confluence synchronization → Existing Confluence

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-confluence: Native API: content deltas; independent permission/group reconciliation. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-confluence
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d6d6f64656c — Define SharePoint and Confluence synchronization → Answer and embedding models

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, model-service
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-model: Generate document embeddings in Australia with scoped access. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d7374617465 — Define SharePoint and Confluence synchronization → Source revisions and recovery state

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, source-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-state: Conditional content/permission checkpoints, revisions, tombstones and health. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-state
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d696e646578 — Define SharePoint and Confluence synchronization → Searchable document index

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, search-index
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-index: Independent content/ACL updates; stale-write rejection and deletion. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-index
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-72756e74696d652d6d6f6e69746f72696e67 — Define Permission-aware answer service → Source health and access-decision monitoring

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: assistant-runtime, operations
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection runtime-monitoring: Redacted access decisions, latency and failures; Australian logs. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge runtime-monitoring
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-73796e632d6d6f6e69746f72696e67 — Define SharePoint and Confluence synchronization → Source health and access-decision monitoring

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: source-sync, operations
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection sync-monitoring: Per-source content/permission lag, outages and recovery failures. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge sync-monitoring
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-656d706c6f79656573 — Integrate existing Employees using a browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-656d706c6f796565732d776562
- Components: employees
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing people outside provisioning scope. Browser loads static application assets, then sends questions and receives cited answers directly through regional API endpoints. No user count or employee location is assumed.
2. Verify Web browser on tools in Existing client locations; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component employees
- Application/configuration and tests for Employees using a browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d776562 — Implement Internal assistant website

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-656d706c6f796565732d776562, TASK-CONTRACT-7765622d7369676e696e, TASK-CONTRACT-7765622d617069
- Components: assistant-web
- Generated files: terraform/main.tf.json
- Requirements: ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Amazon CloudFront distribution serving static application code only. Browser code calls regional authentication and question endpoints directly; documents, questions, answers, citations and tokens must not pass through distribution requests, URLs or caches. CloudFront is global: asset-request IP addresses and other connection metadata are a residency gap requiring review. Static origin, asset build and hosting integration remain implementation work; the origin is owned by this hosting boundary. This is not the bounded-RAG generated web contract.
2. Verify Amazon CloudFront on aws in Global — static assets only; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon CloudFront; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-web
- Application/configuration and tests for Internal assistant website

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d6964656e74697479 — Implement Company sign-in federation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7765622d7369676e696e, TASK-CONTRACT-6964656e746974792d617069
- Components: assistant-identity
- Generated files: terraform/main.tf.json
- Requirements: ai-current-access, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed regional Amazon Cognito user pool federating with the actual company identity provider, which remains unknown. Validate access-token issuer, audience, scope and expiry; map subjects to independently established source identities. Authentication never grants document access. Identity-provider processing locations, Cognito regional support and federation behavior require verification. Browser redirects directly to authentication endpoints; tokens never traverse CloudFront asset URLs. Mapping, federation and denial tests remain implementation work.
2. Verify Amazon Cognito on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon Cognito; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-identity
- Application/configuration and tests for Company sign-in federation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d617069 — Implement Authenticated question API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7765622d617069, TASK-CONTRACT-6964656e746974792d617069, TASK-CONTRACT-6170692d72756e74696d65
- Components: assistant-api
- Generated files: terraform/main.tf.json
- Requirements: ai-current-access

### Implementation steps

1. Responsibility from the board: Proposed regional Amazon API Gateway HTTP API, called directly by browser application code. Validate access tokens and pass trusted subject claims to the runtime; bound request size and rate. Return cited answers, partial-source notices or abstention. No document text, questions, answers or tokens in access logs; disable shared response caching. Regional endpoint, CORS, authorization and application integration require implementation and tests.
2. Verify Amazon API Gateway on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon API Gateway; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-api
- Application/configuration and tests for Authenticated question API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617373697374616e742d72756e74696d65 — Implement Permission-aware answer service

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6170692d72756e74696d65, TASK-CONTRACT-72756e74696d652d736561726368, TASK-CONTRACT-72756e74696d652d7374617465, TASK-CONTRACT-72756e74696d652d7368617265706f696e74, TASK-CONTRACT-72756e74696d652d636f6e666c75656e6365, TASK-CONTRACT-72756e74696d652d6d6f64656c, TASK-CONTRACT-72756e74696d652d6d6f6e69746f72696e67
- Components: assistant-runtime
- Generated files: terraform/main.tf.json
- Requirements: ai-current-access, ai-source-lifecycle, ai-source-outage-isolation, ai-australian-residency, ai-corpus-capacity

### Implementation steps

1. Responsibility from the board: Proposed custom AWS Lambda application. Embed the question regionally and retrieve candidates with ACL prefilters. Independently validate current effective per-user source access and exact content revision before sending evidence to the model; unchanged content never proves unchanged permission. Recheck evidence before answer release and discard or regenerate on change. Unknown identities, unavailable checks or source failures exclude affected evidence and derived context. Return authorized citations, incomplete-coverage notices or abstention. No durable conversation memory or personalized answer cache initially. Owns execution role and scoped logs. Native checks, bounded execution and concurrent-change tests require implementation. Separate source APIs cannot provide an atomic cross-system authorization snapshot; document the final-check race and acceptance behavior rather than promise instantaneous revocation.
2. Verify AWS Lambda on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component assistant-runtime
- Application/configuration and tests for Permission-aware answer service

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7365617263682d696e646578 — Implement Searchable document index

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72756e74696d652d736561726368, TASK-CONTRACT-73796e632d696e646578
- Components: search-index
- Generated files: terraform/main.tf.json
- Requirements: ai-source-lifecycle, ai-australian-residency, ai-corpus-capacity

### Implementation steps

1. Responsibility from the board: Proposed Amazon OpenSearch Serverless vector-search collection for 10,000 source documents and their chunks. Stores text, embeddings, source/document identifiers, content revisions and separately tracked authorization metadata. Document count does not establish storage size or chunk count. Hybrid retrieval and regional support require qualification. ACL filters only reduce candidates; sources authorize disclosure. Only synchronization writes; runtime receives scoped read access. Tombstones and independent revision/authorization checks suppress stale evidence. Keep indexes, recovery copies and processing in Australia; capacity, encryption/network policy, retention and recovery remain engineering work.
2. Verify Amazon OpenSearch Serverless on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon OpenSearch Serverless; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify collection type, encryption, network and data-access policies, private connectivity and capacity limits.
5. Define index mappings and creation ownership; for vector search select embedding model/dimensions and query strategy.
6. Test permissions, document deletion, capacity, reindex/recovery and source ACL freshness.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component search-index
- Application/configuration and tests for Searchable document index

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-736f757263652d7374617465 — Implement Source revisions and recovery state

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72756e74696d652d7374617465, TASK-CONTRACT-73796e632d7374617465
- Components: source-state
- Generated files: terraform/main.tf.json
- Requirements: ai-source-lifecycle, ai-source-outage-isolation, ai-australian-residency, ai-corpus-capacity

### Implementation steps

1. Responsibility from the board: Proposed Amazon DynamoDB table with source-isolated content revisions, independently tracked authorization observations, deletion tombstones, separate change/reconciliation checkpoints, health and identity mappings. A content revision never substitutes for permission freshness. Conditional updates prevent older work restoring deleted, superseded or authorization-stale index entries. State is coordination evidence, not authority for current source access. No credentials. Keep table, backups and recovery processing in Australia; no global replication assumed. Reconciliation, backup and retention behavior require implementation.
2. Verify Amazon DynamoDB on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon DynamoDB; determine exact resource types and required application code. The export has not generated this implementation.
4. Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
5. Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component source-state
- Application/configuration and tests for Source revisions and recovery state

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-736f757263652d73796e63 — Implement SharePoint and Confluence synchronization

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7363686564756c652d73796e63, TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-CONTRACT-73796e632d6d6f64656c, TASK-CONTRACT-73796e632d7374617465, TASK-CONTRACT-73796e632d696e646578, TASK-CONTRACT-73796e632d6d6f6e69746f72696e67
- Components: source-sync
- Generated files: terraform/main.tf.json
- Requirements: ai-source-lifecycle, ai-australian-residency, ai-corpus-capacity

### Implementation steps

1. Responsibility from the board: Proposed custom AWS Lambda worker with distinct native source adapter modules. Process 10,000 documents through bounded checkpointed pages, without assuming one invocation can scan the corpus. Track permission/group/inheritance changes independently of content changes; reconcile permissions even when content revisions do not change. Where native permission deltas are unavailable, use bounded reconciliation plus authoritative request-time checks. Track edits and tombstones, generate regional embeddings and conditionally update state/index. Source-specific checkpoints, bounded retries and nonoverlapping work isolate failures. Owns execution role and scoped logs. Source API semantics, credentials, pagination, rate limits, encrypted secret delivery and tenant-specific tests remain implementation work; no native connector is claimed.
2. Verify AWS Lambda on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for AWS Lambda; determine exact resource types and required application code. The export has not generated this implementation.
4. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
5. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
6. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component source-sync
- Application/configuration and tests for SharePoint and Confluence synchronization

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73796e632d7363686564756c65 — Implement Change checks and reconciliation schedule

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-7363686564756c652d73796e63
- Components: sync-schedule
- Generated files: terraform/main.tf.json
- Requirements: ai-source-lifecycle, ai-corpus-capacity

### Implementation steps

1. Responsibility from the board: Proposed Amazon EventBridge Scheduler schedules independent source content checks, permission reconciliation and recovery passes. Permission work must not depend on a content-change event. Cadences remain engineering proposals pending source limits and business freshness targets. Bounded worker pages resume from durable checkpoints after missed or failed invocations; execution payloads contain identifiers rather than source text. Regional support and retry/failure handling require qualification.
2. Verify Amazon EventBridge Scheduler on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon EventBridge Scheduler; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sync-schedule
- Application/configuration and tests for Change checks and reconciliation schedule

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7368617265706f696e74 — Integrate existing Existing SharePoint

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72756e74696d652d7368617265706f696e74, TASK-CONTRACT-73796e632d7368617265706f696e74
- Components: sharepoint
- Generated files: No implementation files generated yet
- Requirements: ai-current-access, ai-source-outage-isolation, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Existing authoritative content and permission system outside AWS provisioning scope. Content and effective authorization change independently. Native integration must establish current user access, inherited permissions, group membership, deletion and exact document revision. Tenant/API capabilities and existing content/processing locations are unverified; Australian AWS placement cannot establish SharePoint residency.
2. Verify Microsoft SharePoint on tools in Existing placement — not established; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sharepoint
- Application/configuration and tests for Existing SharePoint

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f6e666c75656e6365 — Integrate existing Existing Confluence

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72756e74696d652d636f6e666c75656e6365, TASK-CONTRACT-73796e632d636f6e666c75656e6365
- Components: confluence
- Generated files: No implementation files generated yet
- Requirements: ai-current-access, ai-source-outage-isolation, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Existing authoritative content and permission system outside AWS provisioning scope. Native integration must independently establish effective space/page/group access and current content revision/deletion. Cloud versus self-managed deployment, permission-change interfaces and existing content/processing locations are unverified; Australian AWS placement cannot establish Confluence residency.
2. Verify Atlassian Confluence on tools in Existing placement — not established; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve this externally managed service without creating or importing it.
5. Document its owner, endpoint, identity and integration contract; test actual connections separately.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component confluence
- Application/configuration and tests for Existing Confluence

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6d6f64656c2d73657276696365 — Implement Answer and embedding models

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72756e74696d652d6d6f64656c, TASK-CONTRACT-73796e632d6d6f64656c
- Components: model-service
- Generated files: terraform/main.tf.json
- Requirements: ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Amazon Bedrock managed inference access, with separate generation and embedding model selections rather than provisioned model servers. Embed questions and source chunks and generate answers within Australia. Each model needs verified direct regional availability, entitlement, quotas and data-handling terms; none is selected or verified. Regional API placement alone does not prove inference location. Exclude cross-region inference profiles and overseas fallback; block an unsupported model path. Only authorized evidence reaches generation. Model invocation logging is disabled initially to avoid extra content copies. Citation/abstention enforcement and model integrations remain application work.
2. Verify Amazon Bedrock on aws in ap-southeast-2 (proposed; models unverified); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon Bedrock; determine exact resource types and required application code. The export has not generated this implementation.
4. Select exact generation and, if needed, embedding model IDs, invocation API and inference mode; verify account access, regional availability and quotas with dated evidence.
5. Map every inference destination to the agreed processing boundary; a regional endpoint or APAC profile does not by itself establish country-only processing.
6. Implement scoped invocation IAM, token/time limits, retries and budget controls; keep source authorization before model invocation.
7. Define prompt-injection handling, authorized citations, insufficient-evidence responses and output checks; test these separately from model guardrails.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component model-service
- Application/configuration and tests for Answer and embedding models

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6f7065726174696f6e73 — Implement Source health and access-decision monitoring

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-72756e74696d652d6d6f6e69746f72696e67, TASK-CONTRACT-73796e632d6d6f6e69746f72696e67
- Components: operations
- Generated files: terraform/main.tf.json
- Requirements: ai-source-outage-isolation, ai-australian-residency

### Implementation steps

1. Responsibility from the board: Proposed Amazon CloudWatch metrics, scoped logs and alarms for per-source content/permission synchronization lag, outages, access denials, reconciliation failures and answer errors. Keep logs in Australia; record request IDs, restricted source/revision references and decision outcomes without document text, question/answer bodies, tokens or credentials. Alert payloads must not disclose source content. Retention, operational owner and response targets remain open. Regional support, instrumentation and failure alerts require implementation and tests.
2. Verify Amazon CloudWatch on aws in ap-southeast-2 (proposed); check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for Amazon CloudWatch; determine exact resource types and required application code. The export has not generated this implementation.
4. Define structured redacted logs, retention, metrics, alarms, dashboards and alert ownership for each component.
5. Test ingestion failure, denied access and latency alarms; verify sensitive prompts, source text and credentials are excluded.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component operations
- Application/configuration and tests for Source health and access-decision monitoring

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-656d706c6f796565732d776562 — Wire Employees using a browser to Internal assistant website

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-656d706c6f796565732d776562, TASK-RESOURCE-656d706c6f79656573, TASK-RESOURCE-617373697374616e742d776562
- Components: employees, assistant-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge employees-web carrying HTTPS: static application assets only, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation employees-web
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d7369676e696e — Wire Internal assistant website to Company sign-in federation

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d7369676e696e, TASK-RESOURCE-617373697374616e742d776562, TASK-RESOURCE-617373697374616e742d6964656e74697479
- Components: assistant-web, assistant-identity
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-signin carrying Browser code → regional sign-in: OAuth code with PKCE, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-signin
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7765622d617069 — Wire Internal assistant website to Authenticated question API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7765622d617069, TASK-RESOURCE-617373697374616e742d776562, TASK-RESOURCE-617373697374616e742d617069
- Components: assistant-web, assistant-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge web-api carrying Browser code → regional HTTPS API directly: question/token; cited response, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation web-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6964656e746974792d617069 — Wire Company sign-in federation to Authenticated question API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6964656e746974792d617069, TASK-RESOURCE-617373697374616e742d6964656e74697479, TASK-RESOURCE-617373697374616e742d617069
- Components: assistant-identity, assistant-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge identity-api carrying Validate token issuer, audience, scope, signature and expiry, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation identity-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6170692d72756e74696d65 — Wire Authenticated question API to Permission-aware answer service

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6170692d72756e74696d65, TASK-RESOURCE-617373697374616e742d617069, TASK-RESOURCE-617373697374616e742d72756e74696d65
- Components: assistant-api, assistant-runtime
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge api-runtime carrying Authenticated invocation with trusted subject, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation api-runtime
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72756e74696d652d736561726368 — Wire Permission-aware answer service to Searchable document index

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72756e74696d652d736561726368, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7365617263682d696e646578
- Components: assistant-runtime, search-index
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge runtime-search carrying Scoped hybrid candidate search; ACL filters never grant access, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation runtime-search
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72756e74696d652d7374617465 — Wire Permission-aware answer service to Source revisions and recovery state

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72756e74696d652d7374617465, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-736f757263652d7374617465
- Components: assistant-runtime, source-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge runtime-state carrying Read mappings, independent content/authorization state and tombstones, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation runtime-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72756e74696d652d7368617265706f696e74 — Wire Permission-aware answer service to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72756e74696d652d7368617265706f696e74, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7368617265706f696e74
- Components: assistant-runtime, sharepoint
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge runtime-sharepoint carrying Native API: independently check current access and exact revision; fail closed, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation runtime-sharepoint
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72756e74696d652d636f6e666c75656e6365 — Wire Permission-aware answer service to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72756e74696d652d636f6e666c75656e6365, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-636f6e666c75656e6365
- Components: assistant-runtime, confluence
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge runtime-confluence carrying Native API: independently check current access and exact revision; fail closed, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation runtime-confluence
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72756e74696d652d6d6f64656c — Wire Permission-aware answer service to Answer and embedding models

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72756e74696d652d6d6f64656c, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-6d6f64656c2d73657276696365
- Components: assistant-runtime, model-service
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge runtime-model carrying Australian inference: query embedding; authorized evidence → answer, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation runtime-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-7363686564756c652d73796e63 — Wire Change checks and reconciliation schedule to SharePoint and Confluence synchronization

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-7363686564756c652d73796e63, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65
- Components: sync-schedule, source-sync
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge schedule-sync carrying Independent content checks, permission reconciliation and recovery passes, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation schedule-sync
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d7368617265706f696e74 — Wire SharePoint and Confluence synchronization to Existing SharePoint

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d7368617265706f696e74, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-7368617265706f696e74
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-sharepoint carrying Native API: content deltas; independent permission/group reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-sharepoint
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d636f6e666c75656e6365 — Wire SharePoint and Confluence synchronization to Existing Confluence

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d636f6e666c75656e6365, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-636f6e666c75656e6365
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-confluence carrying Native API: content deltas; independent permission/group reconciliation, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-confluence
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d6d6f64656c — Wire SharePoint and Confluence synchronization to Answer and embedding models

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d6d6f64656c, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6d6f64656c2d73657276696365
- Components: source-sync, model-service
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-model carrying Generate document embeddings in Australia with scoped access, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d7374617465 — Wire SharePoint and Confluence synchronization to Source revisions and recovery state

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d7374617465, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, source-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-state carrying Conditional content/permission checkpoints, revisions, tombstones and health, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-state
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d696e646578 — Wire SharePoint and Confluence synchronization to Searchable document index

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d696e646578, TASK-RESOURCE-7365617263682d696e646578, TASK-RESOURCE-736f757263652d73796e63
- Components: source-sync, search-index
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-index carrying Independent content/ACL updates; stale-write rejection and deletion, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-index
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-72756e74696d652d6d6f6e69746f72696e67 — Wire Permission-aware answer service to Source health and access-decision monitoring

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-72756e74696d652d6d6f6e69746f72696e67, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-6f7065726174696f6e73
- Components: assistant-runtime, operations
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge runtime-monitoring carrying Redacted access decisions, latency and failures; Australian logs, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation runtime-monitoring
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-73796e632d6d6f6e69746f72696e67 — Wire SharePoint and Confluence synchronization to Source health and access-decision monitoring

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-73796e632d6d6f6e69746f72696e67, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-6f7065726174696f6e73
- Components: source-sync, operations
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Implement edge sync-monitoring carrying Per-source content/permission lag, outages and recovery failures, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation sync-monitoring
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-656d706c6f796565732d776562 — Verify live Employees using a browser → Internal assistant website

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-656d706c6f796565732d776562
- Components: employees, assistant-web
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge employees-web with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence employees-web

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d7369676e696e — Verify live Internal assistant website → Company sign-in federation

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d7369676e696e
- Components: assistant-web, assistant-identity
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-signin with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-signin

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7765622d617069 — Verify live Internal assistant website → Authenticated question API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7765622d617069
- Components: assistant-web, assistant-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge web-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence web-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6964656e746974792d617069 — Verify live Company sign-in federation → Authenticated question API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6964656e746974792d617069
- Components: assistant-identity, assistant-api
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge identity-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence identity-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6170692d72756e74696d65 — Verify live Authenticated question API → Permission-aware answer service

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6170692d72756e74696d65
- Components: assistant-api, assistant-runtime
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge api-runtime with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence api-runtime

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72756e74696d652d736561726368 — Verify live Permission-aware answer service → Searchable document index

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72756e74696d652d736561726368
- Components: assistant-runtime, search-index
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge runtime-search with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence runtime-search

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72756e74696d652d7374617465 — Verify live Permission-aware answer service → Source revisions and recovery state

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72756e74696d652d7374617465
- Components: assistant-runtime, source-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge runtime-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence runtime-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74 — Verify live Permission-aware answer service → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72756e74696d652d7368617265706f696e74
- Components: assistant-runtime, sharepoint
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge runtime-sharepoint with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence runtime-sharepoint

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365 — Verify live Permission-aware answer service → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72756e74696d652d636f6e666c75656e6365
- Components: assistant-runtime, confluence
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge runtime-confluence with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence runtime-confluence

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c — Verify live Permission-aware answer service → Answer and embedding models

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72756e74696d652d6d6f64656c
- Components: assistant-runtime, model-service
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge runtime-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence runtime-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-7363686564756c652d73796e63 — Verify live Change checks and reconciliation schedule → SharePoint and Confluence synchronization

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-7363686564756c652d73796e63
- Components: sync-schedule, source-sync
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge schedule-sync with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence schedule-sync

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74 — Verify live SharePoint and Confluence synchronization → Existing SharePoint

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d7368617265706f696e74
- Components: source-sync, sharepoint
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-sharepoint with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-sharepoint

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365 — Verify live SharePoint and Confluence synchronization → Existing Confluence

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d636f6e666c75656e6365
- Components: source-sync, confluence
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-confluence with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-confluence

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d6d6f64656c — Verify live SharePoint and Confluence synchronization → Answer and embedding models

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d6d6f64656c
- Components: source-sync, model-service
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d7374617465 — Verify live SharePoint and Confluence synchronization → Source revisions and recovery state

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d7374617465
- Components: source-sync, source-state
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-state with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-state

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d696e646578 — Verify live SharePoint and Confluence synchronization → Searchable document index

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d696e646578
- Components: source-sync, search-index
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-index with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-index

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67 — Verify live Permission-aware answer service → Source health and access-decision monitoring

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-72756e74696d652d6d6f6e69746f72696e67
- Components: assistant-runtime, operations
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge runtime-monitoring with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence runtime-monitoring

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67 — Verify live SharePoint and Confluence synchronization → Source health and access-decision monitoring

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-73796e632d6d6f6e69746f72696e67
- Components: source-sync, operations
- Generated files: terraform/main.tf.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge sync-monitoring with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence sync-monitoring

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d6165626666366437 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-aebff6d7

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d63757272656e742d616363657373 — Verify REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d6964656e74697479, TASK-RESOURCE-617373697374616e742d617069, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-INTEGRATION-LIVE-7765622d7369676e696e, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67
- Components: assistant-identity, assistant-api, assistant-runtime, sharepoint, confluence
- Generated files: terraform/main.tf.json
- Requirements: ai-current-access

### Implementation steps

1. Basis: “People should get cited answers only from documents they can access.”; rationale: Proposed acceptance requirement: copied ACLs can become stale, so search filtering alone could disclose revoked content to users or to the model.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6c6966656379636c65 — Verify REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7365617263682d696e646578, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7374617465, TASK-INTEGRATION-LIVE-73796e632d696e646578, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67
- Components: source-sync, sync-schedule, source-state, search-index, assistant-runtime
- Generated files: terraform/main.tf.json
- Requirements: ai-source-lifecycle

### Implementation steps

1. Basis: “Permission revocation, edits and deletion must propagate.”; rationale: Proposed acceptance requirement: missed updates or replayed jobs could leave obsolete text searchable or restore deleted content.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6f75746167652d69736f6c6174696f6e — Verify REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-6f7065726174696f6e73, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67
- Components: assistant-runtime, source-state, sharepoint, confluence, operations
- Generated files: terraform/main.tf.json
- Requirements: ai-source-outage-isolation

### Implementation steps

1. Basis: “An outage in one source should not leak stale restricted content.”; rationale: Proposed acceptance requirement: an outage must not turn old permissions, cached answers or conversation history into an alternative disclosure path.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379 — Verify REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d776562, TASK-RESOURCE-617373697374616e742d6964656e74697479, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7365617263682d696e646578, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-6d6f64656c2d73657276696365, TASK-RESOURCE-6f7065726174696f6e73, TASK-INTEGRATION-LIVE-656d706c6f796565732d776562, TASK-INTEGRATION-LIVE-7765622d7369676e696e, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7374617465, TASK-INTEGRATION-LIVE-73796e632d696e646578, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67
- Components: assistant-web, assistant-identity, assistant-runtime, search-index, source-state, source-sync, model-service, operations, sharepoint, confluence
- Generated files: terraform/main.tf.json
- Requirements: ai-australian-residency

### Implementation steps

1. Basis: “Australia for content, indexes and processing; explain service/model residency gaps.” Components include search-index, model-service, source-sync and operations.; rationale: Proposed acceptance requirement derived from the stated residency boundary; regional resource names alone cannot establish model execution, backup or external-source residency.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d636f727075732d6361706163697479 — Verify REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7365617263682d696e646578, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7374617465, TASK-INTEGRATION-LIVE-73796e632d696e646578, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67
- Components: source-sync, sync-schedule, search-index, source-state, assistant-runtime
- Generated files: terraform/main.tf.json
- Requirements: ai-corpus-capacity

### Implementation steps

1. Basis: “Ten thousand company documents.” Existing source-sync, search-index and source-state responsibilities.; rationale: Proposed corpus acceptance target based on the stated document count; chunk count, bytes, request concurrency and freshness remain unknown, so document count cannot establish runtime sizing.
2. Implement a check for Supported source documents >= 10000 documents; specify test data, workload, measurement window and environment.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-656d706c6f79656573, TASK-RESOURCE-617373697374616e742d776562, TASK-RESOURCE-617373697374616e742d6964656e74697479, TASK-RESOURCE-617373697374616e742d617069, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7365617263682d696e646578, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-6d6f64656c2d73657276696365, TASK-RESOURCE-6f7065726174696f6e73, TASK-INTEGRATION-656d706c6f796565732d776562, TASK-INTEGRATION-7765622d7369676e696e, TASK-INTEGRATION-7765622d617069, TASK-INTEGRATION-6964656e746974792d617069, TASK-INTEGRATION-6170692d72756e74696d65, TASK-INTEGRATION-72756e74696d652d736561726368, TASK-INTEGRATION-72756e74696d652d7374617465, TASK-INTEGRATION-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-72756e74696d652d6d6f64656c, TASK-INTEGRATION-7363686564756c652d73796e63, TASK-INTEGRATION-73796e632d7368617265706f696e74, TASK-INTEGRATION-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-73796e632d6d6f64656c, TASK-INTEGRATION-73796e632d7374617465, TASK-INTEGRATION-73796e632d696e646578, TASK-INTEGRATION-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-73796e632d6d6f6e69746f72696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-656d706c6f79656573, TASK-RESOURCE-617373697374616e742d776562, TASK-RESOURCE-617373697374616e742d6964656e74697479, TASK-RESOURCE-617373697374616e742d617069, TASK-RESOURCE-617373697374616e742d72756e74696d65, TASK-RESOURCE-7365617263682d696e646578, TASK-RESOURCE-736f757263652d7374617465, TASK-RESOURCE-736f757263652d73796e63, TASK-RESOURCE-73796e632d7363686564756c65, TASK-RESOURCE-7368617265706f696e74, TASK-RESOURCE-636f6e666c75656e6365, TASK-RESOURCE-6d6f64656c2d73657276696365, TASK-RESOURCE-6f7065726174696f6e73, TASK-INTEGRATION-LIVE-656d706c6f796565732d776562, TASK-INTEGRATION-LIVE-7765622d7369676e696e, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7374617465, TASK-INTEGRATION-LIVE-73796e632d696e646578, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d6165626666366437, TASK-ACCEPTANCE-61692d63757272656e742d616363657373, TASK-ACCEPTANCE-61692d736f757263652d6c6966656379636c65, TASK-ACCEPTANCE-61692d736f757263652d6f75746167652d69736f6c6174696f6e, TASK-ACCEPTANCE-61692d6175737472616c69616e2d7265736964656e6379, TASK-ACCEPTANCE-61692d636f727075732d6361706163697479, TASK-INTEGRATION-LIVE-656d706c6f796565732d776562, TASK-INTEGRATION-LIVE-7765622d7369676e696e, TASK-INTEGRATION-LIVE-7765622d617069, TASK-INTEGRATION-LIVE-6964656e746974792d617069, TASK-INTEGRATION-LIVE-6170692d72756e74696d65, TASK-INTEGRATION-LIVE-72756e74696d652d736561726368, TASK-INTEGRATION-LIVE-72756e74696d652d7374617465, TASK-INTEGRATION-LIVE-72756e74696d652d7368617265706f696e74, TASK-INTEGRATION-LIVE-72756e74696d652d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f64656c, TASK-INTEGRATION-LIVE-7363686564756c652d73796e63, TASK-INTEGRATION-LIVE-73796e632d7368617265706f696e74, TASK-INTEGRATION-LIVE-73796e632d636f6e666c75656e6365, TASK-INTEGRATION-LIVE-73796e632d6d6f64656c, TASK-INTEGRATION-LIVE-73796e632d7374617465, TASK-INTEGRATION-LIVE-73796e632d696e646578, TASK-INTEGRATION-LIVE-72756e74696d652d6d6f6e69746f72696e67, TASK-INTEGRATION-LIVE-73796e632d6d6f6e69746f72696e67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
