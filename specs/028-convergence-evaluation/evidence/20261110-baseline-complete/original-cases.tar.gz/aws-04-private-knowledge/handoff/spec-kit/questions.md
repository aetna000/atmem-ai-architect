# Questions and assumptions to resolve

Snapshot e7a7cad9-cf63-4f5b-a8ba-5cea7318fb94 · design r3 · generated 2026-11-09T17:01:04.031Z

- [ai-current-access] Confirm REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.
- [ai-source-lifecycle] Confirm REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.
- [ai-source-outage-isolation] Confirm REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.
- [ai-australian-residency] Confirm REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
- [ai-corpus-capacity] Confirm REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.
- [acceptance-req-aebff6d7] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-current-access] Agree a measurable acceptance check for REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.
- [acceptance-ai-source-lifecycle] Agree a measurable acceptance check for REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.
- [acceptance-ai-source-outage-isolation] Agree a measurable acceptance check for REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.
- [acceptance-ai-australian-residency] Agree a measurable acceptance check for REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d6175737472616c69616e2d7265736964656e6379] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d636f727075732d6361706163697479] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d63757272656e742d616363657373] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d736f757263652d6c6966656379636c65] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d736f757263652d6f75746167652d69736f6c6174696f6e] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
