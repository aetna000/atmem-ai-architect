# Existing systems

These components remain externally managed. This export does not create, import, replace or modify them. Their presence in the diagram is not proof of availability, authentication, permissions or integration behavior. Connection implementations and runtime tests remain separate requirements.

- "Existing SharePoint" ("sharepoint"): reference only, preserve existing system.
- "Existing Confluence" ("confluence"): reference only, preserve existing system.
