# Delivery handoff

Snapshot e7a7cad9-cf63-4f5b-a8ba-5cea7318fb94 · design r3 · generated 2026-11-09T17:01:04.031Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Company sign-in federation / Checked requests: input needed (requests_per_month).
- Searchable document index / Index storage: input needed (data_gb).
- Source revisions and recovery state / Storage: input needed (data_gb).
- SharePoint and Confluence synchronization / Data processed: input needed (data_gb).
- Change checks and reconciliation schedule / Data processed: input needed (data_gb).
- Existing SharePoint / Storage: input needed (data_gb).
- Existing Confluence / Storage: input needed (data_gb).
- Answer and embedding models / Endpoint hours: price needed.
- Employees using a browser: no cost lines; add charges or an explicit zero-cost line with a reason.
- Internal assistant website: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authenticated question API: no cost lines; add charges or an explicit zero-cost line with a reason.
- Permission-aware answer service: no cost lines; add charges or an explicit zero-cost line with a reason.
- Source health and access-decision monitoring: no cost lines; add charges or an explicit zero-cost line with a reason.
- Internal assistant website: Implementation needed.
- Company sign-in federation: Implementation needed.
- Authenticated question API: Implementation needed.
- Permission-aware answer service: Implementation needed.
- Searchable document index: Implementation needed.
- Source revisions and recovery state: Implementation needed.
- SharePoint and Confluence synchronization: Implementation needed.
- Change checks and reconciliation schedule: Implementation needed.
- Answer and embedding models: Implementation needed.
- Source health and access-decision monitoring: Implementation needed.
- Wire employees → assistant-web: implement data flow, access policy and acceptance test.
- Wire assistant-web → assistant-identity: implement data flow, access policy and acceptance test.
- Wire assistant-web → assistant-api: implement data flow, access policy and acceptance test.
- Wire assistant-identity → assistant-api: implement data flow, access policy and acceptance test.
- Wire assistant-api → assistant-runtime: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → search-index: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → source-state: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → model-service: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → model-service: implement data flow, access policy and acceptance test.
- Wire source-sync → source-state: implement data flow, access policy and acceptance test.
- Wire source-sync → search-index: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → operations: implement data flow, access policy and acceptance test.
- Wire source-sync → operations: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
