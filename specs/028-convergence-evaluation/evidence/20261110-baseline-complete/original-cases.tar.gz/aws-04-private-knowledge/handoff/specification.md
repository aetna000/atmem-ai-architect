Snapshot e7a7cad9-cf63-4f5b-a8ba-5cea7318fb94 · design r3 · generated 2026-11-09T17:01:04.031Z

# Permission-aware knowledge assistant — solution specification

## Problem and intended outcome

Build an internal assistant over our existing SharePoint and Confluence content. People should get cited answers only from documents they can access. Permission revocation, edits and deletion must propagate. An outage in one source should not leak stale restricted content. Use AWS. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations. (must, open); target: acceptance target needed; linked blocks: assistant-identity, assistant-api, assistant-runtime, sharepoint, confluence

Design explanation: Proposed acceptance requirement: copied ACLs can become stale, so search filtering alone could disclose revoked content to users or to the model.

Basis: “People should get cited answers only from documents they can access.”
- [REQ-005] Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance. (must, open); target: acceptance target needed; linked blocks: source-sync, sync-schedule, source-state, search-index, assistant-runtime

Design explanation: Proposed acceptance requirement: missed updates or replayed jobs could leave obsolete text searchable or restore deleted content.

Basis: “Permission revocation, edits and deletion must propagate.”
- [REQ-006] When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes. (must, open); target: acceptance target needed; linked blocks: assistant-runtime, source-state, sharepoint, confluence, operations

Design explanation: Proposed acceptance requirement: an outage must not turn old permissions, cached answers or conversation history into an alternative disclosure path.

Basis: “An outage in one source should not leak stale restricted content.”
- [REQ-007] Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance. (must, open); target: acceptance target needed; linked blocks: assistant-web, assistant-identity, assistant-runtime, search-index, source-state, source-sync, model-service, operations, sharepoint, confluence

Design explanation: Proposed acceptance requirement derived from the stated residency boundary; regional resource names alone cannot establish model execution, backup or external-source residency.

Basis: “Australia for content, indexes and processing; explain service/model residency gaps.” Components include search-index, model-service, source-sync and operations.
- [REQ-008] Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization. (must, open); target: Supported source documents >= 10000documents; linked blocks: source-sync, sync-schedule, search-index, source-state, assistant-runtime

Design explanation: Proposed corpus acceptance target based on the stated document count; chunk count, bytes, request concurrency and freshness remain unknown, so document count cannot establish runtime sizing.

Basis: “Ten thousand company documents.” Existing source-sync, search-index and source-state responsibilities.

## How the system works

The current design contains 13 components and 18 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Employees using a browser → Internal assistant website

HTTPS: static application assets only

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Internal assistant website → Company sign-in federation

Browser code → regional sign-in: OAuth code with PKCE

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Internal assistant website → Authenticated question API

Browser code → regional HTTPS API directly: question/token; cited response

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Company sign-in federation → Authenticated question API

Validate token issuer, audience, scope, signature and expiry

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Authenticated question API → Permission-aware answer service

Authenticated invocation with trusted subject

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Permission-aware answer service → Searchable document index

Scoped hybrid candidate search; ACL filters never grant access

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Permission-aware answer service → Source revisions and recovery state

Read mappings, independent content/authorization state and tombstones

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: Permission-aware answer service → Existing SharePoint

Native API: independently check current access and exact revision; fail closed

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Permission-aware answer service → Existing Confluence

Native API: independently check current access and exact revision; fail closed

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 10: Permission-aware answer service → Answer and embedding models

Australian inference: query embedding; authorized evidence → answer

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 11: Change checks and reconciliation schedule → SharePoint and Confluence synchronization

Independent content checks, permission reconciliation and recovery passes

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 12: SharePoint and Confluence synchronization → Existing SharePoint

Native API: content deltas; independent permission/group reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 13: SharePoint and Confluence synchronization → Existing Confluence

Native API: content deltas; independent permission/group reconciliation

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 14: SharePoint and Confluence synchronization → Answer and embedding models

Generate document embeddings in Australia with scoped access

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 15: SharePoint and Confluence synchronization → Source revisions and recovery state

Conditional content/permission checkpoints, revisions, tombstones and health

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 16: SharePoint and Confluence synchronization → Searchable document index

Independent content/ACL updates; stale-write rejection and deletion

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 17: Permission-aware answer service → Source health and access-decision monitoring

Redacted access decisions, latency and failures; Australian logs

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 18: SharePoint and Confluence synchronization → Source health and access-decision monitoring

Per-source content/permission lag, outages and recovery failures

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Employees using a browser

Web browser · tools · region: Existing client locations · classification: Confidential

Existing people outside provisioning scope. Browser loads static application assets, then sends questions and receives cited answers directly through regional API endpoints. No user count or employee location is assumed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Employees using a browser → Internal assistant website: HTTPS: static application assets only (integration: browser-https)

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Internal assistant website

Amazon CloudFront · aws · region: Global — static assets only · classification: Internal

Proposed Amazon CloudFront distribution serving static application code only. Browser code calls regional authentication and question endpoints directly; documents, questions, answers, citations and tokens must not pass through distribution requests, URLs or caches. CloudFront is global: asset-request IP addresses and other connection metadata are a residency gap requiring review. Static origin, asset build and hosting integration remain implementation work; the origin is owned by this hosting boundary. This is not the bounded-RAG generated web contract.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Employees using a browser → Internal assistant website: HTTPS: static application assets only (integration: browser-https)

Outputs: Internal assistant website → Company sign-in federation: Browser code → regional sign-in: OAuth code with PKCE; Internal assistant website → Authenticated question API: Browser code → regional HTTPS API directly: question/token; cited response

Requirement traceability: REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Company sign-in federation

Amazon Cognito · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed regional Amazon Cognito user pool federating with the actual company identity provider, which remains unknown. Validate access-token issuer, audience, scope and expiry; map subjects to independently established source identities. Authentication never grants document access. Identity-provider processing locations, Cognito regional support and federation behavior require verification. Browser redirects directly to authentication endpoints; tokens never traverse CloudFront asset URLs. Mapping, federation and denial tests remain implementation work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Internal assistant website → Company sign-in federation: Browser code → regional sign-in: OAuth code with PKCE

Outputs: Company sign-in federation → Authenticated question API: Validate token issuer, audience, scope, signature and expiry

Requirement traceability: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Authenticated question API

Amazon API Gateway · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed regional Amazon API Gateway HTTP API, called directly by browser application code. Validate access tokens and pass trusted subject claims to the runtime; bound request size and rate. Return cited answers, partial-source notices or abstention. No document text, questions, answers or tokens in access logs; disable shared response caching. Regional endpoint, CORS, authorization and application integration require implementation and tests.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Internal assistant website → Authenticated question API: Browser code → regional HTTPS API directly: question/token; cited response; Company sign-in federation → Authenticated question API: Validate token issuer, audience, scope, signature and expiry

Outputs: Authenticated question API → Permission-aware answer service: Authenticated invocation with trusted subject

Requirement traceability: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Permission-aware answer service

AWS Lambda · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed custom AWS Lambda application. Embed the question regionally and retrieve candidates with ACL prefilters. Independently validate current effective per-user source access and exact content revision before sending evidence to the model; unchanged content never proves unchanged permission. Recheck evidence before answer release and discard or regenerate on change. Unknown identities, unavailable checks or source failures exclude affected evidence and derived context. Return authorized citations, incomplete-coverage notices or abstention. No durable conversation memory or personalized answer cache initially. Owns execution role and scoped logs. Native checks, bounded execution and concurrent-change tests require implementation. Separate source APIs cannot provide an atomic cross-system authorization snapshot; document the final-check race and acceptance behavior rather than promise instantaneous revocation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Authenticated question API → Permission-aware answer service: Authenticated invocation with trusted subject

Outputs: Permission-aware answer service → Searchable document index: Scoped hybrid candidate search; ACL filters never grant access; Permission-aware answer service → Source revisions and recovery state: Read mappings, independent content/authorization state and tombstones; Permission-aware answer service → Existing SharePoint: Native API: independently check current access and exact revision; fail closed; Permission-aware answer service → Existing Confluence: Native API: independently check current access and exact revision; fail closed; Permission-aware answer service → Answer and embedding models: Australian inference: query embedding; authorized evidence → answer; Permission-aware answer service → Source health and access-decision monitoring: Redacted access decisions, latency and failures; Australian logs

Requirement traceability: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Searchable document index

Amazon OpenSearch Serverless · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed Amazon OpenSearch Serverless vector-search collection for 10,000 source documents and their chunks. Stores text, embeddings, source/document identifiers, content revisions and separately tracked authorization metadata. Document count does not establish storage size or chunk count. Hybrid retrieval and regional support require qualification. ACL filters only reduce candidates; sources authorize disclosure. Only synchronization writes; runtime receives scoped read access. Tombstones and independent revision/authorization checks suppress stale evidence. Keep indexes, recovery copies and processing in Australia; capacity, encryption/network policy, retention and recovery remain engineering work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Permission-aware answer service → Searchable document index: Scoped hybrid candidate search; ACL filters never grant access; SharePoint and Confluence synchronization → Searchable document index: Independent content/ACL updates; stale-write rejection and deletion

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify collection type, encryption, network and data-access policies, private connectivity and capacity limits.
- Define index mappings and creation ownership; for vector search select embedding model/dimensions and query strategy.
- Test permissions, document deletion, capacity, reindex/recovery and source ACL freshness.

### Source revisions and recovery state

Amazon DynamoDB · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed Amazon DynamoDB table with source-isolated content revisions, independently tracked authorization observations, deletion tombstones, separate change/reconciliation checkpoints, health and identity mappings. A content revision never substitutes for permission freshness. Conditional updates prevent older work restoring deleted, superseded or authorization-stale index entries. State is coordination evidence, not authority for current source access. No credentials. Keep table, backups and recovery processing in Australia; no global replication assumed. Reconciliation, backup and retention behavior require implementation.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Permission-aware answer service → Source revisions and recovery state: Read mappings, independent content/authorization state and tombstones; SharePoint and Confluence synchronization → Source revisions and recovery state: Conditional content/permission checkpoints, revisions, tombstones and health

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

### SharePoint and Confluence synchronization

AWS Lambda · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed custom AWS Lambda worker with distinct native source adapter modules. Process 10,000 documents through bounded checkpointed pages, without assuming one invocation can scan the corpus. Track permission/group/inheritance changes independently of content changes; reconcile permissions even when content revisions do not change. Where native permission deltas are unavailable, use bounded reconciliation plus authoritative request-time checks. Track edits and tombstones, generate regional embeddings and conditionally update state/index. Source-specific checkpoints, bounded retries and nonoverlapping work isolate failures. Owns execution role and scoped logs. Source API semantics, credentials, pagination, rate limits, encrypted secret delivery and tenant-specific tests remain implementation work; no native connector is claimed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Change checks and reconciliation schedule → SharePoint and Confluence synchronization: Independent content checks, permission reconciliation and recovery passes

Outputs: SharePoint and Confluence synchronization → Existing SharePoint: Native API: content deltas; independent permission/group reconciliation; SharePoint and Confluence synchronization → Existing Confluence: Native API: content deltas; independent permission/group reconciliation; SharePoint and Confluence synchronization → Answer and embedding models: Generate document embeddings in Australia with scoped access; SharePoint and Confluence synchronization → Source revisions and recovery state: Conditional content/permission checkpoints, revisions, tombstones and health; SharePoint and Confluence synchronization → Searchable document index: Independent content/ACL updates; stale-write rejection and deletion; SharePoint and Confluence synchronization → Source health and access-decision monitoring: Per-source content/permission lag, outages and recovery failures

Requirement traceability: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Change checks and reconciliation schedule

Amazon EventBridge Scheduler · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed Amazon EventBridge Scheduler schedules independent source content checks, permission reconciliation and recovery passes. Permission work must not depend on a content-change event. Cadences remain engineering proposals pending source limits and business freshness targets. Bounded worker pages resume from durable checkpoints after missed or failed invocations; execution payloads contain identifiers rather than source text. Regional support and retry/failure handling require qualification.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: No incoming connection is drawn.

Outputs: Change checks and reconciliation schedule → SharePoint and Confluence synchronization: Independent content checks, permission reconciliation and recovery passes

Requirement traceability: REQ-005: Propagate permission changes, edits and deletions from both sources through revision-aware, idempotent synchronization with durable checkpoints and reconciliation. Suppress tombstoned or superseded content from answers while index updates complete. Establish a propagation target before operational acceptance.; REQ-008: Support synchronization, reconciliation and permission-aware retrieval across 10,000 company documents from SharePoint and Confluence using bounded, resumable processing. Qualify representative document formats, chunk volumes and permission structures without weakening source authorization.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Existing SharePoint

Microsoft SharePoint · tools · region: Existing placement — not established · classification: Confidential

Existing authoritative content and permission system outside AWS provisioning scope. Content and effective authorization change independently. Native integration must establish current user access, inherited permissions, group membership, deletion and exact document revision. Tenant/API capabilities and existing content/processing locations are unverified; Australian AWS placement cannot establish SharePoint residency.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Permission-aware answer service → Existing SharePoint: Native API: independently check current access and exact revision; fail closed; SharePoint and Confluence synchronization → Existing SharePoint: Native API: content deltas; independent permission/group reconciliation

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Existing Confluence

Atlassian Confluence · tools · region: Existing placement — not established · classification: Confidential

Existing authoritative content and permission system outside AWS provisioning scope. Native integration must independently establish effective space/page/group access and current content revision/deletion. Cloud versus self-managed deployment, permission-change interfaces and existing content/processing locations are unverified; Australian AWS placement cannot establish Confluence residency.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Permission-aware answer service → Existing Confluence: Native API: independently check current access and exact revision; fail closed; SharePoint and Confluence synchronization → Existing Confluence: Native API: content deltas; independent permission/group reconciliation

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Bind every request to an authenticated source identity and enforce effective source permissions before model context construction and answer release. Reject unknown mappings; indexed ACLs must never independently authorize disclosure. Test inherited permissions, group changes and revocations.; REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

Implementation status: Existing service reference — preserved without provisioning or import; behavior and connections remain unverified

Implementation considerations (guidance):
- Preserve this externally managed service without creating or importing it.
- Document its owner, endpoint, identity and integration contract; test actual connections separately.

### Answer and embedding models

Amazon Bedrock · aws · region: ap-southeast-2 (proposed; models unverified) · classification: Confidential

Proposed Amazon Bedrock managed inference access, with separate generation and embedding model selections rather than provisioned model servers. Embed questions and source chunks and generate answers within Australia. Each model needs verified direct regional availability, entitlement, quotas and data-handling terms; none is selected or verified. Regional API placement alone does not prove inference location. Exclude cross-region inference profiles and overseas fallback; block an unsupported model path. Only authorized evidence reaches generation. Model invocation logging is disabled initially to avoid extra content copies. Citation/abstention enforcement and model integrations remain application work.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Permission-aware answer service → Answer and embedding models: Australian inference: query embedding; authorized evidence → answer; SharePoint and Confluence synchronization → Answer and embedding models: Generate document embeddings in Australia with scoped access

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Select exact generation and, if needed, embedding model IDs, invocation API and inference mode; verify account access, regional availability and quotas with dated evidence.
- Map every inference destination to the agreed processing boundary; a regional endpoint or APAC profile does not by itself establish country-only processing.
- Implement scoped invocation IAM, token/time limits, retries and budget controls; keep source authorization before model invocation.
- Define prompt-injection handling, authorized citations, insufficient-evidence responses and output checks; test these separately from model guardrails.

### Source health and access-decision monitoring

Amazon CloudWatch · aws · region: ap-southeast-2 (proposed) · classification: Confidential

Proposed Amazon CloudWatch metrics, scoped logs and alarms for per-source content/permission synchronization lag, outages, access denials, reconciliation failures and answer errors. Keep logs in Australia; record request IDs, restricted source/revision references and decision outcomes without document text, question/answer bodies, tokens or credentials. Alert payloads must not disclose source content. Retention, operational owner and response targets remain open. Regional support, instrumentation and failure alerts require implementation and tests.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Permission-aware answer service → Source health and access-decision monitoring: Redacted access decisions, latency and failures; Australian logs; SharePoint and Confluence synchronization → Source health and access-decision monitoring: Per-source content/permission lag, outages and recovery failures

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: When current access or freshness cannot be established for a source, exclude its content and derived context from generation and response delivery. Permit answers using independently authorized healthy-source evidence, identify incomplete coverage and abstain when evidence is inadequate. Test outages, recovery and concurrent permission changes.; REQ-007: Keep assistant-held content, indexes, embeddings and content-bearing processing, logs, temporary copies and backups in Australia. Verify each generation/embedding model's execution location and data handling; prohibit overseas inference/fallback. Document global static-delivery metadata, identity-provider and existing-source residency gaps before acceptance.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Define structured redacted logs, retention, metrics, alarms, dashboards and alert ownership for each component.
- Test ingestion failure, denied access and latency alarms; verify sensitive prompts, source text and credentials are excluded.

## Architecture

```mermaid
flowchart LR
  n0["Employees using a browser<br/>Tools & data"]
  n1["Internal assistant website<br/>AWS"]
  n2["Company sign-in federation<br/>AWS"]
  n3["Authenticated question API<br/>AWS"]
  n4["Permission-aware answer service<br/>AWS"]
  n5["Searchable document index<br/>AWS"]
  n6["Source revisions and recovery state<br/>AWS"]
  n7["SharePoint and Confluence synchronization<br/>AWS"]
  n8["Change checks and reconciliation schedule<br/>AWS"]
  n9["Existing SharePoint<br/>Tools & data"]
  n10["Existing Confluence<br/>Tools & data"]
  n11["Answer and embedding models<br/>AWS"]
  n12["Source health and access-decision monitoring<br/>AWS"]
  n0 -->|HTTPS: static application assets only| n1
  n1 -->|Browser code → regional sign-in: OAuth code with PKCE| n2
  n1 -->|Browser code → regional HTTPS API directly: question/token; cited response| n3
  n2 -->|Validate token issuer, audience, scope, signature and expiry| n3
  n3 -->|Authenticated invocation with trusted subject| n4
  n4 -->|Scoped hybrid candidate search; ACL filters never grant access| n5
  n4 -->|Read mappings, independent content/authorization state and tombstones| n6
  n4 -->|Native API: independently check current access and exact revision; fail closed| n9
  n4 -->|Native API: independently check current access and exact revision; fail closed| n10
  n4 -->|Australian inference: query embedding; authorized evidence → answer| n11
  n8 -->|Independent content checks, permission reconciliation and recovery passes| n7
  n7 -->|Native API: content deltas; independent permission/group reconciliation| n9
  n7 -->|Native API: content deltas; independent permission/group reconciliation| n10
  n7 -->|Generate document embeddings in Australia with scoped access| n11
  n7 -->|Conditional content/permission checkpoints, revisions, tombstones and health| n6
  n7 -->|Independent content/ACL updates; stale-write rejection and deletion| n5
  n4 -->|Redacted access decisions, latency and failures; Australian logs| n12
  n7 -->|Per-source content/permission lag, outages and recovery failures| n12
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| employees | Employees using a browser | tools | Web browser | Existing client locations | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| assistant-web | Internal assistant website | aws | Amazon CloudFront | Global — static assets only | Proposed | Implementation needed |
| assistant-identity | Company sign-in federation | aws | Amazon Cognito | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| assistant-api | Authenticated question API | aws | Amazon API Gateway | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| assistant-runtime | Permission-aware answer service | aws | AWS Lambda | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| search-index | Searchable document index | aws | Amazon OpenSearch Serverless | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| source-state | Source revisions and recovery state | aws | Amazon DynamoDB | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| source-sync | SharePoint and Confluence synchronization | aws | AWS Lambda | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| sync-schedule | Change checks and reconciliation schedule | aws | Amazon EventBridge Scheduler | ap-southeast-2 (proposed) | Proposed | Implementation needed |
| sharepoint | Existing SharePoint | tools | Microsoft SharePoint | Existing placement — not established | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| confluence | Existing Confluence | tools | Atlassian Confluence | Existing placement — not established | Existing | Existing service reference — preserved without provisioning or import; behavior and connections remain unverified |
| model-service | Answer and embedding models | aws | Amazon Bedrock | ap-southeast-2 (proposed; models unverified) | Proposed | Implementation needed |
| operations | Source health and access-decision monitoring | aws | Amazon CloudWatch | ap-southeast-2 (proposed) | Proposed | Implementation needed |

### Resources and cost dimensions

- **Employees using a browser** (employees): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Internal assistant website** (assistant-web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: employees.
- **Company sign-in federation** (assistant-identity): aws_cognito_user_pool. Active users and authentication features. Depends on: assistant-web.
- **Authenticated question API** (assistant-api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: assistant-web, assistant-identity.
- **Permission-aware answer service** (assistant-runtime): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: assistant-api.
- **Searchable document index** (search-index): aws_opensearchserverless_collection. Deployment mode, indexing/search capacity and storage. Depends on: assistant-runtime, source-sync.
- **Source revisions and recovery state** (source-state): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: assistant-runtime, source-sync.
- **SharePoint and Confluence synchronization** (source-sync): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: sync-schedule.
- **Change checks and reconciliation schedule** (sync-schedule): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Existing SharePoint** (sharepoint): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-runtime, source-sync.
- **Existing Confluence** (confluence): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: assistant-runtime, source-sync.
- **Answer and embedding models** (model-service): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: assistant-runtime, source-sync.
- **Source health and access-decision monitoring** (operations): aws_cloudwatch_log_group. Logs, metrics, alarms and retention. Depends on: assistant-runtime, source-sync.

### Engineering work remaining

- Internal assistant website: Implementation needed.
- Company sign-in federation: Implementation needed.
- Authenticated question API: Implementation needed.
- Permission-aware answer service: Implementation needed.
- Searchable document index: Implementation needed.
- Source revisions and recovery state: Implementation needed.
- SharePoint and Confluence synchronization: Implementation needed.
- Change checks and reconciliation schedule: Implementation needed.
- Answer and embedding models: Implementation needed.
- Source health and access-decision monitoring: Implementation needed.
- Wire employees → assistant-web: implement data flow, access policy and acceptance test.
- Wire assistant-web → assistant-identity: implement data flow, access policy and acceptance test.
- Wire assistant-web → assistant-api: implement data flow, access policy and acceptance test.
- Wire assistant-identity → assistant-api: implement data flow, access policy and acceptance test.
- Wire assistant-api → assistant-runtime: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → search-index: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → source-state: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → sharepoint: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → confluence: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → model-service: implement data flow, access policy and acceptance test.
- Wire sync-schedule → source-sync: implement data flow, access policy and acceptance test.
- Wire source-sync → sharepoint: implement data flow, access policy and acceptance test.
- Wire source-sync → confluence: implement data flow, access policy and acceptance test.
- Wire source-sync → model-service: implement data flow, access policy and acceptance test.
- Wire source-sync → source-state: implement data flow, access policy and acceptance test.
- Wire source-sync → search-index: implement data flow, access policy and acceptance test.
- Wire assistant-runtime → operations: implement data flow, access policy and acceptance test.
- Wire source-sync → operations: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### ADR-002 · data.country

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r3 · **Subject:** `data.country`

**Context**

User statement: Australia for content, indexes and processing

**Options considered**

—

**Decision**

Australia

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
