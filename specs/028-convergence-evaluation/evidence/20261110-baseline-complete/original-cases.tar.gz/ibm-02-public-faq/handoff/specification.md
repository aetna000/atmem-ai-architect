Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

# Cited public FAQ — solution specification

## Problem and intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Scope

None recorded.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: not linked

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.
- [REQ-004] The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer. (must, open); target: acceptance target needed; linked blocks: faq-app, faq-store, faq-model

Design explanation: Unsupported answers can mislead visitors; abstention and citation checks must be application behavior with evaluation evidence.

Basis: “answers questions from our twenty public help articles, cites the articles it used, and says when it does not know.” Existing citation requirement: req-91680f68.
- [REQ-005] The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions. (must, open); target: acceptance target needed; linked blocks: faq-articles, faq-app, faq-store, faq-model

Design explanation: An explicit source boundary prevents private information or unrestricted external content from entering answer retrieval.

Basis: “It must not answer from private sources.” Proposed application and published collection boundary.
- [REQ-006] Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access. (must, open); target: acceptance target needed; linked blocks: faq-editors, faq-editor-signin, faq-app, faq-store

Design explanation: Stale retrieval and concurrent changes can cause removed or superseded content to remain in answers; public access must not grant publishing rights.

Basis: “We need to update and remove articles.” Editor authentication and atomic publishing are proposed engineering controls.
- [REQ-007] The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails. (must, open); target: acceptance target needed; linked blocks: faq-articles, faq-editors, faq-app, faq-store

Design explanation: File validation and atomic publication prevent malformed uploads or partial updates from corrupting the answering collection; these are proposed engineering controls.

Basis: “Twenty public UTF-8 help articles under 30 KB each, supplied as files.” Existing faq-app and faq-store own publishing and the active collection.
- [REQ-008] The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision. (should, open); target: acceptance target needed; linked blocks: faq-app, faq-store, faq-editor-signin, faq-model

Design explanation: Storage location alone does not determine model-processing or identity-data location; explicit verification prevents an unintended cross-border design.

Basis: “Australia is preferred; make model/data-location limitations explicit.”

## How the system works

The current design contains 7 components and 7 connections. 3 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Public website visitors → Website and grounded FAQ application

HTTPS question → cited answer or “I don’t know”

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Twenty public UTF-8 article files → Authorised article editors

Approved UTF-8 files under 30 KB each; article IDs and canonical URLs

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: Authorised article editors → Website and grounded FAQ application

Authenticated HTTPS: upload, replace or remove; acknowledge active revision

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Authorised article editors → Editor sign-in

OIDC sign-in with PKCE — integration to implement

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: Website and grounded FAQ application → Editor sign-in

OIDC issuer/JWKS validation; app enforces editor allowlist

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Website and grounded FAQ application → Published article collection

IAM-authenticated object reads and conditional publishing writes

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Website and grounded FAQ application → Grounded answer generation

IAM-authenticated inference: question and public passages → grounded draft

Payload schema, authorization and failure handling need an explicit interface contract.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Public website visitors

Approval workflow · tools · region: Not applicable · classification: Confidential

Existing people using browsers, outside provisioning scope. Ask questions and receive cited answers or an explicit insufficient-evidence response. No visitor account proposed.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Public website visitors → Website and grounded FAQ application: HTTPS question → cited answer or “I don’t know”

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Website and grounded FAQ application

IBM Cloud Code Engine · ibm · region: Australia preferred; region unconfirmed · classification: Confidential

Proposed IBM Cloud Code Engine application hosting the website, question API and protected publishing interface. Editors upload public UTF-8 article files with stable article IDs, titles and canonical public URLs. Validate encoding, declared file-size limits and metadata before publishing; reject invalid uploads without changing the active collection. Recommend lexical passage ranking for twenty small articles, with no vector database, private connectors, unrestricted crawling, general web search or model tools. Send only relevant active passages and the question to inference. Validate cited article IDs and URLs, and return an insufficient-evidence response for unsupported answers or model failure. Treat article text as untrusted evidence. Publish immutable snapshots through a conditional active-manifest update; recheck the current revision before releasing answers and fail closed if current state cannot be checked. Rollbacks must not restore removed articles. Enforce editor authorization, scoped storage/inference identity, bounded requests and outputs, rate limiting and redacted operational logs. Visitor questions may contain personal information despite public source files; avoid retaining raw questions by default. Australia is preferred; verify runtime, logs and processing locations before selection, with no automatic overseas inference fallback. Application, permissions, abuse controls, recovery and integrations require implementation and tests; no supplied container image or generator implementation is asserted.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Public website visitors → Website and grounded FAQ application: HTTPS question → cited answer or “I don’t know”; Authorised article editors → Website and grounded FAQ application: Authenticated HTTPS: upload, replace or remove; acknowledge active revision

Outputs: Website and grounded FAQ application → Editor sign-in: OIDC issuer/JWKS validation; app enforces editor allowlist; Website and grounded FAQ application → Published article collection: IAM-authenticated object reads and conditional publishing writes; Website and grounded FAQ application → Grounded answer generation: IAM-authenticated inference: question and public passages → grounded draft

Requirement traceability: REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.; REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Twenty public UTF-8 article files

Storage or existing data connector · tools · region: Existing location unknown · classification: Public

Existing twenty public help articles supplied as UTF-8 files, each under 30 KB, with no private content. Files remain client-owned and outside provisioning scope. Editors supply approved text with stable article IDs, titles and canonical public article URLs for citations. No source-system connector, private credentials or unrestricted crawling is needed. Original file storage location is not established.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Twenty public UTF-8 article files → Authorised article editors: Approved UTF-8 files under 30 KB each; article IDs and canonical URLs

Requirement traceability: REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.

Implementation status: Existing — reference/import plan needed

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### Authorised article editors

Approval workflow · tools · region: Not applicable · classification: Confidential

Existing people, outside provisioning scope. Proposed protected website interface lets authorised editors upload, replace and remove public article files and maintain their citation metadata. Public visitors receive no publishing permissions. Editor onboarding and operating ownership remain to be assigned.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Twenty public UTF-8 article files → Authorised article editors: Approved UTF-8 files under 30 KB each; article IDs and canonical URLs

Outputs: Authorised article editors → Website and grounded FAQ application: Authenticated HTTPS: upload, replace or remove; acknowledge active revision; Authorised article editors → Editor sign-in: OIDC sign-in with PKCE — integration to implement

Requirement traceability: REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Editor sign-in

IBM Cloud App ID · ibm · region: Australia preferred; region unconfirmed · classification: Confidential

Proposed IBM Cloud App ID instance for editor authentication only. The application separately enforces an explicit editor allowlist and validates token issuer, audience and expiry on every management request. Identity-provider setup, supported sign-in method, Australian service availability, identity-data location and secure onboarding require verification. Visitors do not use this service. Authentication and integration are engineering work, not verified capabilities of this composition.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Authorised article editors → Editor sign-in: OIDC sign-in with PKCE — integration to implement; Website and grounded FAQ application → Editor sign-in: OIDC issuer/JWKS validation; app enforces editor allowlist

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Published article collection

IBM Cloud Object Storage · ibm · region: Australia preferred; region unconfirmed · classification: Public

Proposed private IBM Cloud Object Storage bucket containing approved public UTF-8 article snapshots, canonical citation metadata and an authoritative active manifest. Only the application service identity accesses objects; editors publish through the application. Conditional manifest updates prevent concurrent publishing conflicts. Removed article IDs are excluded from retrieval and response validation; obsolete snapshots are cleaned up under a documented recovery policy, and recovery must not republish removed content. No separate vector store is proposed for twenty small articles. Australia is preferred for primary storage and recovery copies; verify bucket location, retention and recovery behavior before selection. Scoped application permissions, conditional-write behavior and recovery tests require engineering. This is not the standalone operator-storage generator contract.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Website and grounded FAQ application → Published article collection: IAM-authenticated object reads and conditional publishing writes

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.; REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Grounded answer generation

IBM watsonx.ai Runtime · ibm · region: Australia preferred; inference location unverified · classification: Confidential

Proposed IBM watsonx.ai Runtime inference service. Receives the visitor question and selected active public passages; produces a constrained draft with article IDs or an insufficient-evidence result. No private retrieval, browsing or action tools are provided. Application validates citations and abstains on missing evidence or model failure. Australia is preferred, but no Australian model endpoint or processing location has been verified. Australian application or storage placement does not establish inference residency. Verify the exact model, endpoint, processing and retention terms, entitlement and quotas before selection. Do not silently select an overseas endpoint or fallback; any required location exception needs a separate user decision. No model access or regional compatibility is claimed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Website and grounded FAQ application → Grounded answer generation: IAM-authenticated inference: question and public passages → grounded draft

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.; REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.

Implementation status: Implementation needed

Implementation considerations (guidance):
- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Architecture

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Website and grounded FAQ application<br/>IBM"]
  n2["Twenty public UTF-8 article files<br/>Tools & data"]
  n3["Authorised article editors<br/>Tools & data"]
  n4["Editor sign-in<br/>IBM"]
  n5["Published article collection<br/>IBM"]
  n6["Grounded answer generation<br/>IBM"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Approved UTF-8 files under 30 KB each; article IDs and canonical URLs| n3
  n3 -->|Authenticated HTTPS: upload, replace or remove; acknowledge active revision| n1
  n3 -->|OIDC sign-in with PKCE — integration to implement| n4
  n1 -->|OIDC issuer/JWKS validation; app enforces editor allowlist| n4
  n1 -->|IAM-authenticated object reads and conditional publishing writes| n5
  n1 -->|IAM-authenticated inference: question and public passages → grounded draft| n6
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitors | Public website visitors | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Website and grounded FAQ application | ibm | IBM Cloud Code Engine | Australia preferred; region unconfirmed | Proposed | Implementation needed |
| faq-articles | Twenty public UTF-8 article files | tools | Storage or existing data connector | Existing location unknown | Existing | Existing — reference/import plan needed |
| faq-editors | Authorised article editors | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-editor-signin | Editor sign-in | ibm | IBM Cloud App ID | Australia preferred; region unconfirmed | Proposed | Implementation needed |
| faq-store | Published article collection | ibm | IBM Cloud Object Storage | Australia preferred; region unconfirmed | Proposed | Implementation needed |
| faq-model | Grounded answer generation | ibm | IBM watsonx.ai Runtime | Australia preferred; inference location unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Public website visitors** (faq-visitors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Website and grounded FAQ application** (faq-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-visitors, faq-editors.
- **Twenty public UTF-8 article files** (faq-articles): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Authorised article editors** (faq-editors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-articles.
- **Editor sign-in** (faq-editor-signin): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-editors, faq-app.
- **Published article collection** (faq-store): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.
- **Grounded answer generation** (faq-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.

### Engineering work remaining

- Website and grounded FAQ application: Implementation needed.
- Twenty public UTF-8 article files: Existing — reference/import plan needed.
- Editor sign-in: Implementation needed.
- Published article collection: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-articles → faq-editors: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-editor-signin: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-editor-signin: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-store: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Decisions and change history

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—


## Assumptions

None recorded.

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
