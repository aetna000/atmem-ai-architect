Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

# Cited public FAQ — deployment document

Generated 2026-11-09 17:58 UTC from design revision r3 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

- **Cloud:** IBM
- **Usage:** unknown
- **Estimated run cost:** —/month expected (—–—) — **incomplete**
- **Review:** 8 open findings (0 blockers)
- **Current decisions:** 1

## 2. Scope and context

- **What you want to build:** Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
- **Information it uses:** —
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** IBM Twenty public UTF-8 help articles under 30 KB each, supplied as files. No private content. Australia is preferred; make model/data-location limitations explicit.
- **Budget and timeline:** —

## 3. Architecture

**Public experience**

- Public website visitors (Tools & data, existing, sketch) — Existing people using browsers, outside provisioning scope. Ask questions and receive cited answers or an explicit insufficient-evidence response. No visitor account proposed.

**FAQ application**

- Website and grounded FAQ application (IBM, sketch) — Proposed IBM Cloud Code Engine application hosting the website, question API and protected publishing interface. Editors upload public UTF-8 article files with stable article IDs, titles and canonical public URLs. Validate encoding, declared file-size limits and metadata before publishing; reject invalid uploads without changing the active collection. Recommend lexical passage ranking for twenty small articles, with no vector database, private connectors, unrestricted crawling, general web search or model tools. Send only relevant active passages and the question to inference. Validate cited article IDs and URLs, and return an insufficient-evidence response for unsupported answers or model failure. Treat article text as untrusted evidence. Publish immutable snapshots through a conditional active-manifest update; recheck the current revision before releasing answers and fail closed if current state cannot be checked. Rollbacks must not restore removed articles. Enforce editor authorization, scoped storage/inference identity, bounded requests and outputs, rate limiting and redacted operational logs. Visitor questions may contain personal information despite public source files; avoid retaining raw questions by default. Australia is preferred; verify runtime, logs and processing locations before selection, with no automatic overseas inference fallback. Application, permissions, abuse controls, recovery and integrations require implementation and tests; no supplied container image or generator implementation is asserted.
- Published article collection (IBM, sketch) — Proposed private IBM Cloud Object Storage bucket containing approved public UTF-8 article snapshots, canonical citation metadata and an authoritative active manifest. Only the application service identity accesses objects; editors publish through the application. Conditional manifest updates prevent concurrent publishing conflicts. Removed article IDs are excluded from retrieval and response validation; obsolete snapshots are cleaned up under a documented recovery policy, and recovery must not republish removed content. No separate vector store is proposed for twenty small articles. Australia is preferred for primary storage and recovery copies; verify bucket location, retention and recovery behavior before selection. Scoped application permissions, conditional-write behavior and recovery tests require engineering. This is not the standalone operator-storage generator contract.
- Grounded answer generation (IBM, sketch) — Proposed IBM watsonx.ai Runtime inference service. Receives the visitor question and selected active public passages; produces a constrained draft with article IDs or an insufficient-evidence result. No private retrieval, browsing or action tools are provided. Application validates citations and abstains on missing evidence or model failure. Australia is preferred, but no Australian model endpoint or processing location has been verified. Australian application or storage placement does not establish inference residency. Verify the exact model, endpoint, processing and retention terms, entitlement and quotas before selection. Do not silently select an overseas endpoint or fallback; any required location exception needs a separate user decision. No model access or regional compatibility is claimed.

**Article publishing**

- Twenty public UTF-8 article files (Tools & data, existing) — Existing twenty public help articles supplied as UTF-8 files, each under 30 KB, with no private content. Files remain client-owned and outside provisioning scope. Editors supply approved text with stable article IDs, titles and canonical public article URLs for citations. No source-system connector, private credentials or unrestricted crawling is needed. Original file storage location is not established.
- Authorised article editors (Tools & data, existing, sketch) — Existing people, outside provisioning scope. Proposed protected website interface lets authorised editors upload, replace and remove public article files and maintain their citation metadata. Public visitors receive no publishing permissions. Editor onboarding and operating ownership remain to be assigned.
- Editor sign-in (IBM, sketch) — Proposed IBM Cloud App ID instance for editor authentication only. The application separately enforces an explicit editor allowlist and validates token issuer, audience and expiry on every management request. Identity-provider setup, supported sign-in method, Australian service availability, identity-data location and secure onboarding require verification. Visitors do not use this service. Authentication and integration are engineering work, not verified capabilities of this composition.

```mermaid
flowchart LR
  n0["Public website visitors<br/>Tools & data"]
  n1["Website and grounded FAQ application<br/>IBM"]
  n2["Twenty public UTF-8 article files<br/>Tools & data"]
  n3["Authorised article editors<br/>Tools & data"]
  n4["Editor sign-in<br/>IBM"]
  n5["Published article collection<br/>IBM"]
  n6["Grounded answer generation<br/>IBM"]
  n0 -->|HTTPS question → cited answer or “I don’t know”| n1
  n2 -->|Approved UTF-8 files under 30 KB each; article IDs and canonical URLs| n3
  n3 -->|Authenticated HTTPS: upload, replace or remove; acknowledge active revision| n1
  n3 -->|OIDC sign-in with PKCE — integration to implement| n4
  n1 -->|OIDC issuer/JWKS validation; app enforces editor allowlist| n4
  n1 -->|IAM-authenticated object reads and conditional publishing writes| n5
  n1 -->|IAM-authenticated inference: question and public passages → grounded draft| n6
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| faq-visitors | Public website visitors | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-app | Website and grounded FAQ application | ibm | IBM Cloud Code Engine | Australia preferred; region unconfirmed | Proposed | Implementation needed |
| faq-articles | Twenty public UTF-8 article files | tools | Storage or existing data connector | Existing location unknown | Existing | Existing — reference/import plan needed |
| faq-editors | Authorised article editors | tools | Approval workflow | Not applicable | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| faq-editor-signin | Editor sign-in | ibm | IBM Cloud App ID | Australia preferred; region unconfirmed | Proposed | Implementation needed |
| faq-store | Published article collection | ibm | IBM Cloud Object Storage | Australia preferred; region unconfirmed | Proposed | Implementation needed |
| faq-model | Grounded answer generation | ibm | IBM watsonx.ai Runtime | Australia preferred; inference location unverified | Proposed | Implementation needed |

### Resources and cost dimensions

- **Public website visitors** (faq-visitors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Website and grounded FAQ application** (faq-app): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-visitors, faq-editors.
- **Twenty public UTF-8 article files** (faq-articles): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Authorised article editors** (faq-editors): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-articles.
- **Editor sign-in** (faq-editor-signin): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-editors, faq-app.
- **Published article collection** (faq-store): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.
- **Grounded answer generation** (faq-model): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: faq-app.

### Engineering work remaining

- Website and grounded FAQ application: Implementation needed.
- Twenty public UTF-8 article files: Existing — reference/import plan needed.
- Editor sign-in: Implementation needed.
- Published article collection: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-articles → faq-editors: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-editor-signin: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-editor-signin: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-store: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Public website visitors | Website and grounded FAQ application | HTTPS question → cited answer or “I don’t know” | Confidential |
| Twenty public UTF-8 article files | Authorised article editors | Approved UTF-8 files under 30 KB each; article IDs and canonical URLs | Confidential |
| Authorised article editors | Website and grounded FAQ application | Authenticated HTTPS: upload, replace or remove; acknowledge active revision | Confidential |
| Authorised article editors | Editor sign-in | OIDC sign-in with PKCE — integration to implement | Confidential |
| Website and grounded FAQ application | Editor sign-in | OIDC issuer/JWKS validation; app enforces editor allowlist | Confidential |
| Website and grounded FAQ application | Published article collection | IAM-authenticated object reads and conditional publishing writes | Confidential |
| Website and grounded FAQ application | Grounded answer generation | IAM-authenticated inference: question and public passages → grounded draft | Confidential |

## 5. Security controls

- **Public website visitors** — Existing people using browsers, outside provisioning scope. Ask questions and receive cited answers or an explicit insufficient-evidence response. No visitor account proposed.
- **Authorised article editors** — Existing people, outside provisioning scope. Proposed protected website interface lets authorised editors upload, replace and remove public article files and maintain their citation metadata. Public visitors receive no publishing permissions. Editor onboarding and operating ownership remain to be assigned.
- **Editor sign-in** — Proposed IBM Cloud App ID instance for editor authentication only. The application separately enforces an explicit editor allowlist and validates token issuer, audience and expiry on every management request. Identity-provider setup, supported sign-in method, Australian service availability, identity-data location and secure onboarding require verification. Visitors do not use this service. Authentication and integration are engineering work, not verified capabilities of this composition.
- Requirement: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions. (must)
- Requirement: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision. (should)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions. | security | not measurable yet | Open |
| The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer. (must, open)
- Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access. (must, open)
- The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 2 quality requirements have no measurable target. Add a metric and target to: “The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.”, “The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 6 blocks are sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

**Cost**

- [info] No budget stated. Mention a monthly running budget, or a range, in the chat. _(AtMem AI Architect rule CST-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Not estimated. Rough order of magnitude, refined as scope and charge dimensions become known.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Twenty public UTF-8 article files | Storage | needs data_gb | price needed | — | — |
| Editor sign-in | Checked requests | needs requests_per_month | price needed | — | — |
| Published article collection | Storage | needs data_gb | price needed | — | — |
| Grounded answer generation | Endpoint hours | 730 hours | price needed | — | — |

**Usage inputs:** Requests per month: — (needed); Data stored: — (needed); Model endpoint hours per month: 730 (assumption: always on (730 h/month)).

**Range:** low ×0.7, high ×1.5 of expected. Not costed in this release: Public website visitors, Website and grounded FAQ application, Authorised article editors.

**Estimate gaps:**

- Twenty public UTF-8 article files / Storage: input needed (data_gb).
- Editor sign-in / Checked requests: input needed (requests_per_month).
- Published article collection / Storage: input needed (data_gb).
- Grounded answer generation / Endpoint hours: price needed.
- Public website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Website and grounded FAQ application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorised article editors: no cost lines; add charges or an explicit zero-cost line with a reason.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision article publishing: Editor sign-in.
4. Provision faq application: Website and grounded FAQ application, Published article collection, Grounded answer generation.
5. Connect existing systems: Public website visitors, Twenty public UTF-8 article files, Authorised article editors; test failure behaviour.
6. Run the acceptance checks (success measures and requirements) in staging; record results.
7. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-10 · **Design:** r2 · **Subject:** `platform.cloud`

**Context**

User statement: Use IBM Cloud.

**Options considered**

—

**Decision**

ibm

_Changed because: Chosen in the conversation_

**Consequences**

—

## 11. Assumptions

_None recorded._
- _Assumption:_ Model endpoint hours per month = 730 (always on (730 h/month))

## 12. Open questions

- Which information should the system use? _(discovery)_
- Who will use this system? _(discovery)_
- Twenty public UTF-8 article files: needs data_gb _(estimate)_
- Editor sign-in: needs requests_per_month _(estimate)_
- Published article collection: needs data_gb _(estimate)_
- Grounded answer generation: needs a unit price with a source _(estimate)_
