# Delivery handoff

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

This is a reviewable design handoff, not deployment evidence.

## Readiness

Read spec-kit/readiness.md for prioritised decisions, task links and separate evidence stages. Schema checks cannot establish application deployment readiness.

## Work remaining

- Twenty public UTF-8 article files / Storage: input needed (data_gb).
- Editor sign-in / Checked requests: input needed (requests_per_month).
- Published article collection / Storage: input needed (data_gb).
- Grounded answer generation / Endpoint hours: price needed.
- Public website visitors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Website and grounded FAQ application: no cost lines; add charges or an explicit zero-cost line with a reason.
- Authorised article editors: no cost lines; add charges or an explicit zero-cost line with a reason.
- Website and grounded FAQ application: Implementation needed.
- Twenty public UTF-8 article files: Existing — reference/import plan needed.
- Editor sign-in: Implementation needed.
- Published article collection: Implementation needed.
- Grounded answer generation: Implementation needed.
- Wire faq-visitors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-articles → faq-editors: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-app: implement data flow, access policy and acceptance test.
- Wire faq-editors → faq-editor-signin: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-editor-signin: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-store: implement data flow, access policy and acceptance test.
- Wire faq-app → faq-model: implement data flow, access policy and acceptance test.
- Discovery & specification: effort, rate, ordered day range and basis needed.
- Architecture & security: effort, rate, ordered day range and basis needed.
- Implementation & integration: effort, rate, ordered day range and basis needed.
- Testing & acceptance: effort, rate, ordered day range and basis needed.
- Deployment & handover: effort, rate, ordered day range and basis needed.

## Before deployment

- Confirm provider, region, data residency, account owner and environment.
- Complete the resource implementations, application code, IAM and data-flow integrations.
- Validate the estimate against every billable dimension and a current provider quote.
- Review least-privilege access, quotas, secrets handling and Terraform state storage.
- Run and review the infrastructure plan in the intended account.
- Agree acceptance tests, rollback and an explicit deployment approval.
- Capture results and handover ownership. No cloud operation has been performed by this export.
