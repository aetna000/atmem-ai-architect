# Questions and assumptions to resolve

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

- [ai-grounded-answers] Confirm REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.
- [ai-public-source-boundary] Confirm REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.
- [ai-article-lifecycle] Confirm REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.
- [ai-public-file-ingestion] Confirm REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.
- [ai-location-transparency] Confirm REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.
- [acceptance-req-91680f68] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-grounded-answers] Agree a measurable acceptance check for REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.
- [acceptance-ai-public-source-boundary] Agree a measurable acceptance check for REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.
- [acceptance-ai-article-lifecycle] Agree a measurable acceptance check for REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.
- [acceptance-ai-public-file-ingestion] Agree a measurable acceptance check for REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.
- [acceptance-ai-location-transparency] Agree a measurable acceptance check for REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.
- [data.country] Confirm the country and data-residency boundary, including sources, logs and model processing.
- [cloud.region] Confirm the deployment region separately from the accepted country; verify each service and model in that region.
- [scope-boundary] No explicit scope boundary is recorded. Record included and excluded use cases before sizing or implementation.
- [requirement-proposed-61692d61727469636c652d6c6966656379636c65] REQ-006 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d67726f756e6465642d616e7377657273] REQ-004 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379] REQ-008 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d66696c652d696e67657374696f6e] REQ-007 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.
- [requirement-proposed-61692d7075626c69632d736f757263652d626f756e64617279] REQ-005 remains proposed. Confirm, revise or explicitly defer this requirement; do not promote it through generation.

## Assumptions requiring verification

None recorded.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
