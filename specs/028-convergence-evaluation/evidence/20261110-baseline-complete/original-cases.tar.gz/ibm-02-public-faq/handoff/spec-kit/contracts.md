# Component and interface contracts

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-visitors: Public website visitors

- Responsibility: Existing people using browsers, outside provisioning scope. Ask questions and receive cited answers or an explicit insufficient-evidence response. No visitor account proposed.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d76697369746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Website and grounded FAQ application

- Responsibility: Proposed IBM Cloud Code Engine application hosting the website, question API and protected publishing interface. Editors upload public UTF-8 article files with stable article IDs, titles and canonical public URLs. Validate encoding, declared file-size limits and metadata before publishing; reject invalid uploads without changing the active collection. Recommend lexical passage ranking for twenty small articles, with no vector database, private connectors, unrestricted crawling, general web search or model tools. Send only relevant active passages and the question to inference. Validate cited article IDs and URLs, and return an insufficient-evidence response for unsupported answers or model failure. Treat article text as untrusted evidence. Publish immutable snapshots through a conditional active-manifest update; recheck the current revision before releasing answers and fail closed if current state cannot be checked. Rollbacks must not restore removed articles. Enforce editor authorization, scoped storage/inference identity, bounded requests and outputs, rate limiting and redacted operational logs. Visitor questions may contain personal information despite public source files; avoid retaining raw questions by default. Australia is preferred; verify runtime, logs and processing locations before selection, with no automatic overseas inference fallback. Application, permissions, abuse controls, recovery and integrations require implementation and tests; no supplied container image or generator implementation is asserted.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia preferred; region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-articles: Twenty public UTF-8 article files

- Responsibility: Existing twenty public help articles supplied as UTF-8 files, each under 30 KB, with no private content. Files remain client-owned and outside provisioning scope. Editors supply approved text with stable article IDs, titles and canonical public article URLs for citations. No source-system connector, private credentials or unrestricted crawling is needed. Original file storage location is not established.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing location unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d61727469636c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component faq-editors: Authorised article editors

- Responsibility: Existing people, outside provisioning scope. Proposed protected website interface lets authorised editors upload, replace and remove public article files and maintain their citation metadata. Public visitors receive no publishing permissions. Editor onboarding and operating ownership remain to be assigned.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-editor-signin: Editor sign-in

- Responsibility: Proposed IBM Cloud App ID instance for editor authentication only. The application separately enforces an explicit editor allowlist and validates token issuer, audience and expiry on every management request. Identity-provider setup, supported sign-in method, Australian service availability, identity-data location and secure onboarding require verification. Visitors do not use this service. Authentication and integration are engineering work, not verified capabilities of this composition.
- Service: IBM Cloud App ID
- Provider / placement: ibm / Australia preferred; region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d656469746f722d7369676e696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-store: Published article collection

- Responsibility: Proposed private IBM Cloud Object Storage bucket containing approved public UTF-8 article snapshots, canonical citation metadata and an authoritative active manifest. Only the application service identity accesses objects; editors publish through the application. Conditional manifest updates prevent concurrent publishing conflicts. Removed article IDs are excluded from retrieval and response validation; obsolete snapshots are cleaned up under a documented recovery policy, and recovery must not republish removed content. No separate vector store is proposed for twenty small articles. Australia is preferred for primary storage and recovery copies; verify bucket location, retention and recovery behavior before selection. Scoped application permissions, conditional-write behavior and recovery tests require engineering. This is not the standalone operator-storage generator contract.
- Service: IBM Cloud Object Storage
- Provider / placement: ibm / Australia preferred; region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d73746f7265
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-model: Grounded answer generation

- Responsibility: Proposed IBM watsonx.ai Runtime inference service. Receives the visitor question and selected active public passages; produces a constrained draft with article IDs or an insufficient-evidence result. No private retrieval, browsing or action tools are provided. Application validates citations and abstains on missing evidence or model failure. Australia is preferred, but no Australian model endpoint or processing location has been verified. Australian application or storage placement does not establish inference residency. Verify the exact model, endpoint, processing and retention terms, entitlement and quotas before selection. Do not silently select an overseas endpoint or fallback; any required location exception needs a separate user decision. No model access or regional compatibility is claimed.
- Service: IBM watsonx.ai Runtime
- Provider / placement: ibm / Australia preferred; inference location unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### faq-visitor-app: faq-visitors → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d76697369746f722d617070
- Integration task: TASK-INTEGRATION-6661712d76697369746f722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-articles-editor: faq-articles → faq-editors

- Drawn payload/purpose: Approved UTF-8 files under 30 KB each; article IDs and canonical URLs
- Contract task: TASK-CONTRACT-6661712d61727469636c65732d656469746f72
- Integration task: TASK-INTEGRATION-6661712d61727469636c65732d656469746f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-app: faq-editors → faq-app

- Drawn payload/purpose: Authenticated HTTPS: upload, replace or remove; acknowledge active revision
- Contract task: TASK-CONTRACT-6661712d656469746f722d617070
- Integration task: TASK-INTEGRATION-6661712d656469746f722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-signin-flow: faq-editors → faq-editor-signin

- Drawn payload/purpose: OIDC sign-in with PKCE — integration to implement
- Contract task: TASK-CONTRACT-6661712d656469746f722d7369676e696e2d666c6f77
- Integration task: TASK-INTEGRATION-6661712d656469746f722d7369676e696e2d666c6f77
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-signin-validation: faq-app → faq-editor-signin

- Drawn payload/purpose: OIDC issuer/JWKS validation; app enforces editor allowlist
- Contract task: TASK-CONTRACT-6661712d6170702d7369676e696e2d76616c69646174696f6e
- Integration task: TASK-INTEGRATION-6661712d6170702d7369676e696e2d76616c69646174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-store: faq-app → faq-store

- Drawn payload/purpose: IAM-authenticated object reads and conditional publishing writes
- Contract task: TASK-CONTRACT-6661712d6170702d73746f7265
- Integration task: TASK-INTEGRATION-6661712d6170702d73746f7265
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-model: faq-app → faq-model

- Drawn payload/purpose: IAM-authenticated inference: question and public passages → grounded draft
- Contract task: TASK-CONTRACT-6661712d6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.
