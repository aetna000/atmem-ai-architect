# Implementation Spec Kit

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

This is an implementation handoff derived from the requirements, decisions and architecture. It is part of the specification, not a replacement for the requirements. It is a generated work breakdown, not evidence of completed code.

## Handoff readiness

8 priority decisions; infrastructure: not_implemented. See readiness.md and readiness.json for linked gaps and evidence boundaries.

Next action: Record included and excluded use cases before sizing or implementation.

## Intended outcome

Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.

## Confirmed design decisions

- platform.cloud: ibm

## Implementation sequence

1. Confirm scope, country/region and open decisions.
2. Prepare the repository, toolchain and CI.
3. Define contracts for each connection.
4. Implement or reference each component.
5. Implement integrations locally; run static and mock checks continuously.
6. With explicit account authorization, review the real plan and costs; obtain separate staging deployment approval.
7. Deploy staging, verify live integrations, requirements and recovery; prepare separately approved production release.

Dependencies in tasks.json govern execution. Independent component tasks can proceed after their prerequisites; diagram cycles do not create circular build dependencies. Never execute every task blindly when a prerequisite is blocked.

## Infrastructure coverage

- Public website visitors (faq-visitors): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Not applicable.
- Website and grounded FAQ application (faq-app): Implementation needed; ibm, Australia preferred; region unconfirmed.
- Twenty public UTF-8 article files (faq-articles): Existing — reference/import plan needed; tools, Existing location unknown.
- Authorised article editors (faq-editors): External browser — no infrastructure to provision; connection behavior still requires validation; tools, Not applicable.
- Editor sign-in (faq-editor-signin): Implementation needed; ibm, Australia preferred; region unconfirmed.
- Published article collection (faq-store): Implementation needed; ibm, Australia preferred; region unconfirmed.
- Grounded answer generation (faq-model): Implementation needed; ibm, Australia preferred; inference location unverified.

## How to use this kit

Read contracts.md and tasks.md. Use tasks.json for machine-readable dependencies and acceptance checks. Keep progress.json as the implementation journal. Start by reporting the next actionable task and the most consequential unknown. Refine this plan into repository-specific code/file changes once the repository and runtime are known; do not pretend those details were provided.

## Traceability

Requirements retain their own IDs and statements in context.json. Task links reference those IDs and the original component/edge IDs. Keep source requirements distinct from implementation decisions. Record changes in decision-log.md and reconcile substantive scope changes with the user.


Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

# Handoff readiness

Status: engineering required. No deployment readiness is implied.

## Next action

Record included and excluded use cases before sizing or implementation.

## Evidence stages

- design: decisions_required
- infrastructure: not_implemented
- localValidation: not_attached
- cloudPlan: not_run
- staging: not_verified
- production: approval_not_attached

Generated documents and asserted decisions are design evidence only. Schema validation, mock tests, account plans and deployed-system tests require separate receipts tied to the exact configuration. This export does not ingest implementation evidence.

## Decisions and engineering gaps

### scope-boundary — priority 1

No explicit scope boundary is recorded.

Action: Record included and excluded use cases before sizing or implementation.

Tasks: TASK-SCOPE

### decision-cloud.region — priority 1

The deployment region is not independently confirmed.

Action: Record an explicit cloud.region decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### decision-data.country — priority 1

The data country and processing boundary is not independently confirmed.

Action: Record an explicit data.country decision. Proposed diagram placement is not approval.

Tasks: TASK-SCOPE

### requirement-proposed-61692d61727469636c652d6c6966656379636c65 — priority 1

REQ-006 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### requirement-proposed-61692d67726f756e6465642d616e7377657273 — priority 1

REQ-004 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273

### requirement-proposed-61692d6c6f636174696f6e2d7472616e73706172656e6379 — priority 1

REQ-008 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379

### requirement-proposed-61692d7075626c69632d66696c652d696e67657374696f6e — priority 1

REQ-007 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e67657374696f6e

### requirement-proposed-61692d7075626c69632d736f757263652d626f756e64617279 — priority 1

REQ-005 remains proposed.

Action: Confirm, revise or explicitly defer this requirement; do not promote it through generation.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279

### placement-6661712d617070 — priority 2

Website and grounded FAQ application: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6661712d617070

### placement-6661712d656469746f722d7369676e696e — priority 2

Editor sign-in: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6661712d656469746f722d7369676e696e

### placement-6661712d73746f7265 — priority 2

Published article collection: placement is unresolved.

Action: Verify service/model availability and record the chosen region without silently replacing proposed placement.

Tasks: TASK-RESOURCE-6661712d73746f7265

### review-52454c2d3030313a6661712d6d6f64656c — priority 2

No monitoring for model quality or drift.

Action: Add a monitoring block (quality, drift, cost) and decide who is alerted.

Tasks: TASK-SECURITY-DESIGN, TASK-SECURITY

### budget-target — priority 2

No budget constraint is recorded.

Action: Agree a budget or explicitly document that no budget limit was specified; do not invent a price target.

Tasks: TASK-COST-BASELINE

### cost-coverage — priority 2

7 cost worksheet gaps remain; unpriced resources are not free.

Action: Complete usage assumptions and dated regional price sources; reconcile all billable dimensions with the reviewed plan.

Tasks: TASK-COST-BASELINE, TASK-COST

### acceptance-61692d61727469636c652d6c6966656379636c65 — priority 2

REQ-006: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65

### acceptance-61692d67726f756e6465642d616e7377657273 — priority 2

REQ-004: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273

### acceptance-61692d6c6f636174696f6e2d7472616e73706172656e6379 — priority 2

REQ-008: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379

### acceptance-61692d7075626c69632d66696c652d696e67657374696f6e — priority 2

REQ-007: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e67657374696f6e

### acceptance-61692d7075626c69632d736f757263652d626f756e64617279 — priority 2

REQ-005: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279

### acceptance-7265712d3931363830663638 — priority 2

REQ-001: executable acceptance evidence is not supplied.

Action: Agree an observable pass/fail criterion, fixtures and evidence location.

Tasks: TASK-ACCEPTANCE-7265712d3931363830663638

### traceability-7265712d3931363830663638 — priority 2

REQ-001 has no component links.

Action: Map the requirement to relevant components or record why it is project-wide; do not guess the mapping.

Tasks: TASK-ACCEPTANCE-7265712d3931363830663638

### implementation-6661712d617070 — priority 2

Website and grounded FAQ application: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d617070

### implementation-6661712d656469746f722d7369676e696e — priority 2

Editor sign-in: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d656469746f722d7369676e696e

### implementation-6661712d6d6f64656c — priority 2

Grounded answer generation: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d6d6f64656c

### implementation-6661712d73746f7265 — priority 2

Published article collection: native infrastructure/application implementation is absent.

Action: Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.

Tasks: TASK-RESOURCE-6661712d73746f7265

### existing-6661712d61727469636c6573 — priority 2

Twenty public UTF-8 article files: existing-system contract and access are unverified.

Action: Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.

Tasks: TASK-RESOURCE-6661712d61727469636c6573

### existing-6661712d656469746f7273 — priority 2

Authorised article editors: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-6661712d656469746f7273

### existing-6661712d76697369746f7273 — priority 2

Public website visitors: existing-system contract and access are unverified.

Action: Preserve the external browser; no resource or import is required.

Tasks: TASK-RESOURCE-6661712d76697369746f7273


# Component and interface contracts

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

The board describes intent. These contracts must be completed before integrations are declared implemented.

## Component faq-visitors: Public website visitors

- Responsibility: Existing people using browsers, outside provisioning scope. Ask questions and receive cited answers or an explicit insufficient-evidence response. No visitor account proposed.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d76697369746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-app: Website and grounded FAQ application

- Responsibility: Proposed IBM Cloud Code Engine application hosting the website, question API and protected publishing interface. Editors upload public UTF-8 article files with stable article IDs, titles and canonical public URLs. Validate encoding, declared file-size limits and metadata before publishing; reject invalid uploads without changing the active collection. Recommend lexical passage ranking for twenty small articles, with no vector database, private connectors, unrestricted crawling, general web search or model tools. Send only relevant active passages and the question to inference. Validate cited article IDs and URLs, and return an insufficient-evidence response for unsupported answers or model failure. Treat article text as untrusted evidence. Publish immutable snapshots through a conditional active-manifest update; recheck the current revision before releasing answers and fail closed if current state cannot be checked. Rollbacks must not restore removed articles. Enforce editor authorization, scoped storage/inference identity, bounded requests and outputs, rate limiting and redacted operational logs. Visitor questions may contain personal information despite public source files; avoid retaining raw questions by default. Australia is preferred; verify runtime, logs and processing locations before selection, with no automatic overseas inference fallback. Application, permissions, abuse controls, recovery and integrations require implementation and tests; no supplied container image or generator implementation is asserted.
- Service: IBM Cloud Code Engine
- Provider / placement: ibm / Australia preferred; region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d617070
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-articles: Twenty public UTF-8 article files

- Responsibility: Existing twenty public help articles supplied as UTF-8 files, each under 30 KB, with no private content. Files remain client-owned and outside provisioning scope. Editors supply approved text with stable article IDs, titles and canonical public article URLs for citations. No source-system connector, private credentials or unrestricted crawling is needed. Original file storage location is not established.
- Service: Storage or existing data connector
- Provider / placement: tools / Existing location unknown
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d61727469636c6573
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Component faq-editors: Authorised article editors

- Responsibility: Existing people, outside provisioning scope. Proposed protected website interface lets authorised editors upload, replace and remove public article files and maintain their citation metadata. Public visitors receive no publishing permissions. Editor onboarding and operating ownership remain to be assigned.
- Service: Approval workflow
- Provider / placement: tools / Not applicable
- Ownership: Existing system; confirm access and ownership
- Implementation task: TASK-RESOURCE-6661712d656469746f7273
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

## Component faq-editor-signin: Editor sign-in

- Responsibility: Proposed IBM Cloud App ID instance for editor authentication only. The application separately enforces an explicit editor allowlist and validates token issuer, audience and expiry on every management request. Identity-provider setup, supported sign-in method, Australian service availability, identity-data location and secure onboarding require verification. Visitors do not use this service. Authentication and integration are engineering work, not verified capabilities of this composition.
- Service: IBM Cloud App ID
- Provider / placement: ibm / Australia preferred; region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d656469746f722d7369676e696e
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-store: Published article collection

- Responsibility: Proposed private IBM Cloud Object Storage bucket containing approved public UTF-8 article snapshots, canonical citation metadata and an authoritative active manifest. Only the application service identity accesses objects; editors publish through the application. Conditional manifest updates prevent concurrent publishing conflicts. Removed article IDs are excluded from retrieval and response validation; obsolete snapshots are cleaned up under a documented recovery policy, and recovery must not republish removed content. No separate vector store is proposed for twenty small articles. Australia is preferred for primary storage and recovery copies; verify bucket location, retention and recovery behavior before selection. Scoped application permissions, conditional-write behavior and recovery tests require engineering. This is not the standalone operator-storage generator contract.
- Service: IBM Cloud Object Storage
- Provider / placement: ibm / Australia preferred; region unconfirmed
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d73746f7265
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Component faq-model: Grounded answer generation

- Responsibility: Proposed IBM watsonx.ai Runtime inference service. Receives the visitor question and selected active public passages; produces a constrained draft with article IDs or an insufficient-evidence result. No private retrieval, browsing or action tools are provided. Application validates citations and abstains on missing evidence or model failure. Australia is preferred, but no Australian model endpoint or processing location has been verified. Australian application or storage placement does not establish inference residency. Verify the exact model, endpoint, processing and retention terms, entitlement and quotas before selection. Do not silently select an overseas endpoint or fallback; any required location exception needs a separate user decision. No model access or regional compatibility is claimed.
- Service: IBM watsonx.ai Runtime
- Provider / placement: ibm / Australia preferred; inference location unverified
- Ownership: Proposed component
- Implementation task: TASK-RESOURCE-6661712d6d6f64656c
- Still to specify: runtime/configuration, identities, input/output schemas, health checks, failure behavior and operational owner.

- Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

## Interfaces

### faq-visitor-app: faq-visitors → faq-app

- Drawn payload/purpose: HTTPS question → cited answer or “I don’t know”
- Contract task: TASK-CONTRACT-6661712d76697369746f722d617070
- Integration task: TASK-INTEGRATION-6661712d76697369746f722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-articles-editor: faq-articles → faq-editors

- Drawn payload/purpose: Approved UTF-8 files under 30 KB each; article IDs and canonical URLs
- Contract task: TASK-CONTRACT-6661712d61727469636c65732d656469746f72
- Integration task: TASK-INTEGRATION-6661712d61727469636c65732d656469746f72
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-app: faq-editors → faq-app

- Drawn payload/purpose: Authenticated HTTPS: upload, replace or remove; acknowledge active revision
- Contract task: TASK-CONTRACT-6661712d656469746f722d617070
- Integration task: TASK-INTEGRATION-6661712d656469746f722d617070
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-editor-signin-flow: faq-editors → faq-editor-signin

- Drawn payload/purpose: OIDC sign-in with PKCE — integration to implement
- Contract task: TASK-CONTRACT-6661712d656469746f722d7369676e696e2d666c6f77
- Integration task: TASK-INTEGRATION-6661712d656469746f722d7369676e696e2d666c6f77
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-signin-validation: faq-app → faq-editor-signin

- Drawn payload/purpose: OIDC issuer/JWKS validation; app enforces editor allowlist
- Contract task: TASK-CONTRACT-6661712d6170702d7369676e696e2d76616c69646174696f6e
- Integration task: TASK-INTEGRATION-6661712d6170702d7369676e696e2d76616c69646174696f6e
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-store: faq-app → faq-store

- Drawn payload/purpose: IAM-authenticated object reads and conditional publishing writes
- Contract task: TASK-CONTRACT-6661712d6170702d73746f7265
- Integration task: TASK-INTEGRATION-6661712d6170702d73746f7265
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.

### faq-app-model: faq-app → faq-model

- Drawn payload/purpose: IAM-authenticated inference: question and public passages → grounded draft
- Contract task: TASK-CONTRACT-6661712d6170702d6d6f64656c
- Integration task: TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Still to specify: protocol, schema/version, authentication, authorization, retries, timeouts, idempotency, error semantics, observability and test fixtures.


# Detailed implementation tasks

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review spec-kit/questions.md with the user. Ask the highest-impact unanswered question first; record answers and their provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. If starting fresh, agree the application language and runtime, then create application, infrastructure, tests and operations directories.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-6661712d76697369746f722d617070 — Define Public website visitors → Website and grounded FAQ application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-visitors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-visitor-app: HTTPS question → cited answer or “I don’t know”. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-visitor-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d61727469636c65732d656469746f72 — Define Twenty public UTF-8 article files → Authorised article editors

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-articles, faq-editors
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-articles-editor: Approved UTF-8 files under 30 KB each; article IDs and canonical URLs. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-articles-editor
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d656469746f722d617070 — Define Authorised article editors → Website and grounded FAQ application

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-editors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-editor-app: Authenticated HTTPS: upload, replace or remove; acknowledge active revision. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-editor-app
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d656469746f722d7369676e696e2d666c6f77 — Define Authorised article editors → Editor sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-editors, faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-editor-signin-flow: OIDC sign-in with PKCE — integration to implement. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-editor-signin-flow
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d7369676e696e2d76616c69646174696f6e — Define Website and grounded FAQ application → Editor sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-signin-validation: OIDC issuer/JWKS validation; app enforces editor allowlist. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-signin-validation
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d73746f7265 — Define Website and grounded FAQ application → Published article collection

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-store: IAM-authenticated object reads and conditional publishing writes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-store
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-6661712d6170702d6d6f64656c — Define Website and grounded FAQ application → Grounded answer generation

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection faq-app-model: IAM-authenticated inference: question and public passages → grounded draft. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge faq-app-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-6661712d76697369746f7273 — Integrate existing Public website visitors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d76697369746f722d617070
- Components: faq-visitors
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Responsibility from the board: Existing people using browsers, outside provisioning scope. Ask questions and receive cited answers or an explicit insufficient-evidence response. No visitor account proposed.
2. Verify Approval workflow on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-visitors
- Application/configuration and tests for Public website visitors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d617070 — Implement Website and grounded FAQ application

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d76697369746f722d617070, TASK-CONTRACT-6661712d656469746f722d617070, TASK-CONTRACT-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-CONTRACT-6661712d6170702d73746f7265, TASK-CONTRACT-6661712d6170702d6d6f64656c
- Components: faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-article-lifecycle, ai-public-file-ingestion, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud Code Engine application hosting the website, question API and protected publishing interface. Editors upload public UTF-8 article files with stable article IDs, titles and canonical public URLs. Validate encoding, declared file-size limits and metadata before publishing; reject invalid uploads without changing the active collection. Recommend lexical passage ranking for twenty small articles, with no vector database, private connectors, unrestricted crawling, general web search or model tools. Send only relevant active passages and the question to inference. Validate cited article IDs and URLs, and return an insufficient-evidence response for unsupported answers or model failure. Treat article text as untrusted evidence. Publish immutable snapshots through a conditional active-manifest update; recheck the current revision before releasing answers and fail closed if current state cannot be checked. Rollbacks must not restore removed articles. Enforce editor authorization, scoped storage/inference identity, bounded requests and outputs, rate limiting and redacted operational logs. Visitor questions may contain personal information despite public source files; avoid retaining raw questions by default. Australia is preferred; verify runtime, logs and processing locations before selection, with no automatic overseas inference fallback. Application, permissions, abuse controls, recovery and integrations require implementation and tests; no supplied container image or generator implementation is asserted.
2. Verify IBM Cloud Code Engine on ibm in Australia preferred; region unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Code Engine; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.; REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-app
- Application/configuration and tests for Website and grounded FAQ application

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d61727469636c6573 — Integrate existing Twenty public UTF-8 article files

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d61727469636c65732d656469746f72
- Components: faq-articles
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-source-boundary, ai-public-file-ingestion

### Implementation steps

1. Responsibility from the board: Existing twenty public help articles supplied as UTF-8 files, each under 30 KB, with no private content. Files remain client-owned and outside provisioning scope. Editors supply approved text with stable article IDs, titles and canonical public article URLs for citations. No source-system connector, private credentials or unrestricted crawling is needed. Original file storage location is not established.
2. Verify Storage or existing data connector on tools in Existing location unknown; check current provider documentation for region availability, quotas and supported integration methods.
3. Confirm owner and access contract. Reference the existing system; do not recreate or import it into Terraform without an agreed ownership plan.
4. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
5. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
6. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-articles
- Application/configuration and tests for Twenty public UTF-8 article files

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d656469746f7273 — Integrate existing Authorised article editors

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d61727469636c65732d656469746f72, TASK-CONTRACT-6661712d656469746f722d617070, TASK-CONTRACT-6661712d656469746f722d7369676e696e2d666c6f77
- Components: faq-editors
- Generated files: No implementation files generated yet
- Requirements: ai-article-lifecycle, ai-public-file-ingestion

### Implementation steps

1. Responsibility from the board: Existing people, outside provisioning scope. Proposed protected website interface lets authorised editors upload, replace and remove public article files and maintain their citation metadata. Public visitors receive no publishing permissions. Editor onboarding and operating ownership remain to be assigned.
2. Verify Approval workflow on tools in Not applicable; check current provider documentation for region availability, quotas and supported integration methods.
3. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
4. Preserve the external browser; no resource or import is required.
5. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
6. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
7. Cover linked requirements: REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.
8. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-editors
- Application/configuration and tests for Authorised article editors

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d656469746f722d7369676e696e — Implement Editor sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d656469746f722d7369676e696e2d666c6f77, TASK-CONTRACT-6661712d6170702d7369676e696e2d76616c69646174696f6e
- Components: faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-article-lifecycle, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed IBM Cloud App ID instance for editor authentication only. The application separately enforces an explicit editor allowlist and validates token issuer, audience and expiry on every management request. Identity-provider setup, supported sign-in method, Australian service availability, identity-data location and secure onboarding require verification. Visitors do not use this service. Authentication and integration are engineering work, not verified capabilities of this composition.
2. Verify IBM Cloud App ID on ibm in Australia preferred; region unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud App ID; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-editor-signin
- Application/configuration and tests for Editor sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d73746f7265 — Implement Published article collection

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170702d73746f7265
- Components: faq-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-article-lifecycle, ai-public-file-ingestion, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed private IBM Cloud Object Storage bucket containing approved public UTF-8 article snapshots, canonical citation metadata and an authoritative active manifest. Only the application service identity accesses objects; editors publish through the application. Conditional manifest updates prevent concurrent publishing conflicts. Removed article IDs are excluded from retrieval and response validation; obsolete snapshots are cleaned up under a documented recovery policy, and recovery must not republish removed content. No separate vector store is proposed for twenty small articles. Australia is preferred for primary storage and recovery copies; verify bucket location, retention and recovery behavior before selection. Scoped application permissions, conditional-write behavior and recovery tests require engineering. This is not the standalone operator-storage generator contract.
2. Verify IBM Cloud Object Storage on ibm in Australia preferred; region unconfirmed; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM Cloud Object Storage; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.; REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.; REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-store
- Application/configuration and tests for Published article collection

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6661712d6d6f64656c — Implement Grounded answer generation

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-6661712d6170702d6d6f64656c
- Components: faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers, ai-public-source-boundary, ai-location-transparency

### Implementation steps

1. Responsibility from the board: Proposed IBM watsonx.ai Runtime inference service. Receives the visitor question and selected active public passages; produces a constrained draft with article IDs or an insufficient-evidence result. No private retrieval, browsing or action tools are provided. Application validates citations and abstains on missing evidence or model failure. Australia is preferred, but no Australian model endpoint or processing location has been verified. Australian application or storage placement does not establish inference residency. Verify the exact model, endpoint, processing and retention terms, entitlement and quotas before selection. Do not silently select an overseas endpoint or fallback; any required location exception needs a separate user decision. No model access or regional compatibility is claimed.
2. Verify IBM watsonx.ai Runtime on ibm in Australia preferred; inference location unverified; check current provider documentation for region availability, quotas and supported integration methods.
3. Implement the provider-native infrastructure for IBM watsonx.ai Runtime; determine exact resource types and required application code. The export has not generated this implementation.
4. Confirm the exact ibm service, deployment mode, region and supported resource types using current primary documentation.
5. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
6. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.; REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.; REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component faq-model
- Application/configuration and tests for Grounded answer generation

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-6661712d76697369746f722d617070 — Wire Public website visitors to Website and grounded FAQ application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d76697369746f722d617070, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070
- Components: faq-visitors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-visitor-app carrying HTTPS question → cited answer or “I don’t know”, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-visitor-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d61727469636c65732d656469746f72 — Wire Twenty public UTF-8 article files to Authorised article editors

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d61727469636c65732d656469746f72, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d656469746f7273
- Components: faq-articles, faq-editors
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-articles-editor carrying Approved UTF-8 files under 30 KB each; article IDs and canonical URLs, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-articles-editor
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d656469746f722d617070 — Wire Authorised article editors to Website and grounded FAQ application

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d656469746f722d617070, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f7273
- Components: faq-editors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-editor-app carrying Authenticated HTTPS: upload, replace or remove; acknowledge active revision, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-editor-app
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d656469746f722d7369676e696e2d666c6f77 — Wire Authorised article editors to Editor sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d656469746f722d7369676e696e2d666c6f77, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d656469746f722d7369676e696e
- Components: faq-editors, faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-editor-signin-flow carrying OIDC sign-in with PKCE — integration to implement, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-editor-signin-flow
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d7369676e696e2d76616c69646174696f6e — Wire Website and grounded FAQ application to Editor sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f722d7369676e696e
- Components: faq-app, faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-signin-validation carrying OIDC issuer/JWKS validation; app enforces editor allowlist, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-signin-validation
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d73746f7265 — Wire Website and grounded FAQ application to Published article collection

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d73746f7265, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d73746f7265
- Components: faq-app, faq-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-store carrying IAM-authenticated object reads and conditional publishing writes, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-store
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-6661712d6170702d6d6f64656c — Wire Website and grounded FAQ application to Grounded answer generation

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-6661712d6170702d6d6f64656c, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d6d6f64656c
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Implement edge faq-app-model carrying IAM-authenticated inference: question and public passages → grounded draft, using its agreed contract.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation faq-app-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070 — Verify live Public website visitors → Website and grounded FAQ application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d76697369746f722d617070
- Components: faq-visitors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-visitor-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-visitor-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d61727469636c65732d656469746f72 — Verify live Twenty public UTF-8 article files → Authorised article editors

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d61727469636c65732d656469746f72
- Components: faq-articles, faq-editors
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-articles-editor with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-articles-editor

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d656469746f722d617070 — Verify live Authorised article editors → Website and grounded FAQ application

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d656469746f722d617070
- Components: faq-editors, faq-app
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-editor-app with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-editor-app

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d656469746f722d7369676e696e2d666c6f77 — Verify live Authorised article editors → Editor sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d656469746f722d7369676e696e2d666c6f77
- Components: faq-editors, faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-editor-signin-flow with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-editor-signin-flow

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e — Verify live Website and grounded FAQ application → Editor sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d7369676e696e2d76616c69646174696f6e
- Components: faq-app, faq-editor-signin
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-signin-validation with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-signin-validation

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265 — Verify live Website and grounded FAQ application → Published article collection

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d73746f7265
- Components: faq-app, faq-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-store with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-store

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c — Verify live Website and grounded FAQ application → Grounded answer generation

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Components: faq-app, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge faq-app-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence faq-app-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3931363830663638 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: req-91680f68

### Implementation steps

1. Basis: Not recorded; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273 — Verify REQ-004: The public assistant shall answer only when active published article passages support the answer, cite the supporting canonical articles, and explicitly state insufficient knowledge when support is missing; model failures shall not produce an unsupported answer.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-app, faq-store, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-grounded-answers

### Implementation steps

1. Basis: “answers questions from our twenty public help articles, cites the articles it used, and says when it does not know.” Existing citation requirement: req-91680f68.; rationale: Unsupported answers can mislead visitors; abstention and citation checks must be application behavior with evaluation evidence.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279 — Verify REQ-005: The assistant shall retrieve only explicitly published public help articles; private-source connectors, unrestricted browsing and model tools shall be excluded. Article content shall be treated as untrusted evidence rather than execution instructions.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d61727469636c65732d656469746f72, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-articles, faq-app, faq-store, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-source-boundary

### Implementation steps

1. Basis: “It must not answer from private sources.” Proposed application and published collection boundary.; rationale: An explicit source boundary prevents private information or unrestricted external content from entering answer retrieval.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65 — Verify REQ-006: Authorised editors shall be able to add, replace and remove articles through a protected interface. After a change is acknowledged, subsequent answers shall use the active collection revision and exclude removed or superseded content; in-flight answers shall recheck that revision before release. Public visitors shall have no publishing access.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d656469746f722d7369676e696e, TASK-RESOURCE-6661712d73746f7265, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d61727469636c65732d656469746f72, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d7369676e696e2d666c6f77, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-editors, faq-editor-signin, faq-app, faq-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-article-lifecycle

### Implementation steps

1. Basis: “We need to update and remove articles.” Editor authentication and atomic publishing are proposed engineering controls.; rationale: Stale retrieval and concurrent changes can cause removed or superseded content to remain in answers; public access must not grant publishing rights.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e67657374696f6e — Verify REQ-007: The publishing interface shall accept the twenty supplied public UTF-8 article files under 30 KB each, validate encoding and citation metadata before activation, and leave the active collection unchanged when validation fails.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d73746f7265, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d61727469636c65732d656469746f72, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d7369676e696e2d666c6f77, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-articles, faq-editors, faq-app, faq-store
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-public-file-ingestion

### Implementation steps

1. Basis: “Twenty public UTF-8 help articles under 30 KB each, supplied as files.” Existing faq-app and faq-store own publishing and the active collection.; rationale: File validation and atomic publication prevent malformed uploads or partial updates from corrupting the answering collection; these are proposed engineering controls.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-007

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379 — Verify REQ-008: The design shall prefer Australia and document verified locations and limitations for article storage, recovery copies, runtime, identity data, logs and model processing before deployment. Australia remains a preference rather than a confirmed region or strict residency policy; overseas inference shall require a separate decision.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d656469746f722d7369676e696e, TASK-RESOURCE-6661712d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d7369676e696e2d666c6f77, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: faq-app, faq-store, faq-editor-signin, faq-model
- Generated files: terraform/main.tf.json, terraform/generation-status.json
- Requirements: ai-location-transparency

### Implementation steps

1. Basis: “Australia is preferred; make model/data-location limitations explicit.”; rationale: Storage location alone does not determine model-processing or identity-data location; explicit verification prevents an unintended cross-border design.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-008

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d656469746f722d7369676e696e, TASK-RESOURCE-6661712d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-6661712d76697369746f722d617070, TASK-INTEGRATION-6661712d61727469636c65732d656469746f72, TASK-INTEGRATION-6661712d656469746f722d617070, TASK-INTEGRATION-6661712d656469746f722d7369676e696e2d666c6f77, TASK-INTEGRATION-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-6661712d6170702d73746f7265, TASK-INTEGRATION-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-6661712d76697369746f7273, TASK-RESOURCE-6661712d617070, TASK-RESOURCE-6661712d61727469636c6573, TASK-RESOURCE-6661712d656469746f7273, TASK-RESOURCE-6661712d656469746f722d7369676e696e, TASK-RESOURCE-6661712d73746f7265, TASK-RESOURCE-6661712d6d6f64656c, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d61727469636c65732d656469746f72, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d7369676e696e2d666c6f77, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3931363830663638, TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273, TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279, TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65, TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e67657374696f6e, TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379, TASK-INTEGRATION-LIVE-6661712d76697369746f722d617070, TASK-INTEGRATION-LIVE-6661712d61727469636c65732d656469746f72, TASK-INTEGRATION-LIVE-6661712d656469746f722d617070, TASK-INTEGRATION-LIVE-6661712d656469746f722d7369676e696e2d666c6f77, TASK-INTEGRATION-LIVE-6661712d6170702d7369676e696e2d76616c69646174696f6e, TASK-INTEGRATION-LIVE-6661712d6170702d73746f7265, TASK-INTEGRATION-LIVE-6661712d6170702d6d6f64656c
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Build a public website assistant that answers questions from our twenty public help articles, cites the articles it used, and says when it does not know. We need to update and remove articles. It must not answer from private sources. Use IBM Cloud. Recommend a coherent system and the engineering choices. Ask only a small material business question when needed; do not make me configure the system.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.


# Validation and acceptance plan

Snapshot 6eaf31d1-3206-4934-8bbd-9091b01e3bab · design r3 · generated 2026-11-09T17:58:05.823Z

1. Repository: install from a clean checkout; run formatter, linter, unit tests and dependency/secret checks.
2. Contracts: test each edge’s schema, authentication and failure behavior using sanitized fixtures.
3. Infrastructure: validate completed Terraform; run mock policy/gate tests separately from an authorized account-specific plan.
4. Requirements: execute every TASK-ACCEPTANCE task against its agreed criterion.
5. System: run TASK-E2E with representative data in an authorized environment; verify failures, recovery and denied access.
6. Operations: verify alerts, backup/restore, rollback and ownership.

For each check record command, tool versions, environment, timestamp, expected result, observed result, evidence file and limitations. Never turn skipped tests into passes. Exported diagrams and earlier proof-of-concept samples are not live integration evidence.

## Requirement traceability

- REQ-001 (req-91680f68) → TASK-ACCEPTANCE-7265712d3931363830663638; Recorded from user discussion
- REQ-004 (ai-grounded-answers) → TASK-ACCEPTANCE-61692d67726f756e6465642d616e7377657273; Proposed; needs confirmation
- REQ-005 (ai-public-source-boundary) → TASK-ACCEPTANCE-61692d7075626c69632d736f757263652d626f756e64617279; Proposed; needs confirmation
- REQ-006 (ai-article-lifecycle) → TASK-ACCEPTANCE-61692d61727469636c652d6c6966656379636c65; Proposed; needs confirmation
- REQ-007 (ai-public-file-ingestion) → TASK-ACCEPTANCE-61692d7075626c69632d66696c652d696e67657374696f6e; Proposed; needs confirmation
- REQ-008 (ai-location-transparency) → TASK-ACCEPTANCE-61692d6c6f636174696f6e2d7472616e73706172656e6379; Proposed; needs confirmation
