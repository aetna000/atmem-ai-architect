# Questions and assumptions to resolve

Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

- [acceptance-req-104d29bf] Agree a measurable acceptance check for REQ-001: Every answer shows its sources
- [acceptance-ai-permission-trimmed-answers] Agree a measurable acceptance check for REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.
- [acceptance-ai-source-change-sync] Agree a measurable acceptance check for REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.
- [acceptance-ai-audit-trail] Agree a measurable acceptance check for REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.
- [acceptance-example-australia] Agree a measurable acceptance check for Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

## Assumptions requiring verification

- [example-usage] Monthly sample: 100 users, 10,000 answers, 2,000 input and 1,000 output tokens per answer, 256 MiB ARM Lambda for 5 seconds; no free-tier credits.
- [example-cost-scope] Incremental AWS costs only. Browser and existing normalized local source fixtures carry no new AWS resource cost. SaaS licenses, tax, support plans and labor are outside this sample.

Also confirm target repository, runtime/toolchain, deployment account owner, access boundaries and release authorization. Ask questions conversationally, starting with those that block the next task.
