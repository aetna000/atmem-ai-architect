# Detailed implementation tasks

Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

All tasks start as todo. This is a project-specific draft work breakdown; confirm unresolved decisions before dependent work.

## TASK-SCOPE — Confirm implementation scope and unresolved decisions

- Phase: Clarify
- Status: todo
- Depends on: none
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Read START_HERE.md, specification.md, project.atmem-ai-architect.json and spec-kit/context.json; summarise the intended outcome in your own words.
2. Review the existing brief, decisions and spec-kit/questions.md. Reuse answers, recommend routine engineering choices, and consolidate only consequential unresolved business decisions into a small question; record provenance.
3. Resolve conflicts between requirements, diagram and decisions explicitly. Confirm proposed requirements before treating them as agreed constraints.
4. Record repository, language/runtime, cloud account owner, environment, country/region and authorization boundaries. Keep unknowns explicit.

### Deliverables

- Implementation scope and decision log
- Answered or explicitly deferred questions, with affected tasks identified

### Done when

- Confirmed scope and acceptance expectations are recorded.
- No proposed requirement or unselected cloud is silently promoted to an agreed decision.

## TASK-SETUP — Prepare repository, toolchain and CI

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/build-runtime.py, terraform/runtime-requirements.lock, terraform/BUILD.md, terraform/tests/storage-access.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Inspect the destination repository and its instructions before changing files. Preserve existing conventions and useful implementation.
2. Use the generated application runtime (python3.13) and hash-locked dependencies. From terraform/, run python3 build-runtime.py and python3 -m unittest discover -s app-tests -p '*_test.py'; preserve the generated source and record exact tool versions. Do not ask the user to choose a runtime already implemented here.
3. Pin dependencies and Terraform/provider versions; configure formatting, linting, unit tests and secret scanning in CI.
4. Document local setup and use non-secret example configuration. Store secrets in the chosen secret manager or approved environment.

### Deliverables

- Repository structure and setup guide
- CI configuration and dependency locks

### Done when

- A clean checkout can install dependencies and run the documented local checks.
- CI executes actual tests and does not require production credentials.

## TASK-COST-BASELINE — Agree usage assumptions and an initial cost envelope

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Record workload volumes, concurrency, document sizes, model token assumptions, retention and budget or explicitly deferred budget decisions.
2. Identify every proposed billable dimension, including networking, logs, backups, model/embedding requests, third-party licences and one-off delivery effort.
3. Use dated regional primary prices or quotes where available; show missing rates and currency boundaries without invented totals.

### Deliverables

- Initial cost model and assumptions
- Unpriced dimensions and budget decision

### Done when

- Unknown charges remain explicit.
- Capacity and cost assumptions are reviewed before service implementation.

## TASK-SECURITY-DESIGN — Define trust boundaries and deployment units

- Phase: Foundation
- Status: todo
- Depends on: TASK-SCOPE
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map user identity, source permissions, data classification and every storage/processing destination; identify authoritative claims and failure behavior.
2. Map logical components to physical deployment units and preserve accepted consolidation decisions; name implementation and operational owners.
3. Agree network/egress, secrets, encryption, retention and recovery requirements before implementation; record alternatives and unresolved risks.

### Deliverables

- Threat model and deployment-unit map
- Security decisions and unresolved risks

### Done when

- Each trust boundary and physical unit has an owner.
- Proposed controls are not marked implemented.

## TASK-INFRA-STATIC — Establish local infrastructure checks

- Phase: Foundation
- Status: todo
- Depends on: TASK-SETUP
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/build-runtime.py, terraform/runtime-requirements.lock, terraform/BUILD.md, terraform/tests/storage-access.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Select a tested Terraform version and provider constraints; initialize with backend disabled and retain the dependency lock file.
2. Configure format, schema, secret and policy checks in CI without cloud credentials; add mock tests for resource and gate invariants.
3. Run these checks on every implementation change; record command, version, configuration identity and limitations.

### Deliverables

- Local CI checks and lock file
- Static/mock validation evidence

### Done when

- Checks run locally without account access.
- Schema and mocks are reported independently from account plans and deployed tests.

## TASK-CONTRACT-652d757365722d776562 — Define Staff browser → Web app

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: user, web
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-user-web: HTTPS. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-user-web
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d7765622d636f676e69746f — Define Web app → User sign-in

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: web, cognito
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-web-cognito: sign-in (PKCE + MFA). Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-web-cognito
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d636f676e69746f2d617069 — Define User sign-in → RAG API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: cognito, api
- Generated files: terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-cognito-api: JWT authorizer. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-cognito-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d7765622d617069 — Define Web app → RAG API

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: web, api
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-web-api: question → cited answer. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-web-api
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d6170692d666e — Define RAG API → Keyword RAG function

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: api, rag-fn
- Generated files: terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-api-fn: invoke. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-api-fn
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d666e2d636174616c6f67 — Define Keyword RAG function → Document catalog

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: rag-fn, catalog
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-fn-catalog: ACL-filtered keyword read. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-fn-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d666e2d6d6f64656c — Define Keyword RAG function → Foundation model

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: rag-fn, model
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/tests/storage-access.tftest.hcl, terraform/deployment.tfvars.json.example, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-fn-model: Converse (grounded prompt). Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-fn-model
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d73702d636174616c6f67 — Define SharePoint (test server) → Document catalog

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: sp-src, catalog
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-sp-catalog: snapshot sync, ACLs, deletes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-sp-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-CONTRACT-652d63662d636174616c6f67 — Define Confluence (test server) → Document catalog

- Phase: Contracts
- Status: todo
- Depends on: TASK-SCOPE
- Components: cf-src, catalog
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Inspect connection e-cf-catalog: snapshot sync, ACLs, deletes. Determine whether it is an API call, event, batch job or data access path.
2. Specify request/event schema, response/output schema, ownership, authentication, authorization and data classification.
3. Agree timeout, retries, idempotency, failure behavior and observability; define versioning and compatibility rules.
4. Write an executable contract test and representative sanitized fixtures. Do not invent endpoint names, payload fields or service guarantees as settled facts.

### Deliverables

- Versioned contract for edge e-cf-catalog
- Contract tests and fixtures

### Done when

- Producer and consumer responsibilities and failure behavior are explicit.
- Contract tests cover valid input, invalid input and denied access.

## TASK-RESOURCE-75736572 — Integrate existing Staff browser

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d757365722d776562
- Components: user
- Generated files: terraform/deployment-ownership.json
- Requirements: project-wide

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Staff member's browser. This is a client reference, not a provisioned service.
3. Verify Approval workflow on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Preserve the external browser; no resource or import is required.
6. Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: No requirements are linked; confirm expected behavior and traceability.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component user
- Application/configuration and tests for Staff browser

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-776562 — Validate generated Web app

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d757365722d776562, TASK-CONTRACT-652d7765622d636f676e69746f, TASK-CONTRACT-652d7765622d617069
- Components: web
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json
- Requirements: req-104d29bf, example-australia

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Browser channel (required scope). It owns private S3 assets and CloudFront access control, uses authorization code with PKCE, and shows answers with citations.
3. Verify Amazon CloudFront on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
6. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
7. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-001: Every answer shows its sources; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component web
- Application/configuration and tests for Web app

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636f676e69746f — Validate generated User sign-in

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d7765622d636f676e69746f, TASK-CONTRACT-652d636f676e69746f2d617069
- Components: cognito
- Generated files: terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json
- Requirements: ai-permission-trimmed-answers, example-australia

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: User pool with admin-created users, required software-token MFA, an access-token scope, and catalog-backed identity and employee-region mapping. Users are onboarded with the operator tool.
3. Verify Amazon Cognito on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
6. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
7. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component cognito
- Application/configuration and tests for User sign-in

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-617069 — Validate generated RAG API

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d636f676e69746f2d617069, TASK-CONTRACT-652d7765622d617069, TASK-CONTRACT-652d6170692d666e
- Components: api
- Generated files: terraform/main.tf.json, terraform/deployment-ownership.json
- Requirements: req-104d29bf, ai-audit-trail, example-australia

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Authenticated, bounded HTTP API with a JWT browser route. There is no anonymous access. Access logs support the audit trail.
3. Verify Amazon API Gateway on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
6. Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
7. Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-001: Every answer shows its sources; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component api
- Application/configuration and tests for RAG API

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-7261672d666e — Validate generated Keyword RAG function

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d6170692d666e, TASK-CONTRACT-652d666e2d636174616c6f67, TASK-CONTRACT-652d666e2d6d6f64656c
- Components: rag-fn
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json
- Requirements: req-104d29bf, ai-permission-trimmed-answers, ai-source-change-sync, ai-audit-trail, example-australia

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Keyword retrieval with ACL and region filtering and revision rechecks, then a cited answer that is returned through the API. It owns its execution role, logs, version and alias. Unknown identities fail closed.
3. Verify AWS Lambda on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
6. Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
7. Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-001: Every answer shows its sources; REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component rag-fn
- Application/configuration and tests for Keyword RAG function

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-636174616c6f67 — Validate generated Document catalog

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d666e2d636174616c6f67, TASK-CONTRACT-652d73702d636174616c6f67, TASK-CONTRACT-652d63662d636174616c6f67
- Components: catalog
- Generated files: terraform/main.tf.json, terraform/deployment-ownership.json
- Requirements: ai-permission-trimmed-answers, ai-source-change-sync, example-australia

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Holds up to 100 small UTF-8 documents with explicit ACLs, revisions, tombstones for deletes and a sync checkpoint. Writes are conditional.
3. Verify Amazon DynamoDB on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
6. Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.
7. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
8. Cover linked requirements: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.
9. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component catalog
- Application/configuration and tests for Document catalog

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-6d6f64656c — Integrate existing Foundation model

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d666e2d6d6f64656c
- Components: model
- Generated files: terraform/tests/storage-access.tftest.hcl, terraform/deployment.tfvars.json.example, terraform/main.tf.json, terraform/deployment-ownership.json
- Requirements: req-104d29bf, example-australia

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Existing Bedrock direct model, selected by a required model-ID input. Model access, Converse support, quotas and regional availability are not yet verified.
3. Verify Amazon Bedrock on aws in ap-southeast-2; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
6. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
7. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-001: Every answer shows its sources; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component model
- Application/configuration and tests for Foundation model

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-73702d737263 — Integrate existing SharePoint (test server)

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d73702d636174616c6f67
- Components: sp-src
- Generated files: terraform/connectors/sources.json, terraform/deployment-ownership.json
- Requirements: ai-permission-trimmed-answers, ai-source-change-sync, ai-audit-trail

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Existing SharePoint, represented here by the approved local normalized source-contract test server. It provides snapshots, ACLs, updates and deletes. The native API and real-tenant compatibility are not verified.
3. Verify Storage or existing data connector on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
6. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
7. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component sp-src
- Application/configuration and tests for SharePoint (test server)

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-RESOURCE-63662d737263 — Integrate existing Confluence (test server)

- Phase: Components
- Status: todo
- Depends on: TASK-SETUP, TASK-SECURITY-DESIGN, TASK-COST-BASELINE, TASK-CONTRACT-652d63662d636174616c6f67
- Components: cf-src
- Generated files: terraform/connectors/sources.json, terraform/deployment-ownership.json
- Requirements: ai-permission-trimmed-answers, ai-source-change-sync, ai-audit-trail

### Implementation steps

1. Read terraform/deployment-ownership.json for this component. Preserve reference-only/observed state provenance separately from existing application source/new deployment. URNs are not native import IDs. No state import, move or removal is implemented or authorized by this inventory; adoption requires its own reviewed capability and separate authorization.
2. Responsibility from the board: Existing Confluence, represented here by the approved local normalized source-contract test server. The native API and real-tenant compatibility are not verified.
3. Verify Storage or existing data connector on tools in To be selected; check current provider documentation for region availability, quotas and supported integration methods.
4. Review the generated resources, runtime source and scoped permissions. Run shipped application/mock tests, then obtain account-plan and deployed acceptance evidence. Existing model bindings require reviewed regional model IDs.
5. Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
6. Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
7. Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.
8. Implement the component’s application behavior and configuration, including access checks, error handling, logging and health checks where applicable.
9. Cover linked requirements: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.
10. Add focused unit and contract tests. Record any unavailable dependency or remaining engineering gap instead of marking the task complete.

### Deliverables

- Infrastructure/reference implementation for component cf-src
- Application/configuration and tests for Confluence (test server)

### Done when

- Behavior matches confirmed requirements and agreed interface contracts.
- No placeholders, missing IAM rules or unimplemented handlers are presented as complete.
- Resource changes and existing-system boundaries are reviewed.

## TASK-INTEGRATION-652d757365722d776562 — Wire Staff browser to Web app

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d757365722d776562, TASK-RESOURCE-75736572, TASK-RESOURCE-776562
- Components: user, web
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated browser-https contract for edge e-user-web in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-user-web
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d7765622d636f676e69746f — Wire Web app to User sign-in

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d7765622d636f676e69746f, TASK-RESOURCE-776562, TASK-RESOURCE-636f676e69746f
- Components: web, cognito
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated oauth-pkce contract for edge e-web-cognito in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-web-cognito
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d636f676e69746f2d617069 — Wire User sign-in to RAG API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d636f676e69746f2d617069, TASK-RESOURCE-636f676e69746f, TASK-RESOURCE-617069
- Components: cognito, api
- Generated files: terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated jwt-authorizer contract for edge e-cognito-api in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-cognito-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d7765622d617069 — Wire Web app to RAG API

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d7765622d617069, TASK-RESOURCE-776562, TASK-RESOURCE-617069
- Components: web, api
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated web-rag-api contract for edge e-web-api in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-web-api
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d6170692d666e — Wire RAG API to Keyword RAG function

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d6170692d666e, TASK-RESOURCE-617069, TASK-RESOURCE-7261672d666e
- Components: api, rag-fn
- Generated files: terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated http-api-lambda contract for edge e-api-fn in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-api-fn
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d666e2d636174616c6f67 — Wire Keyword RAG function to Document catalog

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d666e2d636174616c6f67, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-636174616c6f67
- Components: rag-fn, catalog
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated lambda-catalog-read contract for edge e-fn-catalog in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-fn-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d666e2d6d6f64656c — Wire Keyword RAG function to Foundation model

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d666e2d6d6f64656c, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-6d6f64656c
- Components: rag-fn, model
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/tests/storage-access.tftest.hcl, terraform/deployment.tfvars.json.example, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated bedrock-converse contract for edge e-fn-model in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-fn-model
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d73702d636174616c6f67 — Wire SharePoint (test server) to Document catalog

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d73702d636174616c6f67, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-73702d737263
- Components: sp-src, catalog
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated source-catalog-sync contract for edge e-sp-catalog in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-sp-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-652d63662d636174616c6f67 — Wire Confluence (test server) to Document catalog

- Phase: Integration
- Status: todo
- Depends on: TASK-CONTRACT-652d63662d636174616c6f67, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-63662d737263
- Components: cf-src, catalog
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Review the generated source-catalog-sync contract for edge e-cf-catalog in spec-kit/interfaces.json and its linked emitted files. Supply only the documented destination inputs and verify the selected authorization boundary.
2. Configure least-privilege identities, network paths, secrets references and producer/consumer settings.
3. Implement and test the integration locally with sanitized fixtures and mocks, including timeout, retries, duplicate requests and denied access. Live verification follows authorized staging.
4. Record trace IDs, outputs and failure cases; distinguish mocked contract checks from tests against real services.

### Deliverables

- Integration implementation e-cf-catalog
- Local contract/mock test evidence

### Done when

- Local behavior matches the contract; live verification remains pending.
- Failure paths are tested with fixtures and recoverable state.

## TASK-INTEGRATION-LIVE-652d757365722d776562 — Verify live Staff browser → Web app

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d757365722d776562
- Components: user, web
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-user-web with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-user-web

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d7765622d636f676e69746f — Verify live Web app → User sign-in

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d7765622d636f676e69746f
- Components: web, cognito
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-web-cognito with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-web-cognito

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069 — Verify live User sign-in → RAG API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d636f676e69746f2d617069
- Components: cognito, api
- Generated files: terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-cognito-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-cognito-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d7765622d617069 — Verify live Web app → RAG API

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d7765622d617069
- Components: web, api
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-web-api with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-web-api

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d6170692d666e — Verify live RAG API → Keyword RAG function

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d6170692d666e
- Components: api, rag-fn
- Generated files: terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-api-fn with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-api-fn

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67 — Verify live Keyword RAG function → Document catalog

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d666e2d636174616c6f67
- Components: rag-fn, catalog
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-fn-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-fn-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c — Verify live Keyword RAG function → Foundation model

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d666e2d6d6f64656c
- Components: rag-fn, model
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/tests/storage-access.tftest.hcl, terraform/deployment.tfvars.json.example, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-fn-model with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-fn-model

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d73702d636174616c6f67 — Verify live SharePoint (test server) → Document catalog

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d73702d636174616c6f67
- Components: sp-src, catalog
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-sp-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-sp-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-INTEGRATION-LIVE-652d63662d636174616c6f67 — Verify live Confluence (test server) → Document catalog

- Phase: Staging verification
- Status: todo
- Depends on: TASK-STAGING, TASK-INTEGRATION-652d63662d636174616c6f67
- Components: cf-src, catalog
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, spec-kit/interfaces.json
- Requirements: project-wide

### Implementation steps

1. Exercise edge e-cf-catalog with approved staging services and representative sanitized data.
2. Verify identity, permission revocation, denied access, timeouts, duplicate events and recovery against the agreed contract.
3. Record deployed versions, trace IDs, commands and results; unavailable account/source access remains blocked.

### Deliverables

- Live integration evidence e-cf-catalog

### Done when

- The authorized staging integration has observed results.
- Mock results are not substituted for live evidence.

## TASK-ACCEPTANCE-7265712d3130346432396266 — Verify REQ-001: Every answer shows its sources

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-776562, TASK-RESOURCE-617069, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-6d6f64656c, TASK-INTEGRATION-LIVE-652d757365722d776562, TASK-INTEGRATION-LIVE-652d7765622d636f676e69746f, TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069, TASK-INTEGRATION-LIVE-652d7765622d617069, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c
- Components: web, api, rag-fn, model
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/tests/storage-access.tftest.hcl, terraform/deployment.tfvars.json.example
- Requirements: req-104d29bf

### Implementation steps

1. Basis:  Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-001

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d7065726d697373696f6e2d7472696d6d65642d616e7377657273 — Verify REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-636f676e69746f, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-73702d737263, TASK-RESOURCE-63662d737263, TASK-INTEGRATION-LIVE-652d7765622d636f676e69746f, TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c, TASK-INTEGRATION-LIVE-652d73702d636174616c6f67, TASK-INTEGRATION-LIVE-652d63662d636174616c6f67
- Components: catalog, rag-fn, sp-src, cf-src, cognito
- Generated files: terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/connectors/sources.json, terraform/web/block_776562/config.json
- Requirements: ai-permission-trimmed-answers

### Implementation steps

1. Basis: User: "Preserve source permissions, updates and deletes." Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.; rationale: Without this, the assistant could reveal restricted content. The test servers do not prove native group expansion or inherited permissions, so production stays blocked until those are verified.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-004

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d73796e63 — Verify REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-73702d737263, TASK-RESOURCE-63662d737263, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c, TASK-INTEGRATION-LIVE-652d73702d636174616c6f67, TASK-INTEGRATION-LIVE-652d63662d636174616c6f67
- Components: sp-src, cf-src, catalog, rag-fn
- Generated files: terraform/connectors/sources.json, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py
- Requirements: ai-source-change-sync

### Implementation steps

1. Basis: User: "Preserve source permissions, updates and deletes" and "include recovery and audit behavior". Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.; rationale: Stale or deleted documents could otherwise be cited. The checkpoint lets an interrupted sync resume without losing changes.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-005

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-61692d61756469742d747261696c — Verify REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-617069, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-73702d737263, TASK-RESOURCE-63662d737263, TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069, TASK-INTEGRATION-LIVE-652d7765622d617069, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c, TASK-INTEGRATION-LIVE-652d73702d636174616c6f67, TASK-INTEGRATION-LIVE-652d63662d636174616c6f67
- Components: rag-fn, api, sp-src, cf-src
- Generated files: terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/connectors/sources.json
- Requirements: ai-audit-trail

### Implementation steps

1. Basis: User: "include recovery and audit behavior". Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.; rationale: An audit trail lets us show which sources supported an answer and investigate access questions. The retention period is still unknown.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for REQ-006

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-ACCEPTANCE-6578616d706c652d6175737472616c6961 — Verify Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

- Phase: Acceptance
- Status: todo
- Depends on: TASK-SCOPE, TASK-STAGING, TASK-RESOURCE-776562, TASK-RESOURCE-636f676e69746f, TASK-RESOURCE-617069, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-6d6f64656c, TASK-INTEGRATION-LIVE-652d757365722d776562, TASK-INTEGRATION-LIVE-652d7765622d636f676e69746f, TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069, TASK-INTEGRATION-LIVE-652d7765622d617069, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c, TASK-INTEGRATION-LIVE-652d73702d636174616c6f67, TASK-INTEGRATION-LIVE-652d63662d636174616c6f67
- Components: web, cognito, api, rag-fn, catalog, model
- Generated files: terraform/web/block_776562/index.html, terraform/web/block_776562/app.css, terraform/web/block_776562/app.js, terraform/web/block_776562/config.json, terraform/main.tf.json, terraform/deployment-ownership.json, terraform/app-tests/connector_contract_test.py, terraform/handlers/block_7261672d666e.py, terraform/app-tests/block_7261672d666e_test.py, terraform/handlers/block_7261672d666e/bounded_rag.py, terraform/handlers/block_7261672d666e/rag_aws_adapter.py, terraform/build-runtime.py, terraform/tests/storage-access.tftest.hcl, terraform/deployment.tfvars.json.example
- Requirements: example-australia

### Implementation steps

1. Basis: Prepared-example author default; destination account/residency verification remains required.; rationale: Clarify with the user.
2. Agree an observable pass/fail criterion with the user before declaring this requirement verified.
3. Create repeatable positive and negative scenarios and record the command, environment, result and evidence path.
4. For performance, security or residency claims, use suitable measurements or configuration evidence; a diagram or mock does not prove compliance.

### Deliverables

- Acceptance test and evidence for Requirement

### Done when

- The agreed criterion has a reproducible result.
- Unconfirmed requirements and unavailable tests remain explicitly unresolved.

## TASK-INFRA-VALIDATION — Complete and validate the Terraform deployment

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-STATIC, TASK-RESOURCE-75736572, TASK-RESOURCE-776562, TASK-RESOURCE-636f676e69746f, TASK-RESOURCE-617069, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-6d6f64656c, TASK-RESOURCE-73702d737263, TASK-RESOURCE-63662d737263, TASK-INTEGRATION-652d757365722d776562, TASK-INTEGRATION-652d7765622d636f676e69746f, TASK-INTEGRATION-652d636f676e69746f2d617069, TASK-INTEGRATION-652d7765622d617069, TASK-INTEGRATION-652d6170692d666e, TASK-INTEGRATION-652d666e2d636174616c6f67, TASK-INTEGRATION-652d666e2d6d6f64656c, TASK-INTEGRATION-652d73702d636174616c6f67, TASK-INTEGRATION-652d63662d636174616c6f67
- Components: project-wide
- Generated files: terraform/main.tf.json, terraform/.terraform.lock.hcl, terraform/build-runtime.py, terraform/runtime-requirements.lock, terraform/BUILD.md, terraform/tests/storage-access.tftest.hcl
- Requirements: project-wide

### Implementation steps

1. Review terraform/resource-schedule.json and every coverage gap. Implement missing resources and integrations before clearing any unfinished-work gate.
2. Run terraform init -backend=false and terraform validate; retain the provider lock file and capture diagnostics.
3. Add Terraform tests for required policy/configuration invariants and for the review gate. Mock-provider tests must be labelled as mocked.
4. Implement remote state configuration, locking, environment boundaries and secret references; document state bootstrap separately. Do not access the account in this local validation task.
5. Capture local checks against the complete generated configuration; leave account-specific planning and deployment to the explicitly authorized tasks.

### Deliverables

- Completed infrastructure implementation
- Validation logs and mock-test results; no account-plan claim

### Done when

- Every intended resource and connection has implementation or an explicitly accepted exclusion.
- Schema checks pass; actual account-plan status is reported independently.
- No apply is executed merely because a ZIP was handed over.

## TASK-CLOUD-PLAN — Review an authorized account-specific infrastructure plan

- Phase: Planning
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY-DESIGN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Obtain explicit authorization for target-account access; confirm account, region, deployment role and separate state bootstrap permissions.
2. Run a real Terraform plan; record tool/provider versions, configuration identity, account, region and protected plan artifact.
3. Review replacements, deletions, IAM, regional service/model availability and quotas; do not apply or treat a static check as a cloud plan.

### Deliverables

- Reviewed account-specific plan and access record

### Done when

- Plan corresponds to the intended account and exact configuration.
- Unavailable access remains blocked; no deployment is performed by this task.

## TASK-STAGING — Approve and deploy the staging candidate

- Phase: Staging
- Status: todo
- Depends on: TASK-CLOUD-PLAN, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Present the reviewed plan, scope, security decisions, cost and rollback procedure for explicit staging deployment authorization.
2. Apply only the approved current plan through the agreed process; verify artifact versions, service health and endpoint access.
3. Record actual deployed resources and smoke-check results; failed provisioning or missing source access blocks dependent live tests.

### Deliverables

- Staging approval and deployment receipt
- Staging health and rollback evidence

### Done when

- Staging deployment is explicitly authorized and observed.
- Production authorization is separate; an exported sketch is not deployment evidence.

## TASK-SECURITY — Review security, resilience and operational readiness

- Phase: Verification
- Status: todo
- Depends on: TASK-SECURITY-DESIGN, TASK-STAGING, TASK-RESOURCE-75736572, TASK-RESOURCE-776562, TASK-RESOURCE-636f676e69746f, TASK-RESOURCE-617069, TASK-RESOURCE-7261672d666e, TASK-RESOURCE-636174616c6f67, TASK-RESOURCE-6d6f64656c, TASK-RESOURCE-73702d737263, TASK-RESOURCE-63662d737263, TASK-INTEGRATION-LIVE-652d757365722d776562, TASK-INTEGRATION-LIVE-652d7765622d636f676e69746f, TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069, TASK-INTEGRATION-LIVE-652d7765622d617069, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c, TASK-INTEGRATION-LIVE-652d73702d636174616c6f67, TASK-INTEGRATION-LIVE-652d63662d636174616c6f67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Map trust boundaries, identities and sensitive data flows from the diagram. Verify least privilege, encryption, data residency and audit logging.
2. Implement backup/restore, retention/deletion and recovery behavior according to confirmed requirements; test restoration and failure handling.
3. Define service health metrics, alerts, runbooks and incident ownership. Verify logging does not expose secrets or sensitive user content.
4. Record unresolved security risks and obtain decisions from their owners.

### Deliverables

- Security review and remediation evidence
- Operational runbook and recovery test evidence

### Done when

- Confirmed security and resilience requirements have evidence.
- Open risks have owners and are not silently marked resolved.

## TASK-COST — Reconcile implementation and costs

- Phase: Verification
- Status: todo
- Depends on: TASK-CLOUD-PLAN
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Reconcile the resource schedule, actual Terraform plan and estimate.json. Identify every billable service and usage dimension.
2. Refresh official pricing or quotes for the selected region, currency, model and capacity; record dates and sources.
3. Separate recurring cloud cost, one-off implementation effort, missing rates and excluded support costs. Agree budgets and alerts.

### Deliverables

- Updated resource/cost inventory and cost assumptions

### Done when

- No unpriced component is counted as free.
- Cost ranges and assumptions match the intended deployment.

## TASK-E2E — Prove the complete user journey

- Phase: Verification
- Status: todo
- Depends on: TASK-INFRA-VALIDATION, TASK-SECURITY, TASK-ACCEPTANCE-7265712d3130346432396266, TASK-ACCEPTANCE-61692d7065726d697373696f6e2d7472696d6d65642d616e7377657273, TASK-ACCEPTANCE-61692d736f757263652d6368616e67652d73796e63, TASK-ACCEPTANCE-61692d61756469742d747261696c, TASK-ACCEPTANCE-6578616d706c652d6175737472616c6961, TASK-INTEGRATION-LIVE-652d757365722d776562, TASK-INTEGRATION-LIVE-652d7765622d636f676e69746f, TASK-INTEGRATION-LIVE-652d636f676e69746f2d617069, TASK-INTEGRATION-LIVE-652d7765622d617069, TASK-INTEGRATION-LIVE-652d6170692d666e, TASK-INTEGRATION-LIVE-652d666e2d636174616c6f67, TASK-INTEGRATION-LIVE-652d666e2d6d6f64656c, TASK-INTEGRATION-LIVE-652d73702d636174616c6f67, TASK-INTEGRATION-LIVE-652d63662d636174616c6f67
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Exercise the intended outcome: Design an AWS knowledge assistant that reads approved documents from existing SharePoint and Confluence systems and provides cited answers through a web application, with Teams as a later channel. Preserve source permissions, updates and deletes. For this stage use the approved local normalized source-contract test servers and bounded keyword retrieval. Keep the requested web application as required scope; an HTTP API alone does not complete that channel. Treat those existing systems as external dependencies; include recovery and audit behavior without claiming native vendor API or real tenant compatibility. Use AWS for this synthetic qualification design. Propose Sydney as a candidate region, but do not record that as an approved deployment region. Draw the architecture and identify the next missing decision. This is a test design, not an instruction to deploy.
2. Use representative sanitized data and authorized non-production services. Test normal operation, malformed input, denied access and dependency failures.
3. Run the full acceptance suite and report actual versus expected results, including latency/capacity only where targets were agreed.
4. Capture reproducible test commands and evidence. Keep failed, skipped and mocked scenarios distinguishable.

### Deliverables

- End-to-end tests and results
- Requirement-to-test traceability

### Done when

- Each confirmed requirement is covered or has an explicitly accepted unresolved gap.
- No mock-only result is reported as proof of a working cloud deployment.

## TASK-RELEASE — Prepare an approved release and operational handover

- Phase: Handover
- Status: todo
- Depends on: TASK-E2E, TASK-COST
- Components: project-wide
- Generated files: No implementation files generated yet
- Requirements: project-wide

### Implementation steps

1. Prepare deployment, migration, rollback and recovery procedures; identify owners and required account access.
2. Present the reviewed plan, test evidence, unresolved risks and cost estimate for deployment approval.
3. Only after explicit approval, deploy through the agreed process, run smoke checks, and document rollback readiness.
4. Record released versions, operational ownership and next tasks. Update progress.json and the decision log with evidence.

### Deliverables

- Release checklist and approval record
- Deployment/rollback runbook and final handover

### Done when

- Release approval and access are explicit.
- Deployment status reflects observed outcomes; pending access is reported as blocked.
