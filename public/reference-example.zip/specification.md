Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

# AI knowledge assistant — complete example — solution specification

## Problem and intended outcome

Design an AWS knowledge assistant that reads approved documents from existing SharePoint and Confluence systems and provides cited answers through a web application, with Teams as a later channel. Preserve source permissions, updates and deletes. For this stage use the approved local normalized source-contract test servers and bounded keyword retrieval. Keep the requested web application as required scope; an HTTP API alone does not complete that channel. Treat those existing systems as external dependencies; include recovery and audit behavior without claiming native vendor API or real tenant compatibility. Use AWS for this synthetic qualification design. Propose Sydney as a candidate region, but do not record that as an approved deployment region. Draw the architecture and identify the next missing decision. This is a test design, not an instruction to deploy.

## Scope

- Signed-in browser answers with citations and source permissions: Pursue — Implemented by the generated web/API/catalog/model path; local tests cover cited answers and authorization.
- Local normalized source snapshots, updates and deletes: Pursue — The bundled contract fixtures qualify the normalized interface. Real Microsoft/Atlassian tenants are separate destination integration work.
- Native SharePoint and Confluence tenant adapters: Park — The original example explicitly uses approved normalized local test servers. No native tenant or permissions compatibility is claimed.
- Microsoft Teams channel: Park — Retained from the original deferred-channel note; not part of this example.

## Requirements and acceptance criteria

- [REQ-001] Every answer shows its sources (should, open); target: acceptance target needed; linked blocks: web, api, rag-fn, model

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.

Basis:  Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.
- [REQ-004] Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed. (must, open); target: acceptance target needed; linked blocks: catalog, rag-fn, sp-src, cf-src, cognito

Design explanation: Without this, the assistant could reveal restricted content. The test servers do not prove native group expansion or inherited permissions, so production stays blocked until those are verified.

Basis: User: "Preserve source permissions, updates and deletes." Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.
- [REQ-005] Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned. (must, open); target: acceptance target needed; linked blocks: sp-src, cf-src, catalog, rag-fn

Design explanation: Stale or deleted documents could otherwise be cited. The checkpoint lets an interrupted sync resume without losing changes.

Basis: User: "Preserve source permissions, updates and deletes" and "include recovery and audit behavior". Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.
- [REQ-006] Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed. (should, open); target: acceptance target needed; linked blocks: rag-fn, api, sp-src, cf-src

Design explanation: An audit trail lets us show which sources supported an answer and investigate access questions. The retention period is still unknown.

Basis: User: "include recovery and audit behavior". Confirmed by the prepared-example author for the bounded local source-contract sample; not a client approval.
- [Requirement] Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally. (must, open); target: acceptance target needed; linked blocks: web, cognito, api, rag-fn, catalog, model

Design explanation: Source references make an answer inspectable: the reader can check the supporting material, its relevance and whether it is current. The answer path must retain the link between retrieved evidence and the final response; an unsupported answer should be distinguishable from one backed by documents.

Basis: Prepared-example author default; destination account/residency verification remains required.

## How the system works

The current design contains 9 components and 9 connections. 4 components are existing systems. The descriptions below follow the actual board; implementation guidance is identified separately from recorded behavior.

### Interaction 1: Staff browser → Web app

HTTPS

Integration contract: browser-https.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 2: Web app → User sign-in

sign-in (PKCE + MFA)

Integration contract: oauth-pkce.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 3: User sign-in → RAG API

JWT authorizer

Integration contract: jwt-authorizer.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 4: Web app → RAG API

question → cited answer

Integration contract: web-rag-api.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 5: RAG API → Keyword RAG function

invoke

Integration contract: http-api-lambda.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 6: Keyword RAG function → Document catalog

ACL-filtered keyword read

Integration contract: lambda-catalog-read.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 7: Keyword RAG function → Foundation model

Converse (grounded prompt)

Integration contract: bedrock-converse.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 8: SharePoint (test server) → Document catalog

snapshot sync, ACLs, deletes

Integration contract: source-catalog-sync.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

### Interaction 9: Confluence (test server) → Document catalog

snapshot sync, ACLs, deletes

Integration contract: source-catalog-sync.

Proposed verification: Verify the expected exchange, reject malformed or unauthorized input, and exercise interruption and recovery. Retry and duplicate-handling behavior must match the operation; it cannot be inferred from an arrow.

## Component responsibilities and design rationale

### Staff browser

Approval workflow · tools · region: To be selected · classification: Internal

Staff member's browser. This is a client reference, not a provisioned service.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Staff browser → Web app: HTTPS (integration: browser-https)

Requirement traceability: No requirement has been explicitly linked to this component.

Implementation status: External browser — no infrastructure to provision; connection behavior still requires validation

Implementation considerations (guidance):
- Preserve the external browser; no resource or import is required.
- Define and test its HTTPS/application interactions, including denied access and unavailable service behavior.

### Web app

Amazon CloudFront · aws · region: ap-southeast-2 · classification: Internal

Browser channel (required scope). It owns private S3 assets and CloudFront access control, uses authorization code with PKCE, and shows answers with citations.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Staff browser → Web app: HTTPS (integration: browser-https)

Outputs: Web app → User sign-in: sign-in (PKCE + MFA) (integration: oauth-pkce); Web app → RAG API: question → cited answer (integration: web-rag-api)

Requirement traceability: REQ-001: Every answer shows its sources; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

Implementation status: Private web hosting and Cognito authorization-code/PKCE sign-in generated

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### User sign-in

Amazon Cognito · aws · region: ap-southeast-2 · classification: Confidential

User pool with admin-created users, required software-token MFA, an access-token scope, and catalog-backed identity and employee-region mapping. Users are onboarded with the operator tool.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Web app → User sign-in: sign-in (PKCE + MFA) (integration: oauth-pkce)

Outputs: User sign-in → RAG API: JWT authorizer (integration: jwt-authorizer)

Requirement traceability: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

Implementation status: Private web hosting and Cognito authorization-code/PKCE sign-in generated

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### RAG API

Amazon API Gateway · aws · region: ap-southeast-2 · classification: Internal

Authenticated, bounded HTTP API with a JWT browser route. There is no anonymous access. Access logs support the audit trail.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: User sign-in → RAG API: JWT authorizer (integration: jwt-authorizer); Web app → RAG API: question → cited answer (integration: web-rag-api)

Outputs: RAG API → Keyword RAG function: invoke (integration: http-api-lambda)

Requirement traceability: REQ-001: Every answer shows its sources; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

Implementation status: Bounded IAM-authenticated RAG implementation generated

Implementation considerations (guidance):
- Confirm the exact aws service, deployment mode, region and supported resource types using current primary documentation.
- Specify runtime/artifact, identity, network paths, secrets, capacity, health checks and operational owner; resolve whether this is infrastructure or a responsibility within another application.
- Document service-specific failure modes, retention/recovery and acceptance tests; do not substitute a similarly named service or another provider.

### Keyword RAG function

AWS Lambda · aws · region: ap-southeast-2 · classification: Confidential

Keyword retrieval with ACL and region filtering and revision rechecks, then a cited answer that is returned through the API. It owns its execution role, logs, version and alias. Unknown identities fail closed.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: RAG API → Keyword RAG function: invoke (integration: http-api-lambda)

Outputs: Keyword RAG function → Document catalog: ACL-filtered keyword read (integration: lambda-catalog-read); Keyword RAG function → Foundation model: Converse (grounded prompt) (integration: bedrock-converse)

Requirement traceability: REQ-001: Every answer shows its sources; REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

Implementation status: Bounded IAM-authenticated RAG implementation generated

Implementation considerations (guidance):
- Specify runtime, entry point, immutable package/image, memory, timeout and concurrency; identify the trigger and its invocation permissions.
- Define execution IAM, network egress, secret references and log retention; implement retries, idempotency, checkpoints and dead-letter handling where asynchronous.
- Test representative payload sizes, duplicate events, throttling and downstream failures; measure cold and warm execution where latency matters.

### Document catalog

Amazon DynamoDB · aws · region: ap-southeast-2 · classification: Confidential

Holds up to 100 small UTF-8 documents with explicit ACLs, revisions, tombstones for deletes and a sync checkpoint. Writes are conditional.

Proposed component: its responsibility is part of the current design, with implementation and deployment still subject to validation.

Inputs: Keyword RAG function → Document catalog: ACL-filtered keyword read (integration: lambda-catalog-read); SharePoint (test server) → Document catalog: snapshot sync, ACLs, deletes (integration: source-catalog-sync); Confluence (test server) → Document catalog: snapshot sync, ACLs, deletes (integration: source-catalog-sync)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

Implementation status: Bounded IAM-authenticated RAG implementation generated

Implementation considerations (guidance):
- Define partition/sort keys and access patterns, capacity mode, indexes, encryption, point-in-time recovery and deletion protection.
- Specify conditional writes, idempotency, TTL semantics and retention; test contention, throttling and restoration.

### Foundation model

Amazon Bedrock · aws · region: ap-southeast-2 · classification: Confidential

Existing Bedrock direct model, selected by a required model-ID input. Model access, Converse support, quotas and regional availability are not yet verified.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: Keyword RAG function → Foundation model: Converse (grounded prompt) (integration: bedrock-converse)

Outputs: No outgoing connection is drawn.

Requirement traceability: REQ-001: Every answer shows its sources; Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.

Implementation status: Bounded IAM-authenticated RAG implementation generated

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### SharePoint (test server)

Storage or existing data connector · tools · region: To be selected · classification: Confidential

Existing SharePoint, represented here by the approved local normalized source-contract test server. It provides snapshots, ACLs, updates and deletes. The native API and real-tenant compatibility are not verified.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: SharePoint (test server) → Document catalog: snapshot sync, ACLs, deletes (integration: source-catalog-sync)

Requirement traceability: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.

Implementation status: Local source-contract runner generated; native vendor integration unverified

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

### Confluence (test server)

Storage or existing data connector · tools · region: To be selected · classification: Confidential

Existing Confluence, represented here by the approved local normalized source-contract test server. The native API and real-tenant compatibility are not verified.

Existing system: integrate with its owner and access contract; the design does not authorize replacing it.

Inputs: No incoming connection is drawn.

Outputs: Confluence (test server) → Document catalog: snapshot sync, ACLs, deletes (integration: source-catalog-sync)

Requirement traceability: REQ-004: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.; REQ-005: Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned.; REQ-006: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.

Implementation status: Local source-contract runner generated; native vendor integration unverified

Implementation considerations (guidance):
- Identify system owner, tenant/location, supported APIs and permitted read scopes; document a reference contract instead of recreating the system.
- Specify identity mapping, source permissions, pagination/rate limits, update/delete events and maximum synchronization lag.
- Define credential rotation, outages and recovery; test revoked access and unavailable sources using approved fixtures before live integration.

## Architecture

```mermaid
flowchart LR
  n0["Staff browser<br/>Tools & data"]
  n1["Web app<br/>AWS"]
  n2["User sign-in<br/>AWS"]
  n3["RAG API<br/>AWS"]
  n4["Keyword RAG function<br/>AWS"]
  n5["Document catalog<br/>AWS"]
  n6["Foundation model<br/>AWS"]
  n7["SharePoint (test server)<br/>Tools & data"]
  n8["Confluence (test server)<br/>Tools & data"]
  n9["Later: Microsoft Teams channel<br/>Tools & data"]
  n0 -->|HTTPS| n1
  n1 -->|sign-in (PKCE + MFA)| n2
  n2 -->|JWT authorizer| n3
  n1 -->|question → cited answer| n3
  n3 -->|invoke| n4
  n4 -->|ACL-filtered keyword read| n5
  n4 -->|Converse (grounded prompt)| n6
  n7 -->|snapshot sync, ACLs, deletes| n5
  n8 -->|snapshot sync, ACLs, deletes| n5
```

## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| user | Staff browser | tools | Approval workflow | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| web | Web app | aws | Amazon CloudFront | ap-southeast-2 | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| cognito | User sign-in | aws | Amazon Cognito | ap-southeast-2 | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| api | RAG API | aws | Amazon API Gateway | ap-southeast-2 | Proposed | Bounded IAM-authenticated RAG implementation generated |
| rag-fn | Keyword RAG function | aws | AWS Lambda | ap-southeast-2 | Proposed | Bounded IAM-authenticated RAG implementation generated |
| catalog | Document catalog | aws | Amazon DynamoDB | ap-southeast-2 | Proposed | Bounded IAM-authenticated RAG implementation generated |
| model | Foundation model | aws | Amazon Bedrock | ap-southeast-2 | Existing | Bounded IAM-authenticated RAG implementation generated |
| sp-src | SharePoint (test server) | tools | Storage or existing data connector | To be selected | Existing | Local source-contract runner generated; native vendor integration unverified |
| cf-src | Confluence (test server) | tools | Storage or existing data connector | To be selected | Existing | Local source-contract runner generated; native vendor integration unverified |

### Resources and cost dimensions

- **Staff browser** (user): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Web app** (web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: user.
- **User sign-in** (cognito): aws_cognito_user_pool. Active users and authentication features. Depends on: web.
- **RAG API** (api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: cognito, web.
- **Keyword RAG function** (rag-fn): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: api.
- **Document catalog** (catalog): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: rag-fn, sp-src, cf-src.
- **Foundation model** (model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: rag-fn.
- **SharePoint (test server)** (sp-src): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Confluence (test server)** (cf-src): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

Generated configuration remains unverified. Validate every delivery unit, interface, destination input, cost and security boundary before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## Options and tradeoffs

Use Design → Options to compare cloud choices and record the rationale before choosing.

## Design checks and decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-07 · **Design:** r1 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS for this synthetic qualification design.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### EXAMPLE-REGION · cloud.region

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `cloud.region`

**Context**

Sydney is selected by the example author for this sample, not as approval for a client deployment.

**Options considered**

—

**Decision**

ap-southeast-2

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-COUNTRY · data.country

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `data.country`

**Context**

Example data location; source fixtures run locally. Production residency requires destination review.

**Options considered**

—

**Decision**

Australia

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-MODEL · model.bedrock

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `model.bedrock`

**Context**

Direct Nova Lite in Sydney. Published regional/Converse support reviewed; account access and quotas remain destination checks.

**Options considered**

—

**Decision**

amazon.nova-lite-v1:0

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-RETENTION · logs.retention

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `logs.retention`

**Context**

CloudWatch retention for this bounded example. Confirm real client policy before deployment.

**Options considered**

—

**Decision**

30 days

_Changed because: Prepared example configuration_

**Consequences**

—


### Design checks

- [open] No monitoring for model quality or drift.
  Rationale: Model answers and predictions degrade quietly; someone needs to see it happen.
  Next action: Add a monitoring block (quality, drift, cost) and decide who is alerted.
  Source: AtMem AI Architect rule REL-001 v1.0.0

- [open] No availability target.
  Rationale: Without one, nobody can say whether a single region or a single endpoint is enough.
  Next action: Add a requirement such as “available 99.5% of the time” or “business hours only”.
  Source: AtMem AI Architect rule AVL-001 v1.0.0

- [open] No response-time target.
  Rationale: Model size, retrieval depth and region all trade speed against cost.
  Next action: Add a requirement such as “responds within 5 seconds”.
  Source: AtMem AI Architect rule PRF-001 v1.0.0

- [open] Expected usage is unknown, so scale can't be assessed.
  Rationale: Usage drives capacity, limits and cost.
  Next action: Tell us in the chat roughly how many people use it and how often.
  Source: AtMem AI Architect rule SCL-001 v1.0.0

- [open] 3 quality requirements have no measurable target.
  Rationale: A target makes it testable and lets the review say met or not met.
  Next action: Add a metric and target to: “Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.”, “Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.”, “Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.”.
  Source: AtMem AI Architect rule MNT-001 v1.0.0

- [open] 1 accepted decision has no owner.
  Rationale: Someone must be accountable for each choice before build.
  Next action: Assign an owner in Design → Decisions.
  Source: AtMem AI Architect rule MNT-002 v1.0.0

- [open] 1 block is sketch-only and can't be test-run yet.
  Rationale: Sketch blocks describe intent; runnable fixtures exist only for some workflows.
  Next action: Keep designing; assign a runnable behaviour in block detail when one exists.
  Source: AtMem AI Architect rule DSN-001 v1.0.0

## Assumptions

- [example-usage] Monthly sample: 100 users, 10,000 answers, 2,000 input and 1,000 output tokens per answer, 256 MiB ARM Lambda for 5 seconds; no free-tier credits. (2026-11-15)
- [example-cost-scope] Incremental AWS costs only. Browser and existing normalized local source fixtures carry no new AWS resource cost. SaaS licenses, tax, support plans and labor are outside this sample. (2026-11-15)

## Questions to resolve

None recorded.


## Implementation specification and coding-agent handoff

The Spec Kit translates these requirements and the architecture into implementation work. Start with START_HERE.md and AGENTS.md; read spec-kit/implementation-spec.md (or PDF) for the implementation plan, contracts, detailed tasks and validation plan. Requirements remain the source of desired outcomes; the kit is the build plan derived from them.
