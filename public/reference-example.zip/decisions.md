Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-07 · **Design:** r1 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS for this synthetic qualification design.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### EXAMPLE-REGION · cloud.region

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `cloud.region`

**Context**

Sydney is selected by the example author for this sample, not as approval for a client deployment.

**Options considered**

—

**Decision**

ap-southeast-2

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-COUNTRY · data.country

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `data.country`

**Context**

Example data location; source fixtures run locally. Production residency requires destination review.

**Options considered**

—

**Decision**

Australia

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-MODEL · model.bedrock

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `model.bedrock`

**Context**

Direct Nova Lite in Sydney. Published regional/Converse support reviewed; account access and quotas remain destination checks.

**Options considered**

—

**Decision**

amazon.nova-lite-v1:0

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-RETENTION · logs.retention

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `logs.retention`

**Context**

CloudWatch retention for this bounded example. Confirm real client policy before deployment.

**Options considered**

—

**Decision**

30 days

_Changed because: Prepared example configuration_

**Consequences**

—
