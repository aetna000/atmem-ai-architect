# Prepared reference review

This package is ready for reference-example download, with the evidence limits below. The application, Terraform, tests, web assets and built Lambda ZIP were preserved. This review does not approve deployment or production use.

## Included deliverables

- `START_HERE.md` and `specification.md`: entry point, requirements and bounded example scope; `diagram.mmd`, architecture documents and `spec-kit/` retain design and engineering traceability.
- `terraform/main.tf.json`: generated AWS resources and review gate; provider lock, mock plans and sample variables accompany it.
- `terraform/handlers/`: bounded keyword retrieval, explicit identity/region ACL filtering, revision rechecks, cited answers and Bedrock adapter source.
- `terraform/web/`: browser application for Cognito authorization-code/PKCE sign-in and API interaction. `terraform/connectors/` contains normalized source synchronization and its contract; operator utilities cover catalog and user management.
- `terraform/app-tests/`, `evidence/*.log` and `evidence/qualification.json`: supplied local qualification records and test sources.
- `terraform/build/block_7261672d666e.zip`: prebuilt runtime with pinned SDK dependencies; `terraform/build/artifact-hashes.json`, runtime dependency locks and source metadata identify its inputs. `terraform/BUILD.md`, `WEB.md`, `CATALOG.md` and `connectors/CONTRACT.md` describe receiving workflows.
- `evidence/price-ledger.json` and eight compressed AWS price catalogs: illustrative pricing inputs with source URLs, dates, meters and hashes.

The ZIP SHA-256 recorded in the runtime manifest is `afff0e844f340e13560522184dbaed5398284a4cee932aa20cace7a9444fc710`. A local integrity comparison during this review matched that value; this was an integrity check, not runtime execution. Python 3.13/Linux ARM64 is the declared Lambda target. The build log records boto3/botocore 1.43.123 and the other locked dependencies; it does not establish live Lambda compatibility or account access.

## Previously executed qualification

All results in this table were recorded externally before this turn. I inspected the supplied logs; I did not rerun these tests, Terraform, the build or a browser.

| Evidence | Recorded result | Meaning and limit |
|---|---|---|
| `evidence/application-tests.log` | 13 passed, zero failures/errors | Eight RAG tests and five normalized-source contract tests, using mocked AWS clients and actual local HTTP source fixtures. Covers restricted evidence exclusion, unknown identities/body spoofing, abstention, fabricated citations, authorization expiry, repository failure, revocation during generation, duplicate IDs, permissions completeness, updates/deletes and partial-failure recovery. |
| `evidence/terraform-validate.log` | Configuration valid | Provider-schema validation recorded with Terraform 1.17.1 in qualification metadata. This is separate from account validation. |
| `evidence/terraform-mocks.log` | Two passed, zero failed | `generated_storage_plan` and `unapproved_plan_rejected`, using `mock_provider "aws"`; the latter expects the review gate to reject an unapproved plan. No account resources are exercised. |
| `evidence/terraform-init.log`, `evidence/build.log` | Initialization and ZIP build recorded | AWS provider 6.72.0 is recorded as installed “unauthenticated”; this is not a signature-verification claim. Build success is separate from functional acceptance. |

The supplied suite does not establish an actual browser journey, immediate interaction before configuration loads, delayed/failed initialization, reload/retry recovery, live Cognito MFA or deployed authorization. Those checks remain open. Python and SHA utilities initially attempted in this turn were unavailable; Ruby standard-library file hashing completed the inventory correction. No packages were installed and no network, AWS, deployment or agent delegation was used.

## Qualification inventory correction

The author clarified that the original `qualification.files` inventory preceded final documentation and pricing-default regeneration, while tested implementation hashes remained unchanged. This review narrowed the inventory from 82 to 39 original entries: implementation/build/test inputs under `terraform/`, evidence logs, price snapshots and the ledger. Every retained entry matched both its original byte count and SHA-256; no eligible entry mismatched. Design documents, Markdown runbooks, example defaults and design metadata were excluded. Existing hash values were preserved; changed documentation hashes were not regenerated as if qualified.

The added `filesScopeNote` explains that tests qualify implementation within their recorded local scope, not design documentation. Retaining price records establishes file identity only, not pricing accuracy. The new review and qualification-note edit are not covered by the historical test runs. Backend `project-context.json`, `.agents/`, `ATMEM_DELIVERY.md` and supplied helpers remain untouched.

## Illustrative AWS worksheet

The 22 ledger lines total approximately **USD 7.56/month** from quantity × unit price before rounding. The worksheet's 0.7–1.5 multipliers give approximately **USD 5.29–11.34/month**; they are illustrative sensitivity factors, not confidence bounds. The USD 20/month target belongs to the example author and is not a client-approved budget or spending cap.

Assumptions are 100 monthly active users, 10,000 answers, 2,000 input and 1,000 output tokens per answer, direct Nova Lite in Sydney, and 256 MiB ARM Lambda running five seconds per answer (12,500 GB-seconds). Additional quantities include 10 GB CloudFront egress, 1 GB-month of S3 assets/retained versions, 0.1 GB of DynamoDB storage/PITR, 1,050,000 read units, 10,000 write units, and 0.5 GB ingestion plus 0.5 GB-month storage for each API and Lambda log stream. Request quantities are itemized in the ledger. No free-tier allowance or credits are applied.

Prices are saved AWS Price List snapshots dated in the package for 2026-11-15 pricing review, not prices retrieved during this turn. Sydney pricing and Australia/global CloudFront meters are sample choices. Existing browsers and local source fixtures have zero incremental AWS lines. Real SaaS licenses, tax, support and labor are excluded. Actual token volumes, retries, storage versions, restoration, traffic and operating requirements can change costs; receiving engineers must reprice their approved destination and usage.

## Receiving checks and preserved uncertainty

The original brief treats Sydney as a candidate; later example-author defaults select `ap-southeast-2`, Australia, `amazon.nova-lite-v1:0` and 30-day logs for the sample. These defaults do not settle client region, residency, retention or model approval. Generic generated statements that no execution evidence exists describe the earlier design export; the supplied logs add the limited local evidence above. Open requirements, acceptance gates and destination tasks remain open.

For a fresh download, the documented local test command is `python3 -B scripts/check-example.py` with an independently supplied Python 3.13 interpreter; it uses the bundled ZIP without package installation. The HTTP fixture tests require a receiving environment permitting local loopback. Terraform rechecks require the locked AWS provider supplied through an approved offline mirror. If aliases are needed, the preserved `atmem-tools/prepare.py` accepts existing Python/Terraform paths and `--provider-mirror`; it installs nothing. Private worker paths in historical logs are provenance, not setup dependencies.

The current build script explicitly selects a public package index. Do not invoke it in an offline workflow expecting it to be self-contained. A clean offline rebuild requires an approved receiving wheelhouse matching `runtime-requirements.lock` and a reviewed build invocation using `--no-index --find-links` instead of the index, with hashes enforced. Such a rebuild was not performed here; the included prebuilt ZIP is the qualified reference artifact.

Real AWS account plans, Bedrock access/Converse/quotas, native SharePoint and Confluence adapters (including inherited/group permissions), browser acceptance, residency review, restore/rollback drills, operational ownership, availability/latency targets and live model-quality monitoring remain destination checks. Existing source systems and the model remain externally owned; Teams remains deferred.

For any later authorized release, retain the prior ZIP, Lambda version/alias and versioned web assets, review a rollback plan restoring the prior application/configuration, and verify compatibility with current catalog revisions and ACLs. Never roll back revoked permissions or bypass deletion protections. Catalog restoration and cleanup need separately reviewed procedures and destination tests. No rollback or cleanup was executed here.

Download the complete prepared directory with its ZIP, source, evidence and this review; begin receiving review with `START_HERE.md`. Agent completion is not independent acceptance.
