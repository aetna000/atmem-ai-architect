Snapshot a4c8e595-443e-46cc-9fe7-32a01c06b3e9 · design r2 · generated 2026-11-15T09:19:00.853Z

# AI knowledge assistant — complete example — deployment document

Generated 2026-11-15 09:19 UTC from design revision r2 · project format 2.3.0 · AtMem AI Architect workbench

> No blockers found by the automated review. Human review and the open questions below still apply.
>
> Statements are **facts** from project data unless marked _assumption_ or listed under open questions. Estimate — not a bill or guarantee.

## 1. Summary

Design an AWS knowledge assistant that reads approved documents from existing SharePoint and Confluence systems and provides cited answers through a web application, with Teams as a later channel. Preserve source permissions, updates and deletes. For this stage use the approved local normalized source-contract test servers and bounded keyword retrieval. Keep the requested web application as required scope; an HTTP API alone does not complete that channel. Treat those existing systems as external dependencies; include recovery and audit behavior without claiming native vendor API or real tenant compatibility. Use AWS for this synthetic qualification design. Propose Sydney as a candidate region, but do not record that as an approved deployment region. Draw the architecture and identify the next missing decision. This is a test design, not an instruction to deploy.

- **Cloud:** AWS
- **Usage:** 10,000 requests/month (entered)
- **Estimated run cost:** USD 7.56/month expected (USD 5.29–USD 11.34)
- **Review:** 7 open findings (0 blockers)
- **Current decisions:** 5

## 2. Scope and context

- **What you want to build:** Design an AWS knowledge assistant that reads approved documents from existing SharePoint and Confluence systems and provides cited answers through a web application, with Teams as a later channel. Preserve source permissions, updates and deletes. For this stage use the approved local normalized source-contract test servers and bounded keyword retrieval. Keep the requested web application as required scope; an HTTP API alone does not complete that channel. Treat those existing systems as external dependencies; include recovery and audit behavior without claiming native vendor API or real tenant compatibility. Use AWS for this synthetic qualification design. Propose Sydney as a candidate region, but do not record that as an approved deployment region. Draw the architecture and identify the next missing decision. This is a test design, not an instruction to deploy.
- **Information it uses:** Review this same architecture and its generated Terraform. Keep the original scenario scope and preserve valid component IDs and existing systems. Validation findings: [{"id":"application-not-qualified","owner":"application","message":"No executable application acceptance evidence for this artifact."},{"id":"provider-schema-unverified","owner":"validation","message":"Run provider-schema validation against this exact export."},{"id":"requirements-review-unverified","owner":"review","message":"Review requirements against emitted configuration, including identity, limits, region, costs and cleanup."}]. Correct architecture defects through a proposal where supported. For missing native resources, application code or integrations, explain the product implementation gap and next concrete engineering action; do not claim a diagram edit implemented it. Do not remove required components, weaken acceptance checks or clear unfinished-work gates to obtain a pass. Do not claim tests ran or request deployment. Identify what remains unverified.
- **Who uses it, and how much:** —
- **Systems it connects to:** —
- **How good, fast and safe:** —
- **Cloud preference:** AWS
- **Budget and timeline:** —

**Use cases considered**

- Signed-in browser answers with citations and source permissions — **Pursue**: Implemented by the generated web/API/catalog/model path; local tests cover cited answers and authorization.
- Local normalized source snapshots, updates and deletes — **Pursue**: The bundled contract fixtures qualify the normalized interface. Real Microsoft/Atlassian tenants are separate destination integration work.
- Native SharePoint and Confluence tenant adapters — **Park**: The original example explicitly uses approved normalized local test servers. No native tenant or permissions compatibility is claimed.
- Microsoft Teams channel — **Park**: Retained from the original deferred-channel note; not part of this example.

## 3. Architecture

**Integration**

- Staff browser (Tools & data, existing) — Staff member's browser. This is a client reference, not a provisioned service.
- RAG API (AWS) — Authenticated, bounded HTTP API with a JWT browser route. There is no anonymous access. Access logs support the audit trail.

**Delivery**

- Web app (AWS) — Browser channel (required scope). It owns private S3 assets and CloudFront access control, uses authorization code with PKCE, and shows answers with citations.

**Governance**

- User sign-in (AWS) — User pool with admin-created users, required software-token MFA, an access-token scope, and catalog-backed identity and employee-region mapping. Users are onboarded with the operator tool.

**Intelligence**

- Keyword RAG function (AWS) — Keyword retrieval with ACL and region filtering and revision rechecks, then a cited answer that is returned through the API. It owns its execution role, logs, version and alias. Unknown identities fail closed.
- Foundation model (AWS, existing) — Existing Bedrock direct model, selected by a required model-ID input. Model access, Converse support, quotas and regional availability are not yet verified.

**Document catalog**

- Document catalog (AWS, sketch) — Holds up to 100 small UTF-8 documents with explicit ACLs, revisions, tombstones for deletes and a sync checkpoint. Writes are conditional.

**Data**

- SharePoint (test server) (Tools & data, existing) — Existing SharePoint, represented here by the approved local normalized source-contract test server. It provides snapshots, ACLs, updates and deletes. The native API and real-tenant compatibility are not verified.
- Confluence (test server) (Tools & data, existing) — Existing Confluence, represented here by the approved local normalized source-contract test server. The native API and real-tenant compatibility are not verified.

**Infrastructure**

- Later: Microsoft Teams channel (Tools & data) — Teams is a deferred channel for a later phase. It is not part of this deployment.

```mermaid
flowchart LR
  n0["Staff browser<br/>Tools & data"]
  n1["Web app<br/>AWS"]
  n2["User sign-in<br/>AWS"]
  n3["RAG API<br/>AWS"]
  n4["Keyword RAG function<br/>AWS"]
  n5["Document catalog<br/>AWS"]
  n6["Foundation model<br/>AWS"]
  n7["SharePoint (test server)<br/>Tools & data"]
  n8["Confluence (test server)<br/>Tools & data"]
  n9["Later: Microsoft Teams channel<br/>Tools & data"]
  n0 -->|HTTPS| n1
  n1 -->|sign-in (PKCE + MFA)| n2
  n2 -->|JWT authorizer| n3
  n1 -->|question → cited answer| n3
  n3 -->|invoke| n4
  n4 -->|ACL-filtered keyword read| n5
  n4 -->|Converse (grounded prompt)| n6
  n7 -->|snapshot sync, ACLs, deletes| n5
  n8 -->|snapshot sync, ACLs, deletes| n5
```
## Cloud resource schedule

Diagram-derived resource schedule; service choices and resource types require engineering review.

| Block ID | Component | Provider | Service | Region | Ownership | Terraform coverage |
|---|---|---|---|---|---|---|
| user | Staff browser | tools | Approval workflow | To be selected | Existing | External browser — no infrastructure to provision; connection behavior still requires validation |
| web | Web app | aws | Amazon CloudFront | ap-southeast-2 | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| cognito | User sign-in | aws | Amazon Cognito | ap-southeast-2 | Proposed | Private web hosting and Cognito authorization-code/PKCE sign-in generated |
| api | RAG API | aws | Amazon API Gateway | ap-southeast-2 | Proposed | Bounded IAM-authenticated RAG implementation generated |
| rag-fn | Keyword RAG function | aws | AWS Lambda | ap-southeast-2 | Proposed | Bounded IAM-authenticated RAG implementation generated |
| catalog | Document catalog | aws | Amazon DynamoDB | ap-southeast-2 | Proposed | Bounded IAM-authenticated RAG implementation generated |
| model | Foundation model | aws | Amazon Bedrock | ap-southeast-2 | Existing | Bounded IAM-authenticated RAG implementation generated |
| sp-src | SharePoint (test server) | tools | Storage or existing data connector | To be selected | Existing | Local source-contract runner generated; native vendor integration unverified |
| cf-src | Confluence (test server) | tools | Storage or existing data connector | To be selected | Existing | Local source-contract runner generated; native vendor integration unverified |

### Resources and cost dimensions

- **Staff browser** (user): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Web app** (web): aws_cloudfront_distribution. Requests, transfer and private static assets. Depends on: user.
- **User sign-in** (cognito): aws_cognito_user_pool. Active users and authentication features. Depends on: web.
- **RAG API** (api): aws_apigatewayv2_api. API requests, transfer and access logs. Depends on: cognito, web.
- **Keyword RAG function** (rag-fn): aws_lambda_function, aws_iam_role. Requests, duration, memory and logs. Depends on: api.
- **Document catalog** (catalog): aws_dynamodb_table. Read/write requests, storage and backup. Depends on: rag-fn, sp-src, cf-src.
- **Foundation model** (model): Resource types to confirm. Model-specific input/output tokens; guardrails, embeddings and knowledge bases separately. Depends on: rag-fn.
- **SharePoint (test server)** (sp-src): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.
- **Confluence (test server)** (cf-src): Resource types to confirm. Confirm service, capacity and billable dimensions. Depends on: none drawn.

### Engineering work remaining

Generated configuration remains unverified. Validate every delivery unit, interface, destination input, cost and security boundary before applying.

References (resource semantics; not retrieved prices):
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrock_guardrail
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_knowledge_base
- https://aws.amazon.com/bedrock/pricing/


## 4. Data flows

| From | To | Data | Classification |
|---|---|---|---|
| Staff browser | Web app | HTTPS | Internal |
| Web app | User sign-in | sign-in (PKCE + MFA) | Confidential |
| User sign-in | RAG API | JWT authorizer | Confidential |
| Web app | RAG API | question → cited answer | Internal |
| RAG API | Keyword RAG function | invoke | Confidential |
| Keyword RAG function | Document catalog | ACL-filtered keyword read | Confidential |
| Keyword RAG function | Foundation model | Converse (grounded prompt) | Confidential |
| SharePoint (test server) | Document catalog | snapshot sync, ACLs, deletes | Confidential |
| Confluence (test server) | Document catalog | snapshot sync, ACLs, deletes | Confidential |

## 5. Security controls

- **Staff browser** — Staff member's browser. This is a client reference, not a provisioned service.
- **User sign-in** — User pool with admin-created users, required software-token MFA, an access-token scope, and catalog-backed identity and employee-region mapping. Users are onboarded with the operator tool.
- Requirement: Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed. (must)
- Requirement: Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed. (should)
- Requirement: Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally. (must)


## 6. Requirements

**Non-functional**

| Requirement | Category | Target | Status |
|---|---|---|---|
| Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed. | security | not measurable yet | Open |
| Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed. | compliance | not measurable yet | Open |
| Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally. | compliance | not measurable yet | Open |

**Functional**

- Every answer shows its sources (should, open)
- Source updates and deletes reach the catalog through conditional writes and a recovery checkpoint, and revisions are rechecked before an answer is returned. (must, open)

**Success measures**

_No success measures defined._


## 7. Review findings

**Reliability**

- [major] No monitoring for model quality or drift. Add a monitoring block (quality, drift, cost) and decide who is alerted. _(AtMem AI Architect rule REL-001 v1.0.0)_

**Availability**

- [minor] No availability target. Add a requirement such as “available 99.5% of the time” or “business hours only”. _(AtMem AI Architect rule AVL-001 v1.0.0)_

**Scalability**

- [info] Expected usage is unknown, so scale can't be assessed. Tell us in the chat roughly how many people use it and how often. _(AtMem AI Architect rule SCL-001 v1.0.0)_

**Performance**

- [minor] No response-time target. Add a requirement such as “responds within 5 seconds”. _(AtMem AI Architect rule PRF-001 v1.0.0)_

**Maintainability**

- [minor] 3 quality requirements have no measurable target. Add a metric and target to: “Answers may use only documents the signed-in user is allowed to open, based on explicit ACLs copied from the source snapshot. Unknown identities or missing ACLs fail closed.”, “Proposed: record who asked, which documents were cited and sync outcomes in logs with a retention period to be agreed.”, “Example application data, model processing and audit logs stay in the selected Australia/Sydney region; source fixtures run locally.”. _(AtMem AI Architect rule MNT-001 v1.0.0)_
- [minor] 1 accepted decision has no owner. Assign an owner in Design → Decisions. _(AtMem AI Architect rule MNT-002 v1.0.0)_
- [info] 1 block is sketch-only and can't be test-run yet. Keep designing; assign a runnable behaviour in block detail when one exists. _(AtMem AI Architect rule DSN-001 v1.0.0)_

## 8. Cost estimate

Estimate — not a bill or guarantee. Monthly run cost only. Prices are as entered, with their sources.

**Estimate stage:** Detailed worksheet. User-entered charge coverage; still needs engineering and pricing validation.

| Component | Driver | Quantity | Unit price | Monthly | Source |
|---|---|---|---|---|---|
| Staff browser | Existing staff browser | 1 existing reference | USD 0 / existing reference | USD 0 | Example scope: existing browser or local normalized source-contract fixture; no incremental AWS resource., 2026-11-15 |
| Web app | CloudFront Australia HTTPS requests | 10,000 Requests | USD 0.00000125 / Requests | USD 0.01 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCloudFront/current/index.json#XXEA4SCG9TSQCDF2, 2026-11-15 |
| Web app | CloudFront Australia internet egress (GB) | 10 GB | USD 0.114 / GB | USD 1.14 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCloudFront/current/index.json#8JNNPNBQD9DSHV5K, 2026-11-15 |
| Web app | S3 assets and all retained object versions (GB-month) | 1 GB-Mo | USD 0.025 / GB-Mo | USD 0.03 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/ap-southeast-2/index.json#5QVJMK36NJC9G6DC, 2026-11-15 |
| Web app | S3 asset uploads and listing requests | 1,000 Requests | USD 0.0000055 / Requests | USD 0.01 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/ap-southeast-2/index.json#U4DFWUZRRJK76GFK, 2026-11-15 |
| Web app | S3 origin GET requests | 10,000 Requests | USD 4.4e-7 / Requests | USD 0 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonS3/current/ap-southeast-2/index.json#ZE67FX933AEQ43H2, 2026-11-15 |
| User sign-in | Cognito Essentials monthly active users | 100 CognitoUserPoolsMAU | USD 0.015 / CognitoUserPoolsMAU | USD 1.5 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCognito/current/ap-southeast-2/index.json#JVU799QJR37664RR, 2026-11-15 |
| RAG API | HTTP API requests | 10,000 Requests | USD 0.00000129 / Requests | USD 0.01 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonApiGateway/current/ap-southeast-2/index.json#GHZQQPU8NMGFKBQZ, 2026-11-15 |
| RAG API | API access log ingestion (GB) | 0.5 GB | USD 0.67 / GB | USD 0.34 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCloudWatch/current/ap-southeast-2/index.json#VSJ57WXDQXM2VKQK, 2026-11-15 |
| RAG API | API access log storage (GB-month) | 0.5 GB-Mo | USD 0.033 / GB-Mo | USD 0.02 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCloudWatch/current/ap-southeast-2/index.json#SXS5MH23MB3SHA9C, 2026-11-15 |
| Keyword RAG function | Lambda requests | 10,000 Request | USD 2e-7 / Request | USD 0 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AWSLambda/current/ap-southeast-2/index.json#ZW6UHD4Q6EPUCZWU, 2026-11-15 |
| Keyword RAG function | Lambda ARM 256 MiB × 5 seconds × 10,000 answers | 12,500 Lambda-GB-Second | USD 0.0000133334 / Lambda-GB-Second | USD 0.17 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AWSLambda/current/ap-southeast-2/index.json#KDEJ26SV7QK2N7DW, 2026-11-15 |
| Keyword RAG function | Lambda log ingestion (GB) | 0.5 GB | USD 0.67 / GB | USD 0.34 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCloudWatch/current/ap-southeast-2/index.json#VSJ57WXDQXM2VKQK, 2026-11-15 |
| Keyword RAG function | Lambda log storage (GB-month) | 0.5 GB-Mo | USD 0.033 / GB-Mo | USD 0.02 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonCloudWatch/current/ap-southeast-2/index.json#SXS5MH23MB3SHA9C, 2026-11-15 |
| Document catalog | DynamoDB read request units; bounded scans and identity reads | 1,050,000 ReadRequestUnits | USD 1.425e-7 / ReadRequestUnits | USD 0.15 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonDynamoDB/current/ap-southeast-2/index.json#BQCZ4TYN2JVHEH4Z, 2026-11-15 |
| Document catalog | DynamoDB conditional write request units | 10,000 WriteRequestUnits | USD 7.1e-7 / WriteRequestUnits | USD 0.01 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonDynamoDB/current/ap-southeast-2/index.json#X43FXEDHFRVHHYQR, 2026-11-15 |
| Document catalog | DynamoDB standard storage; free allowance assumed consumed | 0.1 GB-Mo | USD 0.285 / GB-Mo | USD 0.03 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonDynamoDB/current/ap-southeast-2/index.json#NF4X2QKU7Y7QVY5C, 2026-11-15 |
| Document catalog | DynamoDB point-in-time recovery storage (GB-month) | 0.1 GB-Mo | USD 0.228 / GB-Mo | USD 0.02 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonDynamoDB/current/ap-southeast-2/index.json#KHP6CW3RY2FP49W3, 2026-11-15 |
| Foundation model | Nova Lite input tokens (1,000-token units) | 20,000 1K tokens | USD 0.000063 / 1K tokens | USD 1.26 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonBedrock/current/ap-southeast-2/index.json#VE26ZEBZ95PNKV6H, 2026-11-15 |
| Foundation model | Nova Lite output tokens (1,000-token units) | 10,000 1K tokens | USD 0.000252 / 1K tokens | USD 2.52 | https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonBedrock/current/ap-southeast-2/index.json#8QD3UNYB3WE6E2YA, 2026-11-15 |
| SharePoint (test server) | Existing local SharePoint contract fixture | 1 existing reference | USD 0 / existing reference | USD 0 | Example scope: existing browser or local normalized source-contract fixture; no incremental AWS resource., 2026-11-15 |
| Confluence (test server) | Existing local Confluence contract fixture | 1 existing reference | USD 0 / existing reference | USD 0 | Example scope: existing browser or local normalized source-contract fixture; no incremental AWS resource., 2026-11-15 |

**Usage inputs:** Quantities are entered directly on detailed charge lines above.

**Range:** low ×0.7, high ×1.5 of expected. Budget stated: USD 20/month — within budget.

**Estimate gaps:**

No worksheet gaps detected; validate dimensions, quotations and assumptions before treating this as a full estimate.

### Consulting and build estimate (one-off)

Not estimated; enter work-package days, rates and a basis.

| Work package | Low / expected / high days | Rate / day | Expected | Basis and exclusions |
|---|---|---|---|---|
| Discovery & specification | — / — / — | — | — | Needed |
| Architecture & security | — / — / — | — | — | Needed |
| Implementation & integration | — / — / — | — | — | Needed |
| Testing & acceptance | — / — / — | — | — | Needed |
| Deployment & handover | — / — / — | — | — | Needed |

One-off effort is separate from monthly cloud charges. Days are person-days, not elapsed time. Taxes, support, licences and migration are excluded unless explicitly included in the basis or charge lines.

## 9. Deployment steps

_Draft generated from the design; validate against the provider's current documentation before use. Nothing has been provisioned._

1. Confirm accounts, target regions and who approves each step; resolve every blocker in this document.
2. Create least-privilege identities for each component; keep credentials in the provider's secret store, never in the project.
3. Provision integration: RAG API.
4. Provision infrastructure: Later: Microsoft Teams channel.
5. Provision delivery: Web app.
6. Provision governance: User sign-in.
7. Provision intelligence: Keyword RAG function.
8. Provision document catalog: Document catalog.
9. Connect existing systems: Staff browser, Foundation model, SharePoint (test server), Confluence (test server); test failure behaviour.
10. Run the acceptance checks (success measures and requirements) in staging; record results.
11. Review results and approve promotion to production; keep a rollback plan for each step.

## 10. Decisions

### ADR-001 · platform.cloud

**Status:** Accepted · **Owner:** unassigned · **Date:** 2026-11-07 · **Design:** r1 · **Subject:** `platform.cloud`

**Context**

User statement: Use AWS for this synthetic qualification design.

**Options considered**

—

**Decision**

aws

_Changed because: Chosen in the conversation_

**Consequences**

—

### EXAMPLE-REGION · cloud.region

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `cloud.region`

**Context**

Sydney is selected by the example author for this sample, not as approval for a client deployment.

**Options considered**

—

**Decision**

ap-southeast-2

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-COUNTRY · data.country

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `data.country`

**Context**

Example data location; source fixtures run locally. Production residency requires destination review.

**Options considered**

—

**Decision**

Australia

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-MODEL · model.bedrock

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `model.bedrock`

**Context**

Direct Nova Lite in Sydney. Published regional/Converse support reviewed; account access and quotas remain destination checks.

**Options considered**

—

**Decision**

amazon.nova-lite-v1:0

_Changed because: Prepared example configuration_

**Consequences**

—

### EXAMPLE-RETENTION · logs.retention

**Status:** Accepted · **Owner:** AtMem example defaults · **Date:** 2026-11-15 · **Design:** r1 · **Subject:** `logs.retention`

**Context**

CloudWatch retention for this bounded example. Confirm real client policy before deployment.

**Options considered**

—

**Decision**

30 days

_Changed because: Prepared example configuration_

**Consequences**

—

## 11. Assumptions

- _Assumption:_ Monthly sample: 100 users, 10,000 answers, 2,000 input and 1,000 output tokens per answer, 256 MiB ARM Lambda for 5 seconds; no free-tier credits. _(stated 2026-11-15)_
- _Assumption:_ Incremental AWS costs only. Browser and existing normalized local source fixtures carry no new AWS resource cost. SaaS licenses, tax, support plans and labor are outside this sample. _(stated 2026-11-15)_


## 12. Open questions

- Who will use this system? _(discovery)_
